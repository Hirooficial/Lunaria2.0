# Lunaria — geração de imagem e bloqueio por senha (guia da 1.1.12)

> Versão desta entrega: **1.1.12**. As duas novidades (gerar imagem e bloquear com
> senha) entraram na 1.1.0/1.1.1 e não mudaram de propósito desde então. O que
> mudou nesta versão foi a **proteção dos dados**: o texto das conversas e a
> memória de pesquisa passaram a ser cifrados no disco (antes só as imagens eram).
> O detalhe honesto está na **seção 4**, incluindo o que ainda **não** foi medido
> no aparelho.

Guia curto do que fazer no aparelho. Tudo aqui é em português, dentro do
aplicativo, e não depende de conta paga.

---

## 1. Gerar uma imagem

1. Abra uma conversa.
2. Toque em **Imagem** (na fileira de botões, ao lado de Pesquisa/Fatos) ou em
   **Gerar imagem** no menu do clipe (^).
3. Escreva a cena em **“O que mostrar”**. Exemplos já prontos aparecem abaixo da
   caixa — toque para usar.
4. Escolha a **proporção**: retrato 2:3, vertical 4:5, quadrado 1:1, paisagem
   3:2 ou cinema 16:9.
5. Escolha o **estilo**: gótico, sombrio, fantasia, anime, fotografia,
   ilustração, moda ou romântico. Cada estilo mostra na tela o que ele faz bem e
   onde costuma errar.
6. Se for imagem da própria Lunaria, deixe marcado **“Incluir a aparência da
   Lunaria”** e ajuste o perfil no ícone de pessoa (canto superior direito):
   aparência adulta, cabelo, olhos, roupas, acessórios e extras.
7. Abra **“Descrição final enviada ao provedor”** para ver exatamente o texto que
   sai do aparelho — e nada além dele. É esse texto que vai para o serviço.
8. Toque em **Gerar imagem**.
9. Acompanhe o estado: *preparando* → *na fila (com a posição)* → *gerando* →
   *pronto*. O tempo decorrido aparece sempre.
   - **Cancelar geração**: interrompe e avisa o servidor para descartar o pedido.
   - **Voltar** e editar a descrição: permitido a qualquer momento antes de gerar.
   - Deu erro? **Tentar novamente** repete o mesmo pedido.
10. Quando a imagem ficar pronta: **Usar na conversa** (ela entra como sua
    mensagem, com a descrição) ou **Gerar outra** (variação) e **Salvar na
    galeria**.
11. Na conversa, toque na imagem para abrir o visualizador: **pinça** para
    ampliar, **dois toques** para alternar o zoom, **arrastar** quando ampliada,
    além de **salvar**, **compartilhar** e **apagar**.

### O que pode e o que não pode

Permitido: personagem **adulta**, sensualidade **não explícita**, moda
alternativa, cenas românticas, terror, fantasia, violência estilizada de ficção.

Não é gerado: **nudez sexual explícita**, **atos sexuais**, qualquer coisa com
**menores**, coerção/violência sexual e conteúdo proibido por lei. A checagem
acontece **antes** de o pedido sair do aparelho — a descrição bloqueada nem
chega ao provedor, e a tela explica o motivo para você reescrever.

### Perfil visual da Lunaria e o limite honesto

O perfil (aparência adulta, cabelo, olhos, roupas, acessórios) é usado quando
você pede a Lunaria na imagem. **O modelo não memoriza o rosto dela entre
gerações**: com a mesma descrição e a mesma semente o resultado tende a ficar
parecido; sem isso, sempre varia um pouco. Quem promete rosto idêntico entre
imagens está exagerando o que o serviço faz.

---

## 2. Provedores: limites reais dos gratuitos

A tela de geração e **Configurações → Imagem** mostram isto também dentro do app.

### AI Horde (imagem) — vem escolhido

- **Gratuito, sem cadastro.** Usa a mesma chave anônima `0000000000` que a
  Lunaria já usava para texto.
- É uma **rede comunitária**: quem gera são voluntários com GPU. Se ninguém
  estiver online, o pedido espera. A tela mostra a posição na fila e a espera
  estimada.
- Conta anônima tem a menor prioridade. Uma chave pessoal gratuita
  (aihorde.net/register) melhora a fila — cole no campo opcional.
- Neste projeto, uma imagem 512×768 levou cerca de **25 segundos**, incluindo a
  fila.
- Muitos nós aceitam conteúdo adulto, mas **alguns recusam** — se falhar, tente
  de novo (a Lunaria sorteia outro voluntário).
- A imagem volta em base64 dentro da resposta (WebP).

### Pollinations — alternativa

- **Sem chave e sem cadastro**: a imagem volta direto, em ~2 segundos.
- Nível anônimo: **1 pedido a cada 15 segundos** (a Lunaria avisa em português
  quando o limite bate).
- Imagens do nível anônimo **podem sair com marca d'água**; um cadastro gratuito
  em auth.pollinations.ai aumenta o limite e tira a marca.
- Tem filtro de segurança próprio, além do filtro da Lunaria.

### Provedores pagos

**Desativados por padrão.** A tela só oferece os dois gratuitos. Não existe
cobrança, cartão ou assinatura em nenhum caminho desta versão.

### Por que a geração é remota (e não no aparelho)

O Galaxy A05s tem 6 GB de RAM e a geração local de imagem exige de 2 a 4 GB só
para o modelo, além de minutos por imagem e bateria. Por isso a geração é
remota: o aparelho só monta o texto, recebe a imagem e cifra o arquivo — sem
consumir memória do modelo local nem competir com o GGUF da conversa.

---

## 3. Bloqueio por senha

### Ativar

**Configurações (drawer) → Proteção por senha**:

1. Escreva uma senha ou PIN com **no mínimo 6 dígitos** e repita.
2. Marque **“Permitir digital/rosto além da senha”** se quiser biometria
   (a senha continua valendo como alternativa segura).
3. Toque em **Ativar bloqueio**.

Guarde a senha: **a Lunaria não guarda a senha em lugar nenhum** — nem em texto
puro, nem em cópia de segurança. Ela serve para derivar a chave que cifra suas
imagens.

### Como se comporta

- Pede a senha **ao abrir o aplicativo** e **ao voltar do segundo plano**, depois
  do intervalo escolhido: imediatamente ao sair, 1 min, 5 min, 15 min ou 1 hora.
- **Bloquear agora**: bloqueia na hora e já corta a leitura em voz alta e o
  microfone do ditado.
- Enquanto bloqueado, **nenhuma tela existe por baixo** — conversas, imagens e
  ajustes não são montados antes da autenticação (nem quando o aplicativo é
  aberto por uma notificação: a conversa só abre depois do desbloqueio).
- **Esconder conteúdo das notificações e da prévia de aplicativos recentes**:
  ligado por padrão com o bloqueio. A notificação passa a dizer apenas “Conteúdo
  protegido”.
- **Impedir capturas de tela**: a tela fica preta em prints e gravações. Ligada
  automaticamente enquanto o aplicativo está bloqueado.
- **Senha errada**: a partir da terceira tentativa há espera progressiva (1 s,
  2 s, 4 s… até 5 minutos). **Nada é apagado automaticamente**, nunca, em
  nenhuma quantidade de erros.
- **Trocar senha**: em Configurações → Proteção por senha (exige a senha atual).
  Suas imagens continuam abrindo: a chave do cofre não muda.
- **Desativar**: exige a senha atual. As imagens continuam cifradas no aparelho,
  apenas sem pedir senha para abrir.

### Esqueceu a senha

A chave é **derivada** da senha; sem ela, as imagens guardadas dentro da Lunaria
não podem ser abertas — não existe recuperação, e a Lunaria explica isso antes
de qualquer coisa. O que dá para fazer, com confirmação explícita:

- apagar o cofre (as imagens geradas guardadas no aplicativo) e voltar a usar sem
  senha. **Conversas, personagem, ajustes e memória continuam intactos.** Imagens
  que você já salvou na galeria não são afetadas.

---

## 4. O que a proteção da Lunaria cobre — e o que ela não cobre

Esta seção existe porque "protegido" sem escopo não significa nada. Ela vale para a
versão desta entrega, e é escrita a partir do que está **de fato** no código.

### O que está protegido

| item | como |
| --- | --- |
| **Imagens geradas** | gravadas **cifradas** em `document/private/`, no formato `.lunaenc` (AES-256-GCM, envelope `iv‖ct+tag`). O arquivo em claro só existe por instantes, no cache, para a imagem aparecer na tela |
| **A chave** | a chave de dados (DEK) é aleatória; ela é envelopada com a chave derivada da sua senha (PBKDF2-SHA256, 150 mil iterações). O envelope fica no **armazenamento seguro do sistema** (`expo-secure-store`, apoiado no Android Keystore) |
| **A senha** | **não é guardada** — nem em texto puro, nem cifrada, nem em cópia de segurança, nem no código-fonte, nem nos relatórios de diagnóstico. Ela só existe para derivar a chave |
| **Antes de desbloquear** | nenhuma tela de conversa, imagem ou ajuste é montada: não há conteúdo por baixo da tela de desbloqueio, nem quando o aplicativo é aberto por notificação ou link |
| **Notificações e prévia de recentes** | com o bloqueio ligado, o conteúdo é escondido (a notificação diz "Conteúdo protegido") |
| **Capturas de tela** | opcional (ligado por padrão enquanto bloqueado): a tela sai preta em prints e gravações |
| **Cópias de segurança do Android** | desligadas para o aplicativo (`allowBackup=false`): o sistema não leva para a nuvem as conversas nem as imagens |
| **O texto das conversas** | a partir da 1.1.12, o texto das mensagens é gravado **cifrado** no banco (AES-256-GCM, com a mesma chave do cofre, envelope `iv‖ct+tag` e contexto próprio: um texto cifrado não pode ser trocado de lugar com uma imagem cifrada). O que está no disco é `enc:v1:<base64>`, não a sua frase |
| **A memória de pesquisa** | também cifrada, no mesmo formato, com a mesma chave do cofre |
| **Os ajustes do aplicativo** | ficam **em claro** de propósito: são lidos nos primeiros instantes da abertura, **antes** do desbloqueio. Cifrá-los faria a leitura falhar no arranque — trocar privacidade por um defeito de abertura. Eles não contêm conversa (modo do aplicativo, modelo local, endereço de API, filtros de texto) |

### O que **não** está protegido (limites reais)

| limite | por quê |
| --- | --- |
| **A cifra do texto ainda não foi vista funcionando no aparelho** | o que está provado hoje é o que os testes automatizados mostram: a coluna do banco grava `enc:v1:…` e lê de volta igual, conversa antiga (em claro) continua legível, sem o cofre aberto a leitura **não** estoura e **não** apaga nada, e a busca continua achando o que achava. O que falta: abrir o banco no A05s e confirmar, com os próprios olhos, que não há frase legível lá dentro (item 26 do `CHECKLIST_APARELHO.md`) |
| **Metadados dos anexos** | nome, tipo e tamanho do anexo ficam em claro no banco (o **conteúdo** continua cifrado em `document/private/`). É ficha técnica do arquivo, não o texto da conversa |
| **A chave fica na memória enquanto está desbloqueado** | é o que permite ler e gravar sem pedir a senha a cada mensagem. Ao bloquear, a chave sai da memória. Quem tem root no aparelho, com o aplicativo aberto, pode alcançá-la |
| **A busca de mensagens tem teto de varredura** | a busca passou a acontecer em JavaScript (o `LIKE` do SQL não acharia nada dentro do texto cifrado — falharia **em silêncio**). Em troca, ela percorre no máximo 5000 mensagens do personagem, das mais antigas para as mais novas; em conversa gigante, o resultado é o que foi achado até ali |
| **Aparelho com acesso de root ou comprometido** | quem tem root lê a pasta privada e pode atacar o armazenamento seguro do sistema. Nenhum aplicativo se protege disso sozinho |
| **Enquanto está desbloqueado e aberto** | quem estiver com o seu celular na mão vê o que está na tela. O bloqueio é uma porta, não uma proteção por mensagem |
| **O que saiu do aplicativo** | ao exportar para a galeria, compartilhar ou copiar, aquela cópia **perde** a proteção da Lunaria: passa a depender do aplicativo de destino. O aviso aparece na tela antes de exportar |
| **Outra câmera apontada para a tela** | bloquear captura de tela impede print, não impede foto de outro celular |
| **O provedor de imagem** | a descrição enviada passa por servidor de terceiros (AI Horde ou Pollinations) e pode ser registrada lá. Não mande o que não quer que saia do aparelho |

### O que ainda não foi verificado no aparelho

O comportamento desta proteção no Galaxy A05s (keychain do sistema, biometria,
bloqueio de captura, cifra das imagens, abertura das telas) é exatamente o que os
itens do `CHECKLIST_APARELHO.md` verificam. **Nada nesta seção foi medido no
aparelho** — o que está escrito aqui é o que o código faz, não o que já se viu
funcionando no seu celular.

---

## 5. Arquivos desta entrega

- `Lunaria-1.1.12-arm64-release.apk` — instale **por cima** de qualquer versão
  anterior (mesma assinatura desde a 1.0.0, sem desinstalar; conversas e ajustes
  permanecem).
- `Lunaria-1.1.12-source.zip` — código-fonte completo, sem chaves privadas.
- `INSTALACAO_E_CONFIGURACAO.md` — instalação e primeiros passos.
- `GERACAO_DE_IMAGEM_E_BLOQUEIO.md` — este guia.
- `RELATORIO_DE_TESTES.md` — o que foi testado de verdade e o que depende do
  aparelho (a versão detalhada, `TEST_REPORT.md`, vai dentro do ZIP do código).

---

> **Nota da 1.1.13 (20/09/2026).** O corte da leitura em voz alta ao bloquear continua
> igual para você: a voz para no mesmo instante. O que mudou foi **como** o bloqueio
> avisa a leitura: antes ele importava o módulo do TTS diretamente, e isso criava o
> ciclo de importação que derrubava o aplicativo na abertura (o relato está em
> `BUGS_FOUND.md` §BG). Agora o aviso passa por
> `lib/state/EventosBloqueio.ts`, um arquivo sem importações. Há um teste
> (`tests/render/bloqueio-silencia.test.ts`) que prova que o efeito é o mesmo.
