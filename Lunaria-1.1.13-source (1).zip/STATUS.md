# Estado da entrega — Lunaria

> **Leia primeiro (rodada atual, 19/09/2026 · versão 1.1.7)**
> A rodada anterior fechou a classe do defeito no JavaScript (o porteiro de
> entrada). Esta fecha o ponto cego que restava — e descobre algo incômodo: **a
> captura de falha nativa já existia, mas gravava a prova na pasta privada do
> aplicativo**, inalcançável para quem só tem o celular. Se o aplicativo fechasse
> sempre, a causa ficava gravada, correta e **inutilizável**, dentro do aparelho.
>
> Agora o registro também sai na pasta **Downloads** (`lunaria-ultimo-erro.txt`),
> que o Hamura abre pelo celular e me envia sem computador. E as mortes que **não**
> geram exceção (falha nativa, travamento, memória) passam a ser lidas do histórico
> do próprio Android na abertura seguinte.
> Registro completo: `BUGS_FOUND.md` §AU; a rodada está no fim deste arquivo.
> Ressalva honesta: continua **não provado** que o aplicativo abre no A05s. A
> diferença é que, se ainda fechar, agora existe um arquivo com o motivo.
> As seções abaixo, mais antigas, ficam como histórico — não foram reescritas.

## Resultado desta rodada (18/09 · 1.1.0 — histórico)

| Item | Situação |
| --- | --- |
| Versão comparada com o ZIP “Lunaria2.0” | **Idêntica** — o ZIP publicado é o mesmo arquivo da entrega anterior (sha256 `c5ea31ed…`); o código local era o mais novo |
| Geração de imagem (2 provedores gratuitos) | **Implementada e verificada contra os serviços reais** |
| Bloqueio por senha/PIN + biometria | **Implementado**; regras puras testadas, comportamento de tela depende do aparelho |
| Cifragem das imagens privadas | **Implementada** (AES-256-GCM, chave no Keystore do Android) |
| Migração de imagens antigas em claro | **Implementada e testada** (planejamento); execução real depende do aparelho com dados |
| Bloqueio de cópia de segurança do Android | **Ativado** (`allowBackup=false` + regras de exclusão) |
| Testes automatizados | **87 de 87** passaram (26 anteriores + 61 da rodada 2, reescritos e remedidos após o incidente de 18/09) |
| TypeScript | `npx tsc --noEmit` sem erros |
| ESLint | `eslint .` sem erros (apenas avisos de estilo pré-existentes) |
| APK arm64 de release | **Compilado e assinado** com a mesma chave da versão anterior (atualiza por cima sem desinstalar) |
| Geração de imagem no aparelho | **Pendente** — este ambiente não tem aparelho nem emulador (sem `/dev/kvm`) |
| Bloqueio (tela, biometria, notificação, segundo plano) no aparelho | **Pendente** — mesma limitação |

## O que entrou nesta rodada

### 1. Geração de imagem

- Botão **“Gerar imagem”** na conversa (barra de botões e menu do clipe) → tela
  de geração com: descrição editável, sugestões de exemplo, **proporção**
  (retrato 2:3, vertical 4:5, quadrado 1:1, paisagem 3:2, cinema 16:9) e **8
  estilos** — gótico, sombrio, fantasia, anime, fotografia, ilustração, moda e
  romântico.
- **Perfil visual da Lunaria editável** (aparência adulta, cabelo, olhos, roupas,
  acessórios, extras), salvo no aparelho, usado quando o pedido é sobre ela, com
  aviso explícito do limite real de consistência (o modelo não memoriza rosto
  entre gerações; semente fixa + mesma descrição ≈ parecido).
- **Prévia da descrição final** antes de enviar: o texto exato em inglês que sai
  do aparelho, o prompt negativo e a decisão sobre o perfil.
- **Estados reais**: preparando → enfileirado (posição na fila e espera estimada
  na AI Horde) → gerando → concluído/erro/cancelado, com tempo decorrido, modelo
  usado, **cancelar**, **editar** e **tentar novamente**.
- A imagem aparece **na conversa** (como mensagem do usuário com a descrição) e
  abre no visualizador com **zoom por pinça e toque duplo**, **salvar**,
  **compartilhar** e **apagar**.
- Política de conteúdo rodando **antes de qualquer chamada de rede**: permite
  personagem adulta, sensualidade não explícita, moda alternativa e romance;
  recusa nudez sexual explícita, atos sexuais, menores de idade, coerção e
  conteúdo proibido em qualquer hipótese.

### 2. Provedores (gratuitos, documentados, reais)

| Provedor | Cadastro | Limite conhecido | Verificado |
| --- | --- | --- | --- |
| **AI Horde (imagem)** — padrão | Não (chave anônima `0000000000`); chave pessoal gratuita aumenta prioridade | Rede comunitária: fila depende de quem estiver online; 512×768 levou ~25 s no teste | `POST /generate/async` → id, fila, `generations[0].img` em base64 (WebP), `censored:false` |
| **Pollinations** | Não (nível anônimo) | Nível anônimo: 1 pedido a cada 15 s; pode marcar d'água | JPEG 512×768 em ~2,0 s, sem chave |

Provedores **pagos ficam desativados por padrão** — a tela só oferece os dois
gratuitos acima. A chave pessoal da Horde, se o usuário colar, fica só no
aparelho, nunca em log nem no código.

### 3. Bloqueio por senha

- Senha ou PIN com **mínimo de 6 dígitos/caracteres**; **biometria opcional**
  (com a senha sempre como alternativa segura).
- Pede autenticação **ao abrir** e **na volta do segundo plano**, conforme
  intervalo configurável (imediatamente, 1, 5, 15 min ou 1 h) e botão
  **“Bloquear agora”**.
- Enquanto bloqueado, **nenhuma outra tela é montada**: a tela de bloqueio
  substitui toda a navegação, então não existe um quadro de conversa ou imagem
  antes do desbloqueio. Notificação com “abrir conversa” fica **pendente** e só
  executa depois do desbloqueio.
- **Espera progressiva** nas tentativas erradas (1 s na 3ª, dobrando até 5 min).
  **Nada é apagado automaticamente** — nunca.
- Esconder conteúdo nas notificações e na prévia de aplicativos recentes;
  opção de **impedir captura de tela** (aplicada automaticamente enquanto
  bloqueado).
- Ao bloquear: leitura em voz alta é interrompida, o microfone é abortado, a
  chave sai da memória e as cópias decifradas temporárias são apagadas.
- Ativar, alterar e desativar exigem autenticação. “Esqueci a senha” explica a
  consequência e **só apaga o cofre com confirmação** (conversas, personagem e
  ajustes permanecem).

### 4. Proteção de dados

- Imagens geradas: **AES-256-GCM** (`@noble/ciphers`), chave de 32 bytes aleatória
  que **nunca** é gravada em claro — embrulhada pela senha (PBKDF2-HMAC-SHA256,
  150.000 iterações) e guardada no `expo-secure-store` (Android Keystore). Sem
  senha configurada, a chave fica só no Keystore, para que as imagens continuem
  cifradas em repouso.
- Arquivos cifrados em `documentos/private/`, nome aleatório, extensão
  `.lunaenc`; a senha em si nunca é armazenada, nem em log.
- Cópia de segurança do Android **desativada** para os dados do aplicativo
  (`allowBackup=false` + `data_extraction_rules.xml`):
  conversas, imagens e chave não saem do aparelho em backup automático.
- Exportar para a galeria ou compartilhar avisa, **antes**, que a cópia de fora
  perde a proteção da Lunaria.
- Migração: imagens antigas guardadas em claro em `Attachments/` entram no cofre
  cifrado na primeira abertura, com verificação de leitura do arquivo cifrado
  **antes** de apagar o original. É idempotente e retomável.

## Robustez de execução (decisões de raiz)

- **Nada de globais que talvez não existam**: o Hermes não garante `btoa`,
  `atob`, `TextEncoder` nem `TextDecoder`. O codec de base64 e a conversão UTF-8
  são próprios (`lib/utils/Binary.ts`), testados com acentos, emoji e tamanhos
  que não são múltiplos de 3.
- **Aleatoriedade nunca improvisada**: usa `crypto.getRandomValues` quando
  existe e, senão, o gerador do `expo-crypto` (sistema); se nenhum existir, o
  aplicativo **falha com mensagem clara** em vez de usar `Math.random`.
- **Sem cópias em claro desnecessárias**: imagem gerada não é duplicada em
  `Attachments/`; a conversa guarda `private://nome` e o arquivo segue cifrado.
- **Cópia de segurança desligada** no manifesto, com regras explícitas de
  exclusão para nuvem e transferência.

## Evidências do build (1.1.0)

```
BUILD SUCCESSFUL in 1m 20s
929 actionable tasks: 77 executed, 852 up-to-date
app-release.apk — 60.463.298 bytes
pacote br.aurora.luna.lunaria.next · versão 1.1.0 (versionCode 2)
minSdk 24 · targetSdk 36 · ABI arm64-v8a · 48 bibliotecas nativas
assinatura: CN=Lunaria, digest SHA-256 c0271509…5719a
  → MESMO certificado da 1.0.0: atualiza por cima sem desinstalar
manifesto: READ_MEDIA_IMAGES presente · allowBackup=false ·
  fullBackupContent=false · dataExtractionRules aplicado
assets: index.android.bundle (Hermes, 6.442.212 bytes) · res/RT.gguf
módulos novos confirmados no dex: ScreenCapture, SecureStore,
  MediaLibrary, Sharing, LocalAuthentication
SHA-256 do APK: 6bcbede3ae8a2bf40aebc5f3549062a2ebe5dfd749ce3cf96a2559e2d1236608
```

O build precisou de três tentativas nesta máquina de 2 núcleos e 1,9 GB de RAM:
a primeira morreu com o daemon do Gradle derrubado por falta de memória
(compilando `llama.cpp`), a segunda estourou **Metaspace** no
`lintVitalAnalyzeRelease` de um módulo de biblioteca, e a terceira passou com
`CMAKE_BUILD_PARALLEL_LEVEL=2`, espaço de metadados de 512 MB e o lint de
bibliotecas desativado (`android/build.gradle`, com o motivo comentado no
arquivo — não afeta o APK, é análise estática). As tarefas nativas já compiladas
foram reaproveitadas. Detalhe completo em `BUGS_FOUND.md` e `BUILDING.md`.

## Verificação real feita aqui

```
node --import tsx --test tests/*.test.mjs
# tests 87 · pass 87 · fail 0
#   crypto 9 · imagepolicy 8 · imageprompt 10 · imageprovider 12 · lock 9
#   + 26 anteriores (persona, pesquisa, streaming, persona-guard)
npx tsc --noEmit          → sem erros
npx eslint .              → 0 erros (38 avisos de estilo)
```

Chamadas reais aos provedores (fora do aplicativo, com os mesmos parâmetros):
AI Horde devolveu imagem WebP 512×768 em ~25 s (fila incluída) com a chave
anônima; Pollinations devolveu JPEG 512×768 em ~2,0 s sem chave.

## O que **não** foi verificado (fica registrado como pendente)

- Instalar e usar no Galaxy A05s: gerar imagem de verdade pelo aplicativo,
  cancelar no meio, salvar na galeria, apagar, e a tela de bloqueio na prática
  (senha errada, reinício, volta do segundo plano, abrir por notificação,
  biometria, troca de senha, migração de dados antigos).
- Custo real do PBKDF2 (150.000 iterações) no A05s: no desktop ficou em ~360 ms;
  num aparelho modesto espera-se algo entre 0,5 s e 1,5 s. Se ficar pesado, o
  valor está isolado em `lib/security/Crypto.ts` (`PBKDF2_ITERATIONS`).
- Impressão da tela preta com `preventScreenCaptureAsync` depende do aparelho.

## Limitação deste ambiente (a mesma da rodada anterior)

Sem aparelho Android, sem emulador e sem `/dev/kvm`; o APK é arm64 e o host é
x86_64. O aplicativo **não roda** aqui. Por isso todo o comportamento de tela
descrito acima está implementado e testado na parte pura, mas marcado como
pendente de confirmação no aparelho.

## Resultado do build e da entrega (18/09/2026)

O APK 1.1.0 existe e está assinado. A cadeia inteira está registrada em
`BUGS_FOUND.md`, seções D–K, porque o caminho até aqui teve sete tentativas:

- **nº 4** — o kernel matou o daemon do Gradle (`OOM killer`) porque o daemon do
  Kotlin herdava `-Xmx2560m`; corrigido com `kotlin.daemon.jvmargs=-Xmx1024m`.
- **nº 5** — falhou em 43 s porque eu havia apagado o NDK 27.0.12077973 por
  engano (o projeto precisa dos dois NDKs); reinstalado.
- **nº 6** — disco cheio (`No space left on device`); liberado espaço e
  devolvido o swap extra, que era desnecessário depois do teto do Kotlin.
- **nº 7** — sucesso.

```
> Task :app:minifyReleaseWithR8
BUILD SUCCESSFUL in 3m 17s
929 actionable tasks: 120 executed, 809 up-to-date
--- exit=0 Fri Sep 18 13:49:28 UTC 2026 ---
```

APK arm64-v8a de **60.463.298 bytes**, SHA-256
`6bcbede3ae8a2bf40aebc5f3549062a2ebe5dfd749ce3cf96a2559e2d1236608`, assinado com
o mesmo certificado da 1.0.0 (`c0271509…5719a`).

Verificações feitas no APK final: badging 1.1.0/versionCode 2, minSdk 24 /
targetSdk 36, `READ_MEDIA_IMAGES`, `allowBackup=false`, `fullBackupContent=false`,
`dataExtractionRules` presentes; 48 bibliotecas `.so` arm64; `res/RT.gguf`
(7.818.140 bytes) e `assets/index.android.bundle` (6.424.936 bytes) embutidos — os
mesmos tamanhos do APK perdido, o que confirma que o código recompilado é o mesmo —
com as telas de imagem/bloqueio, o cofre `private://`/`.lunaenc`, a política de
conteúdo e a âncora de idade adulta dentro do bundle; `ScreenCapture`,
`SecureStore`, `MediaLibrary` e `LocalAuthentication` presentes no dex.

Duas mudanças ficaram em `android/gradle.properties` por causa do ambiente, e
nenhuma delas altera o comportamento do aplicativo:
`android.enableR8.fullMode=false` (R8 em modo de compatibilidade) e
`kotlin.daemon.jvmargs` com teto de 1 GB.

Entrega em `/home/user/entrega/`: APK, ZIP do código (sem keystore, sem senha —
conferido com busca pela senha real), relatório de testes, instruções,
`SHA256.txt` e o documento de projeto. O ZIP é também a fonte de recuperação:
foi dele que a árvore foi restaurada depois da segunda reversão do workspace.

## Camada 2 de testes (adicionada depois do APK)

Os 87 testes de lógica cobriam funções puras; nenhum deles executava uma tela.
Foi adicionada uma segunda camada com jest + jest-expo:

```
npm run test:render   → 49 de 49, em 6 suítes
npm run test:unit     → 87 de 87
npx tsc --noEmit      → sem erros
npx eslint .          → 0 erros (72 avisos de estilo)
```

Ela executa de verdade: o portão de bloqueio (não monta o aplicativo enquanto
`locked`; nada aparece com `ready` falso), a tela de conversa com o botão
**Gerar imagem** (e a navegação dele), o ciclo completo de senha com
Crypto + SecureVault + AppLock (ativar, bloquear, errar com espera progressiva,
acertar, trocar, desligar), o cofre de arquivos (cifra, releitura, IV novo a
cada gravação, recusa com o cofre fechado) e as telas novas abrindo.

Os módulos nativos são simulados (keychain, MMKV, SQLite, arquivos em memória,
Reanimated): isto **não** é teste de aparelho. O APK entregue não mudou — o que
mudou é ferramenta de desenvolvimento (`devDependencies`, `jest.setup.js`,
`tests/render/**`), nada disso entra no bundle.

O que continua pendente está listado acima: tudo o que depende do aparelho.


---

## Rodada 1.1.1 — geração real de ponta a ponta (18/09, à noite)

O que mudou em relação à 1.1.0: **três defeitos reais** da geração de imagem,
encontrados porque desta vez a geração foi executada até o fim contra o serviço
real (antes, só com rede simulada nos testes). Registro completo em
`BUGS_FOUND.md` (seções S, T, U, V, W) e no `CHANGELOG.md`.

| # | Defeito | Correção | Prova |
| --- | --- | --- | --- |
| 1 | 429 na consulta de status derrubava a geração e dizia "cota esgotada" | 429/5xx são passageiros: espera com teto (5 s → 30 s), respeita `Retry-After`; 401/403/404/400 continuam fatais; intervalo subiu para 5 s | 6 testes novos; 429 observado de verdade |
| 2 | Resultado vindo como **endereço https** (R2) não era lido — app dizia "base64 inválido" depois de a imagem já ter sido gerada | aceita endereço **ou** base64; bytes conferidos pelo cabeçalho real; erro de download tem mensagem própria | 5 testes novos; geração real baixada (WebP 91.666 bytes) |
| 3 | Pollinations devolvia imagem de **cache** sem relação com a descrição (semente 42 padrão) | semente sempre enviada (sorteada quando o usuário não escolhe) e devolvida no resultado | 2 testes novos; medido: 37.167 bytes idênticos antes, imagem correta depois |

Limite honesto, medido e **não** corrigível no app: a Pollinations segue bem
descrições em **inglês**; em português ignorou a descrição em todas as
tentativas. A tela de ajustes de imagem agora avisa isso e recomenda a AI Horde
para quem escreve em português.

### Números desta rodada (executados nesta máquina)

- `npm run test:unit` → **101 de 101** (era 87; 14 novos)
- `npx jest tests/render` → **50 de 50** em 6 suítes (era 49; 1 novo)
- `npx tsc --noEmit` → 0 erros · `npx eslint .` → 0 erros (45 avisos de estilo)
- Geração real: Horde WebP 512×768 (91.666 bytes, 18 s) e Pollinations JPEG
  512×768 (38.095 bytes, 4 s), **os dois com os bytes conferidos**
- Build do APK 1.1.1 (versionCode 3, mesmo keystore da 1.0.0)

### Pendências (inalteradas, dependem do aparelho)

Gerar imagem **pelo botão dentro do app**, cancelar pelo botão, ver o aviso de
idioma na tela, e todo o checklist de bloqueio em `entrega/CHECKLIST_APARELHO.md`.
Nada disso foi marcado como aprovado.


---

## Rodada 1.1.2 — cancelar avisa o provedor (18/09, noite)

Revisão feita **depois** de entregar a 1.1.1, olhando o que os testes de rede
simulada não cobrem: o que acontece **no servidor** quando o usuário cancela.

- Encontrado: `cancelHordeJob` existia no provedor mas ninguém chamava. Cancelar
  parava a espera no app e deixava o trabalho na fila.
- Medido com o serviço real: trabalho abandonado (ninguém consultando) segue
  sendo gerado — aos 30 s gerando, aos 60 s pronto com imagem. Quem cancelou
  gasta prioridade (kudos) do mesmo jeito e a imagem vai para o lixo.
- Corrigido na causa: ao cancelar, o app envia `DELETE /generate/status/{id}` e o
  trabalho sai da fila. Sucesso não manda cancelamento; 401/404 também não.
- Conferido na API real: o `DELETE` funciona sem cabeçalho de chave
  (HTTP 200, `waiting 0`, `done true`) — o caminho de timeout já estava certo.

Números desta rodada: **104 de 104** na suíte de lógica (3 novos no arquivo do
provedor, que agora tem 30) e **50 de 50** na de renderização; `tsc` e `eslint`
sem erros. Versão 1.1.2, versionCode 4, mesmo keystore.

### Build desta rodada (executada nesta máquina)

- Compilação a frio: ~3 h (R8 sozinho ~58 min de CPU em 2 núcleos), com uma
  falha de **metaspace** no fim e retomada em **1m06s** reaproveitando o R8 em
  cache (`BUGS_FOUND.md`, seção Z). Teto do heap ajustado para 1600m e metaspace
  para 768m.
- APK: 1.1.2, versionCode 4, 60.466.386 bytes, sha256 `e39b3ae7…319b`,
  assinatura v2 conferida pelo `apksigner`, certificado `c0271509…5719a`
  (o mesmo da 1.0.0 → atualiza por cima).
- Bundle: 6.428.024 bytes, com o identificador `Lunaria:1.1.2`; o cancelamento em
  si é lógica (sem texto novo), coberto pelos 30 testes do provedor.

### Provas contra o serviço real (depois do build)

- **Cancelamento**: `tools/cancelar_geracao_real.mjs` criou um trabalho real (fila
  posição 149), cancelou pelo mesmo caminho do aplicativo e o provedor confirmou
  **imagens=0** — o trabalho não foi gerado. Antes da correção, um trabalho
  abandonado terminava com imagem.
- **Caminho de sucesso**: `tools/gerar_imagem_real.mjs` gerou WebP 512×768
  (131.436 bytes, 71 s) depois da reestruturação do laço.
- **429 ao vivo**: essa mesma geração bateu no limite de consultas no meio do
  caminho ("aguardando um pouco…") e terminou com a imagem — as duas correções
  provadas juntas.
- **Limite honesto**: a descrição pedia "jovem adulta com um gato preto"; veio o
  gato preto e a luz de vela, sem a figura humana. Limite do modelo gratuito, não
  do aplicativo — registrado para não prometer o que ele não entrega.

Segue pendente (só o aparelho responde): cancelamento tocando no botão, geração
pelo botão, e o checklist de bloqueio. Nada disso foi marcado como aprovado.

### Conferência final da entrega (18/09, sem aparelho)

- **Preservação provada dentro do APK** — `tools/verificar_preservacao.py` abre o
  pacote entregue, lê o bundle compilado (Hermes) e a lista de arquivos e procura
  um marcador por recurso: **12 de 12 encontrados**. Inclui o modelo local
  (`res/RT.gguf`, 7.818.140 bytes), as bibliotecas nativas do llama.cpp
  (`librnllama*.so`, 17 arquivos, mais `libggml-htp-*.so`) e os textos de
  Pesquisa/Fatos, Hamura, memória e leitura em voz alta.
  Limite declarado: prova que o recurso **está no pacote**, não que funciona no
  aparelho — isso segue no `CHECKLIST_APARELHO.md`.
- **Keystore de depuração removido do ZIP** — o `android/app/debug.keystore`
  (idêntico ao dos templates públicos, senha `android`) estava indo no pacote
  porque a busca anterior filtrava só `*.jks`. Saiu; o ZIP não tem **nenhum**
  keystore. Detalhes em `BUGS_FOUND.md` §AE.
- **Empacotamento virou script repetível** — `tools/empacotar_entrega.sh` monta
  CHECKSUMS + ZIP, sincroniza os documentos com `entrega/` e recusa material de
  chave. A regra "nenhum keystore no pacote público" passou a ser verificada pelo
  próprio script, e não pela minha memória.
- **Contagens corrigidas em `CORRECOES.md`**: 17 testes de lógica novos (87 → 104)
  e 1 de renderização (49 → 50), com a fonte de cada número.
- **Portões reexecutados depois de tudo**: lógica **104/104**, renderização
  **50/50**, `tsc` sem erros, `eslint` sem erros (46 avisos).

## Rodada 1.1.3 — fechamento ao abrir no aparelho (relato do Hamura, 18/09)

**O problema**: a 1.1.2 fechou ao abrir no Galaxy A05s, sem mensagem nenhuma.
Sem `logcat` deste ambiente, a causa raiz **não foi confirmada** — e não tratei
hipótese como conclusão.

**O que foi descartado com prova** (§AF do `BUGS_FOUND.md`): módulos nativos
faltando (os quatro novos estão no pacote, com classes e `.so`), diferença de
configuração de build em relação à 1.0.0 (o `app.config.js` é idêntico fora a
versão), dependência nova incompatível (as duas de JavaScript puro não podem
derrubar a inicialização) e motor do MMKV/Nitro ausente (`libNitroMmkv.so`,
`libNitroModules.so`, `libmmkv.so` presentes).

**O que foi feito** — fazer o aplicativo falar em vez de morrer calado:

- `lib/utils/Diagnostics.ts`: migalhas de percurso (anel de 40), captura de erro
  de JavaScript e de promessa não tratada, contagem de aberturas que não terminam,
  **modo seguro** depois de duas, e relatório em texto que não carrega nada
  pessoal;
- `app/components/views/DiagnosticReport.tsx`: a tela que mostra o relatório, com
  "Copiar diagnóstico" e "Tentar novamente", e o aviso de modo seguro que pode ser
  desligado;
- `app/components/views/DiagnosticBoundary.tsx`: limite de erro — erro de
  renderização vira relatório, não fechamento (e esconde a tela de abertura, que
  senão cobria o relatório);
- `app/_layout.tsx`: cada camada nova em `try/catch` e o `expo-screen-capture`
  **fora do topo do arquivo** — era um `import` que, falhando, derrubava a
  abertura inteira;
- `lib/state/AppLock.ts`: falha ao ler o cofre vira aviso (`initError`), não
  travamento;
- `MainApplication.kt`: falha nativa é gravada em arquivo **antes** de fechar, e
  aparece no relatório na abertura seguinte.

**Verificação**: 115 testes de lógica (11 novos) e 55 de renderização (5 novos),
`tsc` e `eslint` limpos. Dois defeitos no meu próprio código apareceram nesses
testes (botão de sair do modo seguro que não desligava; asserção de privacidade
mal escrita) — corrigidos e registrados no `TEST_REPORT.md` §2.6.

**Build — conseguido em 19/09, às 10:51 UTC**: `BUILD SUCCESSFUL in 29m30s`
(build nº17, log `gradle-26.log`; o nº14 às 10:51 gerou o mesmo APK em 29m30s, perdido no salvamento do workspace — §AJ). O caminho até aqui custou caro e está
registrado para não se repetir: nº11 perdido aos 2h10 num reinício do ambiente
(§AG), nº12 falhou aos 5h35 com estouro de heap no R8 — configuração que eu
julgava validada porque o build nº18 passou, mas nele o R8 estava `UP-TO-DATE`,
isto é, **nunca rodou** (§AH) —, nº13 perdido aos 1h27 em outro reinício.

**APK de diagnóstico da 1.1.3** (em `entrega/`):

| | |
| --- | --- |
| arquivo | `Lunaria-1.1.3-arm64-release.apk` |
| tamanho | 66.612.435 bytes |
| sha256 | `1ceba7a27a32a7e3d5127a38246a9dda4bbbf75d2010ad1e46cf54d1be6bff75` |
| versão | 1.1.3 (código 5) — atualiza sobre a 1.0.0/1.1.1/1.1.2 |
| assinatura | v2 **Verifies**, certificado `c0271509…5719a` (o mesmo de sempre) |
| bundle | 6.442.440 bytes, com `Lunaria:1.1.3` e toda a camada de diagnóstico |
| recursos anteriores | 48 bibliotecas nativas arm64 e `res/RT.gguf` (7.818.140 bytes) presentes |

**R8 desligado de propósito nesta compilação** (assinatura e versão não mudam).
Dois motivos, os dois honestos: (1) tempo — nesta máquina o R8 frio leva de 1h30 a
2h30 e cada reinício do ambiente apaga a pasta de compilação; sem ele a build caiu
para 29 minutos, o que permitiu terminá-la numa janela contínua; (2) hipótese a
testar no aparelho — a 1.1.2 passou pelo R8 e fechou ao abrir, então um APK sem
redução de código, com o resto igual, separa "problema na redução" de "problema no
código". O APK fica um pouco maior por isso (66,6 MB contra 60,4 MB).

O que **não** foi verificado: se ele abre no seu aparelho. Isso é o teste dele.

### Auditoria do APK entregue (19/09, sem aparelho)

Antes de pedir o teste no telefone, conferi dentro do pacote tudo o que costuma
derrubar um aplicativo na abertura. **Nenhuma das hipóteses se confirmou** — o
registro completo está no `BUGS_FOUND.md` §AL:

- **53 bibliotecas nativas**, todas AArch64 (mais 5 do DSP Hexagon), com **todas as
  dependências resolvidas** dentro do pacote ou no sistema (`readelf -d` em cada uma);
- **24 classes instanciadas pelo Android pelo manifesto**, todas presentes no dex
  (`MainApplication`, `MainActivity`, serviços e provedores);
- **4 arquivos dex íntegros** (`dexdump`);
- **bytecode Hermes compatível**: HBC 96 no bundle e no compilador do projeto;
- **R8 de fato desligado**: 30,2 MB de dex em 4 arquivos (contra 14,0 MB da 1.1.2).

E a lacuna de teste que existia foi fechada: a **primeira tela** (`app/index.tsx`)
passou a ser renderizada em teste (`tests/render/primeira-tela.test.tsx`, 5 casos),
cobrindo banco em erro, falha de início, ausência de autorização e o caminho de
sucesso. Portões desta rodada: **115** testes de lógica, **60** de renderização,
`tsc` sem erros, `eslint` sem erros.

## Rodada 1.1.4 — a hipótese principal caiu, um defeito real de abertura foi corrigido (19/09)

**Em uma frase**: testei a hipótese que eu tratava como principal (renomeação pelo
R8) **contra o próprio APK que fechou** e ela estava errada; no caminho, encontrei
e corrigi o único ponto do aplicativo que fazia chamada nativa no instante do
carregamento — que é justamente o que produz "fecha ao abrir, sem mensagem".

### 1. A hipótese do R8 foi refutada com medida, não com opinião

O APK da 1.1.2 (o que fechava) ainda existia no arquivo de instantâneo do ambiente
(`/tmp/arena-workspace/hydrate.zip`) — 60.466.386 bytes, sha256 `e39b3ae7…319b`,
byte a byte o entregue. Com ele, a comparação deixou de ser suposição:

- as classes procuradas **por nome** pelo código nativo estão presentes nos dois
  APKs (`com.tencent.mmkv.MMKV`, `com.margelo.nitro.NitroModules`,
  `HybridMMKVPlatformContext`, `core.HybridObject`, `expo.modules.kotlin.jni.JavaScriptObject`);
- os **métodos** dessas classes são idênticos (os `native` inclusive);
- o **manifesto** é idêntico em 162 elementos/atributos — só o `versionName` difere;
- as 48 bibliotecas nativas e os 12 `assets/` são os mesmos conjuntos;
- as 24 classes instanciadas pelo manifesto existem nos dois dex.

Detalhe metodológico que vale registrar: as classes de registro
(`com.facebook.react.PackageList`, `expo.modules.ExpoModulesPackageList`) **não
aparecem pelo nome** no APK com R8 — o que parece um achado grave e não é: o R8
renomeia e reescreve as referências de forma consistente. Procurar por nome em dex
reduzido dá falso positivo. Números completos no `BUGS_FOUND.md` §AM.

**Decisão**: as regras de `-keep` para esses pacotes ficaram no projeto mesmo assim,
comentadas como **proteção para builds futuros** — não como a correção deste
defeito. Nenhum desses pacotes publica regras de consumo próprias.

### 2. O defeito real: chamada nativa no escopo do módulo

Pergunta que destravou o resto: *o que executa no instante em que o pacote
JavaScript é avaliado?* Nesse instante não há tela, não há `try/catch`, não há
relatório — se algo falha ali, fecha e o usuário não vê nada.

Medido no pacote instalado: `react-native-mmkv` cria os objetos nativos **dentro da
função** (`NitroModules.createHybridObject('MMKVPlatformContext')`) e os hooks
resolvem a instância **no corpo** (na renderização). Ou seja, no aplicativo inteiro
havia **uma única** chamada nativa no `import`: `lib/storage/MMKV.ts:6` —
`export const mmkv = createMMKV()` — e esse arquivo está no caminho da abertura
(`Startup.ts` importa `mmkv`).

**Correção**: `lib/utils/NativeModules.ts` faz a carga sob demanda, memorizada e
protegida, registrando a falha no relatório em vez de derrubar o aplicativo. O
mesmo tratamento foi aplicado a `expo-secure-store`, `expo-crypto`,
`expo-media-library`, `expo-sharing` e `expo-local-authentication`. O MMKV ganhou
**reserva em memória**: se o armazenamento nativo não responder, o aplicativo abre
e diz o motivo, em vez de fechar calado.

**Honestidade sobre o alcance**: isto é um defeito real, comprovado por leitura de
código e do caminho de importação — e é a única construção do aplicativo capaz de
produzir o sintoma relatado. **Não** é prova de que era esta a causa no aparelho do
Hamura. Quem decide isso é o relatório do aparelho (itens 18 e 19 do checklist).

### 3. Verificação automatizada desta rodada

| barreira | resultado |
| --- | --- |
| lógica (node --test) | **123 / 123** (8 novos: carga protegida + guardas de fonte) |
| renderização (jest) | **60 / 60** em 8 suítes |
| tipos (`tsc --noEmit`) | 0 erros |
| lint (`eslint`) | 0 erros (58 avisos de estilo, pré-existentes) |

Os 8 novos incluem **guardas contra o retorno do defeito**: nenhum arquivo pode
importar no topo os módulos convertidos, e `createMMKV()` não pode voltar ao escopo
do módulo. Sem isso, a correção se perderia na próxima alteração sem ninguém notar.

### 4. Versão e build

Versão **1.1.4 (código 6)** — número próprio de propósito: o 1.1.3 anterior já foi
entregue e precisa continuar distinguível no relatório de diagnóstico e na tela de
instalação. A assinatura é a mesma de sempre, então instala por cima.

Build desta rodada rodou com **R8 desligado** (`LUNARIA_SEM_R8=1`, confirmado no
log: `android.enableMinifyInReleaseBuilds=false`). Não é mais para separar hipótese
de R8 — isso já foi resolvido no item 1 — e sim porque é a configuração que produz
o APK de diagnóstico em ~16-30 min nesta máquina, contra 1h30-2h30 do R8 frio.

### 5. Resultado do build desta rodada

**BUILD SUCCESSFUL em 8m12s** (log `lunaria-build/logs/gradle-28.log`, 952 tarefas:
689 executadas, 142 do cache, 121 já atualizadas). Foram **três tentativas** — as
duas primeiras morreram com o disco em 100%, e a causa foi decisão minha, não azar:
apaguei pastas de compilação "regeneráveis" dentro de `node_modules` para abrir
espaço, e elas foram **recompiladas do zero**, consumindo mais pico de disco do que
ocupavam paradas. Também apaguei um NDK julgando-o sem uso, e o Gradle **baixou-o de
volta** durante a build (os dois são necessários). O que destravou foi apagar o
**cache de transformações do Gradle** (3 GB, este sim inerte entre builds),
preservando os objetos nativos já compilados. O registro completo está no
`BUGS_FOUND.md` §AO — inclusive o erro de processo de ter editado documentos direto
em `entrega/` e vê-los sobrescritos pelo empacotador.

| | |
| --- | --- |
| arquivo | `Lunaria-1.1.4-arm64-release.apk` |
| tamanho | 66.615.443 bytes |
| sha256 | `59d914e7687403d91025ede5fe274e6d98ef1daa8cc5703b45dd758ede45b963` |
| versão | 1.1.4 (código 6) — instala por cima da 1.0.0/1.1.1/1.1.2/1.1.3 |
| assinatura | v2 **Verifies**, certificado `c0271509…5719a` (o mesmo desde a 1.0.0) |
| R8 | desligado (dex 30,2 MB em 4 arquivos) |
| bundle | 6.445.276 bytes, com `Lunaria:1.1.4` e a carga protegida (`ModuloNativo:`) |
| fontes | `Lunaria-1.1.4-source.zip` (7.650.447 bytes, 418 arquivos, sem keystore, CHECKSUMS interno confere) |

**O que continua pendente, sem rodeios**: se a 1.1.4 abre no Galaxy A05s do Hamura.
Nenhum teste deste ambiente executa o binário Android — o emulador não existe aqui e
o APK é arm64 (§6.3 do `TEST_REPORT.md`). O que eu posso afirmar: o defeito real
encontrado foi corrigido com prova de código, a correção está dentro do APK entregue
(conferido no bundle) e nenhuma função anterior se perdeu (14/14 na verificação de
preservação).

## Rodada 1.1.5 — o banco de dados executava código nativo no carregamento (19/09/2026)

Continuação direta da caça ao "fecha ao abrir", pelo mesmo método: **medir o
caminho de abertura**, não adivinhar. A hipótese principal da rodada anterior
(renomeação de classes pelo R8) já havia sido **refutada com medida** (§AM); nesta
rodada foram fechados os pontos do mesmo tipo que ainda restavam ao alcance de uma
mudança localizada — e o principal deles é o banco de dados. O defeito completo
está no `BUGS_FOUND.md` §AQ.

### 1. O que foi medido

| ponto | medida |
| --- | --- |
| `db/db.ts` (1.1.4) | 11 linhas, **quatro** chamadas nativas no escopo do módulo: `openDatabaseSync`, `loadExtensionAsync`, `drizzle`, `execAsync('PRAGMA foreign_keys = ON')` |
| quem importa `db/db.ts` | a **primeira tela** (`app/index.tsx`, para `useMigrations(db, migrations)`) — ou seja, o banco abria antes de existir tela, proteção ou `try/catch` |
| `expo-sqlite` | procura o módulo nativo **no import**: `node_modules/expo-sqlite/build/ExpoSQLite.js` → `requireNativeModule('ExpoSQLite')` |
| `drizzle-orm/expo-sqlite` | `node_modules/drizzle-orm/expo-sqlite/query.js:1` → `import { addDatabaseChangeListener } from "expo-sqlite"`: o próprio Drizzle importa o SQLite |
| `expo-crypto` | também procura o nativo no import (`build/Crypto.js` → `build/ExpoCrypto.js`), e era importado no topo de `lib/state/Chat.ts` e de `app/screens/ChatScreen/ChatInput/index.tsx` |
| `expo-local-authentication` | mesma construção, importada no topo de `lib/hooks/LocalAuth.tsx` |
| módulos **registrados** no APK entregue | lido dentro do dex (`apkanalyzer dex code --class expo.modules.ExpoModulesPackageList`): `crypto.CryptoModule`, `filesystem.FileSystemModule`, `sqlite.SQLiteModule`, `securestore`, `medialibrary`, `sharing`, `localauthentication`, `screencapture` — **todos presentes** |
| `expo-file-system` | também procura o nativo no import (`src/ExpoFileSystem.ts:24`) e está no topo de nove arquivos do caminho de abertura — **não corrigido nesta rodada** (ver abaixo) |

Conclusão das medidas: **"faltava um módulo nativo no pacote" não explica o
fechamento** — os módulos estão no pacote *e* registrados. O que existe, medido, é
a construção perigosa: código nativo rodando no instante em que o pacote é
avaliado, onde nenhum `try/catch` do aplicativo alcança.

### 2. O que foi corrigido

| arquivo | antes | depois |
| --- | --- | --- |
| `db/db.ts` | banco aberto no escopo do módulo; `expo-sqlite` e `drizzle-orm/expo-sqlite` importados no topo | acesso **sob demanda** (`db` e `sqliteDB` por Proxy): abre na primeira leitura de propriedade, uma vez, dentro do `try/catch` de quem chamou; os dois pacotes são carregados sob demanda |
| `lib/state/Chat.ts`, `app/screens/ChatScreen/ChatInput/index.tsx` | `randomUUID` do `expo-crypto` importado no topo | novo `lib/utils/RandomId.ts`, com carga tardia protegida e reserva em JavaScript puro |
| `lib/hooks/LocalAuth.tsx` | `expo-local-authentication` no topo | carga tardia; sem o módulo, degrada para "sem prompt de biometria" (antes o botão de repetir chamaria para sempre um módulo inexistente e prenderia o usuário) |
| `lib/utils/RandomId.ts` | — | **defeito encontrado pelo próprio teste**: quando a função nativa responde `undefined` em vez de lançar, o identificador saía vazio; agora o valor é conferido e há reserva |
| `db/db.ts` (promessas) | `loadExtensionAsync` e `execAsync` sem `catch` (rejeição sem dono) | as duas registram a falha no relatório de diagnóstico |

Nada foi removido de recurso: os 47 usos de `db.mutate`, os 38 de `db.query`, os
`insert/update/delete` e o `sqliteDB` direto de `EmbeddingScreen.tsx` continuam
funcionando sem alteração, porque o tipo exposto é o mesmo de antes.

### 3. O que **não** foi corrigido (pendente, com medida)

`expo-file-system` faz a mesma procura nativa no import e está no topo de nove
arquivos do caminho de abertura (`lib/utils/File.ts`, `lib/utils/Startup.ts`,
`lib/state/Characters.ts`, `lib/security/PrivateStorage.ts`,
`lib/security/PrivateImageCache.ts`, `lib/security/Migration.ts`,
`app/components/views/DiagnosticReport.tsx`,
`app/screens/AppSettingsScreen/DatabaseSettings.tsx`). Fechar esse ponto exige
refatorar dezenas de telas — trocar um defeito conhecido por uma regressão em
massa, na véspera de uma entrega, seria pior. **Fica registrado como pendente.** A
atenuação verificável está no §AQ: o módulo **está registrado** no APK, então
nesse build a procura tem o que encontrar.

### 4. Verificação desta rodada (executada nesta máquina)

| item | resultado |
| --- | --- |
| Testes de lógica (`npm run test:unit`) | **126 de 126** (eram 123; +3 varreduras de código-fonte) |
| Testes de render (`npm run test:render`) | **65 de 65** em 9 suítes (eram 60 em 8; +5 comportamentais) |
| `npx tsc --noEmit` | sem erros |
| `npx eslint . --ext .ts,.tsx` | sem erros (58 avisos de estilo, pré-existentes) |
| Prova nova principal | `tests/render/banco-e-identificador.test.ts`: importar o banco **não** abre o banco; a abertura acontece **uma vez**, no primeiro uso, com o PRAGMA de chaves estrangeiras; e o identificador é sempre texto válido, mesmo com a fonte aleatória do sistema devolvendo lixo |

### 5. Versão e build desta rodada

Versão **1.1.5**, código **7** (quatro pontos: `app.config.js`, `package.json`,
`android/app/build.gradle`, `lib/imagegen/ImageProviders.ts`), mantendo a mesma
chave de assinatura da 1.0.0 — instala por cima, sem desinstalar.

### 6. Armadilha de entrega encontrada e corrigida nesta rodada

O vigia do APK copiou um **APK velho** que estava sobrando no diretório de saída e
o batizou com a versão nova — quase foi entregue um arquivo da 1.1.4 com nome de
1.1.5, exatamente o que o Hamura proibiu. O vigia passou a conferir a **versão
gravada dentro do APK** (`apkanalyzer manifest version-name`) antes de copiar, e o
arquivo enganoso foi apagado. Detalhes no `BUGS_FOUND.md` §AR.

### 7. Estado honesto desta rodada

**O fechamento ao abrir não está provado como corrigido.** O que está provado:

1. a hipótese do R8 caiu (§AM);
2. os módulos nativos usados estão no pacote e **registrados** (§AQ);
3. existia, sim, um defeito real da classe "código nativo no carregamento" no
   caminho de abertura — o banco de dados — e ele foi corrigido, com teste que
   prova que o import já não toca o nativo.

O que falta: o teste no Galaxy A05s. A 1.1.5 leva a captura de erro nativo e o
relatório de diagnóstico com os módulos que falharem **nomeados**, de modo que, se
ainda fechar, o motivo aparece em vez de sumir. Os itens 18, 19 e 20 do
`CHECKLIST_APARELHO.md` são os que decidem.

### 8. Resultado do build desta rodada (executado nesta máquina)

| item | resultado |
| --- | --- |
| comando | `bash /home/user/lunaria-build/build-apk-2.sh /home/user/lunaria-build/logs/gradle-29.log` (R8 desligado de propósito) |
| resultado | **BUILD SUCCESSFUL in 17m 59s** — 952 tarefas acionáveis (589 executadas, 335 do cache, 28 já atualizadas) |
| APK | `Lunaria-1.1.5-arm64-release.apk`, **66.814.459 bytes** |
| sha256 | `84f201c0a77e2e2220128b18c381d13d897c8082d5c989ee1a95bb7c625653a8` |
| versão interna | **1.1.5**, código **7** (conferido dentro do APK, não pelo nome do arquivo) |
| assinatura | certificado `c0271509ad829da96e8fd205faa99b7103bf43c358a8501c0925606c7b55719a` — **o mesmo desde a 1.0.0**, então instala por cima sem desinstalar |
| SDK | mínimo 24, alvo 36 |
| bibliotecas | 48 arm64-v8a; 4 arquivos dex (R8 desligado); `res/RT.gguf` com 7.818.140 bytes |
| bundle | 6.644.296 bytes, com `Lunaria:1.1.5`, `ModuloNativo:`, a mensagem do banco em pt-BR, `expo-sqlite` e `expo-local-authentication` (as cargas tardias) |
| preservação | `tools/verificar_preservacao.py` sobre o APK entregue: **tudo o que já funcionava continua dentro** |
| ZIP do código | `Lunaria-1.1.5-source.zip`, 7.664.007 bytes, 513 entradas (420 arquivos), **nenhum** material de chave, CHECKSUMS interno com 419 arquivos conferindo |

**Prova de que a trava do vigia funciona** (o defeito do §AR): às 14:14:27 o vigia
registrou *"IGNORADO: APK no diretório de saída é da versão '1.1.4' e o pedido é
'1.1.5' (arquivo velho, não deste build)"* — o APK velho foi recusado. Às 14:15:39
copiou o APK novo, já conferindo a versão interna: *"COPIADO 66814459 bytes (versao
interna 1.1.5)"*. O mesmo caminho que quase entregou um arquivo trocado hoje agora
recusa o arquivo trocado.

## Rodada 1.1.6 — porteiro de entrada: a classe do defeito, não só os casos (19/09/2026)

Nas rodadas anteriores a caça ao "fecha ao abrir" tratou **casos** (§AN, §AQ),
fechando um ponto por vez. Nesta, ataquei a **classe**: por que uma falha na
avaliação de um módulo fecha o aplicativo **em silêncio**? Porque os `import` são
resolvidos antes de qualquer tela, proteção ou `try/catch` — e não havia nada
rodando antes disso. Agora há.

### 1. O que é, em uma frase

O aplicativo passou a ter um **porteiro de entrada**: um arquivo que roda primeiro,
**não importa nada**, instala o registro de erros fatais e carrega as rotas dentro
de `try/catch`. Se um módulo do aplicativo falhar ao ser avaliado — a falha que
antes fechava tudo sem mensagem — o aplicativo **abre numa tela de aviso** com o
motivo, a versão, o horário e o botão **"Copiar diagnóstico"**.

### 2. Peças novas

| arquivo | papel |
| --- | --- |
| `index.js` | novo `main` do aplicativo (antes era direto `expo-router/entry`): carrega o porteiro, e só depois as rotas, dentro de `try/catch` |
| `lib/utils/EntradaSegura.js` | o porteiro e a tela de aviso; não importa nada, na hora do uso tudo é cercado por `try/catch` |
| `tests/render/entrada-segura.test.ts` | **9 testes** do porteiro: instala antes de tudo, mostra a tela em falha fatal de abertura, **não** interfere depois que as rotas carregam, não age em erro não fatal, mantém a cadeia de tratadores, monta o relatório sem quebrar com objeto hostil |
| `tests/nativemodules.test.mjs` | 2 travas novas: o porteiro **não pode** ganhar `import` no topo; o `main` precisa ser o `index.js` e o porteiro precisa vir **antes** das rotas |

### 3. Decisões que sustentam a correção

- **sem dependências no porteiro**: se ele importasse qualquer coisa, morreria da
  doença que existe para diagnosticar. A regra é travada por teste (coluna 0).
- **cadeia de tratadores**: o aplicativo já instala o dele em `app/_layout.tsx`;
  como o porteiro roda antes, ele **envolve** o `setGlobalHandler` em vez de
  competir — quem chega depois entra na cadeia. Sem isso, o tratador do aplicativo
  apagaria o do porteiro e o silêncio voltaria.
- **só age antes de o aplicativo montar**: depois das rotas carregadas, erro fatal
  continua indo para o relatório de diagnóstico já existente; nada é seqüestrado.
- **`require` em vez de `import`** no `index.js`: com `import` o empacotador pode
  reordenar a avaliação; com `require` explícito a ordem é a escrita.

### 4. Verificação desta rodada (executada nesta máquina)

| item | resultado |
| --- | --- |
| Testes de lógica | **128 de 128** (12 arquivos) |
| Testes de renderização | **74 de 74** em **10 suítes** (eram 65 em 9) |
| `npx tsc --noEmit` | sem erros |
| `npx eslint . --ext .ts,.tsx,.js` | sem erros (dois avisos legítimos do lint foram corrigidos: a tela de aviso deixou de usar hook em caminho condicional e passou a componente de classe criado sob demanda) |

### 5. O que isto **não** prova

Que era essa a causa no A05s. Um porteiro de JavaScript não alcança falha que
acontece **antes** de qualquer JavaScript rodar (biblioteca nativa que não carrega,
`.so` incompatível, instalação recusada). Se a 1.1.6 ainda fechar, a hipótese muda
de lugar — de módulo JS para carregamento nativo/instalação — e a evidência precisa
vir do Android (`adb logcat`), não de leitura de código.

### 6. Estado honesto

O que está provado: o banco não é mais tocado no import (§AQ); o porteiro existe,
roda primeiro e transforma falha de avaliação de módulo em **tela com motivo**
(9 testes de comportamento). O que continua dependendo do aparelho: os itens 18 a
22 do `CHECKLIST_APARELHO.md`.

### 7. Resultado do build desta rodada (executado nesta máquina)

| item | resultado |
| --- | --- |
| comando | `bash /home/user/lunaria-build/build-apk-2.sh /home/user/lunaria-build/logs/gradle-30.log` (R8 desligado de propósito) |
| resultado | **BUILD SUCCESSFUL in 31m 32s** — 952 tarefas acionáveis (810 executadas, 142 do cache) |
| ambiente | sandbox reiniciado: `node_modules`, toolchain e caches do Gradle reinstalados do zero nesta rodada (o build foi frio, por isso mais longo que o anterior) |
| APK | `Lunaria-1.1.6-arm64-release.apk`, **66.824.323 bytes** |
| sha256 | `b05441db3e032f6297f7484cbfbecf8938a20d2bc07b43c4f88d0be855e25c61` |
| versão interna | **1.1.6**, código **8** — conferida **dentro** do APK (a trava do vigia do §AR funcionou: copiou só quando a versão interna bateu) |
| assinatura | certificado `c0271509ad829da96e8fd205faa99b7103bf43c358a8501c0925606c7b55719a` — o mesmo desde a 1.0.0 |
| preservação | `tools/verificar_preservacao.py` sobre o APK entregue: **tudo o que já funcionava continua dentro** |
| porteiro no bundle | **sim** — `A Lunaria não conseguiu abrir`, `Copiar diagnóstico`, `Isto NÃO é uma tela normal`, `instalarTratador`, `mostrarFalha` (busca em bytes, UTF-8 e UTF-16LE; ver §AT) |
| bundle | 6.654.156 bytes; 48 libs arm64-v8a; `res/RT.gguf` 7.818.140 bytes |

Detalhe que vale registrar: o bundle saiu com **"Done writing bundle output"** — ou
seja, a troca do ponto de entrada (`main` → `index.js`, com `expo-router/entry`
carregado de dentro dele) **funciona no empacotamento de produção**, que era o risco
real dessa mudança estrutural.

### 8. Verificação do pacote entregue

Ver o `BUGS_FOUND.md` §AT: versão e assinatura conferidas dentro do APK, porteiro
presente no bundle (duas codificações), preservação intacta. O que segue pendente é
o que só o aparelho responde — itens **18 a 22** do `CHECKLIST_APARELHO.md`, com o
item **22** sendo o novo: se aparecer a tela de aviso, o texto copiado nomeia a
causa.

## Rodada 1.1.7 — a prova do defeito existia e era inalcançável (19/09/2026)

A rodada anterior fechou a *classe* do defeito no JavaScript (§AS, o porteiro de
entrada). Esta fecha o **ponto cego que eu mesmo registrei**: se a 1.1.6 ainda
fechasse no aparelho, não havia como capturar a causa — o porteiro só alcança falhas
depois que o motor JavaScript começa. E mais grave: **a captura nativa já existia
desde a 1.1.3, mas gravava o registro na pasta privada do aplicativo** — inalcançável
para quem tem nas mãos só o celular. O instrumento funcionava e não entregava nada.

### 1. O defeito, em uma frase

A prova do defeito estava sendo gravada, correta, **dentro de uma porta trancada**.

### 2. Correção

| peça | o que faz |
| --- | --- |
| `CapturaDeFalha.kt` (novo) | grava a falha em **dois** lugares: pasta privada (relatório na tela) e pasta **Downloads** — arquivo `lunaria-ultimo-erro.txt`, que o Hamura abre pelo celular e compartilha na conversa, **sem computador** |
| leitura do histórico do Android | na abertura seguinte, registra a morte **anormal** anterior (falha nativa, travamento, memória) — as que **não** geram exceção Java e por isso nunca apareciam |
| `DiagnosticReport.tsx` | diz onde o arquivo está e como enviá-lo; repete no texto copiado |
| `EntradaSegura.js` | a tela de aviso do porteiro também aponta para o arquivo em Downloads |

### 3. Verificação desta rodada (executada nesta máquina)

| item | resultado |
| --- | --- |
| Testes de lógica | **136 de 136** em 13 arquivos (eram 128; **+8** da captura nativa) |
| Testes de renderização | **76 de 76** em 10 suítes (eram 74; **+2** do aviso em Downloads) |
| `npx tsc --noEmit` | sem erros |
| `npx eslint . --ext .ts,.tsx,.js` | sem erros |

Destaque entre os testes novos: um confere que o **nome do arquivo privado é o mesmo
no Kotlin e no JavaScript**. Se um lado renomear e o outro não, o relatório ficaria
vazio **em silêncio** — e o teste falha antes disso chegar ao aparelho.

### 4. O que isto muda (e o que continua pendente)

**Muda**: se a 1.1.7 ainda fechar, existe um caminho para o motivo sair do aparelho.
Antes, fechar significava "não sabemos"; agora significa, no mínimo, um arquivo em
Downloads com versão, aparelho, horário e rastro.

**Continua pendente**: a confirmação no Galaxy A05s — itens **18 a 23** do
`CHECKLIST_APARELHO.md`. O item **23** é o novo, e é o mais valioso desta rodada.

### 5. Estado honesto

Não afirmo que o aplicativo abre. Afirmo, com prova de teste: a captura nativa é
instalada antes de qualquer biblioteca; grava nos dois lugares; preserva o
comportamento do Android; lê as mortes que não geram exceção; e a tela diz ao usuário
onde encontrar o arquivo. O resto é aparelho.

### 6. Resultado do build desta rodada (executado nesta máquina)

| item | resultado |
| --- | --- |
| comando | `bash /home/user/lunaria-build/build-apk-2.sh /home/user/lunaria-build/logs/gradle-33.log` (R8 desligado de propósito) |
| resultado | **BUILD SUCCESSFUL in 15m 21s** — 952 tarefas acionáveis (510 executadas, 334 do cache, 108 já atualizadas) |
| APK | `Lunaria-1.1.7-arm64-release.apk`, **66.829.187 bytes** |
| sha256 | `22113359255349455790f4b1c2ffdbfd3c94529342891695d045b65a653a8c47` |
| versão interna | **1.1.7**, código **9** — conferida **dentro** do APK (a trava do vigia aceitou só quando a versão bateu) |
| assinatura | o mesmo certificado desde a 1.0.0 |
| preservação | verificador sobre o APK entregue: tudo o que já funcionava continua dentro |
| captura nativa no dex | `CapturaDeFalha`, `lunaria-ultimo-erro.txt`, `getHistoricalProcessExitReasons`, `falha NATIVA (biblioteca)` — todos presentes (ver §AW) |
| bundle | 6.655.420 bytes, com `lunaria-ultimo-erro.txt`, `Existe um registro de falha gravado pelo Android` e o texto do porteiro |

### 7. Duas tentativas perdidas antes desta — e o que cada uma ensinou

1. **API inventada de memória**: usei `getHistoricalProcessExitInfos()`, que não
   existe (o correto é `getHistoricalProcessExitReasons`), e as constantes de motivo
   no lugar errado (`ActivityManager` em vez de `ApplicationExitInfo`). O
   compilador corrigiu; agora a conferência é feita contra o `android.jar` com
   `javap` antes de escrever (§AV). Detalhe prático adotado: compilar **só**
   `:app:compileReleaseKotlin` (2 minutos) antes de disparar o build inteiro.
2. **Ambiente derrubado no meio da compilação**: o processo foi interrompido e
   `node_modules` + `android/app/build` desapareceram (pastas fora do instantâneo).
   Reinstalado com `npm ci` e retomado — o cache do Gradle em `/opt` é o que faz a
   retomada custar 15 minutos em vez de meia hora. A receita está em
   `lunaria-build/RESTAURAR_AMBIENTE.md`.

### 8. Estado honesto desta rodada

**Continua não provado que o aplicativo abre no A05s** — nenhuma linha deste
documento afirma isso. O que mudou: se ainda fechar, **existe um caminho para o
motivo sair do aparelho** (arquivo em Downloads), e as mortes que não geram exceção
(falha nativa, travamento, memória) passam a ter evidência. Os itens **18 a 23** do
`CHECKLIST_APARELHO.md` decidem; o **23** é o novo e o mais valioso.

## Rodada 1.1.8 — trilha de abertura: até onde ele chegou (19/09/2026)

O último ponto cego era a morte **sem exceção**: falha nativa de verdade, morte por
sinal, memória. Nada disso passa por tratador de erro — a abertura termina sem
deixar uma linha. Agora cada etapa do arranque deixa uma linha com horário, e a
abertura seguinte diz onde a anterior parou.

### 1. As cinco etapas

`1/5` captura instalada (`attachBaseContext`, o ponto mais cedo em Java) → `2/5`
aplicativo criado → `3/5` React Native carregado → `4/5` tela principal criada →
`5/5` **ABERTURA CONCLUÍDA** (marcada em `onResume`, o sinal de que a tela apareceu).

### 2. Como a resposta chega ao Hamura

Trilha inacabada → promovida na abertura seguinte para o relatório na tela **e**
para `lunaria-ultimo-erro.txt` na pasta **Downloads**, com o cabeçalho "A ABERTURA
ANTERIOR NÃO CHEGOU AO FIM" e o ponto exato onde parou.

### 3. Auditoria do manifesto (hipóteses fechadas com prova)

Antes de escrever código, auditei o que ainda podia explicar morte **antes do
JavaScript**. Caiu tudo: recursos XML do manifesto existem e são válidos
(`network_security_config` e `data_extraction_rules` — resolução de IDs + parse
real), o tema da atividade existe e a cadeia de pais resolve inteira. Achado menor
tratado: o `<service>` do `RNBackgroundActionsTask` estava declarado **duas vezes**
(linhas idênticas) e as duas chegavam ao manifesto mesclado — removido. Detalhes no
`BUGS_FOUND.md` §AX.

### 4. Um defeito **meu**, pego antes do build

Ao mover a instalação da captura para `attachBaseContext`, meu próprio script de
edição removeu a linha do lugar novo (pegou a primeira ocorrência do texto, que era
a recém-inserida) — o resultado compilava e a captura teria ficado no lugar antigo.
Peguei comparando as posições no arquivo, corrigi com edição dirigida, e agora há
**teste** que exige `instalar` dentro de `attachBaseContext` e **antes** de
`onCreate`, aparecendo uma única vez. Lição repetida: edição por script precisa de
teste que confira o **resultado**, não a intenção.

### 5. Verificação desta rodada (executada nesta máquina)

| item | resultado |
| --- | --- |
| Testes de lógica | **145 de 145** em 13 arquivos (eram 136; **+9** da trilha) |
| Testes de renderização | **76 de 76** em 10 suítes |
| `npx tsc --noEmit` | sem erros |
| `npx eslint` | sem erros |
| Compilação isolada do Kotlin | **BUILD SUCCESSFUL** (3m04) — feita **antes** do build completo, de propósito (`BUGS_FOUND.md` §AV) |

### 6. Estado honesto

**Continua não provado que o aplicativo abre no A05s.** O que mudou: se não abrir,
existe endereço — a trilha diz **em qual etapa** o arranque morreu, e o arquivo sai
do aparelho pela pasta Downloads. Itens **18 a 24** do `CHECKLIST_APARELHO.md` (o
**24** é o novo).

### 7. Resultado do build desta rodada (executado nesta máquina)

| item | resultado |
| --- | --- |
| comando | `bash /home/user/lunaria-build/build-apk-2.sh /home/user/lunaria-build/logs/gradle-34.log` |
| resultado | **BUILD SUCCESSFUL in 6m 46s** (cache do Gradle quente; frio leva ~30 min) |
| APK | `Lunaria-1.1.8-arm64-release.apk`, **66.830.487 bytes** |
| sha256 | `32fa0bfb9c77ac55db2aae3a22e80db16d2204717c968af1cd89175b47082741` |
| versão interna | **1.1.8**, código **10** — conferida dentro do APK |
| assinatura | o mesmo certificado desde a 1.0.0 |
| preservação | verificador sobre o APK entregue: tudo o que já funcionava continua dentro |
| trilha no dex | as cinco etapas, o texto da abertura inacabada e `trilha-abertura.txt` — todos presentes (§AZ) |
| manifesto | `<service>` duplicado **corrigido** (1 ocorrência, era 2) |
| verificação prévia | `:app:compileReleaseKotlin` isolado: **BUILD SUCCESSFUL** em 3m04, antes do build completo |

### 8. O que o Hamura deve olhar primeiro (itens 23 e 24)

1. **23** — se o aplicativo fechar (ou já tiver fechado), procure
   `lunaria-ultimo-erro.txt` na pasta **Downloads** do aparelho.
2. **24** — o começo do arquivo diz **em que etapa** o arranque parou. É essa linha
   que fecha o diagnóstico: "parou depois de `3/5 React Native carregado`" aponta
   para o motor JavaScript; "parou depois de `1/5`" aponta para o carregamento
   nativo.
3. Se o aplicativo abrir normalmente, **não existe arquivo** — e isso também é
   resposta.

## Rodada 1.1.9 — nada encerra o app, e o relatório ganhou a terceira saída (19/09/2026)

### 1. Auditoria: encerramento deliberado (refutado com prova)

Toda a instrumentação anterior supõe que a abertura termina por **falha**. Fui
procurar a outra possibilidade — o aplicativo ser encerrado **de propósito** — que
seria invisível para todos os instrumentos: sem exceção, sem falha nativa, sem
rastro; só o aplicativo fechando, exatamente como relatado.

Resultado: **não existe** `DevSettings.reload`, `reloadAsync`, `expo-updates` em uso
(está desligado na configuração), `BackHandler.exitApp`, `process.exit`,
`System.exit`, `killProcess`, `finish()` ou `finishAffinity()` — nem no JavaScript,
nem no Kotlin. Nada no aplicativo encerra a si mesmo. Hipótese refutada.

### 2. O relatório ganhou a terceira saída

Havia dois caminhos para o relatório sair do aparelho, cada um com um furo: a área
de transferência pode estar indisponível (e é o tipo de coisa que quebra junto com o
resto), e o arquivo nativo em Downloads só cobre falhas **antes** do JavaScript.
Faltava o caso mais provável: falha **dentro** do JavaScript, com a tela de aviso no
ar e só o botão de copiar disponível.

Agora existe **"Salvar em Downloads"** — na tela de aviso **e** no relatório — que
grava o mesmo texto em `lunaria-diagnostico.txt`, pelo utilitário que o aplicativo já
usa para exportar arquivos. Carga tardia e cercada (o utilitário toca
`expo-file-system`, que busca nativo no import), nunca lança, e salva exatamente o
que está na tela.

### 3. Verificação desta rodada (executada nesta máquina)

| item | resultado |
| --- | --- |
| Testes de lógica | **145 de 145** em 13 arquivos |
| Testes de renderização | **86 de 86** em **12 suítes** (eram 76 em 10) |
| `npx tsc --noEmit` | sem erros |
| `npx eslint` | sem erros |

O teste que importa desta rodada é o de **integração do porteiro**: com o `index.js`
de verdade e as rotas lançando na avaliação, o aplicativo **não explode**, registra a
tela de aviso como tela principal, **renderiza o motivo real** e mostra as duas
saídas. Os testes anteriores provavam pedaços — e um pedaço pode passar com o
encadeamento quebrado.

### 4. Estado honesto

**Continua não provado que o aplicativo abre no A05s.** O que passou a estar provado
por teste de integração: se ele falhar ao carregar, **abre numa tela com o motivo e
duas formas de me enviá-lo** (copiar ou salvar em Downloads). No aparelho, os itens
**18 a 24** do `CHECKLIST_APARELHO.md` continuam sendo os que decidem.

### 5. Um defeito de entrega, pego antes de sair (§BB)

O pacote de fonte desta rodada quase saiu com `android/keystore.properties` dentro —
o arquivo que tem **as duas senhas da chave de assinatura**. A lista de exclusões do
empacotador novo filtrava por extensão (`*.keystore`, `*.jks`) e o arquivo é
`.properties`. Foi pego pela comparação da lista de arquivos do ZIP novo com a do ZIP
anterior: apareceu um arquivo que ninguém escreveu nesta rodada.

Corrigido com duas barreiras no empacotamento (nome **e** conteúdo), e a barreira de
conteúdo foi **testada contra o arquivo real** — ela aponta o arquivo e aborta. Os
ZIPs públicos anteriores (1.0.0 e 1.1.8) foram conferidos: **nenhum** vazou. O pacote
de fonte agora é gerado por script (`lunaria-build/empacotar-fonte.sh`), não mais à
mão.

## Rodada 1.1.10 — a trilha passa a contornar a metade do caminho (19/09/2026)

### 1. O buraco que sobrou da 1.1.9

A trilha nativa diz até onde o arranque chegou **antes** do JavaScript. A parte mais
provável de um fechamento silencioso fica **depois**: banco, cofre, bloqueio, tema,
primeira tela. Se o processo morre ali sem exceção, a trilha parava em `4/5 tela
criada` sem dizer o quê. As migalhas do JavaScript existiam, mas moram no
`react-native-mmkv` — só o próprio JavaScript lê, e para ler é preciso o aplicativo
**abrir**. Evidência existente e inalcançável.

### 2. O que entrou

Uma ponte mínima (`TrilhaJsModule` + `TrilhaJsPackage`, registrados **dentro de
try/catch**) para o JavaScript gravar na **mesma** trilha nativa, por duas vias
independentes: o arquivo (sobrevive à morte do processo e sai do aparelho pela pasta
Downloads) e as migalhas do relatório na tela. São **oito etapas**, do porteiro até
a lista de conversas aparecer de fato, mais linhas de falha com o mesmo prefixo.

Não foi usado `expo-file-system` de propósito: ele é um dos módulos sob suspeita, e
uma trilha que depende do módulo investigado falha exatamente quando serve.

### 3. Verificação desta rodada (executada nesta máquina)

| item | resultado |
| --- | --- |
| Testes de lógica | **158 de 158** (eram 145) |
| Testes de renderização | **92 de 92** em **13 suítes** (eram 86 em 12) |
| `npx tsc --noEmit` | sem erros |
| `npx eslint` | sem erros |
| Compilação do Kotlin novo | **BUILD SUCCESSFUL** em 6m 7s (`:app:compileReleaseKotlin`) |
| Classes novas geradas | `TrilhaJsModule.class`, `TrilhaJsPackage.class` |

### 4. O que continua **não** provado

- que a ponte responde no aparelho: o registro de módulo nativo na arquitetura nova
  só se verifica ligando o aplicativo;
- que o aplicativo abre no A05s. Continua sendo a pergunta sem resposta.

**O que está provado**, por teste: sem a ponte, ou com a ponte falhando, a abertura
não muda e nada é lançado. No pior caso não há evidência nova — e nenhum caminho
novo de falha. Os itens **18 a 25** do `CHECKLIST_APARELHO.md` são o que decide.

## Rodada 1.1.11 — a evidência podia chegar pela metade (19/09/2026)

### 1. Um defeito meu, encontrado lendo o que eu tinha acabado de escrever

Duas origens de evidência gravavam o **mesmo** arquivo em Downloads, cada uma na sua
thread: a colheita da abertura anterior (a **trilha**) e o histórico do Android (o
**motivo**, inclusive falha nativa). As duas abriam o arquivo em modo "escrever do
começo" — então **a última apagava a primeira**, sem ordem garantida. Numa abertura
depois de uma falha, o Hamura podia receber o motivo sem a trilha, ou a trilha sem o
motivo: metade da história.

### 2. O conserto

Um registro de seções em memória e **uma única** função de gravação (`publicar`,
com trava): quem publica entrega a sua seção, e a função regrava o arquivo
**completo** com tudo o que já foi publicado nesta abertura. A ordem de chegada deixa
de importar; o pior caso passa a ser "escreveu duas vezes a mesma coisa".

A colheita virou uma só (lê o histórico + colhe a trilha + monta um relatório único,
com o motivo primeiro e a trilha depois), e o segundo coletor saiu do
`MainApplication`.

### 3. Verificação desta rodada (executada nesta máquina)

| item | resultado |
| --- | --- |
| Testes de lógica | **163 de 163** (eram 158) |
| Testes de renderização | **92 de 92** em 13 suítes |
| `npx tsc --noEmit` / `npx eslint` | sem erros |
| Compilação do Kotlin | **BUILD SUCCESSFUL** em 3m 1s |

Seis testes prendem o arranjo novo — incluindo um que exige que
`gravarPublico(app, ARQUIVO_PUBLICO` apareça **exatamente uma vez** no arquivo. Um
teste antigo falhou ao fazer esta mudança e foi reescrito para prender o arranjo
novo (não apagado).

### 4. O que continua **não** provado

O Kotlin não roda aqui: não há emulador nem aparelho. A prova é estrutural (a forma do
código, presa por teste), não comportamental — e isso está escrito com essas palavras
no `TEST_REPORT.md` (§13). **A causa-raiz do fechamento continua desconhecida**, e os
itens 18 a 25 do `CHECKLIST_APARELHO.md` seguem sendo o que decide.

### 5. Correção de uma afirmação imprecisa (honestidade da entrega)

Conferindo o que a entrega promete, encontrei na `MATRIZ_DE_CRITERIOS.md` a
afirmação "criptografia real de conversas, memória e imagens privadas". As imagens
**são** cifradas (cofre `.lunaenc`); as **conversas e a memória não são** — vivem em
claro no banco e no MMKV da pasta privada, protegidas pelo cofre do Android e pela
porta de bloqueio, mas não pela Lunaria. A linha foi corrigida na matriz e o escopo
real passou a estar escrito, item por item, no guia da entrega
(`GERACAO_DE_IMAGEM_E_BLOQUEIO.md`, seção 4).

**Por que não implementei nesta rodada**: o mecanismo é viável e está mapeado (cifra
síncrona, chave com acessador síncrono, tipo de coluna do drizzle), mas a busca de
mensagens é SQL `LIKE` sobre o próprio texto — cifrar a coluna quebraria a busca em
silêncio sem refazê-la —, as conversas existentes estão em claro e exigem migração
com releitura verificada, e **nada disso seria verificável aqui**: o aplicativo não
executa neste ambiente, e uma camada nova de dados contaminaria o diagnóstico em
curso (não daria para saber se a próxima falha é o defeito antigo ou a camada nova).

Ordem decidida: primeiro o aplicativo **abrir**; depois a cifra do texto, com a busca
refeita e a migração verificada. A pendência está registrada também no conjunto de
testes, como um teste marcado para ser feito (aparece como "skip").


---

## Rodada 1.1.12 — o texto das conversas e da memória passou a ser cifrado (19/09/2026)

**O que era.** Na 1.1.11 eu declarei a lacuna em vez de maquiar a matriz (§BE): só
as **imagens** eram cifradas. O texto das conversas (coluna `swipe`, banco SQLite) e
a memória de pesquisa (MMKV) ficavam **em claro** no disco, protegidos pelo cofre de
arquivos do Android e pela porta de bloqueio, mas não pela Lunaria.

**O que passou a ser.** Cifra AES-256-GCM no próprio texto, com a **mesma** chave
que já protegia as imagens (envelopada pela senha, guardada no armazenamento seguro
do sistema). Nada de chave nova, nada de senha guardada, nenhuma migração de banco:
a coluna continua `TEXT` e o que muda é o conteúdo (passa a ser `enc:v1:<base64>`).
O caminho escolhido foi um **tipo de coluna** no `db/schema.ts`, que cobre todas as
leituras e gravações de uma vez — as telas não foram tocadas.

**A armadilha que exigiu trabalho de verdade.** A busca de mensagens era um `LIKE`
do SQL sobre o texto. Sobre texto cifrado ele não acharia **nada**, sem erro, sem
aviso: a busca morreria calada. Ela foi reescrita para decifrar durante a varredura,
e há teste provando as duas metades (que o `LIKE` acharia zero e que a busca nova
acha). Preço declarado: teto de 5000 mensagens por pesquisa.

**O que foi decidido para não derrubar a abertura.** Com o cofre fechado, ler texto
cifrado devolve um aviso honesto em vez de uma exceção de propósito: exceção no meio
da leitura do banco, no arranque, é o defeito que estamos caçando. E esse aviso
**nunca** é gravado por cima do conteúdo (a gravação é recusada) — senão a leitura
vira perda de dado. Na memória, cofre fechado não lê e **não grava**.

**Um defeito achado na revisão, depois de a cifra estar pronta.** A memória de
pesquisa é hidratada uma vez, na avaliação do módulo: abrindo **bloqueado**, a
hidratação acontece com o cofre fechado e o estado nasce vazio — e a primeira nota
nova seria gravada por cima de todas as antigas. Não é falha de cifra, é de ciclo de
vida, e atingiria justamente quem usa senha. Correção dupla, com teste que reproduz
o cenário: (1) o adaptador só libera uma chave para gravação depois de uma leitura
que viu o conteúdo — gravar sem isso é ignorado e o disco não muda; (2) ao
desbloquear, a memória é relida, o que restaura o conteúdo e libera a chave.

**Estado dos testes (automatizados, neste ambiente):** `test:unit` **173/173**
(10 novos; o `skip` da 1.1.11 virou teste real, sem remover nada) e `test:render`
**106/106** em 14 suítes (14 novos em `tests/render/cifra-texto.test.ts`, incluindo
o caso que reproduz o defeito de ciclo de vida descrito acima), `tsc` sem erro e
`eslint` sem erro (os 58 avisos são anteriores a esta rodada).

**Pendente no aparelho:** item 26 do `CHECKLIST_APARELHO.md` (abrir o arquivo do
banco no A05s e **não** encontrar a palavra de teste), 27 (a busca continua
achando) e 28 (conversa antiga abre com a proteção ligada). Nada disso foi medido
no aparelho — o que este relatório afirma é o que o código faz e o que os testes
automatizados mostram.

**O fechamento silencioso continua sem causa identificada.** Esta rodada não mexeu
nele. O instrumento segue sendo o relatório gerado no aparelho: `trilha-abertura.txt`
dentro do aplicativo e `lunaria-ultimo-erro.txt` em Downloads, com o motivo da morte
e a trilha etapa por etapa (correção da 1.1.11: uma gravação só, sem duas partes se
apagando). A prova continua sendo o teste no A05s — itens 18 a 25.

## Rodada 1.1.13 — a causa do fechamento na abertura (20/09/2026)

**Ponto de partida:** a 1.1.12 **não estava corrigida**. O Hamura instalou no A05s,
conferiu por ADB (`versionName=1.1.12`, `versionCode=14`) e o aplicativo fechou na
abertura com a mesma exceção de sempre. Esta rodada obedeceu à diretriz: primeiro o
diagnóstico determinístico da carga de rotas, sem build novo, sem esconder o erro com
`try/catch`, sem `ErrorBoundary` por cima e sem tirar nenhuma funcionalidade.

### A causa

Um **ciclo de importação** que nasceu junto com a funcionalidade de bloqueio:

```
lib/state/AppLock.ts  →  lib/state/TTS.ts  →  lib/state/Chat.ts  →  lib/state/AppLock.ts
```

O `app/_layout.tsx` — a **raiz do contexto**, o primeiro nó que o Expo Router
qualifica na abertura — importa o `AppLock`. Ao avaliar essa cadeia, o Metro chegava ao
`TTS.ts` com o `Chat.ts` ainda "em avaliação"; nessa situação, toda importação do
`Chat` vale `undefined`, e o `useInference.subscribe(...)` que fecha o `TTS.ts` (linha
99) lançava `Cannot read property 'subscribe' of undefined`.

O passo que faltava para entender o logcat: em produção, o Metro envolve a avaliação de
cada módulo e, quando ela lança, chama `ErrorUtils.reportFatalError` e **devolve
`undefined`**. O `loadRoute()` da rota recebeu esse `undefined` e o
`fromImport(undefined)` do `expo-router` quebrou ao desestruturar — o
`Cannot read property 'ErrorBoundary' of undefined` que aparecia no telefone. Ou seja:
a chave da rota estava no bundle (conferido); o que faltava era o **grafo de importação
estar correto**.

### A correção

- `lib/state/EventosBloqueio.ts` (novo): barramento sem nenhuma importação.
- `AppLock` deixou de importar o `TTS`; ao bloquear, avisa pelo barramento.
- `TTS` ouve o barramento para parar a leitura — comportamento igual ao de antes.
- Ciclo eliminado: o grafo de 238 arquivos não tem mais nenhum ciclo de avaliação.

### A segunda parte: `app/` só com rotas

| | 1.1.12 | 1.1.13 |
| --- | --- | --- |
| arquivos em `app/` | 118 | 28 |
| rotas descobertas pelo Expo Router | 117 (incluindo componentes e pedaços de tela) | 27 (só telas) |

O código foi para `src/components/**` e `src/screens/**`; cada rota em `app/` é um
arquivo de uma linha que reexporta a tela. As rotas e a navegação continuam idênticas
— inclusive as quatro sub-rotas que o aplicativo abre de verdade
(`AppSettingsScreen/ChatStyleSelector`… ver `BUGS_FOUND.md` §BG).

### Verificação (ambiente, não aparelho)

```
tests/render/raiz-carrega.test.tsx     3/3   (novo: carrega a raiz do contexto)
tests/render/bloqueio-silencia.test.ts 2/2   (novo: o bloqueio silencia a leitura)
tests/arquitetura-rotas.test.mjs       4/4   (novo: app/ só rotas + sem ciclo no grafo)
render (16 suítes)                   111/111
unitários                            177/177
tsc --noEmit                          limpo
eslint (app db lib src)              0 erros
```

### O que falta, sem enfeite

**O teste que decide é o do A05s.** A 1.1.13 é a candidata; ela só passa a ser
"corrigida" quando o Hamura abrir no telefone e ver a tela aparecer. Se ainda fechar, a
trilha de diagnóstico do aplicativo (`lunaria-diagnostico.txt`) e o logcat continuam
sendo o caminho, e a diferença de comportamento entre a 1.1.12 e a 1.1.13 é informação
nova para a próxima rodada.

### A entrega desta rodada, conferida por dentro

| o que | valor |
| --- | --- |
| APK | `Lunaria-1.1.13-arm64-release.apk` — 66.836.927 bytes |
| SHA-256 | `a558df0df469651326d08d6bd4ab8c4e91651dae8d0bca988592c8a7c1b8c5fb` |
| versão gravada dentro do pacote | `versionName=1.1.13`, **`versionCode=17`**, `br.aurora.luna.lunaria.next` |
| assinatura | `CN=Lunaria` — digest SHA-256 `c0271509…5719a`, **o mesmo desde a 1.0.0** (instala por cima) |
| compilação final | `BUILD SUCCESSFUL in 16m 54s` (952 tarefas: 53 executadas, 899 já atualizadas) |
| ZIP de fonte | `Lunaria-1.1.13-source.zip` — 467 arquivos, sem chave e sem senha |

Conferido **dentro** do APK, não pelo nome do arquivo: 48 bibliotecas `.so` arm64,
`res/RT.gguf` presente, `allowBackup=false`, `fullBackupContent=false` e
`dataExtractionRules` no manifesto; no bundle Hermes estão `avisarBloqueio`,
`aoBloquear`, `stopTTS`, `useInference`, `Gerar imagem`, `horde`, `pollinations`,
`enc:v1:`, `lunaria-texto-v1` e `Bloquear agora` — e o identificador do provedor
corrigido (`Lunaria:1.1.13:`, com **zero** ocorrências de `Lunaria:1.1.12:`), além de
**26 chaves de tela** no mapa de contexto do roteador.

**Foram três builds nesta rodada**, e nenhum deles foi dado como bom só porque o Gradle
disse `BUILD SUCCESSFUL`:

1. **14:33 → 14:41 (abortado).** Uma mudança de código (`app/index.tsx` virou rota fina
   e sua lógica foi para `src/screens/HomeScreen.tsx`) aconteceu **depois** do início.
   Pela regra da maratona de builds, build com código alterado depois do start não vale.
2. **14:42:06 → 15:02:27, código 15.** Ficou pronto, passou em todas as verificações de
   pacote — e tombou na **suíte de testes**: `tests/imageprovider.test.mjs` mostrou que
   `lib/imagegen/ImageProviders.ts` anunciava o aplicativo como `1.1.12` ao provedor de
   imagem (o teste compara esse texto com a versão do `package.json`; era assim desde
   que o número foi fixado à mão). Defeito real, ainda que pequeno.
3. **15:25:08 → 15:29:10, código 16 — o entregue.** `CLIENT_AGENT` corrigido para
   `1.1.13` e reconstrução. A checagem por data
   (`find app src lib db index.js *.config.js -newermt "2026-09-20 15:25:08"`) devolve
   **nenhum arquivo**: nada que entra no bundle mudou depois do início deste build, nem
   o `package.json` — que agora diz 1.1.13, como o `app.config.js`.

4. **15:52:38 → 16:09:14, código 16 — a reconstrução final.** Feita **depois** de
   todo o trabalho fechado (experimento causal, prova do injetor, suítes, congelamento),
   como pedido: o artefato passou a ser gerado por último. Build **frio** (a pasta
   `build/` e a `.cxx` haviam sido apagadas quando o disco foi liberado) e
   `BUILD SUCCESSFUL in 16m 34s`. O APK saiu com as mesmas propriedades de conteúdo do
   anterior — mesmo tamanho, mesmo `versionCode`, mesmo certificado, mesmo bundle — e
   outro sha, porque o Gradle grava carimbo de tempo. O verificador comparou os dois
   APKs linha a linha: **a única diferença foi o caminho do arquivo e o sha**.

5. **16:42:32 → 16:59:28, correção de cota — o entregue.** Depois da medição ao vivo
   dos provedores apareceu um defeito de mensagem: o erro `500` da Pollinations é, por
   dentro, um `429` de limite de uso, e o aplicativo dizia "indisponível" (§ BG em
   `BUGS_FOUND.md`). Corrigido, com três testes novos, `versionCode` de **16 para 17** e
   reconstrução. Checagem por data no fim: nenhum arquivo do bundle mudou durante o
   build.

Armadilha registrada para o histórico: o **vigia do APK copiou, no primeiro minuto do
build final, o APK do build anterior**, que ainda estava no diretório de saída — ele
confere só o `versionName`, que era o mesmo (1.1.13). O arquivo certo foi copiado à mão,
conferido (`versionCode=16`, sha `ba0c3554…`, depois substituído pela reconstrução
final) e a lição está em
`lunaria-build/RESTAURAR_AMBIENTE.md`: **apagar o APK do diretório de saída antes de
iniciar o build**.

---

## Verificação final antes da entrega — experimento causal e trava do defeito de abertura

Depois do código 16 (build 4), e antes de gerar qualquer arquivo final, foi
fechado o que faltava da causa-raiz:

| Passo | Resultado |
|---|---|
| Experimento causal (aresta antiga reintroduzida só como controle) | `LUNARIA_ROUTE_LOAD: contextKey=./_layout.tsx … loaded=LANCOU(Cannot read properties of undefined (reading 'subscribe'))` e `SEM_MODULO=1` |
| Mesmo experimento com o código entregue | `contextKey=./_layout.tsx … loaded=objeto(default=function)` e `TOTAL=28 SEM_MODULO=0` |
| Instrumentação temporária | apagada (nenhum arquivo `_exp-*`/`_diag-*` na árvore) |
| Trava permanente | `tests/render/rotas-carregam.test.tsx` — 29 testes (28 rotas + composição) |
| Suítes na árvore congelada | render **142/142** (17 suítes), lógica **180/180**, `tsc --noEmit` limpo, `eslint` 0 erros |
| APK do código 16 (build 4) × código de então | `cmp` byte a byte do `lib/state/AppLock.ts` contra o ZIP-fontes: **idêntico** |

Detalhe completo em `TEST_REPORT.md` §16.7 e §16.8.

---

## Verificação final (2) — busca medida e pacote reexecutado

Depois do build 5 (código 17), dois itens que ainda eram promessa viraram medição:

| item | antes | agora |
| --- | --- | --- |
| teto de 5.000 mensagens na busca | projetado (lido do código) | **medido**: pior caso 5.000 varridas em ~294 ms (média de 3 rodadas, x86), teto de 100 achados confirmado exato |
| pacote de fonte entregue | conferido por somas | **extraído do zero e testado**: 180/180 de dentro do ZIP |

Registro honesto: a primeira versão do instrumento da busca estava sem o `break`
interno (`Chat.ts:722`) e sugeriu um defeito que não existe. Corrigido o instrumento,
o resultado é o da tabela. Detalhes em `TEST_REPORT.md` §16.11.

---

> **Retomada de trabalho:** o estado atual, as regras ativas (versão congelada, um projeto só,
sem build automático) e a próxima etapa única estão em `WORK_PROGRESS.md`.

---

## Rodada de 20/09/2026 (tarde) — seed da AI Horde: mesmo 1.1.13, sem versão nova

**Estado:** o aplicativo **abre corretamente no A05s** (validado por você). O defeito
restante era um só, na geração de imagem: a Lunaria mandava `params.seed` como
**número** e a API da AI Horde exige **texto** — o serviço respondia
`params.seed: "364056 is not of type 'string'"`.

| item | valor |
| --- | --- |
| correção | `lib/imagegen/ImageProviders.ts` — `seedDaHorde()` + validação antes do request |
| versão | **1.1.13, versionCode 17 — sem incremento**, por ordem expressa |
| APK | 66.837.431 bytes, sha `4865463ec55c40643e8f099d8400e4b18a558f1f333467613693df200232a577` |
| certificado | `c0271509…5719a` — o mesmo desde a 1.0.0 |
| build | 17:24:45 → 17:41:32, `BUILD SUCCESSFUL in 16m 44s` (952 tarefas: 36 executadas, 916 já atualizadas) |
| congelamento | nenhum arquivo do bundle mudou durante o build |
| testes | lógica **181/181**; render **142/142** (a trava do startup: 29/29); `tsc` limpo; `eslint` 0 erros |
| o que NÃO mudou | startup, arquitetura de rotas, interface da seed, seed aleatória, seed manual, "Tentar de novo", resolução, estilos, Pollinations e todos os demais provedores |

Detalhe técnico e payload sanitizado: `BUGS_FOUND.md` §BO e `TEST_REPORT.md` §16.12.

## Rodada de 21/09/2026 — botão "Ativar bloqueio" e a imagem que não aparecia (mesmo 1.1.13)

**Estado:** os dois defeitos relatados no aparelho estavam ligados à mesma coisa — o
cofre de imagens **não tinha chave nenhuma** quando não havia senha configurada, e a
tela de bloqueio não dizia nada sobre o próprio formulário.

| item | valor |
| --- | --- |
| defeito 1 | "Ativar bloqueio" parecia morto: a tela não passava estado de validação ao botão, não havia motivo escrito e falha de Keystore não era capturada |
| correção 1 | `validarAtivacao()` em `lib/security/LockPolicy.ts` manda no botão ao vivo: 6+ caracteres nos dois campos, iguais, sem espaço nas pontas; senão fica apagado **com o motivo** ("Use pelo menos 6 caracteres." / "As senhas não coincidem." / …). PIN e senha alfanumérica valem. Tocar agora tem `try/catch` e o erro real aparece na tela |
| defeito 2 | imagem não aparecia com "Não foi possível gerar a imagem." + "Cofre bloqueado…" |
| etapa que falhava | **VAULT_SAVE** (gravar cifrado) — o provedor respondeu, a imagem veio; o cofre recusou por não ter chave |
| correção 2 | chave do aparelho (`lunaria-dek-device`, Keystore, DEK de 32 bytes): `ensureDeviceVault()`, promoção da MESMA chave ao ativar a senha, rebaixamento ao desativar (nada é destruído); etapas nomeadas PROVIDER_REQUEST / PROVIDER_RESPONSE / IMAGE_DOWNLOAD / VAULT_SAVE / IMAGE_READ / IMAGE_DISPLAY |
| seed da Horde | segue **texto** (`"364056"`) — não foi tocada |
| versão | **1.1.13, versionCode 17 — sem versão nova** |
| APK | 66.842.687 bytes, sha `5bc2d0006a97e6a1abbaad4a468fb71579bd13fb88e3df125e0c4f316f753861` |
| certificado | `c0271509…5719a` — o mesmo desde a 1.0.0 (instala por cima) |
| build | build frio, 04:39:30 → 05:06:43 UTC, `BUILD SUCCESSFUL in 27m 10s` |
| conferência | diff contra o APK anterior: só tamanho, sha e bundle (6.666.344 contra 6.661.088 B); marcadores novos achados DENTRO do bundle entregue |
| testes | lógica **193/193**; render **151/151** (19 suítes); `tsc` limpo; `eslint` 0 erros; ZIP de fonte refeito e reexecutado: **193/193** |
| entrega | `SHA256.txt` regenerado: **6/6 OK** |
| o que NÃO mudou | startup/rotas, seed, Pollinations e demais provedores, seed aleatória/manual/retry, estilos, aparência, histórico, memória, GGUF, voz, TTS, conversa, ajustes |
| pendente (só o aparelho responde) | itens **32, 33 e 34** do `CHECKLIST_APARELHO.md` |

Detalhe técnico: `BUGS_FOUND.md` §BP e `TEST_REPORT.md` §16.13 e §16.14.

---

## RODADA DE 21/09/2026 (segunda do dia) — a credencial da AI Horde e o bloqueio que não bloqueava

**Estado:** dois defeitos relatados no aparelho, confirmados com o serviço real. O da
imagem **não era mais a seed** (isso está resolvido): passou a ser **credencial**. O do
bloqueio era o **estado interno discordando do que a tela mostrava**.

| item | valor |
| --- | --- |
| defeito 1 | "O provedor recusou a credencial usada." em toda tentativa de imagem |
| causa medida | havia **chave guardada que a AI Horde não conhece** e o app a repetia em cada pedido. Contra a API real: `0000000000` → **202**; `abc123` → **401 InvalidAPIKey**; `Bearer …` → 401; sem cabeçalho → 400. Faltavam: conferência ao salvar, indicação de qual chave estava ativa e caminho de volta ao modo gratuito |
| correção 1 | `lib/imagegen/ChaveDoProvedor.ts` (novo): normaliza (aspas, `Bearer`/`apikey:`/`token:`, espaços), mascara, confere no `GET /find_user` antes de salvar (chave recusada **não é gravada**), e a recusa na geração cai **uma vez** para a chave anônima **com aviso escrito na tela** e remoção da chave ruim |
| modo gratuito | botão **"Usar modo gratuito (remover chave)"** + linha do modo em vigor nas duas telas; sem chave, o pedido sai com a chave anônima |
| defeito 2 | "Bloquear agora" sem efeito e "Ao sair" sem efeito |
| causa | o **cofre** (durável) e a marca "ligado" (MMKV, que pode voltar vazia) discordavam; a tela mostrava o cofre pronto e `lockNow` tinha `return` **silencioso** quando o estado dizia "não configurado". Ainda: o `set({locked:true})` era o **último** passo (exceção nos efeitos deixava o app aberto) e "ao sair" só bloqueava na volta |
| correção 2 | `lib/state/AppLock.ts`: o **cofre decide** o "ligado" (preferência reescrita para concordar); `lockNow` muda o estado **primeiro** (fail-closed), isola os efeitos e **responde** quando não pode bloquear; `app/_layout.tsx` bloqueia **na saída** com a política "ao sair"; `markStartupOk()` passou a ser chamado no fim da abertura |
| seed da Horde | segue **TEXTO** (`"524766"`), provado nos testes e na prova ao vivo — não foi tocada |
| prova ao vivo | chave inválida → `401 InvalidAPIKey` → queda para anônima → **86.276 bytes WebP, 39 s**, fila anônima (148→142). Medição crua em `lunaria-build/logs/medicao-credencial-2026-09-21.txt` |
| versão | **1.1.13, versionCode 17 — sem versão nova** |
| versão no APK | 1.1.13 / versionCode 17 (conferido pelo `apkanalyzer` dentro do pacote) |
| certificado | `c0271509…5719a` — o mesmo desde a 1.0.0 (instala por cima); assinatura v2 confirmada pelo `apksigner` |
| build | FRIO de verdade (o `/opt` foi apagado com o ambiente: sem cache de transform nem de build): 06:06:13 → 06:32:05 UTC de 21/09, **BUILD SUCCESSFUL in 25m 49s**, 952 tarefas (810 executadas, 142 do cache), SEM R8 (`minify`/`shrinkResources` false) |
| APK | **66.859.835 bytes**, `fafa66dbf1c3423deccf9928612fb7ef17d64613d86db2a553c648325f8ce458` |
| bundle (o que o aparelho carrega) | 6.683.492 bytes — **+17.148** em relação ao da rodada anterior; contém os literais desta rodada (`find_user`, `LOCK_NOW_TRIGGERED`, `AUTO_LOCK_POLICY_APPLIED`, `Conferir e salvar chave`, `Usar modo gratuito`, `A imagem saiu pelo modo gratuito`) e o da rodada passada (`lunaria-dek-device`) |
| comparação com a rodada anterior | tudo o que já funcionava continua no pacote; nenhuma rota antiga voltou (0 `components/...` roteadas) |
| ZIP de fonte | refeito nesta rodada com as docs atualizadas (478 arquivos, nenhuma chave no pacote — conferido pelo empacotador). Tamanho e soma vigentes ficam no `SHA256.txt` da pasta de entrega, porque editar uma doc muda o ZIP |
| entrega | `SHA256.txt` regenerado: **6/6 OK** (`sha256sum -c`)" 
| testes | lógica **208/208** (era 193); render **174/174** (22 suítes, era 151/19); `tsc` limpo; `eslint` 0 erros |
| testes novos | `chave-provedor.test.mjs` (10), `imageprovider` 34→39, `imagem-chave.test.tsx` (8), `bloqueio-estado.test.tsx` (9), `bloqueio-ao-sair.test.tsx` (6) |
| o que NÃO mudou | startup/rotas, seed-tipo, provedores oferecidos, Pollinations, GGUF/local, voz, TTS, conversa, memória, banco, criptografia, cofre, biometria, tema, aparência, histórico, proporções, estilos, ajustes, retry |
| pendente (só o aparelho responde) | itens **35, 36 e 37** do `CHECKLIST_APARELHO.md` — `REAL_DEVICE_VALIDATION` destes pontos segue **NOT_TESTED** |

Detalhe técnico: `BUGS_FOUND.md` §BQ e `TEST_REPORT.md` §16.15. Relatório da rodada
com as sete respostas: `entrega/RELATORIO_RODADA_21-09_CREDENCIAL_E_BLOQUEIO.md`.

### Conferência final da entrega (retomada depois de uma queda da interface)

O fechamento foi retomado do ponto exato e **verificado antes de agir** — nada de
rebuild, nada de versão nova, nada descartado:

| checagem | resultado |
| --- | --- |
| o processo anterior terminou? | sim — `--- exit=0 ---` (build) e `ENTREGA_OK` (fechamento); nenhum processo pendente |
| build refeito? | **não** — o APK é o mesmo do build desta rodada (`fafa66db…`) |
| APK x ZIP | APK **66.859.835 B** `fafa66db…` · ZIP **7.864.873 B** `9dbcf4d2…` (478 arquivos, sem chave) |
| somas | `sha256sum -c SHA256.txt` → **6/6 OK** |
| APK por dentro | `versionName=1.1.13`, `versionCode=17`, `allowBackup="false"`, `dataExtractionRules` presente, assinatura v2 verdadeira, certificado `c0271509…5719a` |
| DOCS | as do ZIP são **idênticas** às soltas na pasta de entrega |
| corrigido nesta conferência | o `CHECKLIST_APARELHO.md` mandava instalar o APK **antigo**; agora aponta para o desta rodada (o ZIP foi refeito com a correção — só doc, nenhum código tocado) |
| empacotamento blindado | o palco do ZIP era criado em `/tmp` (**tmpfs**, filesystem diferente do projeto) e o `tar` não usava `--hard-dereference` — uma árvore com hard link faria o `tar -x` chamar `link()` e falhar com o `Invalid cross-device link` que apareceu. Agora o palco e a conferência ficam no **mesmo filesystem** da origem, o `tar` desreferencia hard link (vira arquivo comum) e o script **falha de propósito** se sobrar qualquer hard link no palco. O empacotador também passou a conferir, no ZIP fechado, que nada pesado/regenerável entrou (`node_modules`, `android/app/build`, `android/build`, `.gradle`, `.expo`, `local.properties`) e que os arquivos de reconstrução estão **todos** presentes (`package.json`, `package-lock.json`, `app.config.js`, `babel.config.js`, `metro.config.js`, `tsconfig.json`, `index.js`, `app/`, `src/`, `android/`, `assets/`, `lib/`, `db/`, `tests/`) |

---

## RODADA DE 21/09/2026 (terceira do dia) — o 403 que era kudos, não credencial

**Estado:** a Lunaria abre, bloqueia, envia a seed como texto e o pedido chega ao
servidor. O defeito restante era de **classificação e de tamanho**: pedido grande
demais para a fila anônima sendo tratado como problema de chave.

| item | valor |
| --- | --- |
| defeito 1 | HTTP 403 de **kudos** aparecendo como "O provedor recusou a credencial usada." |
| causa | `errorFromStatus` tratava 401 e 403 no mesmo balde e o corpo da resposta era lido mas não consultado. Na Horde, 403 tem duas causas: kudos e credencial |
| correção 1 | marcas de kudos no corpo (`rc: KudosUpfront`, "heavy demand", "work budget", "first-order-equivalent", "requires X kudos") → `kind: 'kudos'`, mensagem **"Esta configuração exige kudos no AI Horde."**, com o número de kudos quando vem, e os botões "Usar configuração gratuita" / "Tentar novamente" / "Editar descrição" (+ Ajustes). Credencial de verdade agora diz **"Credencial inválida."** |
| correção 1b | a segunda tentativa automática com a chave anônima **não acontece** em recusa por kudos (não resolvia nada e repetia o 403) |
| defeito 2 | preset grande no modo gratuito sendo enviado como está e recusado |
| correção 2 | `lib/imagegen/LimitesDaHorde.ts` (novo, puro): modo gratuito adapta **antes** do envio — 512x768→384x576, 768x512→576x384, 640x640→512x512, 512x640→512x384, 768x448→576x320; passos com teto de 30; fora da tabela reduz até 576 em múltiplos de 64. **Com chave, o tamanho pedido é respeitado** (não se presume kudos) |
| defeito 3 (achado na medição) | preset **Cinema 768x432** → a Horde responde **HTTP 400** (432 não é múltiplo de 64). Nunca funcionou, em modo nenhum |
| correção 3 | Cinema passa a **768x448** (medido 202) |
| otimização pedida | `unlock` derivava PBKDF2-SHA256 **duas vezes** (150.000 iterações cada). Agora deriva **uma** (`unlockVaultSeCorreto`), com o mesmo PBKDF2, mesmo sal e mesmas iterações — nada afrouxado. `lockNow` e o ouvinte do AppState foram medidos e não têm espera/I-O: **não** foram tocados |
| prova real | recusa real 403 (`rc: KudosUpfront`, 13.68 kudos) classificada certo pelo código do app; e geração real anônima de 512x768 saindo **384x576** → 69.084 bytes WebP em 35 s, com o aviso do ajuste na tela |
| seed | segue **TEXTO** em todos os caminhos (ajustado, com chave, reenvio, ausente) |
| versão | **1.1.13, versionCode 17 — sem versão nova** |
| testes | unidade **227/227** (era 208) · render **184/184** (24 suítes, era 174/22) · `tsc` limpo · `eslint` 0 erros |
| o que NÃO mudou | provedor (nada de troca), cofre, senha/PIN, criptografia, bloqueio, startup/rotas, memória, conversa, voz, TTS, GGUF, aparência, histórico, proporções (só o ajuste do modo gratuito), retry |
| pendente (só o aparelho responde) | itens **35 a 40** do `CHECKLIST_APARELHO.md` |

Detalhe técnico: `BUGS_FOUND.md` §BR e `TEST_REPORT.md` §16.16.

### Entrega desta rodada (mesma 1.1.13, versionCode 17)

```
APK   Lunaria-1.1.13-arm64-release.apk   66.868.595 bytes
      sha256 c51f867201051c80c60a10c82593c7a6bccfe2a2c2f954d18bbc3932ee68b241
      build BUILD SUCCESSFUL em 28m29s · bundle Hermes 6.692.252 bytes (+8.760)
      certificado c0271509… (o mesmo de antes: instala por cima)
ZIP   Lunaria-1.1.13-source.zip          soma e tamanho no SHA256.txt da pasta de entrega
      (nao ha hash do proprio ZIP aqui de proposito: o arquivo muda quando o doc muda)
      SHA256.txt da pasta: 22/22 OK · ZIP == fonte solta nas 7 amostras centrais
```

Código novo provado dentro do bundle (literal que não existia antes):
*"Esta configuração exige kudos no AI Horde."*, *"Modo gratuito: resolução
ajustada"*, *"Credencial inválida."*, *"Usar configuração gratuita"*, `KudosUpfront`,
`768x448`, `heavy demand`, `work budget`.

---

## RODADA DE 21/09/2026 (quarta do dia) — splash infinita no retorno, com o bloqueio ligado

**Estado:** com a senha ativa, sair da Lunaria (bloqueio automático) e voltar prendia o
aplicativo **para sempre na tela do logo**. A tela de senha nunca aparecia.

| item | valor |
| --- | --- |
| defeito | splash infinita ao voltar bloqueado; a tela de senha não chegava a aparecer |
| causa | quem escondia a splash era a `HomeScreen` (`SplashScreen.hideAsync()` no fim de `startLunaria`), e ela só existe **dentro do `<Stack>`** — que o portão não monta enquanto `locked`. A tela de senha estava montada o tempo todo, **atrás** da splash |
| arquivo da causa | `src/screens/HomeScreen.tsx` (quem escondia) + `app/_layout.tsx` (o portão que não monta o Stack bloqueado) |
| correção | `app/_layout.tsx`: `esconderSplash(motivo)` chamado no **fim da hidratação** e em **cada volta ao primeiro plano** (`AppState ACTIVE`). `locked=true` → tela de desbloqueio; `locked=false` → aplicativo. Nunca `locked=true` → splash |
| estado que não terminava | (a) `SPLASH_HIDDEN` nunca era pedido; (b) `ready` podia ficar falso para sempre se `init()` estourasse |
| correção do estado | `lib/state/AppLock.ts`: `markHydrationFailed(error)` fecha a hidratação **mesmo em falha** (`ready=true`, `locked=true`) — fail-closed é *aparecer bloqueado*, não *desaparecer* |
| instrumentação | marcas pedidas na trilha de diagnóstico: `SPLASH_VISIBLE`, `AUTH_HYDRATION_STARTED`, `AUTH_HYDRATION_COMPLETE`, `LOCK_STATE`, `SPLASH_HIDE_REQUESTED`, `SPLASH_HIDDEN`, `UNLOCK_SCREEN_REQUESTED`, `UNLOCK_SCREEN_MOUNTED`, `APPSTATE_BACKGROUND`, `APPSTATE_ACTIVE`, `AUTO_LOCK_POLICY_APPLIED`, `ROUTER_READY`, `UNLOCK_SUCCESS`, `UNLOCK_FAILED` |
| prova automatizada | `tests/render/splash-retorno.test.tsx` (novo, 6 testes) rodando o **portão real** com o **estado real** (cofre, PBKDF2, verificador) |
| prova de rede | gerador continua gerando: imagem real de 82.636 bytes em 40 s, seed em texto, aviso de resolução ajustada |
| o que NÃO mudou | nada de splash removida, nada de bloqueio afrouxado, nada de criptografia, nada de desbloqueio automático, sem cronômetro decidindo estado, sem `try/catch` vazio; versionName/versionCode intactos |
| testes | unidade **227/227** · render **190/190** (25 suítes) · `tsc` limpo · `eslint` 0 erros |
| pendente (só o aparelho responde) | itens **41 a 48** do `CHECKLIST_APARELHO.md` |

Detalhe técnico: `BUGS_FOUND.md` §BS e `TEST_REPORT.md` §16.17.

### Entrega desta rodada (splash no retorno — mesma 1.1.13, versionCode 17)

```
APK   Lunaria-1.1.13-arm64-release.apk   66.870.991 bytes
      sha256 bf2087bb57b9a43a01103c72ef3cf18bb9434a5eaf2b7bb2bf321b1cf9008fa1
      build BUILD SUCCESSFUL em 26m11s · bundle Hermes com as marcas novas da trilha
      certificado c0271509… (o mesmo de antes: instala por cima)
ZIP   Lunaria-1.1.13-source.zip          soma e tamanho no SHA256.txt da pasta de entrega
SHA256.txt                               a conferência única: sha256sum -c SHA256.txt
```

Código novo provado dentro do bundle (literal que não existia antes):
`SPLASH_HIDE_REQUESTED`, `AUTH_HYDRATION_STARTED`, `AUTH_HYDRATION_COMPLETE`,
`AUTH_HYDRATION_LENTA`, `UNLOCK_SCREEN_MOUNTED`, `APPSTATE_ACTIVE`, `ROUTER_READY`,
`ROUTER_READY indisponível`.

