# Verificação da Lunaria 1.1.1 — 18/09/2026 (rodada Arena 2)

> Rodada 2 do dia: a 1.1.0 é a versão que trouxe geração de imagem e bloqueio.
> Esta rodada executou a geração **de ponta a ponta** contra o serviço real e
> corrigiu três defeitos que a rede simulada não mostrava (§2.2 abaixo).

Relatório da versão 1.0.0 preservado em `TEST_REPORT-1.0.0.md`. Aqui só entram
resultados **observados**, separando o que roda nesta máquina (automático), o
que exige emulador (não disponível aqui) e o que exige o Galaxy A05s.

## 1. Testes automatizados (executados nesta máquina — resultado real)

| Verificação | Comando | Resultado |
| --- | --- | --- |
| Camada 1 — lógica pura | `npm run test:unit` | **87 de 87** passaram, 0 falhas |
| Criptografia do cofre | `tests/crypto.test.mjs` | 10 de 10 (AES-256-GCM, PBKDF2, senha errada, senha certa, adulteração detectada, base64 próprio, UTF-8 com acentos e emoji) |
| Política de conteúdo | `tests/imagepolicy.test.mjs` | 9 de 9 (permite adulto/sensual/moda/romance; recusa explícito, menor, coerção, proibido) |
| Montagem do prompt | `tests/imageprompt.test.mjs` | 10 de 10 (proporções, 8 estilos, perfil, negativo, prévia, semente) |
| Cliente dos provedores | `tests/imageprovider.test.mjs` | 13 de 13 (fila, imagem, cancelamento, 429, 502, sem rede, não-imagem, chaves) |
| Bloqueio e migração (regras) | `tests/lock.test.mjs` | 9 de 9 (mínimo de 6, espera progressiva, teto de 5 min, plano de migração idempotente) |
| Suíte anterior (persona, pesquisa, streaming) | mesmos comandos | 26 de 26 continuam passando |
| TypeScript | `npx tsc --noEmit` | sem erros |
| ESLint | `npx eslint .` | 0 erros (32 avisos de estilo, nenhum novo de lógica) |

### Diferença entre teste com rede simulada e teste real

Os 12 testes do cliente de provedor usam um `fetch` falso **de propósito**: eles
verificam como o aplicativo reage a fila, cota estourada (429), provedor fora do
ar (502), arquivo que não é imagem e cancelamento sem depender da sorte da rede.
O que foi testado **contra os serviços reais** está na seção 2.

## 1.1 Camada 2 — testes de renderização (adicionados em 18/09, depois do APK)

Motivo: os testes acima cobrem lógica pura; nenhum deles **executava uma tela**.
Um import quebrado, um símbolo inexistente ou um hook fora de ordem só
apareceriam no aparelho. Estes renderizam componentes de verdade (módulos
nativos simulados) e rodam com `npm run test:render`:

| Arquivo | O que executa | Testes |
| --- | --- | --- |
| `tests/render/smoke.test.tsx` | ambiente de renderização | 1 |
| `tests/render/lockgate.test.tsx` | `app/_layout.tsx` (o portão) + `LockScreen` | 13 |
| `tests/render/lock-flow.test.tsx` | ciclo real de senha (Crypto + SecureVault + AppLock) | 13 |
| `tests/render/vault-flow.test.tsx` | cofre de arquivos: cifrar, gravar, ler, apagar, cofre fechado | 9 |
| `tests/render/screens.test.tsx` | telas de imagem e de bloqueio, `PrivateImage`, `ImageViewer` | 8 |
| `tests/render/chat-e-notificacao.test.tsx` | `ChatScreen` (com o botão Gerar imagem) + aviso escondido | 5 |
| | **total** | **49 de 49 passaram** |

O que passou a ser provado por execução:

- o portão **não monta o aplicativo** com o bloqueio ativo, e não mostra nada
  entre a abertura e a leitura do cofre (`ready` falso);
- tocar em **Gerar imagem** na conversa chama a rota da tela de geração;
- o ciclo de senha inteiro funciona com o código real: ativar, bloquear, errar
  (contagem + espera progressiva), acertar, trocar a senha (abrindo os arquivos
  antigos com a nova) e desligar a proteção — sempre exigindo a senha atual;
- **nenhuma senha em claro** no keychain simulado nem no armazenamento depois do uso;
- o arquivo gravado pelo cofre **não contém o conteúdo original**, dois arquivos
  iguais geram bytes diferentes (IV novo) e, com o cofre fechado, a leitura falha;
- as telas novas abrem sem quebrar e o campo de senha é mascarado.

Continua pendente e **não** é coberto por isto: biometria real, keychain real,
comportamento momento a momento da tela bloqueada, rede e o A05s.

## 2. Chamadas reais aos provedores (executadas nesta máquina)

| Provedor | Pedido | Resultado observado |
| --- | --- | --- |
| AI Horde (imagem), chave anônima `0000000000` | `POST https://aihorde.net/api/v2/generate/async`, 512×768, 24 passos, `nsfw:true` | `{"id":"1f154d33…","kudos":6.0}`; status `done` com `generations[0].img` em base64 (WebP 512×768, 94.280 bytes) em ~25 s, `censored:false`, modelo `stable_diffusion` |
| AI Horde, `dry_run` com conteúdo adulto | mesmo endpoint | aceito, `kudos` 9.0 (autoriza o pedido sem gastar fila) |
| AI Horde (texto), confirmação do caminho existente | `POST /generate/text/async` | resposta correta em 7,8 s, fila 0 |
| Pollinations, sem chave | `GET image.pollinations.ai/prompt/...?width=512&height=768&seed=42` | HTTP 200, JPEG 512×768, 37.291 bytes em ~2,0 s |

Nada disso foi executado **pelo aplicativo** — foi o mesmo pedido, com os mesmos
parâmetros e cabeçalhos, feito por linha de comando. Reproduzir pelo aplicativo
é item da seção 4.

## 2.1. Build do APK da 1.1.0 (executado nesta máquina)

> Esta seção registra o **build da 1.1.0**. O APK entregue desta rodada é o da
> **1.1.1** (versionCode 3), compilado depois das correções da seção 2.2; os
> números dele estão em `RELATORIO_DE_TESTES.md` (§3), que vai na pasta de
> entrega junto do APK.

| Verificação | Resultado |
| --- | --- |
| `:app:assembleRelease` arm64 | **BUILD SUCCESSFUL in 3m 17s** (929 tarefas) |
| Assinatura | `apksigner verify`: CN=Lunaria, digest SHA-256 `c0271509…5719a` — **idêntico ao da 1.0.0** (atualiza por cima) |
| Versão / pacote | `br.aurora.luna.lunaria.next`, versionCode 2, versionName 1.1.0, targetSdk 36, minSdk 24, arm64-v8a |
| Manifesto | `READ_MEDIA_IMAGES` presente; `allowBackup=false`; `fullBackupContent=false`; `dataExtractionRules` aplicado |
| Recursos | `assets/index.android.bundle` (Hermes, 6.424.936 bytes), `res/RT.gguf` (7.818.140 bytes), 48 `.so` arm64 |
| Módulos novos no dex | `ScreenCapture`, `SecureStore`, `MediaLibrary`, `Sharing`, `LocalAuthentication` |
| Código novo no bundle | `lunaria-lock-settings-v1`, `lunaria-image-prefs-v1`, `lunaria-migration-images-v2`, `private://`, `.lunaenc`, `Gerar imagem`, `Proteção por senha` |
| SHA-256 do APK | `6bcbede3ae8a2bf40aebc5f3549062a2ebe5dfd749ce3cf96a2559e2d1236608` |
| Tentativas até o sucesso | 7 (memória da máquina, NDK removido por erro, disco cheio) — ver `BUGS_FOUND.md` seções D–K |

## 2.2. Rodada 1.1.1 — geração real de ponta a ponta (executada nesta máquina)

Ferramenta: `tools/gerar_imagem_real.mjs`, que chama a **mesma função que o botão
"Gerar imagem"** do aplicativo chama (`lib/imagegen/ImageProviders.ts`), com
progresso, download e verificação dos bytes recebidos (cabeçalho real do arquivo,
não a promessa do servidor).

| Verificação | Resultado observado |
| --- | --- |
| AI Horde — geração completa com fila real | fila 262 → 239 → 237 → 0, consultas com 429 no meio, imagem **baixada**: WebP 512×768, **91.666 bytes**, 18 s, modelo `stable_diffusion` |
| Primeira tentativa, antes da correção | `FALHOU: Error — base64 inválido: tamanho não múltiplo de 4` → investigado com sonda própria; causa: o campo `img` trazia **endereço https do R2**, não base64 |
| Pollinations — depois da correção da semente | JPEG 512×768, 38.095 bytes, 4 s |
| Pollinations — antes (sem semente) | imagem de **cache sem relação** com a descrição; reproduzível: mesmos 37.167 bytes em duas execuções |
| Pollinations — descrição em inglês vs português | inglês: imagem fiel ao pedido; português: imagem aleatória em 3 tentativas (limitação do modelo, registrada na tela do app) |
| UA matriz (WAF) | `Python-urllib/3.13` → 403; okhttp 3.x/4.x, Dart, axios, curl, `Lunaria/1.1.1` e sem UA → 200 (o app não é afetado) |
| 429 na consulta de status | observado de verdade; antes abortava a geração e dizia "cota esgotada" — agora espera e continua |

Três correções na raiz, cada uma com teste próprio (`tests/imageprovider.test.mjs`,
24 testes): espera com teto para 429/5xx respeitando `Retry-After`; leitura do
resultado em **endereço ou base64**; **semente sempre enviada** na Pollinations.
Nada disso foi executado pelo aplicativo no aparelho — foi o mesmo código, por
linha de comando.

## 2.3. Rodada 1.1.2 — cancelamento no provedor (executada nesta máquina)

| Verificação | Resultado observado |
| --- | --- |
| Trabalho abandonado na Horde (ninguém consultando) | **segue sendo gerado**: 30 s → `processing=1`; 60 s → `done=true`, 1 imagem pronta |
| `DELETE /generate/status/{id}` na API real | HTTP 200, `waiting 0`, `done true` — funciona **sem** o cabeçalho de chave |
| Código do app emitia esse `DELETE` ao cancelar? | **Não** (a função existia, ninguém chamava) → corrigido: cancelamento agora avisa o provedor |
| Testes novos | 3: cancelar avisa exatamente uma vez e no trabalho certo; sucesso **não** manda cancelamento; erro de autenticação **não** manda cancelamento |

## 2.4. Rodada final — as duas provas que faltavam, contra o serviço real

| Verificação | Resultado observado |
| --- | --- |
| **Cancelar avisa o provedor** (`tools/cancelar_geracao_real.mjs`) | trabalho real na fila (posição **149**), cancelado pelo `AbortController` aos 12 s; o app devolveu `kind=cancelado`; o provedor, consultado por fora, respondeu `done=true, fila=0, gerando=0, pronto=0, **imagens=0**` → **CANCELADO OK**. Para comparar: sem cancelamento, um trabalho abandonado **gera** a imagem (medido antes). |
| **Caminho de sucesso depois da reestruturação** (`tools/gerar_imagem_real.mjs`) | imagem gerada de verdade depois da mudança do laço: WebP 512×768, **131.436 bytes**, 71 s, modelo `stable_diffusion` — o `try/catch` novo não quebrou o caminho normal |
| **429 ao vivo, no meio de uma geração real** | a execução acima bateu no limite de consultas (`"O provedor limitou as consultas; aguardando um pouco…"`) e **mesmo assim terminou** com a imagem: as duas correções (espera com teto e leitura do resultado) provadas na mesma rodada |
| Fidelidade do modelo gratuito (limite honesto) | a descrição pedia "jovem adulta com um gato preto no colo"; a imagem trouxe o **gato preto e a luz de vela**, mas **não** a figura humana. É limite do modelo/fila anônima, não defeito do aplicativo — fica registrado para não prometer o que os gratuitos não entregam |

## 2.5. Preservação verificada dentro do APK entregue (executada nesta máquina)

Ferramenta: `tools/verificar_preservacao.py` (vai no ZIP). Ela abre o APK, lê o
bundle JavaScript compilado (Hermes) e a lista de arquivos do pacote, e procura um
marcador por recurso — **12 de 12 encontrados**:

| Recurso | Evidência dentro do pacote |
| --- | --- |
| Conversa e histórico | `message`, `chats`, `expo-sqlite` |
| Personalidade pt-BR (gótica/afetuosa) | textos de estética/persona |
| Tratamento masculino ao Hamura | `Hamura` |
| Pesquisa/Fatos | "Pesquisar e comparar fontes", "Pesquisas ficam apenas neste aparelho" |
| Memória opcional | "memória local" |
| Ditado | `expo-speech-recognition` |
| Leitura em voz alta | `expo-speech` |
| API remota | `chat/completions` |
| GGUF local | `librnllama*.so` (17 arquivos) + `libggml-htp-*.so` |
| Modelo local embutido | `res/RT.gguf`, 7.818.140 bytes |
| Geração de imagem | "Gerar imagem", `aihorde.net`, `pollinations` |
| Bloqueio e cofre | "Bloquear agora", `SecureStore`, `lunaria-dek` |

Isto **não** substitui teste de aparelho: prova que o recurso está no pacote
enviado, não que ele funciona no Galaxy A05s. O que depende do aparelho segue na
seção 4.

| Verificação | Situação |
| --- | --- |
| Executar o aplicativo em emulador Android | **Impossível aqui**: não há `/dev/kvm`, não há emulador instalado, e o APK é arm64-v8a enquanto o host é x86_64 |
| Captura de tela preta com `preventScreenCaptureAsync` | exige aparelho/emulador |
| Comportamento do Android Keystore / `expo-secure-store` | exige aparelho/emulador |

Não há resultado a reportar: nunca foi executado. Registrado como limitação, não
como aprovação.

## 4. Testes que exigem o Galaxy A05s — **pendentes**

Marcados como pendentes até serem executados no aparelho, com resultado anotado.

### Geração de imagem

1. Abrir uma conversa → “Gerar imagem” → descrever uma cena com o estilo gótico.
2. Conferir a prévia da descrição final e confirmar o envio.
3. Acompanhar os estados: preparando, fila (posição e espera), gerando, pronto.
4. Cancelar no meio de uma geração e conferir que a fila para.
5. Desligar a internet e gerar: deve aparecer mensagem de conexão, sem travar.
6. Estourar o limite do Pollinations (duas gerações seguidas): deve aparecer a
   explicação do limite de 15 s, não um erro técnico.
7. Gerar com descrição proibida (“nua”, “ato sexual”): deve ser recusado antes
   de qualquer chamada de rede.
8. Usar a imagem na conversa, ampliar com pinça, salvar na galeria (aceitando o
   aviso), compartilhar e apagar.
9. Reiniciar o aplicativo e conferir que a imagem continua na conversa.

### Bloqueio

10. Criar senha de 6 dígitos, sair do aplicativo e voltar: deve pedir senha.
11. Errar a senha 3, 4 e 5 vezes: conferir a espera progressiva (1 s, 2 s, 4 s).
12. Fechar o aplicativo de vez e abrir: bloqueio deve aparecer **sem** que
    qualquer conversa apareça antes.
13. Trocar para outro aplicativo e voltar depois do intervalo configurado.
14. Ativar biometria, bloquear e desbloquear com digital; conferir que a senha
    continua funcionando como alternativa.
15. Abrir o aplicativo tocando numa notificação de resposta pronta: deve pedir
    senha **antes** de mostrar a conversa.
16. Ativar “impedir capturas de tela” e tentar tirar print.
17. Ativar leitura em voz alta e bloquear: a fala deve parar; iniciar ditado e
    bloquear: o microfone deve ser liberado.
18. Trocar a senha e conferir que as imagens antigas continuam abrindo.
19. Testar “Esqueci a senha” entendendo o aviso, e confirmar que nada é apagado
    sem confirmação.

### Migração de dados (atualização por cima da 1.0.0)

20. Numa instalação 1.0.0 com imagens anexadas, instalar a 1.1.0 **por cima**
    (sem desinstalar) e conferir que as conversas continuam e que as imagens
    antigas aparecem normalmente.
21. Conferir em `documentos/private/` que os arquivos antigos passaram a
    `.lunaenc` e que a pasta `Attachments/` foi esvaziada.

## 5. Resumo

| Categoria | Passou | Falhou | Pendente |
| --- | --- | --- | --- |
| Automático (esta máquina) | **104 testes de lógica + 50 de renderização** + tsc + eslint (0 erros) + build do APK | 0 | — |
| Serviço real (linha de comando) | 4 verificações da 1.1.0 + **geração completa nos dois provedores, com bytes validados (1.1.1)** | 0 | — |
| Emulador | — | — | impossível neste ambiente |
| Aparelho (Galaxy A05s) | — | — | 21 verificações listadas acima |

Nenhuma verificação de aparelho foi marcada como aprovada sem ter sido feita.

---

# 6. Rodada 1.1.4 (19/09/2026) — a versão entregue

Este trecho responde a duas perguntas, sem enfeite: **o que foi realmente
executado** e **o que ainda depende do aparelho do Hamura**. Tudo que está marcado
como "pendente" não foi testado, e não deve ser lido como aprovado.

## 6.1 Resumo por camada

| camada | onde roda | resultado nesta rodada |
| --- | --- | --- |
| lógica pura (JavaScript/TypeScript, sem módulo nativo) | este ambiente, Node | **123 / 123 passaram** |
| renderização de telas (React em jsdom) | este ambiente, Jest | **60 / 60 passaram** (8 suítes) |
| tipos e lint | este ambiente | `tsc` 0 erros · `eslint` 0 erros (58 avisos de estilo) |
| emulador Android | — | **não executado** — motivo técnico na seção 3 |
| aparelho (Galaxy A05s) | aparelho do Hamura | **pendente** — checklist na seção 4 |

---

## 6.2 Testes automatizados (executados, com resultado real)

Comando: `npm run test:unit` (Node `--test` via `tsx`) e `npx jest tests/render`.

### 6.2.1 Lógica — 123 testes em 12 arquivos

| arquivo | testes | cobre |
| --- | --- | --- |
| `tests/imageprovider.test.mjs` | 30 | provedores de imagem: montagem de requisição, erros, cancelamento, quotas, `Client-Agent`, leitura da versão do `package.json` |
| `tests/research.test.mjs` | 12 | Pesquisa/Fatos |
| `tests/diagnostics.test.mjs` | 11 | migalhas de percurso, anel de 40, erros, modo seguro, contagem de aberturas, relatório sem dado pessoal |
| `tests/crypto.test.mjs` | 10 | PBKDF2, AES-GCM, envelope, verificador, comparação em tempo constante |
| `tests/imageprompt.test.mjs` | 10 | montagem da descrição final, proporção, estilo, perfil visual da Lunaria |
| `tests/privatefiles.test.mjs` | 10 | cofre de arquivos privados, nomes, envelope `.lunaenc` |
| `tests/imagepolicy.test.mjs` | 9 | política de conteúdo: permitido (adulto, sensualidade não explícita, moda alternativa, cena romântica) × proibido (nudez explícita, ato sexual) |
| `tests/lock.test.mjs` | 9 | senha mínima, espera progressiva, limpeza de estados |
| `tests/nativemodules.test.mjs` | **8 (novos)** | carga protegida de módulo nativo + guardas de fonte (detalhe em 2.4) |
| `tests/buffer.test.mjs` | 5 | conversões base64/binário |
| `tests/stream.test.mjs` | 5 | resposta em streaming da API remota |
| `tests/persona.test.mjs` | 4 | persona pt-BR e tratamento masculino ao Hamura |

### 6.2.2 Renderização — 60 testes em 8 suítes

| suíte | testes | cobre |
| --- | --- | --- |
| `lock-flow.test.tsx` | 13 | fluxo do bloqueio: senha errada, espera, troca de senha, desligar proteção |
| `lockgate.test.tsx` | 13 | proteção de todas as telas e caminhos de entrada; nada aparece antes do desbloqueio |
| `screens.test.tsx` | 9 | telas principais |
| `vault-flow.test.tsx` | 9 | criação do cofre, migração, apagar |
| `chat-e-notificacao.test.tsx` | 5 | conversa e notificação sem conteúdo sensível |
| `diagnostico.test.tsx` | 5 | tela de relatório, modo seguro (ligar/desligar), privacidade do texto |
| `primeira-tela.test.tsx` | 5 | abertura: erro de banco → relatório, falha de inicialização com "Tentar novamente", sem autenticação, sucesso |
| `smoke.test.tsx` | 1 | aplicativo renderiza |

### 6.2.3 Estático

- `npx tsc --noEmit` → **0 erros**;
- `npx eslint . --ext .ts,.tsx` → **0 erros**, 58 avisos de estilo pré-existentes
  (regra `object-shorthand` e similares; não são defeitos).

### 6.2.4 Os 8 testes novos desta rodada

`tests/nativemodules.test.mjs` — protegem a correção descrita no `BUGS_FOUND.md` §AN:

1. carrega o módulo quando ele existe;
2. devolve `null` **sem lançar** quando o carregador lança (é o caso real: módulo
   nativo ausente no aparelho);
3. devolve `null` quando o módulo vem vazio;
4. memoriza falha — não repete a tentativa a cada uso;
5. memoriza sucesso — mesma instância;
6. **guarda de fonte**: nenhum arquivo pode importar no topo `expo-secure-store`,
   `expo-media-library` ou `expo-sharing`;
7. **guarda de fonte**: `createMMKV()` não pode voltar ao escopo do módulo
   (a chamada nativa que derrubava a abertura antes de qualquer tela);
8. confirma que MMKV, cofre, imagens, biometria realmente passam pela carga
   protegida.

Testes 6 e 7 são **travas de regressão**: sem elas, a correção se perderia na
próxima alteração sem ninguém perceber.

### 6.2.5 O que os testes automatizados **não** provam

- não provam que o aplicativo abre no Galaxy A05s — nenhum teste daqui executa o
  binário Android;
- não provam geração de imagem em rede real nesta rodada (o que **foi** medido
  contra os provedores reais está registrado em `GERACAO_DE_IMAGEM_E_BLOQUEIO.md`,
  com as medições datadas; nada foi re-medido hoje);
- não provam biometria, galeria, compartilhamento nem captura de tela — todos
  dependem de módulo nativo e só existem no aparelho.

---

## 6.3 Testes de emulador — **nenhum executado**, e o motivo é concreto

Não é escolha, é limitação do ambiente, verificada:

1. **não há emulador instalado**: `/opt/android-sdk/emulator` e
   `/opt/android-sdk/system-images` não existem neste ambiente;
2. **não há aceleração**: `/dev/kvm` não existe (2 núcleos, sem virtualização);
3. **e o APK não rodaria**: o pacote entregue contém **somente `arm64-v8a`**
   (48 bibliotecas, contagem conferida no APK). Um emulador padrão é `x86_64`; o
   aplicativo simplesmente não instalaria nele. Isso é de propósito: o alvo é o
   Galaxy A05s, e mandar quatro arquiteturas só engordaria o APK.

Ou seja: quem testa o binário é o aparelho do Hamura. O que este ambiente pode
fazer — e fez — é garantir que a lógica e a renderização estão corretas antes de
gastar o tempo dele.

---

## 6.4 Testes no aparelho — pendentes (dependem do Galaxy A05s)

Roteiro em `CHECKLIST_APARELHO.md`. O que interessa para o defeito desta rodada:

| item | o que testar | o que conta como resultado válido |
| --- | --- | --- |
| 18 | abrir o aplicativo 1.1.4 | abriu normalmente **ou** abriu com a tela de relatório **ou** fechou — os três são resultados; os dois primeiros trazem dado |
| 18 | se aparecer aviso de armazenamento indisponível | significa que a falha que eu corrigi aconteceu de fato no seu aparelho: "Copiar diagnóstico" e me enviar |
| 19 | abrir duas vezes mesmo que feche | segunda abertura em **modo seguro** = o defeito está nas camadas novas; se continuar fechando = é anterior a elas |
| 1, 5, 7, 8, 13, 15, 16 | conversa, ditado, leitura, Pesquisa/Fatos, memória | conferir que **nada do que já funcionava** se perdeu |

**Sobre o `relatório de diagnóstico`**: ele contém passos, mensagens de erro e
versões. **Não** contém conversas, senhas, imagens nem chaves — isso tem teste
automatizado próprio (`diagnostics.test.mjs` e `diagnostico.test.tsx`).

---

## 6.5 Defeitos encontrados pelos próprios testes (histórico)

Registrado para mostrar que a camada de testes não é decorativa:

- o botão "Sair do modo seguro" não desligava o modo seguro (achado em
  `diagnostico.test.tsx`, corrigido);
- uma asserção de privacidade casava com o próprio texto de aviso do relatório
  (falso alarme, teste reescrito);
- `tests/imageprovider.test.mjs` fixava a versão no código: ao subir para 1.1.3 o
  teste morreu inteiro (115 → 86). Passou a ler a versão do `package.json`;
- um `as string` de TypeScript dentro de arquivo `.mjs` matou a suíte inteira;
  corrigido para JavaScript puro.

---

## 6.6 Verificações de rede real (medidas, com data)

Não foram re-medidas nesta rodada. Os números reais medidos contra os provedores
(Horde e Pollinations: fila, quotas, formatos de resposta, cancelamento, limites de
tempo, comportamento com `429`) estão documentados em `GERACAO_DE_IMAGEM_E_BLOQUEIO.md`
e nos exemplos guardados em `entrega/` (duas imagens WebP e uma JPEG, arquivos
reais recebidos dos serviços).

---

## 7. Rodada 1.1.5 — provas da correção do carregamento (19/09/2026)

Esta seção é da rodada atual. A separação por camada continua a mesma do §6:
**executado** / **emulador** / **aparelho**. O que muda é o alvo: agora o alvo é o
defeito de abertura, e a prova principal é que o banco de dados pode ser **importado
sem tocar em código nativo**.

### 7.1 Resumo por camada

| camada | resultado |
| --- | --- |
| Automatizado (lógica, `node --test`) | **126 de 126** em 12 arquivos |
| Automatizado (renderização, Jest) | **65 de 65** em 9 suítes |
| TypeScript (`npx tsc --noEmit`) | sem erros |
| ESLint | sem erros (58 avisos de estilo pré-existentes) |
| Emulador | **nenhum** — motivo técnico no §6.3 (sem `/dev/kvm`, sem imagem de sistema, 2 núcleos) |
| Aparelho (Galaxy A05s) | **pendente** — itens 18, 19, 20 e 21 do `CHECKLIST_APARELHO.md` |

### 7.2 Testes automatizados novos desta rodada (executados, com resultado real)

| teste | arquivo | o que prova |
| --- | --- | --- |
| importar o banco **não** abre o banco | `tests/render/banco-e-identificador.test.ts` | é a prova central: antes, `openDatabaseSync` rodava no escopo de `db/db.ts`; agora importar `@db` não dispara nenhuma chamada nativa |
| abre no primeiro uso, **uma vez só** | idem | o acesso sob demanda funciona e não reabre o banco a cada consulta (chamada conferida com argumentos: `db.db` + `enableChangeListener`) |
| liga as chaves estrangeiras no primeiro uso | idem | o `PRAGMA foreign_keys = ON` continua sendo executado — comportamento preservado, só adiado |
| identificador válido mesmo com a fonte aleatória falhando | idem | defeito encontrado pelo próprio teste: `randomUUID` podia responder vazio; agora há reserva em JavaScript puro |
| identificadores não se repetem (500 seguidos) | idem | a reserva não é ingênua |
| nenhum arquivo importa `expo-sqlite` no topo | `tests/nativemodules.test.mjs` | varredura de código-fonte que impede a volta do defeito |
| nenhum arquivo importa `expo-crypto` no topo | idem | idem |
| o banco não é aberto no escopo do módulo | idem | idem (varredura) |

Os cinco primeiros são de **comportamento** (rodam o código de verdade, com o
`expo-sqlite` simulado e as chamadas conferidas); os três últimos são **varreduras
de código-fonte**, que valem como trava de regressão: qualquer `import` novo desses
pacotes no topo falha o teste.

### 7.3 O que estes testes provam — e o que não provam

**Provam**: que o aplicativo não morre mais na avaliação do pacote por causa do
banco de dados, do `expo-crypto` ou da biometria; que o banco abre uma única vez, no
primeiro uso, com o comportamento antigo preservado; e que o identificador de anexo
nunca sai vazio.

**Não provam**: que era essa a causa do fechamento no seu aparelho. Um teste
automatizado roda no Node ou no ambiente de teste do React Native — não no Android
do Galaxy A05s, com o banco, o armazenamento e o Keystore reais. Quem decide é o
item 18 do checklist, e o relatório de diagnóstico que a 1.1.5 leva embutido.

### 7.4 Emulador — **nenhum executado** (mesmo motivo do §6.3)

Sem `/dev/kvm`, sem imagem de sistema e com 2 núcleos, não há emulador neste
ambiente; o APK é arm64. Registrado como não executado, não como aprovado.

### 7.5 Aparelho — pendente (depende do Galaxy A05s)

| item do checklist | o que responde |
| --- | --- |
| **18** abrir o aplicativo | se o fechamento ao abrir acabou |
| **19** fechar sem mostrar nada, duas vezes | se o modo seguro entra (e isso localiza o defeito nas camadas novas) |
| **20** o que mudou nesta versão | confirmação curta de que o aplicativo abre e funciona |
| **21** conversas antigas | que o banco abriu sob demanda **sem perder dados** |

Se o item 18 falhar, o pedido é o mesmo de sempre: a tela de relatório tem o botão
**"Copiar diagnóstico"** — cole no chat. É esse texto que identifica o módulo que
falhou, em vez de deixar o motivo invisível.

---

## 8. Rodada 1.1.6 — o porteiro de entrada (19/09/2026)

A mudança desta rodada é estrutural: o aplicativo passou a ter um **primeiro
arquivo** que roda antes de tudo e existe para transformar "fechou sem dizer nada"
em "abriu e disse o motivo". Como é uma mudança na porta de entrada, ela tem suíte
própria.

### 8.1 Resumo por camada

| camada | resultado |
| --- | --- |
| Automatizado (lógica, `node --test`) | **128 de 128** em 12 arquivos |
| Automatizado (renderização, Jest) | **74 de 74** em 10 suítes |
| TypeScript | sem erros |
| ESLint | sem erros |
| Emulador | **nenhum** — sem `/dev/kvm`, sem imagem de sistema (motivo no §6.3) |
| Aparelho (Galaxy A05s) | **pendente** — itens 18 a 22 do `CHECKLIST_APARELHO.md` |

### 8.2 Os 9 testes do porteiro (executados, com resultado real)

| teste | o que prova |
| --- | --- |
| instala o registro de erro fatal antes de qualquer módulo do aplicativo | o porteiro é o primeiro a registrar; a partir dele, erro fatal nunca mais é silencioso |
| erro fatal antes das rotas carregarem: registra a tela de aviso | **o teste central**: a falha de abertura vira tela com motivo, em vez de fechamento |
| depois que as rotas carregaram, não seqüestra a interface | um erro fatal em sessão já aberta **não** toma a tela do usuário |
| erro NÃO fatal não impõe a tela de aviso | a tela de aviso é para abertura, não para qualquer aviso |
| quem instala um tratador depois continua recebendo os erros (cadeia) | o relatório de diagnóstico do aplicativo continua funcionando — o porteiro não "engoliu" o tratador dele |
| descreve a falha sem quebrar, mesmo com um objeto hostil | `message` e `toString` que lançam não derrubam a tela de emergência |
| o relatório mostra o erro capturado e a versão do aplicativo | o texto que o Hamura vai copiar tem o que é preciso para diagnosticar |
| carrega o porteiro e depois as rotas, nessa ordem, num arquivo só | a ordem de avaliação está travada por teste |
| o `main` do `package.json` aponta para o `index.js` | ninguém troca a porta de entrada sem quebrar o teste |

Mais duas travas de código-fonte em `tests/nativemodules.test.mjs`: o porteiro
**não pode** importar nada no topo (coluna 0) e o `main`/ordem precisam continuar
como estão.

### 8.3 O que os testes provam — e o que não provam

**Provam**: que uma falha na avaliação de um módulo do aplicativo deixa de ser
silenciosa; que o comportamento é restrito à abertura (não atrapalha sessão em uso);
que a captura de erro que já existia continua íntegra.

**Não provam**: que o aplicativo abre no A05s. Isso depende do aparelho — e, se
ainda fechar, vai significar que a falha é **anterior ao JavaScript**, o que muda a
investigação para `logcat`/carregamento nativo (registrado no `BUGS_FOUND.md` §AS).

### 8.4 Emulador — nenhum (mesmo motivo do §6.3)

Sem `/dev/kvm`, sem imagem de sistema, 2 núcleos; o APK é arm64. Registrado como
não executado, não como aprovado.

### 8.5 Aparelho — pendente

| item | o que responde |
| --- | --- |
| **18** abrir o aplicativo | se o fechamento acabou |
| **19** fechar sem mostrar nada, duas vezes | se o modo seguro entra |
| **20** o que mudou nesta versão | confirmação curta |
| **21** conversas antigas | que o banco abriu sob demanda sem perder dados |
| **22** se aparecer a tela de aviso | **novidade desta rodada**: o texto do relatório (botão "Copiar diagnóstico") — é ele que nomeia a causa |

---

## 9. Rodada 1.1.7 — captura de falha fora do alcance do usuário (19/09/2026)

O alvo desta rodada não é o aplicativo: é o **instrumento de diagnóstico**. A
captura nativa existia desde a 1.1.3, mas gravava na pasta privada do aplicativo —
e o Hamura não tem como abrir essa pasta pelo celular. Se o aplicativo fechasse
sempre, a causa ficaria registrada e inalcançável.

### 9.1 Resumo por camada

| camada | resultado |
| --- | --- |
| Automatizado (lógica) | **136 de 136** em 13 arquivos |
| Automatizado (renderização) | **76 de 76** em 10 suítes |
| TypeScript / ESLint | sem erros |
| Emulador | **nenhum** — sem `/dev/kvm` e sem imagem de sistema (§6.3) |
| Aparelho (Galaxy A05s) | **pendente** — itens 18 a 23 do `CHECKLIST_APARELHO.md` |

### 9.2 Testes novos (executados)

| teste | o que prova |
| --- | --- |
| grava em dois lugares (privado + Downloads) | o registro sai do aparelho sem computador |
| **nome do arquivo igual nos dois lados (Kotlin × JavaScript)** | se um lado renomear, o relatório ficaria vazio em silêncio — a inconsistência falha o teste |
| gravação em Downloads usa o caminho permitido (MediaStore, Android 10+) | funciona no A05s **sem** pedir permissão de armazenamento |
| preserva o tratador anterior e não engole o comportamento do Android | registrar não muda o que o sistema faz |
| falha ao gravar não gera segundo problema | diagnóstico não pode virar defeito |
| morte sem exceção Java é lida do histórico do Android | falha nativa, ANR e memória passam a ter evidência |
| a mesma morte não é registrada em toda abertura | sem spam de relatório |
| registro identifica versão, aparelho e horário | o arquivo é útil para corrigir |
| a captura é instalada **antes** de `loadReactNative` | ordem que define se a captura serve para alguma coisa |
| a tela diz onde o arquivo está (e não diz quando não há falha) | 2 testes de tela: o aviso aparece com registro e some sem registro |

### 9.3 O que os testes provam — e o que não provam

**Provam**: que a captura está instalada na ordem certa, grava nos dois lugares pelo
caminho permitido no Android atual, preserva o comportamento do sistema, lê as
mortes que não geram exceção e informa o usuário onde encontrar o arquivo. São testes
de **estrutura** (leem o Kotlin) e de **tela**; não executam Android.

**Não provam**: que a gravação funciona no A05s (isso depende do sistema de arquivos
e da MediaStore reais) nem que o aplicativo abre. O teste que decide é o item 23 do
checklist: **se fechar, procure o arquivo em Downloads**.

### 9.4 Emulador e aparelho

Emulador: **nenhum executado** (mesmo motivo do §6.3 — sem `/dev/kvm`, 2 núcleos,
APK arm64). Aparelho: **pendente**, itens 18 a 23.

---

## 10. Rodada 1.1.8 — trilha de abertura e auditoria do manifesto (19/09/2026)

Duas frentes nesta rodada: (a) **auditar** o que ainda podia explicar morte antes do
JavaScript; (b) criar instrumento para a morte que **não deixa exceção**.

### 10.1 Resumo por camada

| camada | resultado |
| --- | --- |
| Automatizado (lógica) | **145 de 145** em 13 arquivos |
| Automatizado (renderização) | **76 de 76** em 10 suítes |
| TypeScript / ESLint | sem erros |
| Compilação Kotlin isolada | **BUILD SUCCESSFUL** (3m04) — antes do build completo |
| Emulador | **nenhum** — sem `/dev/kvm`, sem imagem de sistema (§6.3) |
| Aparelho (Galaxy A05s) | **pendente** — itens 18 a 24 do `CHECKLIST_APARELHO.md` |

### 10.2 Auditoria do manifesto: o que foi testado e refutado

Cada linha abaixo é uma forma conhecida de morrer **antes** de qualquer JavaScript.
Todas foram refutadas com prova lida **de dentro do APK entregue**, não por leitura
de código-fonte:

| hipótese | prova usada | resultado |
| --- | --- | --- |
| recurso XML do manifesto ausente | `aapt2 dump resources`: `0x7f140001` → `xml/data_extraction_rules`, `0x7f140007` → `xml/network_security_config` | existem |
| `network_security_config` malformado | `aapt2 dump xmltree` — parse do XML binário | válido |
| tema da atividade ausente | `0x7f120266` = `style/Theme.App.SplashScreen` | existe |
| cadeia de pais do tema quebrada | pai `Theme.SplashScreen` (0x7f1202da), `postSplashScreenTheme` = `AppTheme` (0x7f12000d) | resolve inteira |

Achado menor **tratado**: o `<service>` do `RNBackgroundActionsTask` estava
declarado duas vezes (linhas idênticas) e as duas chegavam ao manifesto mesclado —
removida a duplicata.

### 10.3 Os 9 testes novos da trilha de abertura (executados)

| teste | o que prova |
| --- | --- |
| instalação no ponto mais cedo | `instalar` está **dentro** de `attachBaseContext` e **antes** de `onCreate` — e aparece uma única vez |
| as cinco etapas existem | `1/5`…`5/5` marcadas nos arquivos certos (`CapturaDeFalha`, `MainApplication`, `MainActivity`) |
| marca final vem do ciclo de vida | `onResume` chama `concluirAbertura(application)` depois de `super.onResume()` |
| conclusão uma vez por processo | trava interna impede reescrever a trilha a cada volta ao primeiro plano |
| abertura inacabada é promovida | texto "A ABERTURA ANTERIOR NÃO CHEGOU AO FIM" + ponto onde parou |
| abertura concluída **não** é promovida | senão o instrumento viraria alarme falso todo dia |
| colheita lê antes de limpar | se limpar primeiro, a prova da abertura anterior some |
| trilha tem teto de linhas | não cresce sem fim no aparelho do usuário |
| a trilha também sai em Downloads | o registro inacabado é enviável sem computador |

### 10.4 O que os testes provam — e o que não provam

**Provam**: que o instrumento está instalado no ponto mais cedo, marca as cinco
etapas, reconhece abertura inacabada e a entrega ao usuário com o ponto onde parou —
e que não dá alarme falso quando o aplicativo abre normalmente.

**Não provam**: que a gravação funciona no Galaxy A05s (depende do sistema de
arquivos e da MediaStore reais) nem que o aplicativo abre. O teste que decide é o
item 24 do checklist.

### 10.5 Emulador e aparelho

Emulador: **nenhum executado** (§6.3). Aparelho: **pendente** — itens **18 a 24**,
com o 24 sendo o novo: se fechar, procure `lunaria-ultimo-erro.txt` em Downloads e
me mande.

---

## 11. Rodada 1.1.9 — auditoria de encerramento e a terceira saída do relatório (19/09/2026)

### 11.1 Resumo por camada

| camada | resultado |
| --- | --- |
| Automatizado (lógica) | **145 de 145** em 13 arquivos |
| Automatizado (renderização) | **86 de 86** em **12 suítes** |
| TypeScript / ESLint | sem erros |
| Emulador | **nenhum** — sem `/dev/kvm`, sem imagem de sistema (§6.3) |
| Aparelho (Galaxy A05s) | **pendente** — itens 18 a 24 do `CHECKLIST_APARELHO.md` |

### 11.2 Auditoria de encerramento deliberado (o que foi procurado e não existe)

Hipótese: o aplicativo fecha porque **algo o encerra de propósito** — o que seria
invisível para todos os instrumentos anteriores (sem exceção, sem falha nativa, sem
rastro).

| procurado | JavaScript | Kotlin |
| --- | --- | --- |
| recarregar no arranque (`DevSettings`, `reloadAsync`, `expo-updates`) | não existe (e `expo.modules.updates.ENABLED=false` no manifesto) | — |
| encerrar processo (`exitApp`, `process.exit`, `System.exit`, `killProcess`) | não existe | não existe |
| encerrar tela (`finish()`, `finishAffinity()`) | — | não existe |
| `BackHandler` no caminho de abertura | só em telas (menu, gaveta, lista), nenhum na abertura | — |

**Refutada com prova.**

### 11.3 O teste de integração que faltava (o mais importante desta rodada)

`tests/render/entrada-rotas-falham.test.tsx` carrega o **`index.js` de verdade** com
as rotas lançando na avaliação (o cenário real: módulo procurando nativo no import) e
verifica, ponta a ponta:

1. o aplicativo **não explode**: `require` não lança;
2. a tela de aviso é **registrada como tela principal** (`AppRegistry`);
3. a tela **renderiza o motivo real** da falha (o texto do erro simulado aparece);
4. estão lá as **duas saídas**: "Copiar diagnóstico" e "Salvar em Downloads";
5. o botão de salvar grava o **relatório completo** (o texto contém a falha real).

Os testes anteriores provavam **pedaços** (o tratador existe, a tela é registrada) —
e um pedaço pode passar com o encadeamento quebrado: bastava o `index.js` deixar de
chamar `mostrarFalha` para a garantia inteira virar promessa. Agora não.

### 11.4 Os testes da terceira saída

| teste | o que prova |
| --- | --- |
| usa o utilitário do aplicativo com nome e codificação definidos | `lunaria-diagnostico.txt`, `utf8` |
| falha ao salvar devolve `false` e **não lança** | a tela de emergência não pode cair junto |
| o texto salvo é idêntico ao da tela | o arquivo serve para diagnosticar de verdade |
| botão no aviso do porteiro | grava e dá retorno ao usuário |
| botão no relatório de diagnóstico | grava e avisa; se falhar, resta o botão de copiar |

### 11.5 Duas armadilhas de teste registradas

1. `jest.resetModules()` + biblioteca de testes requerida **dentro** do teste registra
   hooks aninhados e o Jest aborta. Tudo é carregado uma vez, no topo.
2. Passar a **fábrica** da tela direto ao React faz o React tratá-la como componente
   funcional e receber de volta uma classe — a árvore sai vazia e o teste passa a
   olhar para o nada. A fábrica **precisa ser chamada**.

### 11.6 Emulador e aparelho

Emulador: **nenhum** (§6.3). Aparelho: **pendente** (itens 18 a 24).

---

## 12. Rodada 1.1.10 — a trilha do JavaScript (19/09/2026)

### 12.1 Resumo por camada

| camada | resultado |
| --- | --- |
| Automatizado (lógica) | **158 de 158** em 14 arquivos (eram 145) |
| Automatizado (renderização) | **92 de 92** em **13 suítes** (eram 86 em 12) |
| TypeScript / ESLint | sem erros |
| Compilação Kotlin | **BUILD SUCCESSFUL** em 6m 7s |
| Emulador | **nenhum** — sem `/dev/kvm` (§6.3) |
| Aparelho (Galaxy A05s) | **pendente** — itens 18 a 25 do `CHECKLIST_APARELHO.md` |

### 12.2 O que a rodada acrescenta ao instrumento

O JavaScript passou a gravar as etapas do arranque na **mesma** trilha do lado
nativo (`TrilhaJsModule` → `CapturaDeFalha.marcarEtapaDeJs`), por uma ponte
registrada em `try/catch`. São oito etapas:

| etapa | ponto exato | se faltar na trilha, morreu em |
| --- | --- | --- |
| `js 1/8 porteiro instalado` | `index.js` logo após instalar o tratador | avaliação do `index.js` |
| `js 2/8 rotas carregadas` | depois de `expo-router/entry` | carregamento das rotas |
| `js 3/8 tela inicial montou` | primeiro efeito de `app/_layout.tsx` | montagem do React |
| `js 4/8 bloqueio pronto` | `init()` do bloqueio resolveu | política de bloqueio |
| `js 5/8 imagens prontas` | ajustes de imagem lidos (ou pulados no modo seguro) | inicialização do gerador |
| `js 6/8 banco migrado` | `useMigrations` deu certo | migrações do banco |
| `js 7/8 Lunaria iniciada` | `startupApp()` resolveu | inicialização do aplicativo |
| `js 8/8 lista de conversas na tela` | a lista renderizou | renderização da tela principal |

Falhas gravam linha com `!` no lugar do número, para a última linha da trilha nunca
ser ambígua entre "parou aqui" e "falhou aqui".

### 12.3 Testes desta rodada

| teste | o que prova |
| --- | --- |
| `tests/trilha-js.test.mjs` (12 testes de lógica) | prefixo, corte em 200 caracteres, `true`/`false` de retorno; escritor que lança não derruba nada; migalha que lança não derruba nada; os dois canais são independentes; e guarda de fonte: as oito etapas estão nos trechos certos, o porteiro não ganhou `import` no topo, e `react-native` continua sendo carregado tarde |
| `tests/render/trilha-js.test.tsx` (6 testes de renderização) | a ponte é usada quando existe (com o texto certo), ausência de ponte não quebra, ponte sem método ou que lança é tratada como ausência, a procura é memorizada — e a **integração real** com o `Diagnostics`: a etapa aparece no relatório da tela |

### 12.4 Falhas encontradas nos próprios testes (e o que ensinam)

1. **Duas instâncias do mesmo módulo.** Sob `node --import tsx`, importar
   `./Diagnostics` e `../lib/utils/Diagnostics.ts` cria **dois** módulos distintos,
   cada um com o seu armazenamento. O teste do segundo canal falhava falando com a
   instância errada. Provado por comparação de identidade. Sob o Metro (e no Jest) há
   grafo único; por isso a integração real passou a ser afirmada no Jest.
2. **Ordem no texto ≠ ordem de execução.** A guarda exigia `6/8` antes de `7/8` na
   ordem textual; a execução é o contrário (função declarada antes, chamada depois).
   Cada marca passou a ser presa ao trecho que a executa.

### 12.5 O que **não** foi provado

Que a ponte responde no aparelho: registro de módulo nativo sob a arquitetura nova só
se verifica ligando. O que está provado é o lado que protege o aplicativo — sem
ponte, ou com ponte falhando, a abertura não muda e nada é lançado. **No pior caso,
nenhuma evidência nova e nenhum caminho novo de falha.**

### 12.6 Emulador e aparelho

Emulador: **nenhum** (§6.3). Aparelho: **pendente** (itens 18 a 25).

---

## 13. Rodada 1.1.11 — um escritor só para o relatório (19/09/2026)

### 13.1 Resumo por camada

| camada | resultado |
| --- | --- |
| Automatizado (lógica) | **163 de 163** em 14 arquivos (eram 158) |
| Automatizado (renderização) | **92 de 92** em 13 suítes |
| TypeScript / ESLint | sem erros |
| Compilação Kotlin | **BUILD SUCCESSFUL** em 3m 1s |
| Emulador | **nenhum** — sem `/dev/kvm` (§6.3) |
| Aparelho (Galaxy A05s) | **pendente** — itens 18 a 25 do `CHECKLIST_APARELHO.md` |

### 13.2 O que a rodada conserta

Duas origens de evidência gravavam o mesmo arquivo em Downloads em threads
separadas, com gravação que apaga o conteúdo anterior: a trilha da abertura anterior
e o motivo lido do histórico do Android. A última gravação vencia — e podia deixar o
arquivo **pela metade**, justamente no caso em que a evidência é necessária.
Registro completo do defeito: `BUGS_FOUND.md` §BD.

Agora há uma função de gravação (`publicar`, com trava e registro de seções) que
sempre reescreve o arquivo **completo**, e uma colheita única que junta motivo e
trilha num relatório só.

### 13.3 Os testes que prendem isto (e por que são estruturais)

O Kotlin **não executa** neste ambiente: não há emulador, não há aparelho, e o APK é
arm64. Portanto a prova desta rodada **não é comportamental** — é estrutural, lendo o
código-fonte nativo e prendendo a forma que elimina a corrida:

| teste | o que exige |
| --- | --- |
| só existe UM caminho que grava o relatório público | `gravarPublico(app, ARQUIVO_PUBLICO` aparece **exatamente uma vez**, dentro de `publicar` |
| publicar junta as seções em vez de sobrescrever | registro `secoes`, `joinToString` ao gravar e trava `@Synchronized` |
| os dois produtores passam por publicar | tratador de exceção e colheita usam `publicar`; nenhum grava direto |
| a colheita acontece uma vez, e não duas | `MainApplication` sem o segundo coletor |
| a captura é instalada antes do React Native | a colheita sai de `instalar()`, no `attachBaseContext` |
| a colheita não repete saída já registrada | `jaRegistrado` / `marcarRegistrado` continuam no lugar |

Limite honesto, escrito com todas as letras: **estrutural não é comportamental**. Um
teste que lê o código garante que existe um escritor só; não garante que o arquivo
chega completo ao aparelho — isso só o aparelho responde. É por isso que estes testes
**não** substituem os itens 23 a 25 do checklist, apenas protegem a correção de ser
desfeita por engano.

Um teste da rodada anterior **falhou** ao aplicar esta mudança, e isso está registrado
como resultado, não escondido: ele prendia a fiação antiga. Foi reescrito para prender
a nova.

### 13.4 Emulador e aparelho

Emulador: **nenhum** (§6.3). Aparelho: **pendente** (itens 18 a 25).

---

## 14. Correção de escopo: o que é e o que não é cifrado (19/09/2026)

### 14.1 O que mudou

Nenhum código de comportamento. Uma **afirmação da documentação** estava imprecisa e
foi corrigida: a matriz de critérios dizia "criptografia real de conversas, memória e
imagens privadas", com evidência que só cobria os **arquivos do cofre** (as imagens).

Verificado no código desta entrega:

| armazenamento | estado real |
| --- | --- |
| Imagens geradas (`document/private/*.lunaenc`) | **cifradas** (AES-256-GCM, DEK envelopada pela senha, envelope no armazenamento seguro do sistema) |
| Texto das conversas (`db/schema.ts`, coluna `swipe`) | **em claro**, na pasta privada do aplicativo |
| Memória de pesquisa (MMKV, `lib/state/ResearchMemory.ts`) | **em claro** |

O escopo real — o que a proteção cobre e o que não cobre — passou a estar escrito
item por item no guia da entrega (`GERACAO_DE_IMAGEM_E_BLOQUEIO.md`, seção 4), como
pedido no encargo ("o real escopo da proteção de dados").

### 14.2 Por que a cifra do texto não foi implementada agora

O mecanismo está mapeado e é viável (cifra **síncrona** com `@noble/ciphers`,
chave com acessador **síncrono** no `PrivateVault`, tipo de coluna do drizzle). Três
problemas reais impedem fazê-lo às pressas:

1. **A busca de mensagens é SQL `LIKE` sobre o próprio texto** (`lib/state/Chat.ts`).
   Cifrar a coluna sem refazer a busca quebraria a busca **em silêncio**;
2. **As conversas existentes estão em claro** e exigem migração com releitura
   verificada antes de apagar qualquer original — o mesmo padrão que a migração de
   imagens usa e que precisa ser repetido com o mesmo cuidado;
3. **Não seria verificável aqui.** O aplicativo não executa neste ambiente, e uma
   camada nova de dados contaminaria o diagnóstico em curso: se a próxima abertura
   falhasse, não haveria como distinguir o defeito antigo da camada nova.

Sequência decidida: **primeiro o aplicativo abrir; depois a cifra do texto**, com a
busca refeita em JavaScript e a migração verificada.

### 14.3 A pendência está visível no conjunto de testes

Em vez de ficar só em documento, o item entrou como **teste marcado para ser feito**:
`tests/privatefiles.test.mjs` → "cifra do texto das conversas e da memória (pendente
até o app abrir no aparelho)". Toda execução passa a mostrar
`# skipped 1` — a lacuna é visível, com o plano e os critérios de aceitação escritos
dentro do próprio teste.

### 14.4 Números desta rodada

| item | resultado |
| --- | --- |
| Testes de lógica | **163 de 163** + **1 pendente declarado** |
| Testes de renderização | **92 de 92** em 13 suítes |
| `npx tsc --noEmit` / `npx eslint` | sem erros |


---

## 15. Rodada 1.1.12 — a cifra do texto das conversas e da memória (19/09/2026)

### 15.1 Resultado dos conjuntos automatizados

| conjunto | comando | resultado | o que cobre |
| --- | --- | --- | --- |
| unitário (Node) | `npm run test:unit` | **173/173**, 0 falhas, **0 pulados** | lógica pura: cifra do texto, busca, cofre, migração, trilhas, diagnóstico |
| renderização (Jest) | `npx jest tests/render` | **106/106** em **14 suítes** | telas e integrações com módulos nativos simulados, incluindo a coluna do banco, a memória cifrada e a trava contra perda de dado |
| tipos | `npx tsc --noEmit` | **sem saída** (limpo) | — |
| estilo | `npx eslint app db lib` | **0 erros** (58 avisos, todos anteriores a esta rodada) | — |

Comparação com a 1.1.11: 163/163 + 1 pulado e 92/92. Nesta rodada o item pulado
deixou de existir — virou **10 testes reais** — e o arquivo de render novo
(`tests/render/cifra-texto.test.ts`) acrescentou **14 casos**.

### 15.2 Os cinco critérios combinados, um por um

Os critérios foram combinados quando o item ainda estava pendente (BUGS_FOUND §BE):

| critério | onde está a prova | resultado |
| --- | --- | --- |
| 1. ida e volta: texto cifrado volta idêntico | `privatefiles` "1. ida e volta…" + `cifra-texto` "grava cifrado e lê de volta idêntico" | passa |
| 2. os bytes gravados não contêm o texto | `privatefiles` "2. os bytes gravados não contêm o texto" (procura o texto no base64 do envelope, em UTF-8 **e** UTF-16LE) + `cifra-texto` (o valor gravado não contém a palavra) | passa |
| 3. conversa antiga, em claro, continua legível | `privatefiles` "3. conversa antiga…" + `cifra-texto` "conversa antiga, gravada em claro, continua legível" + "memória antiga…" | passa |
| 4. sem a chave: ler não lança e não perde dado | `privatefiles` "4. sem a chave…" (usa `assert.doesNotThrow` e depois **reabre** o cofre para provar que o conteúdo continua lá) + `cifra-texto` "sem cofre aberto: a leitura não estoura…" | passa |
| 5. a busca continua encontrando o que encontrava | `privatefiles` "5. a busca continua encontrando o que encontrava no LIKE" + "5b. …NÃO podia mais ser feita no SQL" | passa |

### 15.3 Dois desvios conscientes, registrados

1. **A leitura com o cofre fechado NÃO lança** (devolve o aviso
   `«conteúdo cifrado — desbloqueie a Lunaria para ler»`). O critério 4 pedia
   exatamente isso ("não lança e não perde dado"). A alternativa — lançar — foi
   descartada por um motivo do momento: uma exceção no meio da leitura do banco,
   durante a abertura, é o defeito que está sendo caçado. A proteção contra perda
   ficou do outro lado: gravar o aviso é **recusado** (`privatefiles` "4b"), e na
   memória a gravação com o cofre fechado é **ignorada** (`cifra-texto`), para que
   um estado vazio não apague o conteúdo cifrado.
2. **A busca mudou de forma e ganhou um teto**: a comparação passou a ser feita em
   JavaScript (o `LIKE` do SQL acharia zero dentro do texto cifrado) e a varredura
   para em 5000 mensagens por pesquisa. A regra de comparação continua a mesma do
   `LIKE`: trecho contido, maiúsculas/minúsculas indiferentes, **acento contando**
   (procurar `acao` não acha `Ação` — como era antes). Melhorar isso seria mudança
   de recurso, e mudança de recurso não entra escondida numa correção de segurança.

### 15.4 Um defeito encontrado na revisão, depois de a cifra já estar pronta

A revisão da própria implementação levantou um caso que o codec sozinho não cobria:
a memória de pesquisa é hidratada **uma vez**, na avaliação do módulo. Se o
aplicativo abre **bloqueado**, a hidratação acontece com o cofre fechado e o estado
nasce vazio — e a primeira gravação depois disso apagaria todas as notas antigas
(grave por cima um estado vazio e o conteúdo anterior acaba ali). Duas correções:

1. o adaptador cifrado só libera uma chave para gravação depois de uma leitura que
   viu o conteúdo de verdade; gravar sem essa leitura é **ignorado** (o disco
   permanece intacto);
2. ao desbloquear, `app/_layout.tsx` relê a memória (`persist.rehydrate()`), o que
   restaura o conteúdo antigo e libera a chave.

Caso de teste que reproduz o cenário inteiro:
`cifra-texto` → "o aplicativo abrindo BLOQUEADO não apaga a memória da sessão
anterior" (cifra → abre bloqueado → tenta gravar → **o disco não muda** →
desbloqueia → conteúdo volta → grava de novo sem perder nada). Mais dois casos
cobrem a liberação da chave e o conteúdo cifrado ilegível. Sem esse teste, o defeito
teria passado: todos os testes anteriores usavam o adaptador sempre com o cofre
aberto, que é o caminho fácil.

### 15.5 O que os testes desta rodada NÃO provam

- **Não** provam que o arquivo do banco no aparelho está sem texto legível: isso é
  o item 26 do `CHECKLIST_APARELHO.md`, feito com gerenciador de arquivos no A05s.
- **Não** provam nada sobre o fechamento silencioso na abertura — nem para melhor,
  nem para pior. A causa segue sem diagnóstico e o instrumento é o relatório do
  aparelho.
- **Não** medem o tempo da busca reescrita numa conversa grande; o teto de 5000
  mensagens é um limite projetado, não um número medido no A05s.
- **Não** cobrem a troca de senha depois de já haver texto cifrado (o caminho
  existe — re-envelope da mesma chave — mas não há texto cifrado antigo para
  exercitá-lo neste ambiente).

## 16. Rodada 1.1.13 — o ciclo de importação e a arquitetura de rotas (20/09/2026)

Esta rodada não começou com um build: começou com a diretriz do Hamura depois de ele
instalar a 1.1.12 no A05s e ver o mesmo fechamento. As três proibições da diretriz
foram respeitadas: **nada de outro build às cegas, nada de `try/catch` escondendo o
erro, nada de `ErrorBoundary` por cima**. O que está abaixo é o diagnóstico
determinístico e a correção da causa (relato completo em `BUGS_FOUND.md` §BG).

### 16.1 A cadeia de evidências

| # | passo | resultado |
| --- | --- | --- |
| 1 | Reproduzir o nó raiz com as opções exatas do `router-store` (`skipGenerated`, `ignoreEntryPoints`, `platform`) num contexto montado a partir dos arquivos reais de `app/` | todo `contextKey` do grafo existe no mapa; nenhuma rota sem módulo |
| 2 | Comparar as chaves do **bundle Hermes entregue** (extraído do APK da 1.1.12) com as 118 chaves da árvore | todos os caminhos de rota estão presentes — a hipótese "falta chave" morre aqui |
| 3 | Ler o runtime de produção do Metro dentro do bundle entregue | `catch(r){ e.ErrorUtils.reportFatalError(r) }` … **`return o`** com `o` indefinido: módulo que lança vira `undefined` |
| 4 | Carregar `app/_layout.tsx` num teste isolado (é o que o aparelho carrega primeiro) | **`TypeError: Cannot read properties of undefined (reading 'subscribe')` em `lib/state/TTS.ts:99`** com o módulo não exportando nada |
| 5 | Procurar ciclos no grafo de importação de `app/`, `lib/` e `src/` | um ciclo de avaliação: `AppLock.ts → TTS.ts → Chat.ts → AppLock.ts` |
| 6 | Repetir o passo 4 depois de quebrar o ciclo | `erro=nenhum exportOK=function` |

O passo 4 é o que transforma o relato do aparelho em algo reproduzível aqui: o
`TypeError` que quebra a raiz e o `Cannot read property 'ErrorBoundary' of undefined`
que aparece no logcat são o mesmo acontecimento, em dois pontos diferentes (o factory
que lança e o `fromImport` que recebe `undefined`).

### 16.2 Testes novos (e por que existem)

| teste | o que afirma | por que importa |
| --- | --- | --- |
| `tests/render/raiz-carrega.test.tsx` | a raiz do contexto carrega; `AppLock`, `TTS` e `Chat` carregam em qualquer ordem; a tela de bloqueio carrega | é a falha exata do aparelho, agora presa a uma suíte |
| `tests/arquitetura-rotas.test.mjs` | `app/` só tem rotas/layouts; cada rota é um arquivo fino que reexporta de `src/`; **toda rota navegada pelo código tem arquivo em `app/`**; **o grafo de importação não tem ciclo de avaliação** | impede a volta do defeito e impede o crescimento de `app/` como em 1.1.12 |
| `tests/render/bloqueio-silencia.test.ts` | o bloqueio para a leitura em voz alta pelo barramento; o barramento espera ouvinte assíncrono e respeita quem sai | prova que o requisito da 1.1.12 continua de pé depois da troca da ligação direta pelo aviso |
| `tests/render/*` (14 suítes anteriores) | telas, bloqueio, cofre, cifra, diagnóstico, primeira tela | suíte anterior, reexecutada depois da mudança de estrutura |

Resultados desta rodada, no ambiente:

```
raiz-carrega             3/3
bloqueio-silencia        2/2
arquitetura-rotas        4/4
render (16 suítes)    111/111
unitários             177/177
tsc --noEmit            limpo
eslint (app db lib src) 0 erros, 58 avisos antigos
```

E a verificação de estrutura pelo próprio Expo Router, com a árvore nova:

```
LUNARIA_ROTAS: chaves no contexto = 28
LUNARIA_ROTAS: nós por tipo = {"layout":1,"route":27}
LUNARIA_ROTAS: rotas sem componente = 0
```

Antes da mudança, o mesmo instrumento mostrava **117 rotas**, com componentes e
pedaços de tela entre elas.

### 16.3 O que mudou

- `lib/state/EventosBloqueio.ts` (novo): barramento sem importações; `aoBloquear` e
  `avisarBloqueio`.
- `lib/state/AppLock.ts`: não importa mais o `TTS`; ao bloquear, avisa pelo barramento
  (o `stopAudioAndMic` continua existindo e continua parando a leitura).
- `lib/state/TTS.ts`: ouve o barramento para parar a fala ao bloquear.
- `app/`: de 118 arquivos para 28 — 1 layout, 1 índice e 26 arquivos de rota finos.
- `src/components/**` e `src/screens/**`: o código que estava dentro de `app/`.
- `tsconfig.json`, `package.json` (Jest e `lint`): aliases e escopo ajustados.
- `app.config.js` / `android/app/build.gradle`: `1.1.13` / `versionCode 15`.

### 16.4 O que esta rodada NÃO provou

- **Nada sobre o aparelho.** Todos os números acima são deste ambiente. A validação
  que interessa continua sendo o A05s: abrir, ver a tela de bloqueio, desbloquear,
  conversar, gerar imagem. Enquanto isso não acontecer, a 1.1.13 é uma **candidata**,
  não uma correção confirmada — e a 1.1.12 segue marcada como não corrigida.
- Não mede tempo de abertura nem consumo de memória no A05s.
- Não cobre as ordens de avaliação possíveis no aparelho; cobre as que o grafo atual
  permite, e o teste de ciclo impede a volta da que quebrava.

### 16.5 O APK corresponde ao código entregue (checagem por data)

Houve **cinco** builds nesta rodada, e o primeiro foi descartado por duas razões
concretas — nenhuma delas "porque o Gradle compilou":

| build | janela | código | o que aconteceu |
| --- | --- | --- | --- |
| 1º | 14:33 → 14:41 (abortado) | — | uma mudança de código (`app/index.tsx` virou rota fina; a lógica foi para `src/screens/HomeScreen.tsx`) aconteceu **depois** do início. Pela regra adotada nas rodadas anteriores, build com código alterado depois do start não vale |
| 2º | 14:42:06 → 15:02:27 (`20m 18s`) | 15 | concluído, verificado e entregue… até a suíte unitária apontar um defeito real (§16.6): o `CLIENT_AGENT` do provedor de imagem estava **fixo em `1.1.12`** |
| 3º | 15:25:08 → 15:29:10 (`3m 59s`) | **16** | reconstrução com o `CLIENT_AGENT` corrigido |
| 4º | 15:52:38 → 16:09:14 (`16m 34s`) | **16** | reconstrução gerada depois de todo o trabalho fechado — build frio (§16.9) |
| 5º | 16:42:32 → 16:59:28 (`16m 54s`) | **17** | correção do erro de servidor que é limite de uso (§16.10). **É este o APK entregue** |

A checagem que fecha o assunto, sobre a árvore que gerou o ZIP:

```
$ find app src lib db index.js app.config.js babel.config.js metro.config.js package.json tsconfig.json \
      -type f -newermt "2026-09-20 15:25:08"
(nenhum arquivo)
```

**Nenhum** arquivo que entra no bundle foi tocado depois do início do build final. O
ZIP de fonte corresponde ao que foi compilado, sem exceção — inclusive o
`package.json`, que agora diz 1.1.13 como o `app.config.js` e o `build.gradle`.

Uma armadilha registrada: o **vigia do APK copiou o arquivo do build anterior** no
primeiro minuto do build final (o APK antigo ainda estava no diretório de saída, e o
vigia só confere a versão do pacote — que era a mesma, 1.1.13). O arquivo certo foi
copiado e conferido à mão depois. Lição em `lunaria-build/RESTAURAR_AMBIENTE.md`:
**apagar o APK do diretório de saída antes de iniciar o build**.

### 16.6 A instrumentação de rotas pedida na diretriz (executada)

A diretriz exigia uma instrumentação que dissesse, rota por rota, o que o
`loadRoute()` devolve — não o stack genérico. Ela foi executada sobre a árvore
entregue, carregando **cada arquivo de `app/` de verdade** (os dois módulos nativos de
CPU/texto simulados, porque só existem no aparelho). Saída literal, abreviada nos
comentários e completa em número:

```
LUNARIA_ROUTE_LOAD: contextKey=./_layout.tsx          route=            type=layout loaded=objeto(default=function)
LUNARIA_ROUTE_LOAD: contextKey=./index.tsx            route=index       type=route  loaded=objeto(default=function)
LUNARIA_ROUTE_LOAD: contextKey=./screens/AboutScreen.tsx route=         type=route  loaded=objeto(default=function)
LUNARIA_ROUTE_LOAD: contextKey=./screens/ChatScreen/index.tsx route=ChatScreen type=route loaded=objeto(default=function)
LUNARIA_ROUTE_LOAD: contextKey=./screens/LockScreen.tsx route=          type=route  loaded=objeto(default=function)
LUNARIA_ROUTE_LOAD: contextKey=./screens/AppSettingsScreen/ColorSelector.tsx … loaded=objeto(default=function)
LUNARIA_ROUTE_LOAD: contextKey=./screens/ConnectionsManagerScreen/TemplateManager.tsx … loaded=objeto(default=function)
   … (28 arquivos, um a um)
LUNARIA_ROUTE_LOAD: TOTAL=28 SEM_MODULO=0
```

**Nenhuma rota devolveu `undefined`.** As 28 carregam um módulo com `default` de
função — inclusive a raiz, a rota inicial e a tela de bloqueio.

### O valor que causou o defeito (medido antes da correção, na árvore da 1.1.12)

Na árvore anterior, a mesma instrumentação (e o carregamento da raiz em isolamento)
dava:

```
LUNARIA_RAIZ: modulo=app/_layout.tsx
   erro=TypeError: Cannot read properties of undefined (reading 'subscribe')
   em lib/state/TTS.ts:99:14      exportOK=SEM MODULO
```

Ou seja: o `loadRoute()` da raiz devolvia `undefined` porque o **factory do módulo
lançava** — e o runtime de produção do Metro converte isso em `undefined`
(`ErrorUtils.reportFatalError` + `return o`, com `o` indefinido). Era esse `undefined`
que o `fromImport` do Expo Router tentava desestruturar.

### Duas correções de infraestrutura que a instrumentação revelou

1. **O Jest não transformava `@vali98/react-native-cpu-info` nem
   `@vali98/react-native-process-text`** (os dois publicam ESM fora da lista de
   `transformIgnorePatterns` do `jest-expo`). Qualquer cadeia que chegasse neles
   quebrava com `SyntaxError: Cannot use import statement outside a module` — e era por
   isso que a **rota inicial não tinha nenhum teste de carregamento**. Corrigido em
   `package.json` (`jest.transformIgnorePatterns` estendido com `@vali98`), com os dois
   módulos simulados em `tests/render/raiz-carrega.test.tsx`. Isto é ambiente de teste:
   **não** entra no APK.
2. **O identificador enviado ao provedor de imagem estava fixo em `1.1.12`**:
   `lib/imagegen/ImageProviders.ts` (`CLIENT_AGENT`). O teste `imageprovider` compara
   esse texto com a versão do `package.json` — e foi ele que pegou a divergência
   quando a versão subiu para 1.1.13. Corrigido para `1.1.13`. Este arquivo **entra** no
   APK: por isso o APK foi reconstruído (código 16) depois desta correção.

### Provas desta revisão

```
tests/render/raiz-carrega.test.tsx   5/5   (3 anteriores + rota inicial + rota da conversa)
render (16 suítes)                 113/113
npm run test:unit                  177/177 (inclui o `imageprovider`, que achou o 1.1.12 fixo)
tsc --noEmit                        limpo
eslint (app db lib src)             0 erros
LUNARIA_ROUTE_LOAD                 28 rotas, 0 sem módulo
```

---

## 16.7 Experimento causal da causa-raiz (rota raiz) — 20/09/2026

### O que foi feito

O defeito relatado no aparelho (`Cannot read property 'ErrorBoundary' of undefined`,
em `fromImport`, com origem na raiz do contexto) já tinha sido explicado pelo ciclo
`AppLock → TTS → Chat → AppLock`. Faltava **provar a causalidade**: mostrar que é
*aquela* aresta — e não outra coisa — que produz a falha de carregamento.

Para isso, com a árvore congelada do código 16:

1. Um teste temporário (`tests/render/_exp-rotas.test.ts`, apagado depois) carregava
   **todas as rotas de `app/` em um único registro de módulos**, exatamente como o
   aplicativo faz na abertura, e imprimia o resultado de cada `loadRoute()`:
   `contextKey`, `route`, `type` e o módulo devolvido.
2. Rodado com o código corrigido → linha de base.
3. Reintroduzida **apenas** a aresta antiga em `lib/state/AppLock.ts` (import de
   `useTTSStore` no lugar de `avisarBloqueio`, e a chamada `stopTTS()` no lugar de
   `avisarBloqueio()`), mantendo todo o resto igual → mesma medição.
4. Restaurado o arquivo corrigido (cópia de segurança feita antes) → medição final.

### Resultado (verbatim)

Com a aresta antiga (`AppLock` importando `TTS`):

```
LUNARIA_ROUTE_LOAD: contextKey=./_layout.tsx route=./_layout type=layout
    loaded=LANCOU(Cannot read properties of undefined (reading 'subscribe'))
LUNARIA_ROUTE_LOAD: contextKey=./index.tsx route=./index type=route
    loaded=objeto(default=function)
LUNARIA_ROUTE_LOAD: TOTAL=28 SEM_MODULO=1
```

Com o código corrigido (`EventosBloqueio` no meio):

```
LUNARIA_ROUTE_LOAD: contextKey=./_layout.tsx route=./_layout type=layout
    loaded=objeto(default=function)
LUNARIA_ROUTE_LOAD: TOTAL=28 SEM_MODULO=0
```

### Leitura

- A falha **só** aparece na chave de contexto da **raiz** (`./_layout.tsx`) — a única
  que o Expo Router qualifica em `useStore` no arranque. É por isso que o aplicativo
  fechava antes de desenhar qualquer tela.
- A mensagem é a **mesma do aparelho** (`reading 'subscribe'`), no mesmo ponto
  (`lib/state/TTS.ts:99`): a aresta reexecuta o ciclo e o `useInference` ainda está
  `undefined` quando o `TTS` é avaliado.
- Retirando a aresta, nada mais falha. **Causa confirmada por controle experimental.**

### Trava permanente

O experimento virou teste definitivo: `tests/render/rotas-carregam.test.tsx`
(**29 testes** — 1 de composição + 28 rotas, uma por arquivo). Ele reprova se qualquer
rota de `app/` deixar de devolver um módulo com componente — o sintoma que, no aparelho,
aparece como `loadRoute() === undefined` e fechamento na abertura. A aresta antiga faz
esse teste reprovar; o código entregue passa.

## 16.8 Reexecução final (mesma árvore do código 16)

```
tests/render/rotas-carregam.test.tsx   29/29  (novo — trava do defeito de abertura)
tests/render/raiz-carrega.test.tsx      5/5
render (17 suítes)                    142/142
npm run test:unit                     177/177
tsc --noEmit                          limpo
eslint (app db lib src)               0 erros (58 avisos antigos)
find app src lib db … -newermt 15:25:08 → AppLock.ts só por data: cmp byte a byte
                                        contra o ZIP-fontes = IDÊNTICO
```

Os testes e estes documentos **não entram no bundle**: o APK do código 16 continua
correspondendo exatamente ao código atual (conferido por `cmp` com o `AppLock.ts`
guardado dentro do ZIP-fontes do código 16).


---

## 16.9 Reconstrução final do APK — o artefato gerado por último (20/09/2026)

### Por que existe

A diretriz do usuário foi explícita e veio repetida: *"Não gere nada ainda, volte de onde
você parou, por favor faça tudo, só depois gere algo como apk"*. Ou seja: o artefato devia
ser **gerado depois** de todo o trabalho — não antes nem no meio. A ordem praticada foi:

1. Experimento causal da causa-raiz (§16.7) — feito na árvore final, temporário, apagado;
2. Prova do injetor de rotas (§16.6) — 28 rotas, 0 sem módulo;
3. Trava permanente (`tests/render/rotas-carregam.test.tsx`) + suítes completas (§16.8);
4. Congelamento conferido (`find … -newermt` + `cmp` byte a byte);
5. **Só então** o APK foi reconstruído do zero.

### O build

```
início   15:52:38 UTC   (frio: `android/app/build` e `android/.cxx` tinham sido apagados
                         quando o disco foi liberado; cache de transforms do Gradle
                         removido antes, ~3 GB regeneráveis, para abrir espaço)
fim      16:09:14 UTC
resultado BUILD SUCCESSFUL in 16m 34s
tarefas  952 acionáveis — 62 executadas, 24 do cache, 866 já atualizadas
disco    6,2 GB livres no início (mínimo exigido pelo próprio script: 4 GB)
```

Nenhum arquivo do bundle foi tocado entre a decisão e o build — a árvore é a mesma que
passou nas suítes.

### O APK que saiu

| o que | valor |
| --- | --- |
| arquivo | `Lunaria-1.1.13-arm64-release.apk` |
| tamanho | 66.836.167 bytes (o mesmo do build anterior, byte a byte no conteúdo) |
| SHA-256 | `f5d1341dcf9f5d92e823f5936f962ae72ef7776c3ba7b57506b55ae4ed6f0000` |
| versão interna | `versionName=1.1.13`, `versionCode=16`, `br.aurora.luna.lunaria.next` |
| assinatura | `CN=Lunaria`, digest `c0271509…5719a` — **o mesmo desde a 1.0.0** |
| bibliotecas nativas | 53 `.so` (48 arm64-v8a), `res/RT.gguf` presente |
| bundle Hermes | 6.659.820 bytes, 26 chaves de rota, 0 rota antiga `components/...` |
| manifesto | `allowBackup=false`, `fullBackupContent=false`, `dataExtractionRules` presente (conferido com `apkanalyzer manifest print` — o `grep` no manifesto binário dá falso negativo) |

> Nota acrescentada depois: este build (4º) foi **superado** pelo 5º (§16.10), que
> entrega uma correção de mensagem encontrada na medição ao vivo dos provedores. O
> conteúdo abaixo segue valendo como retrato daquele build.

A prova de que a reconstrução não mudou nada além do carimbo

O mesmo verificador rodou sobre o APK anterior e sobre o novo. **A saída é idêntica linha
a linha; as duas únicas diferenças são o caminho do arquivo e o `sha256`:**

```
4c4
< sha256 : ba0c35547445c5f9a47c7e8a334028b804699b1460ede085d65efc0f8caf6244
---
> sha256 : f5d1341dcf9f5d92e823f5936f962ae72ef7776c3ba7b57506b55ae4ed6f0000
```

Tamanho, `versionCode`, certificado, contagem de `.so`, `RT.gguf`, tamanho do bundle,
chaves de rota e marcadores: tudo igual. É o mesmo aplicativo, agora com o artefato
gerado **depois** de o trabalho estar fechado — como a diretriz exigia.

---

## 16.10 Correção do erro de servidor que é limite de uso (20/09/2026)

Descoberto pela medição ao vivo dos provedores (§16.9 de
`lunaria-build/logs/medicao-provedores-2026-09-20.txt`), não por relato de tela.

| o que foi medido | resultado |
| --- | --- |
| 4 descrições **novas** na Pollinations, em rajada | `500, 500, 500, 200` |
| corpo do erro | `"Gen Sana request failed with 429: ... Per-user limit of 300 RPM exceeded ... community_model_rate_limit"` |
| leitura | o 500 é um **429 de cota** embrulhado pelo serviço |

**Antes:** todo `5xx` virava `kind: 'rede'` — "O provedor está indisponível no momento".
**Depois:** quando o corpo traz marca de limite, vira `kind: 'cota'`, com mensagem e
dica próprias; sem a marca, continua `rede`.

Testes novos em `tests/imageprovider.test.mjs` (com o corpo real capturado):
o 500 de limite vira cota; o 500 genérico continua indisponibilidade; o mesmo caso
pelo caminho da Pollinations também vira cota.

**Suítes desta rodada (árvore já com a correção):**

```
npm run test:unit      180/180   (eram 177; +3 deste relatório)
npx jest               142/142   (17 suítes)
tsc --noEmit           limpo
eslint app db lib src  0 erros (58 avisos antigos)
```

O `versionCode` subiu de **16** para **17** porque o código mudou: o APK desta rodada
é distinguível do anterior na instalação. O `versionName` continua **1.1.13**
(correção pequena, sem mudança de recurso).

### Build e verificação deste APK

```
início  16:42:32 UTC      fim  16:59:28 UTC      BUILD SUCCESSFUL in 16m 54s
952 tarefas acionáveis: 53 executadas, 899 já atualizadas
congelamento: find app src lib db index.js *.config.js package.json
              -newermt "2026-09-20 16:42:32"  ->  NENHUM arquivo

APK  66.836.927 bytes   sha256 a558df0df469651326d08d6bd4ab8c4e91651dae8d0bca988592c8a7c1b8c5fb
     versionName=1.1.13   versionCode=17   br.aurora.luna.lunaria.next
     certificado c0271509…5719a (o mesmo desde a 1.0.0)
     53 .so (48 arm64)   res/RT.gguf presente   bundle Hermes 6.660.584 bytes

Dentro do bundle (conferido byte a byte, tratando UTF-16 para as strings com acento):
  "O serviço gratuito está limitando os pedidos agora"      1 ocorrência  (UTF-16)
  padrões de detecção: rate[_ -]?limit, rpm exceeded,
                       too many requests                     1 cada (UTF-8)
  mensagens antigas preservadas:
  "A cota gratuita do provedor foi atingida."               1 ocorrência
  "O provedor está indisponível no momento."                1 ocorrência
```

Nota de método: a conferência de textos no bundle Hermes precisa procurar também em
**UTF-16** — o Hermes guarda em UTF-16 as strings que contêm acento, e um `grep` ASCII
dá falso negativo (foi o que aconteceu na primeira tentativa desta rodada).

---

## 16.11 Teto da busca medido (não mais projetado) e pacote de fonte reexecutado

### 16.11.1 O que estava pendente

O `TEST_REPORT.md` registrava o teto de 5.000 mensagens da busca como **projetado** —
o número vinha da leitura do código, não de medição. Medido agora.

### 16.11.2 Como foi medido

Instrumento em `/tmp` (fora da árvore, apagado depois), com as **mesmas constantes** do
`searchChat` (`lib/state/Chat.ts`): páginas de 250, teto de 5.000 varridas, parada em
100 achados — e as **mesmas funções** do aplicativo (`decifrarTexto` e `combinaBusca`).
Acervo de 10.000 mensagens cifradas de verdade (AES-256-GCM, o mesmo caminho do app).

### 16.11.3 Resultado

| caso | varridas | achados | tempo |
| --- | --- | --- | --- |
| termo comum (toda mensagem casa) | 250 | **100** | 12,0 ms |
| termo frequente (1 em 4) | 500 | **100** | 31,3 ms |
| termo que não existe — **pior caso** | **5.000** | 0 | 364,9 ms |
| pior caso, 3 rodadas | 5.000 | 0 | 313,7 / 279,6 / 287,6 ms (média **293,6 ms**) |

```
TETO DE 100 ACHADOS: 100   (confirmado: para exatamente em 100, não passa)
TETO DE 5000 VARRIDAS: 5000 de 10.000 no acervo (confirmado: para no teto)
custo por mensagem varrida: 0,059 ms nesta máquina (x86)
```

**Leitura:** o pior caso custa ~0,3 s **nesta máquina**. O A05s é mais lento, mas a
busca roda fora da thread de desenho do aplicativo e o teto existe justamente para
não crescer com o tamanho do histórico. O número do aparelho continua **não medido** —
entra no `CHECKLIST_APARELHO.md` como o que se observa no item de busca.

### 16.11.4 Correção do instrumento (registro honesto)

A **primeira versão** do instrumento estava incompleta: não tinha o `break` interno do
`searchChat` (`Chat.ts:722`) e por isso devolveu **250 achados**, sugerindo um defeito
que **não existe** — o aplicativo para em 100. O erro era do instrumento, não do app.
Lição, da mesma família da lição do vigia do APK: **instrumento copiado à mão precisa
ser conferido contra o original linha a linha antes de virar conclusão.** Depois de
corrigido, a medição acima.

### 16.11.5 O pacote de fonte roda os próprios testes quando extraído do zero

Verificação do **entregável**, não do projeto: o `Lunaria-1.1.13-source.zip` foi
extraído num diretório vazio (468 arquivos) e a suíte de lógica foi executada **de
dentro dele**:

```
$ unzip Lunaria-1.1.13-source.zip -d /tmp/zipcheck && cd /tmp/zipcheck
$ node --import tsx --test tests/*.test.mjs
# tests 180
# pass 180
# fail 0
```

Isto é: o pacote entregue é **autossuficiente** — o que está dentro dele passa nos
testes que ele mesmo carrega, sem depender de nada que só exista na árvore de trabalho.

---

## 16.12 Correção da seed no payload da AI Horde (20/09/2026)

### O defeito

Com a 1.1.13 já abrindo no aparelho, a geração de imagem com seed escolhida
devolvia, do próprio serviço:

```
Input payload validation failed — params.seed: "364056 is not of type 'string'"
```

A Lunaria mandava `seed` como **número**; o schema da AI Horde exige **texto**.
Gerações sem seed nunca esbarraram nisso — o campo simplesmente não ia.

### A correção

`lib/imagegen/ImageProviders.ts`:

```ts
export const seedDaHorde = (seed: number | string | null | undefined): string | undefined => {
    if (seed === null || seed === undefined) return undefined
    if (typeof seed === 'number') return Number.isFinite(seed) ? String(seed) : undefined
    const texto = seed.trim()
    return texto === '' ? undefined : texto
}
```

e, na montagem do corpo, o campo entra só quando há valor válido, com validação
antes do `fetch` (quando presente, tem de ser texto — senão lança erro claro).

### Payload sanitizado (chave anônima pública; nenhuma credencial exposta)

```
seed automática : {"params":{...,"seed":"516586"}}
seed manual     : {"params":{...,"seed":"364056"}}
sem seed        : {"params":{...}}            <-- campo omitido, não null
cabeçalhos      : Content-Type, apikey: 0000000000 (chave anônima pública),
                  Client-Agent: Lunaria:1.1.13:(github.com/Hirooficial/Lunaria2.0)
```

### Os cinco testes pedidos (todos inspecionam o corpo REAL enviado)

```
TESTE 1 seed automática  : payload.params.seed = "516586"     typeof = string  OK
TESTE 2 seed manual      : payload.params.seed = "364056"     typeof = string  OK
TESTE 3 tentar de novo   : 3 tentativas -> "364056"           typeof = string  OK
TESTE 4 ausente/nula/vazia/só espaços/NaN/Infinity
                         : campo OMITIDO em todos os 6 casos; nada de
                           null/undefined/NaN no payload                  OK
TESTE 5 outros provedores: Pollinations segue com seed=42 na URL; a fachada
                           generateImage continua escolhendo o provedor     OK
```

``` 
npm run test:unit     181/181   (era 180; +1: os cinco casos acima num teste)
npx jest              142/142   (17 suítes; incluindo rotas-carregam 29/29)
tsc --noEmit          limpo
eslint                0 erros
```

### Build

Reconstrução da **MESMA** versão (1.1.13, `versionCode` 17, **sem incremento**, como
pedido): 17:24:45 UTC → conclusão registrada abaixo. A correção do startup
(`EventosBloqueio`, `app/` com 28 arquivos) permanece intacta — conferida por
`rotas-carregam` 29/29 antes do build.

---

## 16.13 Cofre + imagem: botão de ativação e a etapa que falhava (20/09/2026)

### As duas perguntas do relato, respondidas com prova

**1) Por que o botão "Ativar bloqueio" ficava apagado:** não havia validação na tela
— e a que existia no toque não cobria o segundo campo de forma clara nem tratava
exceção de `enableLock` (que fala com o Keystore e pode lançar). Resultado: botão sem
estado definido e toque silencioso quando algo falhava. Agora a validação é
explícita, viva e escrita na tela (`validarAtivacao`), e o botão só fica aceso com
duas digitações iguais de 6+ caracteres — com o motivo escrito quando está apagado.

**2) Em que etapa do fluxo a imagem falhava:** **`VAULT_SAVE`** — a imagem era
gerada e baixada com sucesso, e a gravação cifrada no cofre é que lançava "Cofre
bloqueado". A causa não era o estado do cofre na interface: era o cofre **sem chave
nenhuma** quando não havia senha configurada (o caminho "chave no Keystore" existia
no `CHANGELOG` e não existia no código).

### Testes desta rodada

```
tests/lock.test.mjs                     21/21  (+8: formulário de ativação)
   duas senhas iguais 6+ -> liberado | diferentes -> bloqueado + "As senhas não coincidem."
   curta -> bloqueado + "Use pelo menos 6 caracteres." | PIN 364056 -> liberado
   alfanumérica Lunaria2026 -> liberado | apagar um campo -> volta a bloquear
tests/falhaimagem.test.mjs              4/4   novo — etapa por etapa
tests/render/cofre-aparelho.test.tsx    6/6   novo — chave do aparelho ponta a ponta
    cria e reusa a chave | SEM senha grava e lê (arquivo cifrado de verdade)
    ativar a senha promove a MESMA chave (imagem antiga continua legível)
    desligar devolve a chave (imagem não se perde) | fechado -> CofreBloqueadoError
    a senha não aparece em nenhum slot
tests/render/imagem-cofre.test.tsx      3/3   novo — o fluxo real do store
    cofre aberto: gera, grava cifrado, lê de volta (resolvePrivateImage) e indexa
    cofre fechado: erro kind="cofre", hint com VAULT_SAVE, provedor NÃO é culpado
    "tentar de novo" com o cofre reaberto: funciona e guarda a imagem

unidade 193/193 · render 184/184 (24 suítes) · tsc --noEmit limpo · eslint 0 erros
```

### O log real que a interface passa a mostrar (antes: "não foi possível")

```
[ERROR] Geração de imagem falhou (cofre, etapa VAULT_SAVE): A imagem foi gerada,
        mas o cofre está fechado e não deu para guardá-la.
        — Etapa: VAULT_SAVE (falhou ao guardar no cofre).
```

### O que continua igual (conferido pelos testes que já existiam)

startup (rotas-carregam 29/29), seed da Horde como texto (imageprovider 34/34),
Pollinations e demais provedores, seed automática/manual/retry, estilos e telas
(screens/smoke verdes, 19 suítes de render no total), cifra do texto, cofre das imagens, memória, GGUF,
voz, notificações e o resto do aplicativo.

## 16.14 Reconstrução do APK desta rodada e conferência do que foi entregue (21/09/2026)

Mesmo `1.1.13`, mesmo `versionCode 17` — **nenhuma versão nova**. Build frio
(transforms do Gradle e cache do Gradle apagados antes de começar), iniciado
04:39:30 UTC e concluído 05:06:43 UTC: **BUILD SUCCESSFUL in 27m 10s**.

### Etapa 1 — as suítes, na árvore congelada (a mesma que gerou o APK)

```
npm run test:unit     → 193/193 testes, 0 falhas
npm run test:render   → 151/151 testes, 19 suítes, 0 falhas
tsc --noEmit          → limpo
eslint                → 0 erros
```

Nenhum arquivo de código foi tocado depois das suítes (o que mudou entre o build e
a entrega foram só documentos, que não entram no APK).

### Etapa 2 — o APK

```
tamanho      : 66.842.687 bytes
sha256       : 5bc2d0006a97e6a1abbaad4a468fb71579bd13fb88e3df125e0c4f316f753861
versionName  : 1.1.13        versionCode : 17
applicationId: br.aurora.luna.lunaria.next
certificado  : CN=Lunaria … SHA-256 c0271509ad829da96e8fd205faa99b7103bf43c358a8501c0925606c7b55719a
               (o MESMO desde a 1.0.0 — instala por cima, sem desinstalar)
bibliotecas  : 53 .so (48 em arm64) | rotas: 26 chaves no bundle Hermes
```

### Etapa 3 — comparação com o APK anterior (o da correção da seed)

O verificador (`lunaria-build/verificar-apk-113.py`) rodou nos dois e o diff é
mínimo — ou seja, **nada regrediu**:

```
ÚNICAS diferenças: caminho do arquivo, tamanho (66.842.687 contra 66.837.431),
                   sha256 e o bundle Hermes (6.666.344 contra 6.661.088 bytes)
IGUAIS: versionCode 17, versionName 1.1.13, applicationId, certificado,
        26 chaves de rota, 53 .so, res/RT.gguf, marcadores de startup
```

### Etapa 4 — o código novo está DENTRO do APK entregue (conferido no bundle)

Procurando em UTF-8 **e** UTF-16-LE (armadilha conhecida):

```
validarAtivacao · "Digite uma senha ou um PIN." · "Use pelo menos … caracteres."
"Evite espaços no começo ou no fim." · "Repita a senha no segundo campo."
"As senhas não coincidem." · cofre-ativar
CofreBloqueadoError · "Etapa: VAULT_SAVE (falhou ao guardar no cofre)."
VAULT_SAVE · IMAGE_READ · IMAGE_DISPLAY · PROVIDER_RESPONSE · "salvando"
lunaria-dek-device · ensureDeviceVault … (presentes)
```

### Etapa 5 — pacote de fonte e integridade da entrega

O ZIP de fonte foi refeito (ele ainda era o da rodada anterior, sem as correções):
contém o código e os testes novos, **nenhuma chave** (conferência por nome e por
conteúdo dentro do script), e rodando as suítes **a partir do próprio ZIP**
(com `node_modules` emprestado) dá **193/193**. `entrega/SHA256.txt` regenerado e
conferido: **6/6 OK** (APK, ZIP 1.1.13, ZIP 1.0.0 e as três imagens de exemplo).

### O que depende do aparelho (segue pendente, sem fingir que foi testado)

Itens **32, 33 e 34** do `CHECKLIST_APARELHO.md`: o botão acender com 6+ iguais / ficar
apagado com o motivo, o cofre ficar ativo de verdade ao ativar o bloqueio, e a geração
no AI Horde aparecer no histórico guardada cifrada. Até esse teste,
`REAL_DEVICE_VALIDATION` para o cofre/geração continua **NOT_TESTED**.

## 16.15 Segunda rodada de 21/09 — credencial da AI Horde e estado do bloqueio

Os dois defeitos relatados no aparelho depois de a 1.1.13 abrir corretamente: a
geração de imagem parando em "O provedor recusou a credencial usada." e o bloqueio que
não aplicava estado. Diagnóstico completo em `BUGS_FOUND.md` §BQ.

### O que foi medido contra os serviços reais (não deduzido)

```
AI Horde POST /generate/async (mesmos cabeçalhos do aplicativo):
  apikey: 0000000000            -> 202   (modo gratuito funciona)
  apikey: abc123                -> 401   {"rc":"InvalidAPIKey"}
  apikey: <40 hex inexistente>  -> 401   InvalidAPIKey
  apikey: "Bearer 0000000000"   -> 401   InvalidAPIKey
  sem cabeçalho apikey          -> 400   Missing required parameter

AI Horde GET /find_user (usado para conferir antes de salvar):
  0000000000 -> 200 {"username":"Anonymous#0"} | abc123 -> 404 | "" -> 401

Pollinations (mesma URL, 3 pedidos):
  sem Authorization / Bearer inválido / Bearer anônimo -> 200 image/jpeg 27.838 B
  (ignora o cabeçalho: o modo gratuito lá é o normal)

PROVA PONTA A PONTA com o código do aplicativo (ImageProviders.ts, rede real):
  PROVIDER_MODE com chave própria ····ueda (34 caracteres) · cabecalho_apikey=enviado
  PROVIDER_CREDENTIAL_REFUSED HTTP 401 InvalidAPIKey · tentando o modo gratuito
  PROVIDER_MODE_GRATUITO_OK
  RESULTADO: 86.276 bytes · image/webp · seed=524766 (TIPO string nas duas tentativas)
             · 39 s · fila anônima (posição 148 -> 142)
```

### Suítes desta rodada (na árvore congelada, a mesma que gerou o APK)

```
unidade                                    208/208   (era 193)
  tests/chave-provedor.test.mjs            novo, 10
  tests/imageprovider.test.mjs             34 -> 39  (os 5 obrigatórios da credencial)
render                                     174/174   (era 151; 22 suítes)
  tests/render/imagem-chave.test.tsx       novo, 8
  tests/render/bloqueio-estado.test.tsx    novo, 9
  tests/render/bloqueio-ao-sair.test.tsx   novo, 6
tsc --noEmit                               limpo
eslint                                     0 erros
```

### Testes obrigatórios do relato e onde cada um está

```
BUG 1 / TESTE 1 (sem chave: usa o modo gratuito)      imageprovider "modo gratuito…"
BUG 1 / TESTE 2 (com chave: vai no cabeçalho apikey)  imageprovider "chave do usuário…"
BUG 1 / TESTE 3 (chave inválida: erro claro)          chave-provedor + imagem-chave
BUG 1 / TESTE 4 (voltar ao gratuito após inválida)    imagem-chave (chave removida)
BUG 1 / TESTE 5 (seed continua STRING em todos)       imageprovider (3 casos) + prova real
BUG 2 / TESTE 1 (bloquear agora muda o estado)        bloqueio-estado
BUG 2 / TESTE 2 (bloquear ao sair)                    bloqueio-ao-sair (AppState real)
BUG 2 / TESTE 3 (temporizadores)                      bloqueio-ao-sair (5 min / 1 min)
BUG 2 / TESTE 4 (desbloquear volta a liberar)         bloqueio-estado
BUG 2 / TESTE 5 (integração com a imagem)             imagem-chave + bloqueio-estado
```

### Build e entrega (medido)

```
versão dentro do APK     1.1.13 / versionCode 17 (apkanalyzer manifest)
aplicativo               br.aurora.luna.lunaria.next
assinatura               Verifies · v2 = true · certificado c0271509…5719a (o MESMO desde a 1.0.0)
APK                      66.859.835 bytes · fafa66dbf1c3423deccf9928612fb7ef17d64613d86db2a553c648325f8ce458
bundle Hermes            6.683.492 bytes (+17.148 contra o da rodada anterior)
manifesto                allowBackup="false" · dataExtractionRules presente · 48 bibliotecas arm64 de 53
build                    FRIO (sem cache nenhum) · 06:06:13 → 06:32:05 UTC · BUILD SUCCESSFUL in 25m 49s
ZIP de fonte             refeito com as docs atualizadas (478 arquivos, sem chave no pacote)
                         — tamanho e soma vigentes no SHA256.txt da entrega
SHA256.txt               sha256sum -c -> 6/6 OK
```

Nota honesta sobre a conferência do bundle: a varredura de **nomes** de função
(`EventosBloqueio`, `HomeScreen`, `UNLOCK_*`, `VAULT_*`) é **inconclusiva** neste
pacote — esses identificadores estão ausentes tanto no APK novo quanto no anterior,
porque o Hermes não os guarda em texto puro. O que prova o código desta rodada é a
varredura de **literais de texto**: os seis literais novos aparecem **só** no APK novo.

### Conferência da entrega na retomada (sem rebuild)

Depois de uma queda da interface, o fechamento foi verificado antes de qualquer ação:
`sha256sum -c SHA256.txt` → **6/6 OK**; APK da entrega **idêntico** ao do build
(`fafa66db…`, 66.859.835 B); `versionName=1.1.13` / `versionCode=17` e assinatura v2
conferidos **por dentro** do pacote; docs do ZIP **idênticas** às soltas. Nenhum build
foi refeito e nenhuma versão foi criada. Correção feita na conferência: o
`CHECKLIST_APARELHO.md` apontava para o sha do APK **anterior** — corrigido para o
desta rodada (mudança só de documentação).

### Empacotamento do ZIP: estratégia de cópia corrigida

O erro `Invalid cross-device link` é da **estratégia de cópia**, não do aplicativo: ele
acontece quando alguma etapa tenta criar um **link** entre sistemas de arquivos
diferentes. O empacotador tinha duas exposições a isso e as duas foram fechadas:

| exposição | correção |
| --- | --- |
| palco criado em `/tmp` (**tmpfs**) enquanto o projeto está em `/dev/root` — qualquer link cruzava filesystem | o palco e a pasta de conferência agora nascem no **mesmo filesystem** da origem (`/home/user/.empacotamento-*`, `/home/user/.conferencia-*`), com `trap` para limpar mesmo em caso de erro |
| `tar` sem `--hard-dereference`: se a árvore tivesse hard link, a extração chamava `link()` | `--hard-dereference` faz o hard link virar **arquivo comum**; e o script **falha** se contar qualquer hard link no palco |

Conferência medida nesta rodada, na árvore real:

```
hard links no projeto (fora de node_modules) : 0
hard links em node_modules                   : 0
ZIP contem node_modules                      : 0
ZIP contem android/app/build, android/build, .gradle, .expo, local.properties : 0
ZIP contem (necessario para reconstruir)     : package.json, package-lock.json,
   app.config.js, babel.config.js, metro.config.js, tsconfig.json, index.js,
   app/, src/, android/, assets/, lib/, db/, tests/
```

Nada disso mudou código: o APK é o mesmo build (`fafa66db…`, não regenerado).

### O que continua pendente (só o aparelho responde)

Itens **32 a 37** do `CHECKLIST_APARELHO.md`: geração com/sem chave no A05s, chave
inválida mostrando o aviso e voltando ao modo gratuito, "Bloquear agora", "Ao sair",
temporizadores, biometria e a imagem protegida não abrindo sem desbloqueio.
`REAL_DEVICE_VALIDATION` para estes pontos segue **NOT_TESTED**.

## 16.16 Terceira rodada de 21/09 — o 403 que era kudos, não credencial

O aplicativo já abre, o bloqueio já bloqueia, a seed já é texto e o pedido já chega
ao servidor. O defeito restante era de **classificação e de tamanho**: um pedido
grande demais para a fila anônima era tratado como problema de chave.

### O que foi medido contra a API real (chave anônima, 21/09/2026)

```
512x768 30p -> 202     768x512 30p -> 202     512x640 30p -> 202
640x640 30p -> 403 kudos      768x768 30p -> 403 kudos
512x512 50p -> 403 kudos      512x512 40p -> 202   (o orçamento é área x passos)
384x576 · 576x384 · 512x512 · 512x384 · 576x320 · 384x384 · 448x576 -> 202
768x432 30p -> 400 "Input payload validation failed"   (432 não é múltiplo de 64)

403 por kudos, corpo real e sem edição:
{"message":"Due to heavy demand, for requests over 576x576 or over the applicable
 first-order-equivalent sampler work budget ... requires 13.68 kudos to fulfil.",
 "rc":"KudosUpfront"}
classificador do aplicativo sobre esse corpo: ehBloqueioDeKudos=true · kudosExigidos=13.68
```

Todo pedido que criou trabalho (202) foi **cancelado na hora**, para não gastar o
trabalho dos workers voluntários.

### Prova ponta a ponta com o código do aplicativo (rede real)

```
PROVIDER_MODE gratuito (chave anônima) · cabecalho_apikey=anonimo · seed=524766 (tipo=string)
HORDE_GRATUITO_AJUSTE · pedido=512x768/30p · usado=384x576/30p · limite=576 · 30
imagem: 69.084 bytes · image/webp · 35 s · avisoTipo=resolucao
aviso: "Modo gratuito: resolução ajustada para 384x576 para evitar cobrança de kudos."
```

### Suítes desta rodada

```
unidade                                     227/227   (era 208)
  tests/limites-horde.test.mjs               novo, 19  (os 6 obrigatórios + 13 da regra)
  tests/imageprompt.test.mjs                 ajustado: Cinema 432 -> 448 (medição real)
  tests/imageprovider.test.mjs               ajustado: pedido anônimo sai 384x576
render                                      184/184   (era 174; 24 suítes)
  tests/render/imagem-kudos.test.tsx         novo, 5
  tests/render/bloqueio-desempenho.test.tsx  novo, 5
tsc --noEmit                                limpo
eslint app db lib src --ignore-pattern db/migrations   0 erros (71 avisos antigos)
```

### Testes obrigatórios do relato e onde cada um está

```
TESTE 1 gratuito retrato 384x576        limites-horde "TESTE 1 · retrato"
TESTE 2 gratuito paisagem 576x384       limites-horde "TESTE 2 · paisagem"
TESTE 3 gratuito quadrado 512x512       limites-horde "TESTE 3 · quadrado"
TESTE 4 preset grande ajustado antes    limites-horde "TESTE 4" (+ 4b chave, + 4c cinema)
TESTE 5 403 de kudos não é credencial   limites-horde "TESTE 5"/"5b" + render "imagem-kudos"
TESTE 6 chave inválida é credencial     limites-horde "TESTE 6"/"6b"
seed continua texto (todos os caminhos) limites-horde "a seed continua TEXTO…"
```

### Otimização do bloqueio (medida, não presumida)

```
unlock: 2 derivações PBKDF2 (150.000 iterações cada) -> agora 1
medido nesta máquina: 1 derivação 347 ms · 2 derivações 666 ms · decifrar a DEK 0,8 ms
testes: deriva 1x na senha certa, 1x na errada; 150.000 iterações intactas;
        lockNow abaixo de 50 ms (é síncrono, sem espera artificial)
lockNow e o ouvinte do AppState: medidos, não têm espera/I-O/derivação -> não tocados
```

### O que continua pendente (só o aparelho responde)

Itens **35 a 40** do `CHECKLIST_APARELHO.md`. Os três novos são: 38 (resolução
ajustada no modo gratuito), 39 (erro de kudos com as saídas certas) e 40 (tempo do
desbloqueio). Seguem **NOT_TESTED**.

## 16.17 Quarta rodada de 21/09 — splash infinita no retorno com o bloqueio ligado

Relato: com a senha ativa, sair da Lunaria, o bloqueio automático disparar e voltar
prendia o aplicativo **para sempre na tela do logo**, sem chegar à tela de senha.
Causa: quem escondia a splash era a `HomeScreen`, que só existe **dentro do
`<Stack>`** — e o portão não monta o `<Stack>` enquanto está bloqueado. Detalhe em
`BUGS_FOUND.md` §BS.

### Suítes desta rodada

```
unidade                                     227/227
render                                      190/190 · 25 suítes   (era 184 · 24)
  tests/render/splash-retorno.test.tsx       novo, 6  (o defeito, com o portão REAL e o
                                             estado REAL: cofre, PBKDF2, verificador)
tsc --noEmit                                limpo
eslint app db lib src --ignore-pattern db/migrations   0 erros
versão                                      inalterada: 1.1.13 · versionCode 17
```

Os seis testes do defeito, e o que cada um prende:

```
1 abrir bloqueado     -> splash sai no fim da hidratação e a LockScreen aparece
2 "Bloquear agora"    -> LockScreen na frente, Stack fora, nada recoloca a splash
3 senha errada        -> continua na tela, erro na tela, sem splash
4 senha certa         -> destrava, Stack monta, cofre aberto, splash continua fora
5 sair e voltar       -> APPSTATE_ACTIVE refaz a decisão (SPLASH_HIDE_REQUESTED
                         motivo=volta ao primeiro plano) e a tela de senha aparece
6 hidratação que falha-> termina mesmo assim: ready=true, locked=true, tela de senha
                         na frente (nunca splash infinita)
```

### Prova de rede real, depois da correção (o gerador continua gerando)

```
PROVIDER_MODE gratuito (chave anônima) · seed=970406 (tipo=string) · tamanho=512x768
HORDE_GRATUITO_AJUSTE · pedido=512x768/30p · usado=384x576/30p · limite=576 · 30
imagem: 82.636 bytes · image/webp · 40 s · avisoTipo=resolucao
fila mostrada na tela ("Na fila — posição 250.") e conclusão em "Imagem pronta."
```

Prova crua em `lunaria-build/logs/prova-gerador-pos-splash-2026-09-21.txt`.

### Instrumentação no aparelho (para a trilha não ter mais "travou e não sei por quê")

Marcas pedidas no relato, todas gravadas na trilha de diagnóstico (Ajustes →
Diagnóstico): `SPLASH_VISIBLE`, `AUTH_HYDRATION_STARTED`, `AUTH_HYDRATION_COMPLETE`,
`LOCK_STATE`, `SPLASH_HIDE_REQUESTED`, `SPLASH_HIDDEN`, `UNLOCK_SCREEN_REQUESTED`,
`UNLOCK_SCREEN_MOUNTED`, `APPSTATE_BACKGROUND`, `APPSTATE_ACTIVE`,
`AUTO_LOCK_POLICY_APPLIED`, `ROUTER_READY`, `UNLOCK_SUCCESS`, `UNLOCK_FAILED`.

### O que continua pendente (só o aparelho responde)

Itens **41 a 48** do `CHECKLIST_APARELHO.md` — este defeito e os cenários do relato
(sair/voltar bloqueado, bloquear agora, senha errada, senha certa, sair e voltar
rápido, gerador depois de desbloquear, biometria). Seguem **NOT_TESTED**.

