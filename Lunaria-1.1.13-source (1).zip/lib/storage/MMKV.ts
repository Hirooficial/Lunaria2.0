import type * as MMKVModule from 'react-native-mmkv'
import { createJSONStorage, StateStorage } from 'zustand/middleware'

import { AVISO_CIFRADO, cifrarTexto, decifrarTexto, estaBloqueado } from '@lib/security/PrivateText'
import { setDiagStorage } from '@lib/utils/Diagnostics'
import { carregarModuloNativo } from '@lib/utils/NativeModules'

/**
 * Preferências do aplicativo.
 *
 * O armazenamento nativo (`react-native-mmkv`, ainda em beta na versão 4) é
 * criado **aqui**, no escopo do módulo — ou seja, no instante em que o pacote
 * JavaScript é avaliado, antes de qualquer tela. É o ponto mais frágil da
 * abertura: se a criação falhar, o aplicativo fechava sozinho, sem mensagem e
 * sem diagnóstico.
 *
 * Por isso a carga passa por `carregarModuloNativo` (com `try/catch` e registro
 * no relatório) e existe uma **reserva em memória**. Com ela o aplicativo abre
 * mesmo quando o armazenamento nativo não responde — as preferências não são
 * gravadas em disco durante essa sessão, mas o usuário vê o motivo no relatório
 * de diagnóstico em vez de um fechamento silencioso.
 */
type Preferencias = {
    getString: (key: string) => string | undefined
    getBoolean: (key: string) => boolean | undefined
    getNumber: (key: string) => number | undefined
    set: (key: string, value: string | number | boolean) => void
    remove: (key: string) => void
    getAllKeys: () => string[]
    clearAll: () => void
}

const memoria = (): Preferencias => {
    const dados = new Map<string, string | number | boolean>()
    return {
        getString: (key) => {
            const valor = dados.get(key)
            return typeof valor === 'string' ? valor : undefined
        },
        getBoolean: (key) => {
            const valor = dados.get(key)
            return typeof valor === 'boolean' ? valor : undefined
        },
        getNumber: (key) => {
            const valor = dados.get(key)
            return typeof valor === 'number' ? valor : undefined
        },
        set: (key, value) => {
            dados.set(key, value)
        },
        remove: (key) => {
            dados.delete(key)
        },
        getAllKeys: () => [...dados.keys()],
        clearAll: () => {
            dados.clear()
        },
    }
}

const nativo = carregarModuloNativo<Preferencias>('react-native-mmkv', () =>
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    (require('react-native-mmkv') as typeof MMKVModule).createMMKV()
)

export const mmkvEmMemoria = nativo === null

export const mmkv: Preferencias = nativo ?? memoria()

// O diagnóstico grava no armazenamento do próprio aplicativo. A ligação fica
// aqui, e não no Diagnostics, para aquele arquivo continuar sem dependência
// nativa — é o que permite testá-lo em Node puro.
setDiagStorage({
    getString: (key) => mmkv.getString(key),
    set: (key, value) => {
        mmkv.set(key, value)
    },
    remove: (key) => {
        mmkv.remove(key)
    },
})

export const mmkvStorage: StateStorage = {
    setItem: (name, value) => {
        return mmkv.set(name, value)
    },
    getItem: (name) => {
        const value = mmkv.getString(name)
        return value ?? null
    },
    removeItem: (name) => {
        return mmkv.remove(name)
    },
}

export const createMMKVStorage = () => {
    return createJSONStorage(() => mmkvStorage)
}

/**
 * Adaptador **cifrado** para estados que guardam texto do usuário — hoje, a
 * memória de pesquisa (`lib/state/ResearchMemory.ts`).
 *
 * Por que só ela, e não todos: os outros estados guardam **ajustes** (modo do
 * aplicativo, modelo local, endereço de API, filtros de texto) que são lidos **no
 * início da abertura**, antes de o cofre estar aberto. Cifrá-los faria a leitura
 * falhar justamente no arranque — trocar um ganho de privacidade por um defeito de
 * abertura. A memória de pesquisa, ao contrário, só é lida quando o usuário usa a
 * pesquisa, já com o aplicativo desbloqueado.
 *
 * Compatibilidade: valor antigo (sem marcador) volta como está. Com o cofre
 * fechado, a leitura devolve "nada" e a gravação é **ignorada** — assim o
 * conteúdo cifrado nunca é apagado por um estado vazio, e nada estoura na
 * abertura (ver `lib/security/PrivateText.ts`, regras 2 e 3).
 */
/**
 * Chaves cuja última leitura trouxe conteúdo de verdade (ou que não tinham nada
 * gravado). Serve para a regra da linha de baixo: **nunca gravar por cima do que
 * nunca se leu**.
 */
const leiturasValidas = new Set<string>()

/** A leitura desta chave já viu o conteúdo real do disco? (para testes e diagnóstico) */
export const leituraCifradaValida = (nome: string) => leiturasValidas.has(nome)

export const createMMKVStorageCifrado = () =>
    createJSONStorage(() => ({
        setItem: (name, value) => {
            // Cofre fechado: **não grava**. Gravar aqui seria gravar por cima do
            // conteúdo cifrado com um estado vazio (o armazenamento cifrado devolve
            // "nada" enquanto está fechado) — apagaria a memória do usuário. Ficar
            // sem gravar não perde nada: o conteúdo no disco continua intacto.
            if (estaBloqueado()) return
            // Nunca leu (por exemplo: o aplicativo abriu bloqueado, o estado nasceu
            // vazio e o desbloqueio ainda não religou a leitura): também não grava,
            // pelo mesmo motivo. Quem chama `rehydrate()` depois do desbloqueio
            // destrava esta chave.
            if (!leiturasValidas.has(name)) return
            mmkv.set(name, cifrarTexto(value))
        },
        getItem: (name) => {
            const value = mmkv.getString(name)
            // Nada gravado: não há o que perder, e a chave fica liberada para gravar.
            if (value === undefined) {
                leiturasValidas.add(name)
                return null
            }
            // Cofre fechado: devolve "nada" em vez do aviso (o aviso não é JSON e
            // faria a leitura do estado estourar) e **não** libera a chave para
            // gravação — a leitura não viu o conteúdo de verdade.
            if (estaBloqueado()) return null
            const aberto = decifrarTexto(value)
            // Valor ilegível (chave trocada, arquivo corrompido): "nada" em vez de
            // um aviso que não é JSON. A chave também não é liberada.
            if (aberto === AVISO_CIFRADO) return null
            leiturasValidas.add(name)
            return aberto
        },
        removeItem: (name) => {
            // Apagar continua valendo com o cofre fechado: aqui o usuário **quis**
            // apagar, e recusar seria guardar dado que ele mandou apagar.
            leiturasValidas.add(name)
            mmkv.remove(name)
        },
    }))
