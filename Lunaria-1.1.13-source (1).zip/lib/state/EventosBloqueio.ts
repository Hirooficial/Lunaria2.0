/**
 * Barramento de bloqueio.
 *
 * Existe por um motivo concreto: quando o aplicativo é bloqueado, o `AppLock`
 * precisa parar a leitura em voz alta e o microfone. Para isso ele importava o
 * TTS — e aí nascia o ciclo de importação
 *
 *     AppLock.ts → TTS.ts → Chat.ts → AppLock.ts
 *
 * O Metro avalia os módulos na ordem em que são pedidos. Dentro desse ciclo, o
 * `TTS.ts` chegava a ser avaliado com o `Chat.ts` ainda em avaliação; nessa
 * situação toda importação do `Chat` vale `undefined`, e o
 * `useInference.subscribe(...)` que está no fim do `TTS.ts` lançava
 * `Cannot read property 'subscribe' of undefined`.
 *
 * O estrago no aparelho era maior do que esse erro: o Metro, em produção,
 * envolve a avaliação de cada módulo e, quando ela lança, chama
 * `ErrorUtils.reportFatalError` e **devolve `undefined`** no lugar do módulo.
 * Quem pediu o módulo era o `loadRoute()` da rota raiz (`app/_layout.tsx`), que
 * importa o `AppLock`. Resultado: `fromImport(undefined)` em
 * `expo-router/build/useScreens.js:134` →
 * `Cannot read property 'ErrorBoundary' of undefined` → o aplicativo fechava na
 * abertura, antes de qualquer tela.
 *
 * Este arquivo é de propósito um módulo sem nenhuma importação. Quem avisa
 * (o `AppLock`) e quem ouve (o TTS) dependem apenas dele, e o ciclo desaparece.
 */

type Ouvinte = () => void | Promise<void>

const ouvintes = new Set<Ouvinte>()

/** Registra um ouvinte. Devolve a função que cancela o registro. */
export const aoBloquear = (ouvinte: Ouvinte): (() => void) => {
    ouvintes.add(ouvinte)
    return () => {
        ouvintes.delete(ouvinte)
    }
}

/**
 * Avisa todos os ouvintes de que o aplicativo foi bloqueado. Aguarda quem
 * devolver promessa (o TTS, por exemplo, precisa terminar de silenciar antes de
 * o cofre fechar), sem deixar um ouvinte travar os outros.
 */
export const avisarBloqueio = async (): Promise<void> => {
    await Promise.allSettled([...ouvintes].map((ouvinte) => ouvinte()))
}

/** Só para os testes: esvazia o barramento. */
export const limparOuvintesDeBloqueio = (): void => {
    ouvintes.clear()
}
