/**
 * Estado do bloqueio por senha/PIN.
 *
 * Princípios que este arquivo respeita (pedidos explicitamente):
 *  - o aplicativo começa **fechado** (`ready: false` trata como bloqueado);
 *    nada de conversa ou imagem aparecendo antes da autenticação;
 *  - autenticação é exigida para entrar, para trocar a senha e para desligar a
 *    proteção;
 *  - erros seguidos geram espera progressiva e **nunca** apagam dados;
 *  - ao bloquear: para a leitura em voz alta, desliga o microfone, fecha o cofre
 *    e limpa os temporários de imagem;
 *  - a senha nunca é guardada — só o verificador derivado dela.
 */

import type * as LocalAuthenticationModule from 'expo-local-authentication'
import { AppStateStatus } from 'react-native'
import { create } from 'zustand'

import {
    DEFAULT_AUTO_LOCK_MINUTES,
    lockoutSecondsFor,
    MIN_SECRET_LENGTH,
    validateSecret,
} from '@lib/security/LockPolicy'
import { clearPrivateImageCache } from '@lib/security/PrivateImageCache'
import { privateVault } from '@lib/security/PrivateStorage'
import {
    biometricAccessEnabled,
    changeSecret as changeVaultSecret,
    createVault,
    degradeToDeviceKey,
    destroyVault,
    deviceKeyExists,
    disableBiometricAccess,
    enableBiometricAccess,
    ensureDeviceVault,
    protectExistingKey,
    secretIsCorrect,
    unlockVaultSeCorreto,
    unlockVault,
    unlockWithBiometric,
    vaultExists,
} from '@lib/security/SecureVault'
import { avisarBloqueio } from '@lib/state/EventosBloqueio'
import { mmkv } from '@lib/storage/MMKV'
import { breadcrumb, describeError, recordError } from '@lib/utils/Diagnostics'
import { carregarModuloNativo } from '@lib/utils/NativeModules'

/**
 * A biometria é carregada sob demanda: importar `expo-local-authentication` no
 * topo faria o aplicativo fechar na abertura em aparelho sem o módulo, antes
 * mesmo de a tela de bloqueio existir. Ver `lib/utils/NativeModules.ts`.
 */
const carregarLocalAuthentication = () =>
    carregarModuloNativo<typeof LocalAuthenticationModule>('expo-local-authentication', () =>
        require('expo-local-authentication')
    )

const SETTINGS_KEY = 'lunaria-lock-settings-v1'

/** Motivo do bloqueio — vai para o log e para o texto da tela. */
export type LockReason = 'inicio' | 'segundo-plano' | 'manual' | 'tempo'

export type LockSettings = {
    /** Proteção ligada? Desligada por padrão. */
    enabled: boolean
    /** Atalho de biometria (exige senha para ativar/desativar). */
    biometric: boolean
    /** Minutos fora do aplicativo até bloquear. `0` = ao sair da frente. */
    autoLockMinutes: number
    /** Impede captura de tela e esconde o conteúdo no seletor de apps. */
    blockScreenshots: boolean
    /** Esconde o texto da mensagem nas notificações. */
    hideInNotifications: boolean
}

const DEFAULT_SETTINGS: LockSettings = {
    enabled: false,
    biometric: false,
    autoLockMinutes: DEFAULT_AUTO_LOCK_MINUTES,
    blockScreenshots: false,
    hideInNotifications: true,
}

const readSettings = (): LockSettings => {
    const raw = mmkv.getString(SETTINGS_KEY)
    if (!raw) return { ...DEFAULT_SETTINGS }
    try {
        return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<LockSettings>) }
    } catch {
        return { ...DEFAULT_SETTINGS }
    }
}

const writeSettings = (settings: LockSettings) => {
    mmkv.set(SETTINGS_KEY, JSON.stringify(settings))
}

const FAILURES_KEY = 'lunaria-lock-failures-v1'

type AppLockState = {
    /** `false` até a inicialização terminar: nesse estado o app não mostra conteúdo. */
    ready: boolean
    /** `true` = tela de bloqueio na frente. */
    locked: boolean
    /** Existe senha configurada? */
    configured: boolean
    /** Nome do histórico que aguardava destravar (vingo de notificação). */
    pendingChat?: { chatId: number; characterId: number }
    settings: LockSettings
    failures: number
    /** Segundos restantes de espera após erros seguidos. */
    lockoutSeconds: number
    biometricAvailable: boolean
    lastReason?: LockReason

    init: () => Promise<void>
    /**
     * Fecha a hidratação pelo lado seguro quando `init` falha de um jeito que ele
     * mesmo não conteve.
     *
     * Defeito de 21/09/2026, relatado no aparelho: voltando para o aplicativo com o
     * bloqueio automático ligado, a tela do logo ficava para sempre e a tela de
     * senha nunca aparecia. Parte da correção é no `_layout.tsx` (a splash sai no
     * fim da hidratação, não quando a `HomeScreen` monta); esta função fecha o outro
     * lado do mesmo buraco: **a hidratação precisa terminar mesmo quando falha**,
     * senão `ready` fica falso para sempre e não existe tela nenhuma para mostrar.
     *
     * Fail-closed aqui é aparecer **bloqueado**, não desaparecer: `locked: true` e a
     * LockScreen na frente, com as saídas que ela já tem (senha, biometria e
     * "esqueci a senha", que preserva as conversas). Nunca: falhou -> splash eterna.
     */
    markHydrationFailed: (error: unknown) => void
    /** Falha ao consultar o cofre nesta abertura (vazio quando deu tudo certo). */
    initError?: string
    unlock: (secret: string) => Promise<boolean>
    unlockWithBiometrics: () => Promise<boolean>
    /**
     * Bloqueia agora. Devolve o resultado: a tela **precisa** saber quando não deu
     * para bloquear (antes, sem cofre, a função saía em silêncio e o toque parecia
     * não fazer nada).
     */
    lockNow: (reason: LockReason) => { ok: boolean; error?: string }
    /** Primeira configuração: cria o cofre e liga a proteção. */
    enableLock: (secret: string) => Promise<{ ok: boolean; error?: string }>
    changeSecret: (current: string, next: string) => Promise<{ ok: boolean; error?: string }>
    disableLock: (secret: string) => Promise<{ ok: boolean; error?: string }>
    /** Esqueceu a senha: apaga o cofre e mantém as conversas. */
    resetVaultKeepingChats: (nextSecret: string) => Promise<{ ok: boolean; error?: string }>
    setAutoLock: (minutes: number) => Promise<void>
    setBlockScreenshots: (value: boolean) => Promise<void>
    setHideInNotifications: (value: boolean) => Promise<void>
    setBiometric: (value: boolean, secret: string) => Promise<{ ok: boolean; error?: string }>
    setPendingChat: (value?: { chatId: number; characterId: number }) => void
    registerFailure: () => void
    clearFailures: () => void
    tickLockout: () => void
}

const stopAudioAndMic = async () => {
    // Quem para a leitura em voz alta e o microfone são os ouvintes do
    // barramento (o TTS, por exemplo). Importar o TTS daqui criava o ciclo
    // AppLock → TTS → Chat → AppLock, que derrubava o aplicativo na abertura.
    // Ver o comentário longo em `EventosBloqueio.ts`.
    await avisarBloqueio()
}

export const useAppLock = create<AppLockState>()((set, get) => ({
    ready: false,
    // Começa bloqueado; `init` decide se há proteção configurada.
    locked: true,
    configured: false,
    settings: readSettings(),
    failures: Number(mmkv.getString(FAILURES_KEY) ?? 0),
    lockoutSeconds: 0,
    biometricAvailable: false,
    initError: undefined,

    init: async () => {
        breadcrumb('cofre: lendo ajustes')
        let settings = readSettings()
        let configured = false
        let initError: string | undefined

        // A leitura do cofre conversa com o Keystore do aparelho. Se ela falhar,
        // o aplicativo **não** pode morrer por isso: registra, avisa na tela e
        // segue com a proteção desligada. O conteúdo cifrado continua cifrado —
        // o que muda é que a falha fica visível em vez de virar tela preta.
        try {
            configured = await vaultExists()
            breadcrumb(`cofre: ${configured ? 'existe' : 'nao configurado'}`)
        } catch (error) {
            initError = describeError(error)
            recordError('cofre', error)
        }

        /**
         * QUEM MANDA NO "ESTÁ LIGADO" É O COFRE, NÃO A PREFERÊNCIA.
         *
         * Defeito relatado no aparelho em 21/09/2026: com a senha configurada, a
         * tela mostrava o cofre pronto (botão "Bloquear agora", biometria,
         * "Bloquear depois de") e **nada bloqueava** — nem o botão, nem o "Ao
         * sair", nem a abertura seguinte. A causa é a assimetria: o cofre (a prova
         * de que existe senha) mora no armazenamento seguro do sistema, durável; a
         * marca "está ligado" morava só no MMKV, que é preferência e pode voltar
         * vazia (ou o módulo nativo degradar para memória, o que este projeto já
         * admite em `lib/storage/MMKV.ts`). Quando os dois discordavam, o aplicativo
         * ficava **aberto** enquanto a tela continuava dizendo que estava protegido.
         *
         * Agora a existência do cofre decide: existe senha configurada -> proteção
         * ligada. A preferência é reescrita para concordar (conserta sozinho, em vez
         * de prender o usuário num estado em que nada bloqueia).
         */
        const ligado = configured
        if (settings.enabled !== ligado) {
            breadcrumb(
                `bloqueio: ajustando "ligado" de ${settings.enabled} para ${ligado} ` +
                    `(cofre ${configured ? 'existe' : 'não configurado'})`
            )
            settings = { ...settings, enabled: ligado }
            writeSettings(settings)
        }

        let biometricAvailable = false
        const biometria = carregarLocalAuthentication()
        try {
            biometricAvailable = biometria ? await biometria.hasHardwareAsync() : false
        } catch {
            biometricAvailable = false
        }

        // Sem senha configurada, o aplicativo abre direto — mas só aqui, depois
        // de ler o disco. Antes disto, `locked` continua `true` (fail-closed).
        //
        // Antes de destravar o aplicativo, o cofre precisa de chave para gravar
        // imagem e cifrar texto. Com senha configurada, a chave só aparece no
        // desbloqueio. SEM senha, ela é a **chave do aparelho** (Keystore) — sem
        // isto, gerar imagem falhava com "Cofre bloqueado" mesmo com o aplicativo
        // aberto (defeito relatado em 20/09/2026, BUGS_FOUND.md §BP).
        // `configured` é a autoridade agora: sem cofre com senha, o cofre usa a
        // chave do aparelho para gravar imagem e cifrar texto.
        if (!configured) {
            try {
                privateVault.unlock(await ensureDeviceVault())
                breadcrumb('cofre: chave do aparelho destravada')
            } catch (error) {
                recordError('cofre-aparelho', error)
                breadcrumb('cofre: sem chave do aparelho')
            }
        }

        set({
            settings,
            configured,
            biometricAvailable,
            // Fail-closed: existe cofre com senha -> abre bloqueado.
            locked: configured,
            ready: true,
            initError,
        })
        breadcrumb(
            `LOCK_STATE_CHANGED abertura -> locked=${configured} ` +
                `(cofre=${configured} · politica=${settings.autoLockMinutes === 0 ? 'ao sair' : `${settings.autoLockMinutes} min`})`
        )
    },

    markHydrationFailed: (error) => {
        const texto = describeError(error)
        recordError('bloqueio-hidratacao', error)
        breadcrumb(`AUTH_HYDRATION_COMPLETE (com falha) locked=true`)
        breadcrumb(`LOCK_STATE ready=true locked=true (hidratacao falhou · fail-closed)`)
        set({ ready: true, locked: true, initError: texto })
    },

    unlock: async (secret) => {
        const { failures } = get()
        const wait = lockoutSecondsFor(failures)
        if (wait > 0 && get().lockoutSeconds > 0) return false

        // UMA derivação, não duas (ver `unlockVaultSeCorreto`): antes o caminho
        // chamava `secretIsCorrect` e `unlockVault`, cada um com 150.000 iterações
        // de PBKDF2 sobre a mesma senha e o mesmo sal. O relato de 21/09/2026
        // ("o bloqueio está demorando um pouco") tem essa conta dentro.
        let dek: Uint8Array | undefined
        try {
            dek = await unlockVaultSeCorreto(secret)
        } catch (error) {
            // Cofre ausente/corrompido não é senha errada, mas também não pode abrir.
            recordError('cofre-desbloqueio', error)
            breadcrumb('UNLOCK_FAILED cofre indisponível (senha não conferida)')
            return false
        }

        if (!dek) {
            const nextFailures = failures + 1
            mmkv.set(FAILURES_KEY, nextFailures)
            set({ failures: nextFailures, lockoutSeconds: lockoutSecondsFor(nextFailures) })
            breadcrumb(`UNLOCK_FAILED tentativa ${nextFailures}`)
            return false
        }

        privateVault.unlock(dek)
        get().clearFailures()
        set({ locked: false, lastReason: undefined })
        breadcrumb('VAULT_UNLOCKED chave do cofre carregada · UNLOCK_SUCCESS')
        return true
    },

    unlockWithBiometrics: async () => {
        const enabled = await biometricAccessEnabled()
        if (!enabled) return false
        const biometria = carregarLocalAuthentication()
        if (!biometria) return false
        const result = await biometria.authenticateAsync({
            promptMessage: 'Desbloquear a Lunaria',
            cancelLabel: 'Usar senha',
        })
        if (!result.success) {
            breadcrumb('UNLOCK_FAILED biometria não confirmada')
            return false
        }
        const dek = await unlockWithBiometric()
        if (!dek) {
            breadcrumb('UNLOCK_FAILED biometria ligada mas sem chave guardada')
            return false
        }
        privateVault.unlock(dek)
        get().clearFailures()
        set({ locked: false, lastReason: undefined })
        breadcrumb('VAULT_UNLOCKED chave do cofre carregada · UNLOCK_SUCCESS (biometria)')
        return true
    },

    lockNow: (reason) => {
        const { configured, locked: estavaBloqueado } = get()

        breadcrumb(
            `LOCK_NOW_TRIGGERED motivo=${reason} · cofre=${configured ? 'configurado' : 'ausente'}`
        )

        if (!configured) {
            // Sem senha configurada não existe o que trancar — e isto **é** uma
            // resposta, não um silêncio: a tela mostra o motivo.
            breadcrumb('LOCK_NOW_TRIGGERED sem senha configurada: nada a bloquear')
            return {
                ok: false,
                error: 'Não há senha configurada ainda: preencha os dois campos e toque em "Ativar bloqueio".',
            }
        }

        // ORDEM IMPORTA — e a ordem certa é esta: **estado primeiro**.
        //
        // Antes o estado era o último passo, depois de cortar áudio, fechar o cofre
        // e limpar temporários. Bastava uma exceção em qualquer um desses três para
        // o `set({ locked: true })` nunca acontecer: o aplicativo continuava aberto
        // e o toque parecia não fazer nada — exatamente o relato de 21/09/2026.
        // Agora o bloqueio vale primeiro (fail-closed) e cada efeito colateral falha
        // sozinho, registrado, sem desfazer o bloqueio.
        set({ locked: true, lastReason: reason })
        breadcrumb(`LOCK_STATE_CHANGED ${estavaBloqueado} -> true (motivo=${reason})`)

        try {
            stopAudioAndMic()
        } catch (error) {
            recordError('bloqueio-audio', error)
        }
        try {
            privateVault.lock()
            breadcrumb('VAULT_LOCKED chave do cofre fora da memória')
        } catch (error) {
            recordError('bloqueio-cofre', error)
        }
        try {
            clearPrivateImageCache()
        } catch (error) {
            recordError('bloqueio-temporarios', error)
        }

        return { ok: true }
    },

    enableLock: async (secret) => {
        const verdict = validateSecret(secret)
        if (!verdict.ok) return { ok: false, error: verdict.reason }

        // Se já existe chave de aparelho (o usuário usava o aplicativo sem
        // senha), ela é **promovida**: a mesma DEK passa a ser embrulhada pela
        // senha, e as imagens já gravadas continuam legíveis. Só quando não há o
        // que promover é que uma DEK nova é criada.
        let dek: Uint8Array
        const chaveAtual = privateVault.chaveAtual()
        if (chaveAtual && (await deviceKeyExists()) && !(await vaultExists())) {
            await protectExistingKey(secret, chaveAtual)
            dek = chaveAtual
        } else {
            dek = await createVault(secret)
        }
        privateVault.unlock(dek)
        const settings: LockSettings = { ...get().settings, enabled: true }
        writeSettings(settings)
        set({ settings, configured: true, locked: false })
        get().clearFailures()
        breadcrumb('VAULT_UNLOCKED cofre criado/promovido · bloqueio LIGADO (aplicativo aberto)')
        return { ok: true }
    },

    changeSecret: async (current, next) => {
        if (!(await secretIsCorrect(current))) {
            get().registerFailure()
            return { ok: false, error: 'A senha atual não confere.' }
        }
        const verdict = validateSecret(next)
        if (!verdict.ok) return { ok: false, error: verdict.reason }
        await changeVaultSecret(current, next)
        // A DEK não mudou; se a biometria estava ligada, continua válida.
        get().clearFailures()
        return { ok: true }
    },

    disableLock: async (secret) => {
        if (!(await secretIsCorrect(secret))) {
            get().registerFailure()
            return { ok: false, error: 'Senha incorreta.' }
        }
        // Desligar a proteção **não** apaga as imagens: a mesma DEK passa a viver
        // só na chave do aparelho (Keystore). Elas continuam cifradas e legíveis —
        // o que muda é que a proteção deixa de exigir senha. Antes isto destruía o
        // cofre e as imagens ficavam inacessíveis; a tela avisa o que acontece.
        const dekAtual = privateVault.chaveAtual() ?? (await unlockVault(secret))
        await degradeToDeviceKey(dekAtual)
        privateVault.unlock(dekAtual)
        await disableBiometricAccess()
        privateVault.lock()
        clearPrivateImageCache()
        const settings: LockSettings = { ...get().settings, enabled: false, biometric: false }
        writeSettings(settings)
        set({ settings, configured: false, locked: false })
        get().clearFailures()
        return { ok: true }
    },

    resetVaultKeepingChats: async (nextSecret) => {
        const verdict = validateSecret(nextSecret)
        if (!verdict.ok) return { ok: false, error: verdict.reason }
        await destroyVault()
        // Aqui a DEK antiga se perde de propósito: o cofre foi esquecido, e o
        // aviso prévio na tela diz exatamente isso. Uma DEK nova é criada.
        const dek = await createVault(nextSecret)
        privateVault.unlock(dek)
        const settings: LockSettings = { ...get().settings, enabled: true }
        writeSettings(settings)
        set({ settings, configured: true, locked: false })
        get().clearFailures()
        return { ok: true }
    },

    setAutoLock: async (minutes) => {
        const settings: LockSettings = { ...get().settings, autoLockMinutes: minutes }
        writeSettings(settings)
        set({ settings })
    },

    setBlockScreenshots: async (value) => {
        const settings: LockSettings = { ...get().settings, blockScreenshots: value }
        writeSettings(settings)
        set({ settings })
    },

    setHideInNotifications: async (value) => {
        const settings: LockSettings = { ...get().settings, hideInNotifications: value }
        writeSettings(settings)
        set({ settings })
    },

    setBiometric: async (value, secret) => {
        if (!(await secretIsCorrect(secret))) {
            get().registerFailure()
            return { ok: false, error: 'Senha incorreta: a biometria só muda com autenticação.' }
        }
        if (value) {
            const dek = await unlockVault(secret)
            await enableBiometricAccess(dek)
        } else {
            await disableBiometricAccess()
        }
        const settings: LockSettings = { ...get().settings, biometric: value }
        writeSettings(settings)
        set({ settings })
        return { ok: true }
    },

    setPendingChat: (value) => set({ pendingChat: value }),

    registerFailure: () => {
        const nextFailures = get().failures + 1
        mmkv.set(FAILURES_KEY, nextFailures)
        set({ failures: nextFailures, lockoutSeconds: lockoutSecondsFor(nextFailures) })
    },

    clearFailures: () => {
        mmkv.remove(FAILURES_KEY)
        set({ failures: 0, lockoutSeconds: 0 })
    },

    tickLockout: () => {
        const current = get().lockoutSeconds
        if (current > 0) set({ lockoutSeconds: current - 1 })
    },
}))

/** Rótulo de minutos usado na tela: 0 é uma opção legítima ("ao sair"). */
export const MIN_SECRET = MIN_SECRET_LENGTH

export const shouldLockAfterBackground = (
    state: AppStateStatus,
    autoLockMinutes: number,
    secondsAway: number
): boolean => {
    if (state !== 'background' && state !== 'inactive') return false
    if (autoLockMinutes === 0) return true
    return secondsAway >= autoLockMinutes * 60
}
