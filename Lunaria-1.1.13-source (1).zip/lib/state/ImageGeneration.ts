/**
 * Estado da geração de imagem.
 *
 * Regras que valem aqui:
 *  - a política de conteúdo decide **antes** de qualquer rede;
 *  - a descrição final é mostrada ao usuário antes do envio (nada sai sem ele ver);
 *  - só existe **uma** geração por vez, cancelável (um `AbortController`);
 *  - a imagem pronta é gravada cifrada no cofre e indexada em
 *    `lunaria-generated-images-v1` (limite de 500 entradas antigas);
 *  - baixar é uma ação explícita do usuário e sempre avisa que a cópia externa
 *    perde a proteção da Lunaria.
 */

import type * as MediaLibraryModule from 'expo-media-library'
import type * as SharingModule from 'expo-sharing'
import { create } from 'zustand'

import Alert from '@components/views/Alert'
import {
    conferirChaveHorde,
    mascararChave,
    normalizarChave,
    ResultadoConferencia,
} from '@lib/imagegen/ChaveDoProvedor'
import { assessImagePrompt, PolicyVerdict } from '@lib/imagegen/ContentPolicy'
import {
    cofreEstaBloqueado,
    falhaAoGuardarNoCofre,
    falhaDesconhecida,
    estagioLegivel,
} from '@lib/imagegen/FalhaDeImagem'
import { buildImagePrompt, BuiltPrompt, randomSeed } from '@lib/imagegen/ImagePrompt'
import {
    generateImage,
    GenerationProgress,
    ImageGenerationError,
    ImageProviderId,
} from '@lib/imagegen/ImageProviders'
import {
    AspectRatioId,
    DEFAULT_LUNARIA_PROFILE,
    DEFAULT_NEGATIVE_PROMPT,
    ImageStyleId,
    LunariaProfile,
} from '@lib/imagegen/ImageStyles'
import { clearPrivateImageCache, forgetPrivateImage } from '@lib/security/PrivateImageCache'
import { exportFileName, toPrivateUri } from '@lib/security/PrivateNames'
import { privateVault } from '@lib/security/PrivateStorage'
import { Logger } from '@lib/state/Logger'
import { mmkv } from '@lib/storage/MMKV'
import { breadcrumb, recordError } from '@lib/utils/Diagnostics'
import { carregarModuloNativo } from '@lib/utils/NativeModules'

// Galeria e compartilhamento entram sob demanda: são módulos novos na 1.1.x e
// um `import` no topo derrubaria o aplicativo na abertura em aparelho onde eles
// não respondam (ver `lib/utils/NativeModules.ts`).
const carregarMediaLibrary = () =>
    carregarModuloNativo<typeof MediaLibraryModule>('expo-media-library', () =>
        require('expo-media-library')
    )

const carregarSharing = () =>
    carregarModuloNativo<typeof SharingModule>('expo-sharing', () => require('expo-sharing'))

const PREFS_KEY = 'lunaria-image-prefs-v1'
const PROFILE_KEY = 'lunaria-visual-profile-v1'
const LIBRARY_KEY = 'lunaria-generated-images-v1'
const LIBRARY_LIMIT = 500

export type ImagePrefs = {
    provider: ImageProviderId
    styleId: ImageStyleId
    aspectRatioId: AspectRatioId
    /** Chave própria do usuário (opcional). Nunca é gravada em log. */
    apiKey?: string
    model?: string
}

const DEFAULT_PREFS: ImagePrefs = {
    provider: 'horde',
    styleId: 'gotico',
    aspectRatioId: 'retrato',
}

export type GeneratedImageEntry = {
    id: number
    fileName: string
    width: number
    height: number
    styleId: ImageStyleId
    provider: ImageProviderId
    prompt: string
    bytes: number
    createdAt: string
    seconds: number
}

const readPrefs = (): ImagePrefs => {
    const raw = mmkv.getString(PREFS_KEY)
    if (!raw) return { ...DEFAULT_PREFS }
    try {
        return { ...DEFAULT_PREFS, ...(JSON.parse(raw) as Partial<ImagePrefs>) }
    } catch {
        return { ...DEFAULT_PREFS }
    }
}

const writePrefs = (prefs: ImagePrefs) => mmkv.set(PREFS_KEY, JSON.stringify(prefs))

export const readLunariaProfile = (): LunariaProfile => {
    const raw = mmkv.getString(PROFILE_KEY)
    if (!raw) return { ...DEFAULT_LUNARIA_PROFILE }
    try {
        return { ...DEFAULT_LUNARIA_PROFILE, ...(JSON.parse(raw) as Partial<LunariaProfile>) }
    } catch {
        return { ...DEFAULT_LUNARIA_PROFILE }
    }
}

export const writeLunariaProfile = (profile: LunariaProfile) =>
    mmkv.set(PROFILE_KEY, JSON.stringify(profile))

const readLibrary = (): GeneratedImageEntry[] => {
    const raw = mmkv.getString(LIBRARY_KEY)
    if (!raw) return []
    try {
        return JSON.parse(raw) as GeneratedImageEntry[]
    } catch {
        return []
    }
}

const writeLibrary = (entries: GeneratedImageEntry[]) =>
    mmkv.set(LIBRARY_KEY, JSON.stringify(entries.slice(0, LIBRARY_LIMIT)))

type ImageGenerationState = {
    prefs: ImagePrefs
    profile: LunariaProfile
    library: GeneratedImageEntry[]
    /** Prévia mostrada antes de enviar. */
    draft?: BuiltPrompt
    progress?: GenerationProgress
    /** Resultado pronto, aguardando o usuário anexar à conversa. */
    result?: GeneratedImageEntry
    error?: { kind: string; message: string; hint: string }
    /**
     * Aviso que a tela **precisa** mostrar sobre a credencial usada nesta imagem
     * (por exemplo: a chave salva foi recusada pelo provedor e a imagem saiu pelo
     * modo gratuito). Fica separado do erro: a imagem saiu, mas o usuário tem de
     * saber o que aconteceu — silêncio aqui esconderia uma chave errada.
     */
    aviso?: string
    /** Que aviso é: chave recusada (`credencial`) ou resolução baixada (`resolucao`). */
    avisoTipo?: 'credencial' | 'resolucao'
    /** Última conferência de chave (resultado para a tela de ajustes). */
    conferenciaChave?: ResultadoConferencia
    conferindoChave: boolean
    busy: boolean
    controller?: AbortController

    init: () => void
    setProvider: (provider: ImageProviderId) => void
    setStyle: (styleId: ImageStyleId) => void
    setAspectRatio: (aspectRatioId: AspectRatioId) => void
    setApiKey: (apiKey: string) => void
    /**
     * Confere a chave **antes** de salvar (pergunta à própria AI Horde). Chave que
     * o provedor não conhece não é salva — e, se havia uma chave salva, ela é
     * removida, para o usuário não ficar preso num estado inválido.
     */
    conferirESalvarChave: (chave: string) => Promise<ResultadoConferencia>
    /** Volta ao modo gratuito (chave anônima pública), apagando a chave salva. */
    usarModoGratuito: () => void
    /**
     * "Usar configuração gratuita": botão do erro de kudos.
     *
     * Faz as duas coisas que o erro pede — sai da chave (a cota anônima é quem
     * aceita o pedido) e tenta de novo **já com o tamanho gratuito**, porque é o
     * `generateWithHorde` que ajusta a resolução no modo gratuito. Nada de gastar
     * kudos do usuário sem ele saber: se a chave tiver saldo, ela continua lá até
     * este toque.
     */
    usarConfiguracaoGratuita: () => Promise<GeneratedImageEntry | undefined>
    limparAviso: () => void
    setModel: (model: string) => void
    saveProfile: (profile: LunariaProfile) => void
    /** Monta a prévia (não envia nada). */
    preview: (params: {
        description: string
        includeCharacter: boolean
        styleId?: ImageStyleId
        aspectRatioId?: AspectRatioId
    }) => BuiltPrompt
    /** Envia de verdade, depois da confirmação do usuário. */
    start: (params: {
        description: string
        includeCharacter: boolean
        styleId?: ImageStyleId
        aspectRatioId?: AspectRatioId
    }) => Promise<GeneratedImageEntry | undefined>
    cancel: () => void
    retry: () => Promise<GeneratedImageEntry | undefined>
    discard: () => void
    saveImageToGallery: (entry: GeneratedImageEntry) => Promise<void>
    shareImage: (entry: GeneratedImageEntry) => Promise<void>
    deleteImage: (entry: GeneratedImageEntry) => Promise<void>
}

/** Aviso padrão quando a cópia sai da proteção da Lunaria. */
const externalCopyWarning = (action: 'galeria' | 'compartilhar') =>
    action === 'galeria'
        ? 'A imagem vai para a galeria do aparelho. Fora da Lunaria ela fica **sem** a proteção do aplicativo: qualquer app com acesso à galeria poderá vê-la.'
        : 'Ao compartilhar, a imagem é enviada para fora da Lunaria e perde a proteção do aplicativo no destino.'

export const useImageGeneration = create<ImageGenerationState>()((set, get) => ({
    prefs: DEFAULT_PREFS,
    profile: { ...DEFAULT_LUNARIA_PROFILE },
    library: [],
    busy: false,
    conferindoChave: false,

    init: () => {
        // Preferências de imagem não podem impedir a abertura do aplicativo.
        try {
            set({ prefs: readPrefs(), profile: readLunariaProfile(), library: readLibrary() })
        } catch (error) {
            recordError('imagens (ajustes)', error)
        }
    },

    setProvider: (provider) => {
        const prefs = { ...get().prefs, provider }
        writePrefs(prefs)
        set({ prefs })
    },
    setStyle: (styleId) => {
        const prefs = { ...get().prefs, styleId }
        writePrefs(prefs)
        set({ prefs })
    },
    setAspectRatio: (aspectRatioId) => {
        const prefs = { ...get().prefs, aspectRatioId }
        writePrefs(prefs)
        set({ prefs })
    },
    setApiKey: (apiKey) => {
        const prefs = { ...get().prefs, apiKey }
        writePrefs(prefs)
        set({ prefs })
        breadcrumb(
            `IMAGEM_CHAVE_SET modo=${apiKey ? mascararChave(apiKey) : 'modo gratuito (sem chave)'}`
        )
    },

    /** Confere na AI Horde antes de salvar — e não deixa chave ruim guardada. */
    conferirESalvarChave: async (chave) => {
        // A Pollinations é gratuita e ignora chave de API (medido em 21/09/2026: 200
        // com chave inválida, com a anônima e sem cabeçalho). Conferir uma chave
        // contra a AI Horde aqui recusaria algo que o usuário nem precisa — então
        // nada é alterado e a tela explica.
        if (get().prefs.provider === 'pollinations') {
            return {
                estado: 'indeterminada',
                mensagem:
                    'A Pollinations é gratuita e não usa chave de API (o campo é ignorado por ' +
                    'ela). Nada foi alterado. Para usar chave própria, escolha a AI Horde acima.',
            }
        }
        set({ conferindoChave: true })
        breadcrumb('IMAGEM_CHAVE_CONFERINDO · GET /find_user')
        const resultado = await conferirChaveHorde(chave)
        breadcrumb(
            `IMAGEM_CHAVE_CONFERIDA estado=${resultado.estado} http=${resultado.status ?? '-'}` +
                `${resultado.detalhe ? ` · ${resultado.detalhe}` : ''}`
        )

        if (resultado.estado === 'valida') {
            // Guarda a chave **normalizada** (sem aspas/prefixo/espaço que vieram na cópia).
            const prefs = { ...get().prefs, apiKey: normalizarChave(chave) ?? chave.trim() }
            writePrefs(prefs)
            set({
                prefs,
                conferindoChave: false,
                conferenciaChave: resultado,
                aviso: undefined,
            })
            return resultado
        }

        if (resultado.estado === 'invalida') {
            // Não grava a chave recusada e remove a que estivesse salva: o usuário
            // volta ao modo gratuito **sem ficar preso** (era o defeito).
            const prefs = { ...get().prefs, apiKey: '' }
            writePrefs(prefs)
            set({ prefs, conferindoChave: false, conferenciaChave: resultado })
            breadcrumb('IMAGEM_CHAVE_REMOVIDA · voltou ao modo gratuito')
            return resultado
        }

        // Indeterminada (sem internet, 5xx): não troca nada às cegas.
        set({ conferindoChave: false, conferenciaChave: resultado })
        return resultado
    },

    usarModoGratuito: () => {
        const prefs = { ...get().prefs, apiKey: '' }
        writePrefs(prefs)
        set({ prefs, aviso: undefined, conferenciaChave: undefined })
        breadcrumb('IMAGEM_MODO_GRATUITO chave removida dos ajustes')
    },

    usarConfiguracaoGratuita: async () => {
        const prefs = { ...get().prefs, apiKey: '' }
        writePrefs(prefs)
        set({
            prefs,
            aviso: undefined,
            avisoTipo: undefined,
            error: undefined,
            conferenciaChave: undefined,
        })
        breadcrumb(
            'IMAGEM_CONFIGURACAO_GRATUITA pedida no erro de kudos · chave fora, tentando de novo'
        )
        return get().retry()
    },

    limparAviso: () => set({ aviso: undefined, avisoTipo: undefined }),
    setModel: (model) => {
        const prefs = { ...get().prefs, model }
        writePrefs(prefs)
        set({ prefs })
    },
    saveProfile: (profile) => {
        writeLunariaProfile(profile)
        set({ profile })
    },

    preview: ({ description, includeCharacter, styleId, aspectRatioId }) => {
        const { prefs, profile } = get()
        const draft = buildImagePrompt({
            description,
            styleId: styleId ?? prefs.styleId,
            aspectRatioId: aspectRatioId ?? prefs.aspectRatioId,
            includeCharacter,
            profile,
        })
        set({ draft, error: undefined })
        return draft
    },

    start: async ({ description, includeCharacter, styleId, aspectRatioId }) => {
        const { prefs, profile, busy } = get()
        if (busy) return undefined

        const draft = buildImagePrompt({
            description,
            styleId: styleId ?? prefs.styleId,
            aspectRatioId: aspectRatioId ?? prefs.aspectRatioId,
            includeCharacter,
            profile,
        })

        // Portão de conteúdo: recusa local, sem gastar rede nem cota.
        const verdict: PolicyVerdict = assessImagePrompt(draft.prompt)
        if (!verdict.allowed) {
            set({
                draft,
                error: {
                    kind: verdict.category ?? 'recusa',
                    message: verdict.reason,
                    hint: 'Ajuste a descrição e tente de novo.',
                },
            })
            return undefined
        }

        const controller = new AbortController()
        set({
            busy: true,
            draft,
            controller,
            error: undefined,
            aviso: undefined,
            avisoTipo: undefined,
            progress: { phase: 'preparando', message: 'Preparando o pedido…' },
        })

        try {
            const generated = await generateImage({
                provider: prefs.provider,
                prompt: draft.prompt,
                negativePrompt: draft.negativePrompt || DEFAULT_NEGATIVE_PROMPT,
                width: draft.width,
                height: draft.height,
                seed: draft.seed,
                apiKey: prefs.apiKey,
                model: prefs.model,
                signal: controller.signal,
                onProgress: (progress) => set({ progress }),
                // Diagnóstico pedido no relato: modo (gratuito/chave), se a chave foi
                // detectada, se o cabeçalho foi enviado, status HTTP, corpo sanitizado
                // e o payload sem segredo. Vai para a trilha do relatório.
                onDiagnostic: (evento) => breadcrumb(`IMAGEM ${evento}`),
            })

            // A chave salva foi recusada e a imagem saiu pelo modo gratuito: o
            // aviso vai para a tela **e** a chave ruim é removida dos ajustes —
            // sem isso o usuário seguiria preso no mesmo erro na próxima imagem.
            if (generated.aviso) {
                // Sem tipo declarado, o aviso é de credencial — é o único que existia
                // antes; `resolucao` (ajuste do modo gratuito) só vem explícito, e
                // nesse caso a chave do usuário continua onde estava.
                if ((generated.avisoTipo ?? 'credencial') === 'credencial') {
                    // A chave salva foi recusada: sai dos ajustes, senão o usuário
                    // segue preso no mesmo erro na próxima imagem.
                    const prefsLimpos = { ...get().prefs, apiKey: '' }
                    writePrefs(prefsLimpos)
                    set({ prefs: prefsLimpos })
                    breadcrumb('IMAGEM_CHAVE_REMOVIDA depois de recusa do provedor')
                }
                set({ aviso: generated.aviso, avisoTipo: generated.avisoTipo ?? 'credencial' })
            }

            // Grava cifrado no cofre e indexa. A gravação é a **etapa**
            // VAULT_SAVE: se o cofre estiver fechado aqui, o erro sai com essa
            // informação (não com um "não foi possível" genérico) e não vira
            // imagem pela metade.
            set({ progress: { phase: 'salvando', message: 'Guardando no cofre…' } })
            const stored = privateVault.writeFile(generated.bytes)
            const entry: GeneratedImageEntry = {
                id: Date.now(),
                fileName: stored.fileName,
                width: draft.width,
                height: draft.height,
                styleId: draft.styleId,
                provider: generated.provider,
                prompt: draft.prompt,
                bytes: generated.bytes.length,
                createdAt: new Date().toISOString(),
                seconds: generated.elapsedSeconds,
            }
            const library = [entry, ...get().library].slice(0, LIBRARY_LIMIT)
            writeLibrary(library)
            set({
                library,
                result: entry,
                busy: false,
                controller: undefined,
                progress: {
                    phase: 'concluido',
                    message: 'Imagem pronta.',
                    elapsedSeconds: entry.seconds,
                },
            })
            return entry
        } catch (error) {
            const failure =
                error instanceof ImageGenerationError
                    ? error
                    : cofreEstaBloqueado(error)
                      ? falhaAoGuardarNoCofre(error)
                      : falhaDesconhecida(error)
            Logger.error(
                `Geração de imagem falhou (${failure.kind}${
                    failure.stage ? `, etapa ${failure.stage}` : ''
                }): ${failure.message}` +
                    (failure.stage ? ` — ${estagioLegivel(failure.stage)}` : '')
            )
            set({
                busy: false,
                controller: undefined,
                error: { kind: failure.kind, message: failure.message, hint: failure.hint },
                progress:
                    failure.kind === 'cancelado'
                        ? { phase: 'cancelado', message: 'Geração cancelada.' }
                        : { phase: 'erro', message: failure.message },
            })
            return undefined
        }
    },

    cancel: () => {
        const controller = get().controller
        controller?.abort()
        set({
            busy: false,
            controller: undefined,
            progress: { phase: 'cancelado', message: 'Geração cancelada.' },
        })
    },

    retry: async () => {
        const draft = get().draft
        if (!draft) return undefined
        return get().start({
            description: draft.prompt,
            includeCharacter: draft.includeCharacter,
            styleId: draft.styleId,
            aspectRatioId: draft.aspectRatioId,
        })
    },

    discard: () =>
        set({ draft: undefined, result: undefined, error: undefined, progress: undefined }),

    saveImageToGallery: async (entry) => {
        Alert.alert({
            title: 'Salvar na galeria',
            description: externalCopyWarning('galeria'),
            buttons: [
                { label: 'Cancelar', type: 'default' },
                {
                    label: 'Salvar',
                    type: 'warning',
                    onPress: async () => {
                        try {
                            const { uri } = privateVault.exportToCache(entry.fileName)
                            const MediaLibrary = carregarMediaLibrary()
                            if (!MediaLibrary) {
                                Alert.alert({
                                    title: 'Galeria indisponível',
                                    description:
                                        'O módulo de galeria não respondeu neste aparelho. A imagem continua no cofre da Lunaria — use Compartilhar, escolhendo "Salvar em Fotos". O motivo está no relatório de diagnóstico.',
                                    buttons: [{ label: 'Entendi' }],
                                })
                                return
                            }
                            // No Android 10+ salvar na galeria não exige permissão;
                            // em versões antigas, o pedido pode ser negado.
                            const permission = await MediaLibrary.requestPermissionsAsync(false)
                            if (!permission.granted && permission.canAskAgain === false) {
                                Alert.alert({
                                    title: 'Permissão necessária',
                                    description:
                                        'Sem permissão de acesso às fotos, a Lunaria não consegue salvar na galeria. Você pode abrir o compartilhamento e escolher outro destino.',
                                    buttons: [{ label: 'Entendi' }],
                                })
                                return
                            }
                            await MediaLibrary.saveToLibraryAsync(uri)
                            Alert.alert({
                                title: 'Imagem salva',
                                description:
                                    'A cópia foi para a galeria do aparelho, fora da proteção da Lunaria.',
                                buttons: [{ label: 'Entendi' }],
                            })
                        } catch (error) {
                            Logger.error('Falha ao salvar na galeria: ' + error)
                            Alert.alert({
                                title: 'Não deu para salvar',
                                description:
                                    'A imagem continua no cofre da Lunaria. Tente pelo botão Compartilhar, escolhendo "Salvar em Fotos".',
                                buttons: [{ label: 'Entendi' }],
                            })
                        }
                    },
                },
            ],
        })
    },

    shareImage: async (entry) => {
        Alert.alert({
            title: 'Compartilhar',
            description: externalCopyWarning('compartilhar'),
            buttons: [
                { label: 'Cancelar', type: 'default' },
                {
                    label: 'Compartilhar',
                    type: 'warning',
                    onPress: async () => {
                        try {
                            const { uri } = privateVault.exportToCache(entry.fileName)
                            const Sharing = carregarSharing()
                            if (!Sharing) {
                                Alert.alert({
                                    title: 'Compartilhamento indisponível',
                                    description:
                                        'O módulo de compartilhamento não respondeu neste aparelho. A imagem continua no cofre da Lunaria. O motivo está no relatório de diagnóstico.',
                                    buttons: [{ label: 'Entendi' }],
                                })
                                return
                            }
                            if (!(await Sharing.isAvailableAsync())) {
                                Alert.alert({
                                    title: 'Compartilhamento indisponível',
                                    description:
                                        'Este aparelho não oferece o menu de compartilhar.',
                                    buttons: [{ label: 'Entendi' }],
                                })
                                return
                            }
                            await Sharing.shareAsync(uri, {
                                mimeType: 'image/*',
                                dialogTitle: 'Compartilhar imagem da Lunaria',
                            })
                        } catch (error) {
                            Logger.error('Falha ao compartilhar: ' + error)
                            Alert.alert({
                                title: 'Não deu para compartilhar',
                                description: 'Tente novamente em alguns instantes.',
                                buttons: [{ label: 'Entendi' }],
                            })
                        }
                    },
                },
            ],
        })
    },

    deleteImage: async (entry) => {
        Alert.alert({
            title: 'Apagar imagem',
            description:
                'A imagem sai do cofre da Lunaria e não pode ser recuperada. Se você já salvou uma cópia na galeria, essa cópia continua lá — a Lunaria não controla arquivos fora dela.',
            buttons: [
                { label: 'Cancelar', type: 'default' },
                {
                    label: 'Apagar',
                    type: 'warning',
                    onPress: async () => {
                        privateVault.deleteFile(entry.fileName)
                        forgetPrivateImage(entry.fileName)
                        const library = get().library.filter((item) => item.id !== entry.id)
                        writeLibrary(library)
                        set({
                            library,
                            result: get().result?.id === entry.id ? undefined : get().result,
                        })
                    },
                },
            ],
        })
    },
}))

/** Chamado ao bloquear: nenhum temporário decifrado pode sobreviver ao bloqueio. */
export const clearDecryptedImages = () => clearPrivateImageCache()
