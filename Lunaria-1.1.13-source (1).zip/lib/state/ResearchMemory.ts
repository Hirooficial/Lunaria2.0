import { create } from 'zustand'
import { persist } from 'zustand/middleware'

import { ResearchBundle, ResearchNote } from '@lib/research/Research.types'
import { formatResearchForModel } from '@lib/research/WebResearch'
import { createMMKVStorageCifrado } from '@lib/storage/MMKV'

const MAX_NOTES = 50

type ResearchMemoryState = {
    notes: ResearchNote[]
    activeBundle?: ResearchBundle
    saveBundle: (bundle: ResearchBundle) => void
    saveSummary: (id: string, summary: string) => void
    activate: (bundle?: ResearchBundle) => void
    remove: (id: string) => void
    clear: () => void
}

const tokenize = (value: string) =>
    new Set(
        value
            .toLocaleLowerCase('pt-BR')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .split(/[^a-z0-9]+/)
            .filter((term) => term.length >= 4)
    )

const relevance = (query: string, note: ResearchNote) => {
    const queryTerms = tokenize(query)
    const noteTerms = tokenize(`${note.query} ${note.summary ?? ''}`)
    let score = 0
    queryTerms.forEach((term) => {
        if (noteTerms.has(term)) score++
    })
    return score
}

export const useResearchMemoryStore = create<ResearchMemoryState>()(
    persist(
        (set) => ({
            notes: [],
            activeBundle: undefined,
            saveBundle: (bundle) =>
                set((state) => ({
                    notes: [
                        { ...state.notes.find((note) => note.id === bundle.id), ...bundle },
                        ...state.notes.filter((note) => note.id !== bundle.id),
                    ].slice(0, MAX_NOTES),
                })),
            saveSummary: (id, summary) =>
                set((state) => ({
                    notes: state.notes.map((note) =>
                        note.id === id ? { ...note, summary: summary.slice(0, 4_000) } : note
                    ),
                })),
            activate: (bundle) => set({ activeBundle: bundle }),
            remove: (id) =>
                set((state) => ({
                    notes: state.notes.filter((note) => note.id !== id),
                    activeBundle: state.activeBundle?.id === id ? undefined : state.activeBundle,
                })),
            clear: () => set({ notes: [], activeBundle: undefined }),
        }),
        {
            name: 'lunaria-research-memory-v1',
            storage: createMMKVStorageCifrado(),
            version: 2,
            partialize: (state) => ({ notes: state.notes }),
            migrate: (state) => ({ notes: (state as { notes?: ResearchNote[] })?.notes ?? [] }),
        }
    )
)

export namespace ResearchMemory {
    export const contextFor = (latestUserMessage: string) => {
        const state = useResearchMemoryStore.getState()
        const active = state.activeBundle
        if (active) return formatResearchForModel(active)

        const relevant = state.notes
            .map((note) => {
                const score = relevance(latestUserMessage, note)
                return { note, score }
            })
            .filter((item) => item.score > 0)
            .sort((a, b) => b.score - a.score || b.note.createdAt - a.note.createdAt)
            .slice(0, 2)

        if (relevant.length === 0) return ''
        return `MEMÓRIA DE PESQUISAS ANTERIORES (pode estar desatualizada; deixe isso claro):\n\n${relevant
            .map(({ note }) => formatResearchForModel(note))
            .join('\n\n---\n\n')}`
    }
}
