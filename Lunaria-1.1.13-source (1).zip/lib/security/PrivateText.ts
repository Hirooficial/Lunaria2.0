/**
 * Cifra do **texto** — conversas e memória.
 *
 * ## O que faltava
 *
 * As imagens geradas já eram cifradas no cofre (`.lunaenc`). O **texto** das
 * conversas (banco SQLite) e a memória de pesquisa (MMKV) ficavam em claro no
 * disco: protegidos pelo cofre de arquivos do Android, pela pasta privada do
 * aplicativo e pela porta de bloqueio, mas **não** pela Lunaria (`BUGS_FOUND.md`
 * §BE). Este arquivo fecha essa lacuna.
 *
 * ## Como funciona
 *
 * - A chave é a **mesma** do cofre (`PrivateVault`), que já é envelopada com a
 *   chave derivada da senha e guardada no armazenamento seguro do sistema. Nada
 *   de chave nova, nada de senha guardada.
 * - O valor cifrado vira uma string marcada: `enc:v1:<base64>`. O marcador é o que
 *   permite ler **dados antigos, ainda em claro**, sem migração obrigatória: o que
 *   não tem marcador é devolvido como está.
 * - Contexto autenticado (AAD) **próprio** (`lunaria-texto-v1`), diferente do
 *   usado nos arquivos: um texto cifrado não pode ser "colado" no lugar de uma
 *   imagem, nem o contrário.
 *
 * ## As quatro regras que este arquivo segue
 *
 * 1. **Claro nunca vira cifrado sem chave.** Sem cofre aberto, `cifrarTexto`
 *    devolve o texto como está — o aplicativo continua funcionando (quem não
 *    configurou a proteção não tem cofre, e é assim desde sempre).
 *
 * 2. **A leitura nunca lança e nunca inventa conteúdo.** Ler um valor cifrado sem
 *    a chave devolve um **aviso honesto** (`AVISO_CIFRADO`), não texto inventado e
 *    não uma exceção. A abertura do aplicativo tem de ser chata de quebrar: uma
 *    exceção no meio de uma leitura do banco, no arranque, é exatamente o defeito
 *    que estamos caçando. Nada é perdido — o conteúdo cifrado continua no disco,
 *    intacto, esperando o desbloqueio.
 *
 * 3. **Esse aviso nunca é gravado por cima do conteúdo.** Devolver o aviso poderia
 *    virar perda de dado se uma tela o salvasse de volta por cima da mensagem
 *    verdadeira (bastaria o usuário editar o texto). Por isso `cifrarTexto`
 *    **recusa** gravar o aviso: a tentativa lança, e a mensagem original fica onde
 *    está. É a única exceção que este arquivo lança, e ela só dispara na gravação
 *    por outros caminhos a leitura nunca chegaria a lançar.
 *
 * 4. **Falha inesperada não derruba nada.** Qualquer erro na gravação devolve o
 *    texto em claro (melhor perder a cifra daquela linha do que perder a linha).
 *    Na leitura, conteúdo cifrado corrompido também devolve o aviso, não uma
 *    exceção.
 */

import { textToBytes } from '@lib/utils/Binary'

import { decryptString, encryptString } from './Crypto'

/** Marca que distingue um valor cifrado de um valor antigo, em claro. */
export const MARCADOR = 'enc:v1:'

/** Contexto autenticado do texto (diferente do usado nos arquivos). */
export const AAD_TEXTO = textToBytes('lunaria-texto-v1')

/**
 * Aviso devolvido no lugar do conteúdo quando o cofre está fechado. É um texto
 * reconhecível (e recusado na gravação — ver regra 3).
 */
export const AVISO_CIFRADO = '«conteúdo cifrado — desbloqueie a Lunaria para ler»'

/** Erro lançado ao tentar **gravar** o aviso por cima de conteúdo de verdade. */
export const ERRO_GRAVACAO_DO_AVISO =
    'Recusado: isto é o aviso de conteúdo cifrado, não o conteúdo. Gravá-lo apagaria a mensagem original.'

export type FonteDaChave = () => Uint8Array | undefined

let fonte: FonteDaChave | null = null
let tentouCarregarCofre = false

/**
 * Liga a cifra de texto à chave do cofre. Chamado pelo `PrivateStorage` no
 * momento em que o módulo do cofre é avaliado — assim este arquivo continua
 * **puro** (sem dependência nativa) e testável em Node.
 */
export const registrarFonteDaChave = (nova: FonteDaChave) => {
    fonte = nova
}

/** Desliga a fonte (usado pelos testes). */
export const esquecerFonteDaChave = () => {
    fonte = null
    tentouCarregarCofre = false
}

const chaveAgora = (): Uint8Array | undefined => {
    if (!fonte && !tentouCarregarCofre) {
        tentouCarregarCofre = true
        try {
            // Carga tardia e cercada: se o cofre não estiver disponível neste
            // aparelho, o texto simplesmente não é cifrado — nada quebra.
            require('./PrivateStorage')
        } catch {
            // segue sem chave
        }
    }
    try {
        return fonte?.()
    } catch {
        return undefined
    }
}

/** O cofre está aberto agora? (usado para explicar a proteção na tela) */
export const podeCifrar = (): boolean => chaveAgora() !== undefined

/** O corpo depois do marcador parece um valor cifrado de verdade (base64)? */
const CORPO_CIFRADO = /^[A-Za-z0-9+/]+={0,2}$/

/**
 * O valor já está cifrado pela Lunaria?
 *
 * A checagem não é só o marcador: o corpo tem de parecer base64 e ter tamanho de
 * envelope (IV + etiqueta + conteúdo). Isso evita que um texto antigo, digitado
 * pelo usuário, que por acaso comece com `enc:v1:` seja lido como cifrado e vire
 * lixo. Na dúvida, o valor é tratado como dado antigo, em claro — que é a leitura
 * que não perde nada.
 */
export const estaCifrado = (valor: unknown): valor is string =>
    typeof valor === 'string' &&
    valor.startsWith(MARCADOR) &&
    valor.length > MARCADOR.length + 32 &&
    CORPO_CIFRADO.test(valor.slice(MARCADOR.length))

/**
 * Cifra um texto para gravar. Devolve o próprio texto quando não há chave, quando
 * o texto é vazio ou quando ele já está cifrado (idempotente).
 */
export const cifrarTexto = (texto: string): string => {
    if (typeof texto !== 'string' || texto.length === 0) return texto
    // Regra 3: o aviso nunca entra no lugar do conteúdo.
    if (texto === AVISO_CIFRADO) throw new Error(ERRO_GRAVACAO_DO_AVISO)
    if (estaCifrado(texto)) return texto
    const chave = chaveAgora()
    if (!chave) return texto
    try {
        return `${MARCADOR}${encryptString(chave, texto, AAD_TEXTO)}`
    } catch {
        // Gravar em claro é melhor do que não gravar.
        return texto
    }
}

/**
 * Abre um texto lido do disco.
 *
 * - Valor sem marcador: dado antigo, em claro — volta como está (é isto que faz as
 *   conversas anteriores à cifra continuarem legíveis, sem migração obrigatória).
 * - Valor cifrado com o cofre aberto: volta o texto de verdade.
 * - Valor cifrado **com o cofre fechado**: volta `AVISO_CIFRADO`, sem lançar.
 * - Valor cifrado **ilegível** (arquivo corrompido, chave diferente): volta
 *   `AVISO_CIFRADO`, sem lançar. Não inventamos conteúdo, e não derrubamos a tela.
 */
export const decifrarTexto = (valor: string): string => {
    if (!estaCifrado(valor)) return valor
    const chave = chaveAgora()
    if (!chave) return AVISO_CIFRADO
    try {
        return decryptString(chave, valor.slice(MARCADOR.length), AAD_TEXTO)
    } catch {
        return AVISO_CIFRADO
    }
}

/** O cofre está fechado agora? (a memória de pesquisa usa isto para não gravar) */
export const estaBloqueado = (): boolean => chaveAgora() === undefined
