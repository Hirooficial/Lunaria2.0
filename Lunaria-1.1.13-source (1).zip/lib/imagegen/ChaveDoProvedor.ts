/**
 * Credencial do provedor de imagem: ler, limpar, conferir e **não prender o
 * usuário** num estado inválido.
 *
 * ## O defeito que este arquivo resolve (relato de 21/09/2026)
 *
 * A tela mostrava, sempre:
 *
 *     "O provedor recusou a credencial usada."
 *     "Confira a chave nas configurações de imagem ou volte para a opção gratuita
 *      (AI Horde sem chave)."
 *
 * Medido contra a API real (21/09/2026), com o mesmo corpo e os mesmos cabeçalhos
 * do aplicativo:
 *
 *     apikey: 0000000000 (chave anônima pública)  -> HTTP 202  (funciona)
 *     apikey: <chave que a Horde não conhece>     -> HTTP 401  {"rc":"InvalidAPIKey"}
 *     sem o cabeçalho apikey                      -> HTTP 400
 *
 * Ou seja: **havia uma chave guardada que a Horde não reconhece** e o aplicativo a
 * enviava em todo pedido. O modo gratuito só é usado quando não há chave nenhuma —
 * e não existia (a) conferência no momento de salvar, (b) aviso de que havia chave
 * ativa, nem (c) caminho de volta ao modo gratuito que não fosse apagar um campo
 * mascarado e tocar em "Salvar chave". Quem errava uma letra da chave ficava preso.
 *
 * Aqui ficam as três peças que faltavam, **puras** (sem rede obrigatória, sem
 * módulo nativo) para rodarem nos testes de lógica:
 *
 *  1. `normalizarChave` — aceita o que as pessoas realmente colam: com aspas, com
 *     "Bearer ", com "apikey:", com espaço ou quebra de linha no meio. Chave que o
 *     usuário cola embrulhada não é chave errada; é chave mal copiada.
 *  2. `conferirChaveHorde` — pergunta à própria Horde (`GET /find_user`) se a chave
 *     existe, **antes** de salvar. Medido: 200 = existe (a anônima devolve
 *     `Anonymous#0`), 404 = "User with api_key … not found", 401 = sem chave.
 *  3. `avisoChaveRecusada` / `corpoSanitizado` — texto claro para a tela e para o
 *     diagnóstico, **sem nunca escrever a chave** (a Horde devolve a chave dentro da
 *     mensagem de erro: "User with api_key 'abc123' not found" — isso precisa ser
 *     mascarado antes de virar log).
 *
 * Regra que vem do encargo e vale sempre: **nada disso troca de provedor nem
 * esconde a falha**. Se a chave do usuário for recusada, a tela diz que foi
 * recusada; o modo gratuito entra como tentativa explícita, avisada na tela.
 */

/** Chave anônima pública da AI Horde (identificada, não é segredo). */
export const HORDE_ANONYMOUS_KEY = '0000000000'

export const HORDE_API = 'https://aihorde.net/api/v2'

/** A AI Horde pede identificação do cliente no formato Nome:Versão:Contato. */
export const CLIENT_AGENT = 'Lunaria:1.1.13:(github.com/Hirooficial/Lunaria2.0)'

export type ModoCredencial = 'gratuito' | 'chave'

export type CredencialEscolhida = {
    /** `gratuito` = chave anônima pública; `chave` = chave do usuário. */
    modo: ModoCredencial
    /** Valor já normalizado, quando há chave do usuário. */
    chave?: string
}

/**
 * Limpa o que o usuário colou. Chaves de API são alfanuméricas: espaço, aspas e
 * prefixos nunca fazem parte delas, então tirá-los nunca estraga uma chave boa —
 * só conserta uma mal copiada.
 *
 * Devolve `undefined` quando não sobra nada (aí o modo é gratuito).
 */
export const normalizarChave = (bruta?: string | null): string | undefined => {
    if (bruta === null || bruta === undefined) return undefined
    let texto = String(bruta).trim()
    if (!texto) return undefined
    // A ORDEM importa: aspas e prefixo são reconhecidos **com** os espaços ainda no
    // lugar. Tirar os espaços primeiro transformaria "Bearer chave" em
    // "Bearerchave" e o prefixo deixaria de ser reconhecido — foi o próprio teste
    // desta rodada que pegou isso.
    texto = texto.replace(/^["'`“”‘’«»]+/, '').replace(/["'`“”‘’«»]+$/, '')
    texto = texto.replace(/^(?:bearer|apikey|api[-_]key|key|token)\s*[:=]\s*/i, '')
    texto = texto.replace(/^bearer\s+/i, '')
    texto = texto.replace(/[\s\u00a0]/g, '')
    return texto.length > 0 ? texto : undefined
}

/** Decide qual credencial o request vai usar. Sem chave = modo gratuito. */
export const escolherCredencial = (apiKey?: string | null): CredencialEscolhida => {
    const chave = normalizarChave(apiKey)
    return chave ? { modo: 'chave', chave } : { modo: 'gratuito' }
}

/** O valor que vai no cabeçalho `apikey` (nunca vazio: a Horde recusa vazio com 400). */
export const chaveParaEnviar = (credencial: CredencialEscolhida): string =>
    credencial.modo === 'chave' ? (credencial.chave as string) : HORDE_ANONYMOUS_KEY

/**
 * Forma segura de citar a chave em log/tela: nada do segredo além dos 4 últimos
 * caracteres. Serve para o usuário reconhecer **qual** chave está ativa.
 */
export const mascararChave = (chave?: string): string => {
    if (!chave) return 'sem chave (modo gratuito)'
    const fim = chave.slice(-4)
    return `····${fim} (${chave.length} caracteres)`
}

/**
 * Rótulo do modo **por provedor**.
 *
 * A Pollinations é gratuita e **ignora** o cabeçalho de autorização (medido em
 * 21/09/2026: 200 com chave inválida, com a anônima e sem cabeçalho). Dizer "chave
 * anônima da AI Horde" ali seria mentira; e conferir uma chave de outro serviço
 * contra o `find_user` da Horde recusaria uma chave que o usuário nem precisa.
 */
export const rotuloDoModoPara = (
    provedor: 'horde' | 'pollinations',
    apiKey?: string | null
): string => {
    const credencial = escolherCredencial(apiKey)
    if (provedor === 'pollinations') {
        return credencial.modo === 'chave'
            ? `com chave própria ${mascararChave(credencial.chave)} (a Pollinations ignora chave)`
            : 'gratuito (Pollinations não usa chave)'
    }
    return rotuloDoModo(credencial)
}

/** Texto do modo, para a tela e para o diagnóstico. */
export const rotuloDoModo = (credencial: CredencialEscolhida): string =>
    credencial.modo === 'chave'
        ? `com chave própria ${mascararChave(credencial.chave)}`
        : 'gratuito (chave anônima da AI Horde)'

/** A resposta indica credencial recusada? (401/403 — medido na Horde: 401.) */
export const credencialRecusada = (status: number): boolean => status === 401 || status === 403

/**
 * O corpo do erro **sem segredo**. A Horde devolve a chave dentro da mensagem
 * (`User with api_key 'abc123' not found`), então a chave é trocada por `····`.
 */
export const corpoSanitizado = (
    corpo: string | undefined,
    chave?: string,
    limite = 240
): string => {
    const texto = (corpo ?? '').replace(/\s+/g, ' ').trim()
    if (!texto) return ''
    if (!chave) return texto.slice(0, limite)
    // Chave curta demais (1–2 caracteres) não dá para mascarar sem destruir o texto:
    // nesse caso o corpo inteiro é ocultado. Nada de segredo no relatório.
    if (chave.length < 3) return 'corpo oculto (chave curta demais para mascarar)'
    return texto.split(chave).join('····').slice(0, limite)
}

/** Linha de diagnóstico do pedido: sem chave, sem prompt inteiro, seed com tipo. */
export const descreverPedido = (dados: {
    provedor: string
    prompt: string
    width: number
    height: number
    seed?: string | number
    credencial: CredencialEscolhida
    model?: string
}): string =>
    [
        `provedor=${dados.provedor}`,
        `modo=${dados.credencial.modo}`,
        `chave=${mascararChave(dados.credencial.chave)}`,
        `cabecalho_apikey=${dados.credencial.modo === 'chave' ? 'enviado' : 'anonimo'}`,
        `seed=${dados.seed ?? 'ausente'} (tipo=${typeof dados.seed})`,
        `tamanho=${dados.width}x${dados.height}`,
        `modelo=${dados.model ?? 'padrão'}`,
        `prompt=${dados.prompt.length} caracteres`,
    ].join(' · ')

export type ResultadoConferencia = {
    /** `valida` = a Horde reconheceu; `invalida` = recusou; `indeterminada` = não deu para saber. */
    estado: 'valida' | 'invalida' | 'indeterminada'
    status?: number
    /** Nome do usuário dono da chave, quando a Horde respondeu. */
    usuario?: string
    /** Texto curto para a tela (sem a chave). */
    mensagem: string
    /** Corpo sanitizado da resposta, para o diagnóstico. */
    detalhe?: string
}

/**
 * Pergunta à AI Horde se a chave existe — **antes** de salvar.
 *
 * `GET /find_user` com a chave do usuário devolve o dono dela; com a chave anônima
 * devolve `Anonymous#0`. Medido em 21/09/2026: 200 = existe, 404 = não existe
 * ("User with api_key … not found"), 401 = sem chave nenhuma.
 *
 * Sem rede, devolve `indeterminada` — e nesse caso o aplicativo **não** troca a
 * credencial às cegas: mantém o modo em que estava e diz que não deu para conferir.
 */
export const conferirChaveHorde = async (
    chaveBruta: string,
    fetchImpl: typeof fetch = fetch,
    timeoutMs = 15_000
): Promise<ResultadoConferencia> => {
    const chave = normalizarChave(chaveBruta)
    if (!chave) {
        return {
            estado: 'invalida',
            mensagem: 'Nenhuma chave para conferir: o campo está vazio.',
        }
    }

    const controlador = new AbortController()
    const timer = setTimeout(() => controlador.abort(), timeoutMs)
    try {
        const resposta = await fetchImpl(`${HORDE_API}/find_user`, {
            headers: { apikey: chave, 'Client-Agent': CLIENT_AGENT },
            signal: controlador.signal,
        })
        const corpo = await resposta.text().catch(() => '')
        const detalhe = corpoSanitizado(corpo, chave)

        if (resposta.status === 200) {
            let usuario = 'conta confirmada'
            try {
                const dados = JSON.parse(corpo) as { username?: string }
                if (dados?.username) usuario = dados.username
            } catch {
                // Corpo inesperado não invalida a chave: o 200 já é a resposta.
            }
            return {
                estado: 'valida',
                status: 200,
                usuario,
                mensagem: `Chave aceita pela AI Horde (${usuario}).`,
            }
        }

        if (credencialRecusada(resposta.status) || resposta.status === 404) {
            return {
                estado: 'invalida',
                status: resposta.status,
                mensagem:
                    resposta.status === 404
                        ? 'A AI Horde não conhece esta chave (HTTP 404). Ela não foi salva.'
                        : 'A AI Horde recusou esta chave (HTTP ' +
                          `${resposta.status}). Ela não foi salva.`,
                detalhe,
            }
        }

        return {
            estado: 'indeterminada',
            status: resposta.status,
            mensagem: `A AI Horde respondeu ${resposta.status} e não deu para confirmar a chave.`,
            detalhe,
        }
    } catch (erro) {
        return {
            estado: 'indeterminada',
            mensagem:
                'Não deu para conferir a chave agora (sem internet?). ' +
                'Nada mudou: o aplicativo continua no modo em que estava.',
            detalhe: String((erro as { message?: unknown })?.message ?? erro).slice(0, 120),
        }
    } finally {
        clearTimeout(timer)
    }
}

/** Aviso mostrado **na tela** quando a chave salva foi recusada e o modo gratuito entrou. */
export const avisoChaveRecusada = (status: number, usuario?: string): string =>
    `A chave salva foi recusada pelo provedor (HTTP ${status}).` +
    `${usuario ? ` A chave que funcionou agora foi a pública.` : ''} ` +
    'Esta imagem saiu pelo **modo gratuito** (chave anônima da AI Horde). ' +
    'A chave recusada foi removida dos ajustes de imagem — se quiser usá-la, ' +
    'confira em stablehorde.net/register e cole de novo.' +
    (usuario ? ` A Horde registrou o pedido como ${usuario}.` : '')

/**
 * Aviso para quando a chave foi aceita **depois** de uma recusa anterior — o texto
 * é o mesmo caminho, mas sem prometer que a chave ruim sumiu sozinha.
 */
export const avisoModoGratuitoAtivo =
    'O aplicativo está no modo gratuito: a AI Horde usa a chave anônima pública. ' +
    'Pedidos anônimos entram na fila com prioridade menor e podem demorar mais.'
