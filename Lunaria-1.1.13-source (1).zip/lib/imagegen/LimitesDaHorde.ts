/**
 * Limite do modo gratuito da AI Horde — e a adaptação que evita pedir kudos.
 *
 * ## O defeito que este arquivo resolve (relato de 21/09/2026)
 *
 * No aparelho, gerar em **512×768** devolveu:
 *
 *     HTTP 403 · "Due to heavy demand, for requests over 576x576 or over the
 *     applicable first-order-equivalent sampler work budget the client needs to
 *     already have the required kudos. This request requires 10.42 kudos to fulfil."
 *
 * e a tela traduzia isso como **"O provedor recusou a credencial usada."** — que é
 * outra coisa. A credencial não tem nada a ver com isso: o pedido é que é grande
 * demais para a fila anônima.
 *
 * ## O que foi medido contra a API real (21/09/2026, chave anônima)
 *
 * Ordem do dia: "heavy demand" ativo, com o limite anunciado em **634x634** (no
 * relato do aparelho ele apareceu como 576x576 — o número é **dinâmico**, sobe e
 * desce com a demanda). Todos os pedidos que criaram trabalho foram **cancelados na
 * hora** (`DELETE /generate/status/{id}`), para não gastar o trabalho dos workers.
 *
 *     512x768  30 passos  -> 202   (passou HOJE, mas é o que falhou no aparelho)
 *     768x512  30 passos  -> 202
 *     512x640  30 passos  -> 202
 *     640x640  30 passos  -> 403   kudos
 *     768x768  30 passos  -> 403   kudos
 *     512x512  50 passos  -> 403   kudos   <- o orçamento de trabalho conta também
 *     512x512  40 passos  -> 202
 *     384x576  30 passos  -> 202
 *     576x384  30 passos  -> 202
 *     512x512  30 passos  -> 202
 *     512x384  30 passos  -> 202
 *     576x320  30 passos  -> 202
 *     384x384  30 passos  -> 202
 *     448x576  30 passos  -> 202
 *     768x432  30 passos  -> 400   "Input payload validation failed"  <- ver abaixo
 *
 * Duas conclusões que valem código:
 *
 *  1. O limite **não é fixo**: hoje 634, no relato 576. Por isso a regra do modo
 *     gratuito é conservadora e não usa o número do dia: **nenhuma dimensão acima
 *     de 576** e **no máximo 30 passos**. Todos os presets gratuitos abaixo passam
 *     nos dois cenários (576 e 634) — foram medidos, não deduzidos.
 *  2. A Horde exige **múltiplos de 64** nas duas dimensões. O preset "Cinema"
 *     (768×432) devolvia **400** em qualquer modo: 432 não é múltiplo de 64
 *     (432/64 = 6,75). Medido: 768×448 funciona. Isso não é limite de kudos — é
 *     pedido inválido, e é corrigido em **todos** os modos.
 *
 * O que **não** se faz aqui: trocar de provedor, esconder a recusa, gastar kudos do
 * usuário sem ele saber, ou presumir que ter chave é ter kudos. Quem tem chave mas
 * não tem kudos recebe o erro de kudos — com o texto certo e as opções certas.
 *
 * Módulo **puro**: sem rede, sem módulo nativo, sem relógio. Roda nos testes de
 * lógica (`tests/limites-horde.test.mjs`).
 */

/** Dimensão máxima do modo gratuito (conservador: o limite anunciado oscila entre 576 e 634). */
export const LIMITE_GRATUITO_HORDE = 576

/** Teto de passos no modo gratuito (medido: 40 passa, 50 é recusado por orçamento). */
export const PASSOS_GRATUITOS_MAX = 30

/** A Horde exige as duas dimensões múltiplas de 64 (medido: 432 = 400). */
export const MULTIPLO_HORDE = 64

/** Menor dimensão que o modo gratuito usa. */
export const MINIMO_GRATUITO = 384

export type Resolucao = { width: number; height: number }

/**
 * Equivalentes gratuitos dos presets da tela — **cada linha foi medida** (202 na
 * fila anônima). A tabela existe em vez de só uma conta porque o preset "Clássico"
 * (512×640, 4:5) não tem equivalente 4:5 dentro do limite: 448×560 não é múltiplo
 * de 64. Nesse caso, seguir o que o encargo pediu (512×384) é melhor do que um
 * número inventado que ninguém testou.
 */
const EQUIVALENTES_GRATUITOS: Record<string, Resolucao> = {
    '512x768': { width: 384, height: 576 },
    '768x512': { width: 576, height: 384 },
    '640x640': { width: 512, height: 512 },
    '512x640': { width: 512, height: 384 },
    '768x432': { width: 576, height: 320 },
    '768x448': { width: 576, height: 320 },
}

/** Arredonda **para baixo** até o múltiplo de 64 (nunca aumenta o pedido). */
const paraBaixo64 = (n: number): number =>
    Math.max(MULTIPLO_HORDE, Math.floor(n / MULTIPLO_HORDE) * MULTIPLO_HORDE)

/** As duas dimensões são válidas para a Horde? (múltiplos de 64 — medido com 768x432) */
export const dimensoesValidasParaHorde = (width: number, height: number): boolean =>
    Number.isFinite(width) &&
    Number.isFinite(height) &&
    width > 0 &&
    height > 0 &&
    width % MULTIPLO_HORDE === 0 &&
    height % MULTIPLO_HORDE === 0

/**
 * Conserta dimensão inválida sem inventar tamanho novo: arredonda para baixo até o
 * múltiplo de 64 (512×432 -> 512×384). Vale em **qualquer** modo, porque 400 é
 * pedido malformado, não limite de kudos.
 */
export const ajustarMultiploDeHorde = (width: number, height: number): Resolucao => ({
    width: paraBaixo64(width),
    height: paraBaixo64(height),
})

/**
 * A recusa é por **kudos/orçamento**, e não por credencial?
 *
 * A resposta da Horde é inconfundível ("heavy demand", "work budget",
 * "first-order-equivalent", "requires X kudos to fulfil") e **não** contém nada de
 * chave. A recusa de credencial é `{"rc":"InvalidAPIKey"}` / "No user matching sent
 * API Key". São coisas separadas de propósito: a primeira se resolve baixando a
 * resolução, a segunda trocando a chave.
 */
const MARCAS_DE_KUDOS = [
    // O código que a própria Horde usa para esta recusa (medido em 21/09/2026):
    //   {"message":"Due to heavy demand ... requires 13.68 kudos to fulfil.",
    //    "rc":"KudosUpfront"}
    // É o marcador mais confiável de todos: é o `rc` do serviço, não um texto solto.
    /KudosUpfront/i,
    /heavy demand/i,
    /work budget/i,
    /first-order/i,
    /requires?\s+[\d.,]+\s+kudos/i,
    /kudos to fulfil/i,
]

export const ehBloqueioDeKudos = (corpo?: string): boolean =>
    MARCAS_DE_KUDOS.some((marca) => marca.test(corpo ?? ''))

/** Quantos kudos o provedor exigiu, quando ele diz o número (para a tela). */
export const kudosExigidos = (corpo?: string): number | undefined => {
    const achado = /requires?\s+([\d.,]+)\s+kudos/i.exec(corpo ?? '')
    if (!achado) return undefined
    const numero = Number(achado[1].replace(',', '.'))
    return Number.isFinite(numero) ? numero : undefined
}

/**
 * Resolução equivalente dentro do que o modo gratuito aceita.
 * Usa a tabela medida quando o preset é conhecido; fora dela, reduz a maior
 * dimensão até 576 e arredonda para baixo em múltiplos de 64.
 */
export const resolucaoGratuitaPara = ({ width, height }: Resolucao): Resolucao => {
    const daTabela = EQUIVALENTES_GRATUITOS[`${width}x${height}`]
    if (daTabela) return daTabela

    // Já cabe: só garante o múltiplo de 64.
    if (width <= LIMITE_GRATUITO_HORDE && height <= LIMITE_GRATUITO_HORDE) {
        return ajustarMultiploDeHorde(width, height)
    }

    const maior = Math.max(width, height)
    const escala = LIMITE_GRATUITO_HORDE / maior
    const largura = paraBaixo64(width * escala)
    const altura = paraBaixo64(height * escala)
    return {
        width: Math.max(MINIMO_GRATUITO, Math.min(LIMITE_GRATUITO_HORDE, largura)),
        height: Math.max(MINIMO_GRATUITO, Math.min(LIMITE_GRATUITO_HORDE, altura)),
    }
}

export type AjusteDeLimite = {
    width: number
    height: number
    steps: number
    /** A resolução pedida era grande demais para a fila anônima. */
    mudouResolucao: boolean
    /** Os passos pedidos passavam do orçamento de trabalho do modo gratuito. */
    mudouPassos: boolean
    /** Alguma dimensão não era múltipla de 64 (pedido inválido para a Horde). */
    corrigiuMultiplo: boolean
    /** Texto pronto para a tela; só existe quando algo mudou. */
    aviso?: string
}

/**
 * Ajusta o pedido ao que o modo gratuito aceita — **antes** de enviar.
 *
 * O encargo é explícito: "NÃO envie a requisição inválida primeiro". Um pedido que
 * a fila anônima vai recusar por kudos não é enviado: ele sai já no tamanho
 * gratuito, e a tela diz o que foi feito e por quê.
 */
export const ajustarAoModoGratuito = (
    width: number,
    height: number,
    steps: number
): AjusteDeLimite => {
    const passos = Number.isFinite(steps) && steps > 0 ? Math.floor(steps) : PASSOS_GRATUITOS_MAX
    const mudouPassos = passos > PASSOS_GRATUITOS_MAX
    const foraDoLimite = width > LIMITE_GRATUITO_HORDE || height > LIMITE_GRATUITO_HORDE
    const multiploInvalido = !dimensoesValidasParaHorde(width, height)

    const resolucao =
        foraDoLimite || multiploInvalido
            ? resolucaoGratuitaPara({ width, height })
            : { width, height }

    const mudouResolucao = resolucao.width !== width || resolucao.height !== height
    const passosFinal = Math.min(passos, PASSOS_GRATUITOS_MAX)

    const partes: string[] = []
    if (mudouResolucao) {
        partes.push(
            `Modo gratuito: resolução ajustada para ${resolucao.width}x${resolucao.height} para evitar cobrança de kudos.`
        )
    }
    if (mudouPassos) {
        partes.push(
            `Passos ajustados de ${passos} para ${passosFinal} para caber no orçamento de trabalho do modo gratuito.`
        )
    }

    return {
        width: resolucao.width,
        height: resolucao.height,
        steps: passosFinal,
        mudouResolucao,
        mudouPassos,
        corrigiuMultiplo: !multiploInvalido ? false : !foraDoLimite,
        aviso: partes.length > 0 ? partes.join(' ') : undefined,
    }
}

/** O pedido, como está, caberia na fila anônima? (usado nos testes e no diagnóstico) */
export const cabeNoModoGratuito = (width: number, height: number, steps: number): boolean =>
    width <= LIMITE_GRATUITO_HORDE &&
    height <= LIMITE_GRATUITO_HORDE &&
    steps <= PASSOS_GRATUITOS_MAX &&
    dimensoesValidasParaHorde(width, height)

/** Linha de diagnóstico da adaptação (sem segredo, sem prompt). */
export const descreverAjuste = (
    pedido: Resolucao & { steps: number },
    usado: Resolucao & { steps: number }
): string =>
    [
        'HORDE_GRATUITO_AJUSTE',
        `pedido=${pedido.width}x${pedido.height}/${pedido.steps}p`,
        `usado=${usado.width}x${usado.height}/${usado.steps}p`,
        `limite=${LIMITE_GRATUITO_HORDE} (dimensão) · ${PASSOS_GRATUITOS_MAX} (passos)`,
    ].join(' · ')

/**
 * Texto curto mostrado **junto do seletor de proporção**, para a pessoa saber o que
 * vai sair antes de tocar em gerar — e não descobrir depois, com a imagem pronta no
 * tamanho que não escolheu.
 */
export const resumoDoModoGratuito = (preset: Resolucao): string => {
    const livre = resolucaoGratuitaPara(preset)
    if (livre.width === preset.width && livre.height === preset.height) {
        return `Modo gratuito: este tamanho (${preset.width}×${preset.height}) já cabe na fila anônima da AI Horde.`
    }
    return (
        `Modo gratuito: este preset sai em ${livre.width}×${livre.height} — ` +
        `a fila anônima da Horde limita a ${LIMITE_GRATUITO_HORDE} de largura/altura e ` +
        `${PASSOS_GRATUITOS_MAX} passos. Com chave e kudos suficientes, sai em ` +
        `${preset.width}×${preset.height}.`
    )
}
