/**
 * Classificação das falhas da geração de imagem, por **etapa do fluxo**.
 *
 * Por que existe: o relato de 20/09/2026 foi claro — "não esconda a falha com uma
 * mensagem genérica; diga em qual etapa parou". Quando a imagem não aparece, a
 * pessoa precisa saber se o pedido nem foi enviado, se o provedor recusou, se o
 * download falhou, se o cofre estava fechado na hora de guardar, ou se a leitura
 * de volta falhou. Isto aqui transforma o erro cru nessa informação, sem inventar
 * causa e sem esconder nada.
 *
 * As etapas são as mesmas usadas no diagnóstico pedido:
 *
 *   PROVIDER_REQUEST    o pedido não chegou a ser aceito pelo provedor
 *   PROVIDER_RESPONSE   o provedor aceitou e depois recusou / estourou a fila
 *   IMAGE_DOWNLOAD      a imagem foi gerada, mas não veio inteira/reconhecível
 *   VAULT_SAVE          a imagem chegou e o cofre recusou a gravação
 *   IMAGE_READ          a imagem está no cofre e a leitura de volta falhou
 *   IMAGE_DISPLAY       a imagem foi lida e a interface não conseguiu exibir
 *
 * O arquivo é **puro** de propósito (não importa o cofre nem módulo nativo): assim
 * roda nos testes de lógica sem aparelho, e a detecção do cofre é feita pelo
 * **nome** do erro — que é o contrato de `PrivateStorage.CofreBloqueadoError`.
 */

import { ImageGenerationError, ImageStage } from './ImageProviders'

/** Nome do erro de cofre fechado (contrato com `lib/security/PrivateStorage`). */
export const NOME_COFRE_BLOQUEADO = 'CofreBloqueadoError'

/** O erro veio do cofre fechado? (checado por nome, sem importar módulo nativo) */
export const cofreEstaBloqueado = (error: unknown): boolean =>
    (error as { name?: string })?.name === NOME_COFRE_BLOQUEADO

const mensagemCrua = (error: unknown): string =>
    String((error as { message?: unknown })?.message ?? error)

/** Falha ao guardar a imagem no cofre (cofre fechado na hora da gravação). */
export const falhaAoGuardarNoCofre = (error: unknown): ImageGenerationError =>
    new ImageGenerationError(
        'cofre',
        'A imagem foi gerada, mas o cofre está fechado e não deu para guardá-la.',
        `Etapa: VAULT_SAVE. ${mensagemCrua(error)} ` +
            'Abra a Lunaria e entre com a senha ou a biometria; depois gere de novo. ' +
            'A imagem não ficou salva pela metade — nada quebrou no cofre.',
        'VAULT_SAVE'
    )

/** Falha desconhecida: mantém a mensagem real do erro e diz a etapa, se souber. */
export const falhaDesconhecida = (
    error: unknown,
    stage?: ImageStage
): ImageGenerationError =>
    new ImageGenerationError(
        'desconhecido',
        'Não foi possível gerar a imagem.',
        `${estagioLegivel(stage)} ${mensagemCrua(error)}`.trim(),
        stage
    )

/** Texto curto da etapa, para entrar na dica mostrada na tela. */
export const estagioLegivel = (stage?: ImageStage): string => {
    switch (stage) {
        case 'PROVIDER_REQUEST':
            return 'Etapa: PROVIDER_REQUEST (o pedido não foi aceito pelo provedor).'
        case 'PROVIDER_RESPONSE':
            return 'Etapa: PROVIDER_RESPONSE (o provedor aceitou e depois recusou).'
        case 'IMAGE_DOWNLOAD':
            return 'Etapa: IMAGE_DOWNLOAD (a imagem não veio inteira).'
        case 'VAULT_SAVE':
            return 'Etapa: VAULT_SAVE (falhou ao guardar no cofre).'
        case 'IMAGE_READ':
            return 'Etapa: IMAGE_READ (falhou ao ler de volta do cofre).'
        case 'IMAGE_DISPLAY':
            return 'Etapa: IMAGE_DISPLAY (falhou ao exibir).'
        default:
            return ''
    }
}
