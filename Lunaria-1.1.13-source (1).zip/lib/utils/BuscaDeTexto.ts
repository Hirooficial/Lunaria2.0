/**
 * Comparação de texto da busca de mensagens.
 *
 * Por que isto é um arquivo separado: a busca deixou de ser um `LIKE` do SQL
 * (o texto das mensagens agora é **cifrado** no disco, e um `LIKE` sobre conteúdo
 * cifrado não encontraria nada — falharia em silêncio). A comparação passou a
 * acontecer em JavaScript, e é **aqui** que ela vive, para poder ser testada sem
 * banco, sem aparelho e sem tela.
 *
 * A regra é a mesma que o `LIKE` tinha, nem mais nem menos: **trecho contido,
 * sem diferenciar maiúsculas e minúsculas**. E também como o `LIKE`, **acento
 * conta**: procurar por `acao` não acha `Ação` — tem de procurar com o acento,
 * exatamente como antes. Manter a regra igual foi decisão: a busca mudou de
 * forma por causa da cifra, não para mudar de comportamento. Melhorar isso
 * (ignorar acento) seria mudança de recurso, e mudança de recurso não entra
 * escondida numa correção de segurança.
 */

/** Forma normalizada usada nas duas pontas da comparação. */
export const normalizarBusca = (texto: string): string => texto.toLocaleLowerCase()

/**
 * O texto contém o que se procura? Devolve `false` para consulta vazia — busca
 * vazia não devolve o histórico inteiro.
 */
export const combinaBusca = (texto: string, procurado: string): boolean => {
    if (typeof texto !== 'string') return false
    const alvo = procurado.trim()
    if (!alvo) return false
    return normalizarBusca(texto).includes(normalizarBusca(alvo))
}
