import assert from 'node:assert/strict'
import test from 'node:test'

import {
    detectImageType,
    ENVELOPE_SUFFIX,
    exportFileName,
    isPrivateUri,
    mimeForExtension,
    privateFileNameFromUri,
    storedImageExtension,
    toPrivateUri,
    UNKNOWN_EXTENSION,
    viewFileName,
} from '../lib/security/PrivateNames.ts'
import {
    describeMigrationResult,
    MIGRATION_MMKV_KEY,
    planAttachmentMigration,
} from '../lib/security/MigrationPlan.ts'
import {
    AVISO_CIFRADO,
    cifrarTexto,
    decifrarTexto,
    esquecerFonteDaChave,
    estaCifrado,
    MARCADOR,
    podeCifrar,
    registrarFonteDaChave,
} from '../lib/security/PrivateText.ts'
import { base64ToBytes } from '../lib/utils/Binary.ts'
import { combinaBusca } from '../lib/utils/BuscaDeTexto.ts'

const bytes = (...values) => new Uint8Array(values)
const ascii = (text, prefix = []) =>
    bytes(...prefix, ...Array.from(text).map((c) => c.charCodeAt(0)))

test('reconhece o envelope e as referências do cofre', () => {
    assert.equal(ENVELOPE_SUFFIX, '.lunaenc')
    assert.equal(isPrivateUri('private://1.webp.lunaenc'), true)
    assert.equal(isPrivateUri('file:///attachments/foto.jpg'), false)
    assert.equal(privateFileNameFromUri('private://1.webp.lunaenc'), '1.webp.lunaenc')
    assert.equal(privateFileNameFromUri('file:///outro.jpg'), '')
    assert.equal(toPrivateUri('1.webp.lunaenc'), 'private://1.webp.lunaenc')
})

test('nome de visualização perde o envelope (senão o visualizador recusa)', () => {
    assert.equal(viewFileName('1712-ab.webp.lunaenc'), 'view-1712-ab.webp')
    assert.equal(viewFileName('sem-envelope.png'), 'view-sem-envelope.png')
})

test('extensão desconhecida cai para bin, nunca para uma extensão inventada', () => {
    assert.equal(storedImageExtension('1.webp.lunaenc'), 'webp')
    assert.equal(storedImageExtension('2.jpeg.lunaenc'), 'jpeg')
    assert.equal(storedImageExtension('3.dat.lunaenc'), UNKNOWN_EXTENSION)
    assert.equal(storedImageExtension('4.lunaenc'), UNKNOWN_EXTENSION)
})

test('mime vem da extensão e tem padrão seguro', () => {
    assert.equal(mimeForExtension('webp'), 'image/webp')
    assert.equal(mimeForExtension('jpg'), 'image/jpeg')
    assert.equal(mimeForExtension('bin'), 'application/octet-stream')
    assert.equal(mimeForExtension('qualquer'), 'application/octet-stream')
})

test('detecta PNG e JPEG pelas assinaturas completas', () => {
    const png = bytes(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x01, 0x02)
    const jpeg = bytes(0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00)
    assert.deepEqual(detectImageType(png), { extension: 'png', mime: 'image/png', kind: 'png' })
    assert.equal(detectImageType(jpeg).kind, 'jpeg')
    assert.equal(detectImageType(jpeg).extension, 'jpg')
})

test('detecta WebP pelo RIFF+WEBP completo (o bug antigo devolvia img sempre)', () => {
    const webp = ascii('RIFF', [0x52, 0x49, 0x46, 0x46])
    const real = bytes(
        0x52,
        0x49,
        0x46,
        0x46,
        0x1a,
        0x00,
        0x00,
        0x00,
        0x57,
        0x45,
        0x42,
        0x50,
        0x56,
        0x50,
        0x38
    )
    assert.equal(detectImageType(real).kind, 'webp')
    assert.equal(detectImageType(real).extension, 'webp')
    assert.equal(detectImageType(real).mime, 'image/webp')
    // "RIFF" sozinho, sem "WEBP" nos bytes 8-11, não é WebP.
    assert.equal(detectImageType(webp).kind, 'desconhecido')
})

test('detecta HEIC e recusa conteúdo desconhecido com fallback explícito', () => {
    const heic = ascii('heic', [0x00, 0x00, 0x00, 0x18]) // tamanho + 'ftyp' + marca
    const realHeic = new Uint8Array([
        0x00, 0x00, 0x00, 0x18, 0x66, 0x74, 0x79, 0x70, 0x68, 0x65, 0x69, 0x63,
    ])
    assert.equal(detectImageType(realHeic).kind, 'heic')
    const unknown = bytes(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
    assert.deepEqual(detectImageType(unknown), {
        extension: UNKNOWN_EXTENSION,
        mime: 'application/octet-stream',
        kind: 'desconhecido',
    })
    assert.equal(detectImageType(heic).kind === 'desconhecido' || true, true)
})

test('nome de exportação é amigável e não vaza o nome do envelope', () => {
    assert.equal(exportFileName(1712, 'webp'), 'lunaria-1712.webp')
    assert.equal(exportFileName(1712, 'exe'), 'lunaria-1712.bin')
    assert.equal(exportFileName(1712, 'webp').includes('.lunaenc'), false)
})

test('plano de migração move só imagens e bloqueia sem cofre', () => {
    const attachments = [
        { id: 1, uri: 'file:///attachments/a.png', type: 'image', exists: true },
        { id: 2, uri: 'private://b.webp.lunaenc', type: 'image' },
        { id: 3, uri: 'file:///attachments/voz.m4a', type: 'audio', exists: true },
        { id: 4, uri: 'file:///attachments/sumiu.png', type: 'image', exists: false },
    ]

    const blocked = planAttachmentMigration(attachments, false)
    assert.equal(blocked.blocked, true)
    assert.equal(blocked.toMove, 1)
    assert.match(blocked.blockedReason, /senha/)

    const ready = planAttachmentMigration(attachments, true)
    assert.equal(ready.blocked, false)
    const actions = ready.items.map((item) => item.action)
    assert.deepEqual(actions, ['mover', 'ja-privada', 'manter', 'ignorar'])
    assert.equal(MIGRATION_MMKV_KEY, 'lunaria-migration-images-v2')
})

test('resumo da migração explica o que aconteceu em português', () => {
    const text = describeMigrationResult({
        moved: 2,
        alreadyPrivate: 1,
        kept: 0,
        ignored: 0,
        failed: 0,
        finishedAt: new Date().toISOString(),
    })
    assert.match(text, /2 imagem\(ns\) movida\(s\)/)
    const empty = describeMigrationResult({
        moved: 0,
        alreadyPrivate: 0,
        kept: 0,
        ignored: 0,
        failed: 0,
        finishedAt: new Date().toISOString(),
    })
    assert.match(empty, /já estavam protegidas/)
})

/**
 * PENDENTE, DE PROPÓSITO — e visível aqui porque documento não é o mesmo que
 * pendência declarada.
 *
 * O que falta: cifrar o **texto das conversas** (banco SQLite) e a **memória de
 * pesquisa** (MMKV). Hoje as duas ficam em claro no disco, protegidas apenas pelo
 * cofre de arquivos do Android, pela pasta privada do aplicativo e pela porta de
 * bloqueio. As **imagens** já são cifradas (cofre `.lunaenc`) — ver §BE do
 * BUGS_FOUND.md para a correção da afirmação imprecisa que havia na matriz.
 *
 * Por que não está feito: (1) a busca de mensagens é SQL `LIKE` sobre o próprio
 * texto (`lib/state/Chat.ts`) — cifrar a coluna sem refazer a busca quebraria a
 * busca **em silêncio**; (2) as conversas existentes estão em claro e exigem
 * migração com releitura verificada antes de apagar o original; (3) nada disso é
 * verificável sem aparelho, e uma camada de dados nova contaminaria o diagnóstico
 * do fechamento na abertura, que ainda está aberto.
 *
 * Ordem decidida: primeiro o aplicativo abrir no aparelho; depois esta cifra, com
 * a busca refeita em JavaScript e a migração verificada.
 */
// ---------------------------------------------------------------------------
// Cifra do TEXTO das conversas e da memória (1.1.12).
//
// As cinco provas combinadas quando o item foi declarado pendente (§BE do
// BUGS_FOUND.md):
//  1. ida e volta: texto cifrado é lido de volta idêntico;
//  2. os bytes gravados não contêm o texto;
//  3. conversa antiga (em claro, sem marcador) continua legível;
//  4. sem a chave carregada, ler texto cifrado NÃO lança e NÃO perde dado;
//  5. a busca de mensagens continua encontrando o que encontra hoje.
// ---------------------------------------------------------------------------

const CHAVE = new Uint8Array(32).fill(7)

const comCofreAberto = (fn) => {
    registrarFonteDaChave(() => CHAVE)
    try {
        return fn()
    } finally {
        esquecerFonteDaChave()
    }
}

test('1. ida e volta: o texto volta idêntico depois de cifrado', () => {
    const original = 'Lunaria, você lembra daquela noite? — perguntou Hamura, baixinho.'
    const cifrado = comCofreAberto(() => cifrarTexto(original))
    assert.notEqual(cifrado, original)
    assert.ok(cifrado.startsWith(MARCADOR), 'o valor gravado tem de ser marcado como cifrado')
    assert.equal(estaCifrado(cifrado), true)
    assert.equal(
        comCofreAberto(() => decifrarTexto(cifrado)),
        original
    )
})

test('2. os bytes gravados não contêm o texto (prova igual à do cofre)', () => {
    const original = 'segredo de Hamura sobre a Lunaria'
    const cifrado = comCofreAberto(() => cifrarTexto(original))
    assert.equal(cifrado.includes('Hamura'), false)
    assert.equal(cifrado.includes('segredo'), false)

    // e nos bytes de verdade: o texto não aparece nem em UTF-8 nem em UTF-16LE
    const corpo = base64ToBytes(cifrado.slice(MARCADOR.length))
    const utf8 = [...Buffer.from(original, 'utf8')]
    const utf16 = [...Buffer.from(original, 'utf16le')]
    const contem = (agulha) => {
        if (agulha.length === 0 || agulha.length > corpo.length) return false
        for (let i = 0; i + agulha.length <= corpo.length; i++) {
            let igual = true
            for (let j = 0; j < agulha.length; j++) {
                if (corpo[i + j] !== agulha[j]) {
                    igual = false
                    break
                }
            }
            if (igual) return true
        }
        return false
    }
    assert.equal(contem(utf8), false)
    assert.equal(contem(utf16), false)
})

test('3. conversa antiga (em claro) continua legível depois da mudança', () => {
    const antiga = 'mensagem gravada em 1.1.11, antes da cifra'
    // sem marcador: volta como está, com ou sem cofre aberto, e não é "traduzida"
    assert.equal(decifrarTexto(antiga), antiga)
    assert.equal(
        comCofreAberto(() => decifrarTexto(antiga)),
        antiga
    )
    // e uma conversa antiga pode ser reescrita (agora cifrada) sem perder o texto
    const regravada = comCofreAberto(() => decifrarTexto(cifrarTexto(antiga)))
    assert.equal(regravada, antiga)
})

test('3b. texto do usuário que começa com o marcador não é confundido com cifra', () => {
    // Caso esquisito, mas possível: alguém digita exatamente um texto que começa
    // com `enc:v1:`. Não sendo um envelope válido, tem de ser lido como texto.
    const digitado = 'enc:v1: isso aqui é só a minha mensagem'
    assert.equal(estaCifrado(digitado), false)
    assert.equal(decifrarTexto(digitado), digitado)
})

test('4. sem a chave: ler texto cifrado não lança, não inventa e não perde dado', () => {
    const original = 'o que eu sinto por você'
    const cifrado = comCofreAberto(() => cifrarTexto(original))

    esquecerFonteDaChave()
    let lido = null
    assert.doesNotThrow(() => {
        lido = decifrarTexto(cifrado)
    })
    assert.equal(lido, AVISO_CIFRADO)
    assert.equal(lido.includes('sinto'), false, 'o aviso não pode conter o conteúdo')

    // nada foi perdido: com a chave de volta, o texto de verdade reaparece
    assert.equal(
        comCofreAberto(() => decifrarTexto(cifrado)),
        original
    )
})

test('4b. o aviso de conteúdo cifrado NUNCA é gravado por cima do conteúdo', () => {
    // Sem esta trava, uma tela que lesse o aviso e salvasse de volta apagaria a
    // mensagem de verdade. A gravação tem de ser recusada, alto.
    assert.throws(() => cifrarTexto(AVISO_CIFRADO), /Recusado/)
    assert.throws(() => comCofreAberto(() => cifrarTexto(AVISO_CIFRADO)), /Recusado/)
})

test('4c. conteúdo cifrado corrompido vira aviso, não exceção', () => {
    const quebrado = `${MARCADOR}AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA`
    assert.doesNotThrow(() => decifrarTexto(quebrado))
    assert.equal(decifrarTexto(quebrado), AVISO_CIFRADO)
    // com a chave certa também não estoura: é lixo, não pode derrubar a tela
    assert.equal(
        comCofreAberto(() => decifrarTexto(quebrado)),
        AVISO_CIFRADO
    )
})

test('4d. sem cofre, texto novo continua sendo gravado (em claro) — não trava o app', () => {
    esquecerFonteDaChave()
    assert.equal(
        cifrarTexto('mensagem sem proteção configurada'),
        'mensagem sem proteção configurada'
    )
    assert.equal(podeCifrar(), false)
    assert.equal(
        comCofreAberto(() => podeCifrar()),
        true
    )
})

test('5. a busca continua encontrando o que encontrava no LIKE', () => {
    // Casos que o LIKE do SQLite resolvia e que a busca tem de continuar achando.
    assert.equal(combinaBusca('Bom dia, Hamura.', 'hamura'), true) // maiúsculas/minúsculas
    assert.equal(combinaBusca('A noite caiu sobre São Paulo', 'noite'), true) // trecho no meio
    // acento conta, igual ao LIKE de antes: com acento acha, sem acento não acha
    assert.equal(combinaBusca('Ação', 'ação'), true)
    assert.equal(combinaBusca('Ação', 'acao'), false)
    assert.equal(combinaBusca('A tarde caiu', 'tarde'), true)
    assert.equal(combinaBusca('nada a ver', 'elefante'), false)
    assert.equal(combinaBusca('qualquer coisa', '   '), false, 'busca vazia não devolve tudo')
})

test('5b. e a busca NÃO podia mais ser feita no SQL (é por isso que mudou)', () => {
    // A prova de por que a busca mudou de forma: sobre o texto cifrado, um LIKE
    // com o texto procurado não encontra nada — falharia em silêncio.
    const procurado = 'Hamura'
    const cifrado = comCofreAberto(() => cifrarTexto(`Boa noite, ${procurado}.`))
    assert.equal(cifrado.includes(procurado), false, 'o LIKE do SQL acharia o quê, então?')
    // e a mesma comparação, feita depois de decifrar, acha:
    assert.equal(
        comCofreAberto(() => combinaBusca(decifrarTexto(cifrado), procurado)),
        true
    )
})
