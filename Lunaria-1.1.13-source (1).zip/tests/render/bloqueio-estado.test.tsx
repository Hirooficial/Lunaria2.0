/**
 * Bloqueio: o ESTADO tem de mudar de verdade.
 *
 * O que este arquivo prende (relato de 21/09/2026 no Galaxy A05s):
 *
 *   1. "Bloquear agora" aparecia e **não bloqueava**;
 *   2. "Bloquear ao sair" também não;
 *   3. com a senha configurada, o aplicativo não ia para bloqueado quando devia.
 *
 * A causa era a assimetria entre as duas fontes de verdade: o cofre (prova de que
 * existe senha) mora no armazenamento seguro do sistema, e a marca "está ligado"
 * morava só no MMKV — que é preferência e pode voltar vazia. Quando os dois
 * discordavam, a tela mostrava o cofre pronto e o aplicativo continuava aberto.
 *
 * Aqui só o armazenamento nativo é simulado (keychain e MMKV em memória, em
 * jest.setup.js); o estado, o cofre e a criptografia são o código que vai no APK.
 */
import * as SecureStore from 'expo-secure-store'

import { privateVault } from '@lib/security/PrivateStorage'
import { shouldLockAfterBackground, useAppLock } from '@lib/state/AppLock'
import { mmkv } from '@lib/storage/MMKV'

const SETTINGS_KEY = 'lunaria-lock-settings-v1'
const senha = '123456'

const zeraEstado = () => {
    useAppLock.setState({
        ready: false,
        locked: false,
        configured: false,
        failures: 0,
        lockoutSeconds: 0,
        lastReason: undefined,
        settings: {
            enabled: false,
            biometric: false,
            autoLockMinutes: 0,
            blockScreenshots: false,
            hideInNotifications: true,
        },
    })
    ;(SecureStore as unknown as { __slots: Map<string, string> }).__slots.clear()
    mmkv.clearAll()
    privateVault.lock()
}

describe('estado do bloqueio (o que o aparelho mostrou e não acontecia)', () => {
    beforeEach(zeraEstado)

    it('ativa → bloqueia agora → o estado muda, o cofre fecha e o resultado é ok', async () => {
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)
        expect(useAppLock.getState().locked).toBe(false)
        expect(privateVault.isUnlocked).toBe(true)

        const resultado = useAppLock.getState().lockNow('manual')

        expect(resultado.ok).toBe(true)
        expect(useAppLock.getState().locked).toBe(true)
        expect(useAppLock.getState().lastReason).toBe('manual')
        expect(privateVault.isUnlocked).toBe(false)
    })

    it('desbloquear com a senha certa volta a liberar o aplicativo e o cofre', async () => {
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)
        useAppLock.getState().lockNow('manual')

        const abriu = await useAppLock.getState().unlock(senha)

        expect(abriu).toBe(true)
        expect(useAppLock.getState().locked).toBe(false)
        expect(privateVault.isUnlocked).toBe(true)
    })

    it('senha errada não abre e soma tentativa', async () => {
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)
        useAppLock.getState().lockNow('manual')
        const antes = useAppLock.getState().failures

        expect(await useAppLock.getState().unlock('999999')).toBe(false)
        expect(useAppLock.getState().locked).toBe(true)
        expect(useAppLock.getState().failures).toBe(antes + 1)
    })

    it('cofre existe e a preferência "ligado" se perdeu: a proteção continua LIGADA e bloqueia', async () => {
        // Primeira sessão: o usuário ativa a proteção normalmente.
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)

        // Segunda abertura: o MMKV voltou vazio (é preferência; pode degradar para
        // memória) — o cofre, que mora no armazenamento seguro, continua lá.
        mmkv.clearAll()
        privateVault.lock()
        useAppLock.setState({ ready: false, locked: false, configured: false })

        await useAppLock.getState().init()

        // O cofre manda: protegido, bloqueado na abertura, e o botão funciona.
        expect(useAppLock.getState().configured).toBe(true)
        expect(useAppLock.getState().locked).toBe(true)
        expect(useAppLock.getState().settings.enabled).toBe(true)
        expect(privateVault.isUnlocked).toBe(false)

        expect(useAppLock.getState().lockNow('manual').ok).toBe(true)
        expect(useAppLock.getState().locked).toBe(true)

        // E a preferência foi reescrita, para os módulos que leem `settings.enabled`
        // (o aviso de notificação, por exemplo) concordarem com o estado real.
        const gravado = JSON.parse(mmkv.getString(SETTINGS_KEY) as string)
        expect(gravado.enabled).toBe(true)
    })

    it('sem cofre, "Bloquear agora" responde o motivo em vez de não fazer nada', async () => {
        await useAppLock.getState().init() // sem senha configurada

        const resultado = useAppLock.getState().lockNow('manual')

        expect(resultado.ok).toBe(false)
        expect(resultado.error).toMatch(/não há senha configurada/i)
        expect(useAppLock.getState().locked).toBe(false)
    })

    it('a marca de "ligado" sem cofre é corrigida para desligado (não mente na tela)', async () => {
        mmkv.set(SETTINGS_KEY, JSON.stringify({ enabled: true, autoLockMinutes: 0 }))

        await useAppLock.getState().init()

        expect(useAppLock.getState().configured).toBe(false)
        expect(useAppLock.getState().locked).toBe(false)
        expect(useAppLock.getState().settings.enabled).toBe(false)
    })

    it('política "ao sair" (0 min): decide bloquear em qualquer tempo fora', () => {
        expect(shouldLockAfterBackground('background', 0, 0)).toBe(true)
        expect(shouldLockAfterBackground('background', 0, 3600)).toBe(true)
        expect(shouldLockAfterBackground('active', 0, 0)).toBe(false)
    })

    it('política de tempo: só bloqueia depois do tempo configurado', () => {
        expect(shouldLockAfterBackground('background', 5, 299)).toBe(false)
        expect(shouldLockAfterBackground('background', 5, 300)).toBe(true)
        expect(shouldLockAfterBackground('background', 1, 60)).toBe(true)
    })

    it('integração cofre/imagem: bloqueado, gerar imagem para em VAULT_SAVE; desbloqueado, funciona', async () => {
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)

        // Guarda uma imagem com o cofre aberto.
        const arquivo = privateVault.writeFile(new Uint8Array([0x89, 0x50, 0x4e, 0x47, 1, 2, 3]))
        expect(privateVault.readFile(arquivo.fileName).length).toBe(7)

        // Bloqueia: a imagem fica inacessível para o próprio aplicativo.
        useAppLock.getState().lockNow('manual')
        expect(() => privateVault.readFile(arquivo.fileName)).toThrow(/Cofre bloqueado/)

        // Desbloqueia: volta a ler a MESMA imagem (a chave não mudou).
        await useAppLock.getState().unlock(senha)
        expect(privateVault.readFile(arquivo.fileName).length).toBe(7)
    })
})
