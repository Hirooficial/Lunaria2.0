/**
 * O socorro do aplicativo, executado de verdade.
 *
 * Os testes de lógica (`tests/diagnostics.test.mjs`) provam a regra: contagem de
 * falhas, modo seguro depois de duas aberturas que não terminam, anel de passos.
 * Eles não provam que a **tela** aparece — e é isso que importa aqui: quando algo
 * dá errado no aparelho, esta é a única tela que o Hamura vai ver no lugar de um
 * fechamento silencioso.
 *
 * O que este teste cobre:
 *  - o relatório mostra o erro e os passos, e o botão copia o texto;
 *  - um erro de renderização cai no limite de erro em vez de derrubar a árvore;
 *  - o aviso de modo seguro aparece e pode ser desligado.
 */
import { fireEvent, render, screen, waitFor } from '@testing-library/react-native'
import { setStringAsync } from 'expo-clipboard'
import React from 'react'
import { Text } from 'react-native'

import DiagnosticBoundary from '../../src/components/views/DiagnosticBoundary'
import DiagnosticReport from '../../src/components/views/DiagnosticReport'
import {
    breadcrumb,
    isSafeMode,
    recordError,
    resetDiagStorage,
    setSafeMode,
} from '../../lib/utils/Diagnostics'

// Leitor do arquivo de falha nativa: controlado por teste. Por padrão devolve
// nada (nenhuma falha nativa registrada), como no aparelho de quem nunca travou.
const mockReadString = jest.fn(async (_caminho?: string) => undefined as string | undefined)
jest.mock('@lib/utils/File', () => {
    const real = jest.requireActual('@lib/utils/File')
    return { ...real, readStringAsync: (caminho: string) => mockReadString(caminho) }
})

const mockSalvarDiagnostico = jest.fn(async (_texto: string) => true)
jest.mock('@lib/utils/SalvarDiagnostico', () => ({
    salvarDiagnosticoNoAparelho: (texto: string) => mockSalvarDiagnostico(texto),
    NOME_ARQUIVO_DIAGNOSTICO: 'lunaria-diagnostico.txt',
}))

jest.mock('expo-clipboard', () => ({ setStringAsync: jest.fn(async () => true) }))
jest.mock('expo-application', () => ({
    nativeApplicationVersion: '1.1.3',
    nativeBuildVersion: '5',
}))
jest.mock('expo-device', () => ({
    modelName: 'SM-A055F',
    osName: 'Android',
    osVersion: '14',
    totalMemory: 6 * 1024 ** 3,
}))
jest.mock('expo-router', () => ({
    SplashScreen: { hideAsync: jest.fn(async () => undefined) },
}))

beforeEach(() => {
    resetDiagStorage()
    jest.clearAllMocks()
})

test('o relatório mostra o erro registrado e o aparelho, e o botão copia tudo', async () => {
    breadcrumb('abertura: começando')
    breadcrumb('bloqueio: lendo')
    recordError('cofre', new Error('Keystore indisponível'))

    render(<DiagnosticReport title="A Lunaria não conseguiu iniciar" detail="detalhe cru" />)

    expect(screen.getByText('A Lunaria não conseguiu iniciar')).toBeTruthy()
    expect(screen.getByText('detalhe cru')).toBeTruthy()
    const corpo = screen.getByText(/Lunaria — relatório de diagnóstico/)
    expect(corpo.props.children).toContain('Keystore indisponível')
    expect(corpo.props.children).toContain('SM-A055F')
    expect(corpo.props.children).toContain('bloqueio: lendo')
    expect(corpo.props.children).toContain('1.1.3 (build 5)')

    fireEvent.press(screen.getByText('Copiar diagnóstico'))
    await waitFor(() => expect(setStringAsync).toHaveBeenCalledTimes(1))
    const copiado = (setStringAsync as jest.Mock).mock.calls[0][0] as string
    expect(copiado).toContain('Keystore indisponível')
    expect(copiado).toContain('abertura: começando')

    // O relatório avisa, nele mesmo, que não carrega conteúdo pessoal.
    expect(copiado).toContain('Nenhuma conversa, senha ou imagem é registrada aqui')
})

test('o botão de tentar de novo chama de volta quem falhou', () => {
    const tentar = jest.fn()
    render(<DiagnosticReport title="Erro" onRetry={tentar} />)
    fireEvent.press(screen.getByText('Tentar novamente'))
    expect(tentar).toHaveBeenCalledTimes(1)
})

test('o modo seguro aparece com o número de falhas e pode ser desligado', () => {
    setSafeMode(true)
    render(<DiagnosticReport title="Erro" />)

    expect(screen.getByText('Modo seguro ligado')).toBeTruthy()
    expect(screen.getByText(/camadas novas ficaram de fora/)).toBeTruthy()
    expect(isSafeMode()).toBe(true)

    fireEvent.press(screen.getByText('Sair do modo seguro'))
    expect(isSafeMode()).toBe(false)
})

test('um erro de renderização vira relatório, não fechamento', () => {
    const Quebrado = () => {
        throw new Error('quebrou na montagem da tela')
    }
    // Silencia o log esperado do React para o erro do componente.
    const erroOriginal = console.error
    console.error = () => undefined
    try {
        render(
            <DiagnosticBoundary>
                <Quebrado />
            </DiagnosticBoundary>
        )
    } finally {
        console.error = erroOriginal
    }

    expect(screen.getByText('A Lunaria encontrou um erro na tela')).toBeTruthy()
    expect(screen.getByText('quebrou na montagem da tela')).toBeTruthy()
    expect(screen.getByText(/Nenhuma conversa, senha ou imagem é registrada aqui/)).toBeTruthy()
})

test('sem erro, o limite deixa a tela normal passar', () => {
    render(
        <DiagnosticBoundary>
            <Text>conversa da Lunaria</Text>
        </DiagnosticBoundary>
    )
    expect(screen.getByText('conversa da Lunaria')).toBeTruthy()
})

/**
 * O caso desta rodada: quando o Android gravou um registro de falha, a tela tem de
 * dizer **onde** o arquivo está (pasta Downloads do aparelho) e como enviá-lo sem
 * computador. Antes, o registro existia só na pasta privada — inalcançável para
 * quem usa o celular.
 */
test('falha nativa registrada: a tela diz que o arquivo está em Downloads', async () => {
    mockReadString.mockResolvedValueOnce(
        'Lunaria — registro de falha (gravado pelo próprio Android, antes do JavaScript)\n' +
            'versão: 1.1.7 (9)\n' +
            'tipo: a execução ANTERIOR terminou de forma anormal\n' +
            'motivo: falha NATIVA (biblioteca) (código 5)'
    )

    render(<DiagnosticReport title="A Lunaria encontrou um erro" />)

    // Duas menções de propósito: o aviso na tela e o texto do relatório.
    await waitFor(() => expect(screen.getByText(/Dá para me enviar sem computador/)).toBeTruthy())
    expect(screen.getAllByText(/lunaria-ultimo-erro\.txt/).length).toBeGreaterThan(0)

    fireEvent.press(screen.getByText('Copiar diagnóstico'))
    await waitFor(() => expect(setStringAsync).toHaveBeenCalledTimes(1))
    const copiado = (setStringAsync as jest.Mock).mock.calls[0][0] as string
    expect(copiado).toContain('falha NATIVA (biblioteca)')
    expect(copiado).toContain('lunaria-ultimo-erro.txt')
})

test('sem falha nativa registrada, a tela não fala em Downloads', async () => {
    mockReadString.mockResolvedValue(undefined)
    render(<DiagnosticReport title="A Lunaria encontrou um erro" />)
    await waitFor(() => expect(screen.getByText('Copiar diagnóstico')).toBeTruthy())
    expect(screen.queryByText(/lunaria-ultimo-erro\.txt/)).toBeNull()
})

/**
 * O terceiro caminho de saída: gravar o relatório na pasta Downloads do aparelho.
 * Se a área de transferência falhar (e ela pode falhar justamente quando o
 * aplicativo está quebrado), este botão ainda leva o texto para fora.
 */
test('o botão "Salvar em Downloads" grava o relatório e avisa o usuário', async () => {
    mockSalvarDiagnostico.mockClear()
    recordError('cofre', new Error('Keystore indisponível'))

    render(<DiagnosticReport title="A Lunaria não conseguiu iniciar" />)
    fireEvent.press(screen.getByText('Salvar em Downloads'))

    await waitFor(() => expect(mockSalvarDiagnostico).toHaveBeenCalledTimes(1))
    const salvo = String(mockSalvarDiagnostico.mock.calls[0][0])
    expect(salvo).toContain('Keystore indisponível')
    expect(salvo).toContain('SM-A055F')
    expect(await screen.findByText(/Relatório salvo na pasta Downloads/)).toBeTruthy()
})

test('se gravar falhar, a tela continua de pé (o texto não se perde)', async () => {
    mockSalvarDiagnostico.mockClear()
    mockSalvarDiagnostico.mockResolvedValueOnce(false)

    render(<DiagnosticReport title="A Lunaria não conseguiu iniciar" />)
    fireEvent.press(screen.getByText('Salvar em Downloads'))

    await waitFor(() => expect(mockSalvarDiagnostico).toHaveBeenCalled())
    // Sem aviso de sucesso; e o botão de copiar continua disponível.
    expect(screen.queryByText(/Relatório salvo na pasta Downloads/)).toBeNull()
    expect(screen.getByText('Copiar diagnóstico')).toBeTruthy()
})
