/**
 * Ao bloquear, a leitura em voz alta para.
 *
 * Este requisito existia desde a 1.1.12, e era ele que sustentava o ciclo de
 * importação que derrubava o aplicativo na abertura: o `AppLock` importava o
 * `TTS` para chamar `stopTTS()`, e o `TTS` importa o `Chat`, que importa o
 * `AppLock`. Agora o aviso passa por `lib/state/EventosBloqueio.ts` — e este
 * teste existe para provar que **o comportamento continua o mesmo** depois da
 * troca (BUGS_FOUND.md §BG).
 */
jest.mock('expo-speech', () => ({
    speak: jest.fn(),
    stop: jest.fn(async () => {}),
    getAvailableVoicesAsync: jest.fn(async () => []),
    isSpeakingAsync: jest.fn(async () => false),
}))

import { aoBloquear, avisarBloqueio, limparOuvintesDeBloqueio } from '@lib/state/EventosBloqueio'
import { useTTSStore } from '@lib/state/TTS'

describe('bloqueio silencia a leitura em voz alta', () => {
    it('avisarBloqueio() para a leitura (o TTS ouve o barramento)', async () => {
        // O TTS registra o ouvinte quando o módulo é avaliado (import acima),
        // exatamente como no aplicativo.
        const parar = jest.spyOn(useTTSStore.getState(), 'stopTTS').mockResolvedValue(undefined)
        await avisarBloqueio()
        expect(parar).toHaveBeenCalled()
        parar.mockRestore()
    })

    it('o barramento espera quem é assíncrono e respeita quem sai', async () => {
        limparOuvintesDeBloqueio()
        const ordem: string[] = []
        const remover = aoBloquear(async () => {
            await new Promise((r) => setTimeout(r, 5))
            ordem.push('assincrono')
        })
        aoBloquear(() => {
            ordem.push('sincrono')
        })

        await avisarBloqueio()
        expect(ordem.sort()).toEqual(['assincrono', 'sincrono'])

        remover()
        ordem.length = 0
        await avisarBloqueio()
        expect(ordem).toEqual(['sincrono'])
    })
})
