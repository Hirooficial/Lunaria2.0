/**
 * Regressão do fechamento na abertura (BUGS_FOUND.md §BG).
 *
 * No aparelho, o aplicativo fechava antes de mostrar qualquer tela com
 * `TypeError: Cannot read property 'ErrorBoundary' of undefined`, em
 * `expo-router/build/useScreens.js:134`, chamado pela raiz do contexto.
 *
 * A causa era um ciclo de importação (`AppLock → TTS → Chat → AppLock`): o Metro
 * avaliava o `TTS` com o `Chat` ainda em avaliação, o `useInference.subscribe(...)`
 * do fim do `TTS` lançava, o runtime de produção do Metro devolvia `undefined` no
 * lugar do módulo e o `fromImport` quebrava ao desestruturar `undefined`.
 *
 * Este teste carrega exatamente o que o aparelho carrega primeiro: a raiz do
 * contexto do Expo Router. Se o grafo de importação voltar a ter ciclo, é aqui
 * que aparece — em segundo, e não no telefone do Hamura.
 */
// Os dois módulos nativos de CPU/texto só existem no aparelho. Simulá-los é o que
// permite carregar a ROTA INICIAL inteira aqui dentro — antes desta rodada o Jest
// nem conseguia transformar esses pacotes (eram ESM fora da lista de transformação)
// e a primeira tela ficava sem teste de carregamento justamente por isso.
jest.mock('@vali98/react-native-cpu-info', () => ({
    getCpuFeatures: async () => ({}),
    getThreads: async () => 4,
}))
jest.mock('@vali98/react-native-process-text', () => ({
    setTextIntentEnabled: () => {},
    useTextIntentOnForeground: () => {},
}))

describe('abertura do aplicativo (raiz do contexto)', () => {
    const carregar = (caminho: string) => {
        let erro: unknown = null
        let mod: any = null
        jest.isolateModules(() => {
            try {
                mod = require(caminho)
            } catch (e) {
                erro = e
            }
        })
        return { erro, mod }
    }

    it('app/_layout.tsx carrega sem lançar e exporta o componente', () => {
        const { erro, mod } = carregar('app/_layout')
        expect(erro).toBeNull()
        expect(typeof mod?.default).toBe('function')
    })

    it('os módulos da cadeia do bloqueio carregam em qualquer ordem', () => {
        // A ordem em que o Metro avalia os módulos é a ordem dos imports; era
        // justamente uma ordem específica que derrubava o aplicativo.
        for (const caminho of ['@lib/state/AppLock', '@lib/state/TTS', '@lib/state/Chat']) {
            const { erro } = carregar(caminho)
            expect(erro).toBeNull()
        }
    })

    it('a tela de bloqueio carrega (ela é montada antes do desbloqueio)', () => {
        const { erro, mod } = carregar('@screens/LockScreen')
        expect(erro).toBeNull()
        expect(typeof mod?.default).toBe('function')
    })
    it('a ROTA INICIAL (app/index.tsx → HomeScreen) carrega sem lançar', () => {
        const { erro, mod } = carregar('app/index')
        expect(erro).toBeNull()
        expect(typeof mod?.default).toBe('function')
    })

    it('a rota da conversa carrega sem lançar', () => {
        const { erro, mod } = carregar('app/screens/ChatScreen/index')
        expect(erro).toBeNull()
        expect(typeof mod?.default).toBe('function')
    })
})
