/**
 * Bloqueio mais rápido, sem afrouxar nada (pedido de 21/09/2026:
 * "está demorando um pouco para executar; otimize só se puder fazer sem reduzir a
 * segurança ou quebrar o cofre").
 *
 * O que foi medido antes de mexer em qualquer linha:
 *
 *   1. `lockNow`     — não tem espera nenhuma: o estado muda primeiro e os efeitos
 *                      (parar voz/microfone, fechar o cofre, limpar a memória da
 *                      imagem) são síncronos e falham sozinhos. Nada a otimizar.
 *   2. ouvinte do AppState — não tem `setTimeout`, `sleep` nem I/O: decide e chama.
 *                      Nada a otimizar.
 *   3. **desbloquear** — aqui estava o custo: o caminho fazia DUAS derivações
 *                      PBKDF2-SHA256 de 150.000 iterações sobre a mesma senha e o
 *                      mesmo sal (`secretIsCorrect` + `unlockVault`). Isso é o
 *                      dobro do trabalho para a mesma resposta.
 *
 * A correção deriva **uma vez** (`unlockVaultSeCorreto`) e usa a mesma chave para
 * conferir o verificador e abrir o envelope. Este arquivo prova as três coisas que
 * importam: (a) deriva uma vez só; (b) senha errada não deriva duas vezes nem
 * decifra nada; (c) o resultado é o mesmo de antes.
 */
import * as Crypto from '@lib/security/Crypto'
import { privateVault } from '@lib/security/PrivateStorage'
import * as SecureVault from '@lib/security/SecureVault'
import { useAppLock } from '@lib/state/AppLock'
import { mmkv } from '@lib/storage/MMKV'

const senha = '123456'
const SETTINGS_KEY = 'lunaria-lock-settings-v1'

const zeraEstado = () => {
    useAppLock.setState({
        ready: false,
        locked: false,
        configured: false,
        failures: 0,
        lockoutSeconds: 0,
        lastReason: undefined,
        settings: {
            enabled: false,
            biometric: false,
            autoLockMinutes: 0,
            blockScreenshots: false,
            hideInNotifications: true,
        },
    })
    ;(require('expo-secure-store') as unknown as { __slots: Map<string, string> }).__slots.clear()
    mmkv.clearAll()
    privateVault.lock()
}

describe('desbloquear: uma derivação de chave, não duas', () => {
    beforeEach(() => {
        jest.restoreAllMocks()
        zeraEstado()
    })

    it('a senha certa deriva PBKDF2 UMA vez e abre o cofre', async () => {
        const espiao = jest.spyOn(Crypto, 'deriveKeyFromSecret')
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)
        useAppLock.getState().lockNow('manual')
        espiao.mockClear()

        const abriu = await useAppLock.getState().unlock(senha)

        expect(abriu).toBe(true)
        expect(privateVault.isUnlocked).toBe(true)
        // O número que importa: 1. Antes eram 2, cada uma com 150.000 iterações.
        expect(espiao).toHaveBeenCalledTimes(1)
    })

    it('a senha errada também deriva uma vez e NÃO abre o cofre', async () => {
        const espiao = jest.spyOn(Crypto, 'deriveKeyFromSecret')
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)
        useAppLock.getState().lockNow('manual')
        espiao.mockClear()

        const abriu = await useAppLock.getState().unlock('senha-errada')

        expect(abriu).toBe(false)
        expect(privateVault.isUnlocked).toBe(false)
        expect(useAppLock.getState().failures).toBe(1)
        expect(espiao).toHaveBeenCalledTimes(1)
    })

    it('a derivação continua com PBKDF2-SHA256 e as mesmas 150.000 iterações', () => {
        // Nada foi afrouxado para ficar mais rápido: se alguém baixar as iterações
        // para "otimizar", este teste reprova.
        expect(Crypto.PBKDF2_ITERATIONS).toBe(150_000)
        const espiao = jest.spyOn(Crypto, 'deriveKeyFromSecret')
        const sal = new Uint8Array(16).fill(7)
        SecureVault.encodeSalt(sal) // só para garantir que o módulo está carregado
        const chave = Crypto.deriveKeyFromSecret('senha', sal)
        expect(chave.length).toBe(32)
        expect(espiao).toHaveBeenCalledTimes(1)
    })

    it('o veredito do desbloqueio é o mesmo de antes: senha certa depois de erradas', async () => {
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)
        useAppLock.getState().lockNow('manual')

        expect(await useAppLock.getState().unlock('errada')).toBe(false)
        expect(await useAppLock.getState().unlock('outra-errada')).toBe(false)
        expect(useAppLock.getState().failures).toBe(2)

        expect(await useAppLock.getState().unlock(senha)).toBe(true)
        // Acertando, o contador zera — como antes.
        expect(useAppLock.getState().failures).toBe(0)
        expect(useAppLock.getState().locked).toBe(false)
    })

    it('bloquear agora segue sem espera artificial (estado primeiro, efeitos depois)', async () => {
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)

        const inicio = Date.now()
        const resultado = useAppLock.getState().lockNow('manual')
        const gasto = Date.now() - inicio

        expect(resultado.ok).toBe(true)
        expect(useAppLock.getState().locked).toBe(true)
        // Não há sleep, retry nem derivação no caminho de bloquear: é síncrono.
        expect(gasto).toBeLessThan(50)
        expect(privateVault.isUnlocked).toBe(false)
    })
})
