/**
 * "Bloquear ao sair" no portão de verdade (`app/_layout.tsx`).
 *
 * O relato de 21/09/2026 foi direto: a opção "Ao sair" estava selecionada e o
 * aplicativo não pedia senha ao voltar do segundo plano. Aqui o evento de
 * `AppState` é disparado à mão no layout real, com o estado do bloqueio
 * controlado pelo teste, e a asserção é sobre o que o portão **faz**: chamar
 * `lockNow('segundo-plano')` na saída (política "ao sair") ou na volta, depois do
 * tempo configurado.
 *
 * O que continua fora do alcance daqui: o comportamento do Android de verdade ao
 * mandar o aplicativo para trás (o A05s pode matar o processo) — isso fica no
 * checklist do aparelho.
 */
import { render } from '@testing-library/react-native'
import React from 'react'
import { AppState } from 'react-native'

import Layout from '../../app/_layout'

type LockState = Record<string, unknown>
let mockLockState: LockState = {}
let lockNowMock: jest.Mock

jest.mock('@lib/state/AppLock', () => {
    const useAppLock = (selector?: (s: LockState) => unknown) =>
        selector ? selector(mockLockState) : mockLockState
    // o layout também consulta o estado fora do React (segundo plano)
    useAppLock.getState = () => mockLockState
    return { useAppLock }
})

jest.mock('expo-router', () => {
    const React = require('react')
    const { View } = require('react-native')
    const Stack = ({ children }: { children?: React.ReactNode }) =>
        React.createElement(View, { testID: 'stack-do-app' }, children)
    Stack.Screen = () => null
    return {
        Stack,
        useRouter: () => ({ navigate: jest.fn(), push: jest.fn(), replace: jest.fn() }),
        SplashScreen: { preventAutoHideAsync: jest.fn(), hideAsync: jest.fn() },
    }
})
jest.mock('expo-splash-screen', () => ({ setOptions: jest.fn(), hideAsync: jest.fn() }))
jest.mock('expo-screen-capture', () => ({
    preventScreenCaptureAsync: jest.fn(),
    allowScreenCaptureAsync: jest.fn(),
}))
jest.mock('react-native-gesture-handler', () => {
    const React = require('react')
    const { View } = require('react-native')
    return {
        GestureHandlerRootView: ({ children }: { children?: React.ReactNode }) =>
            React.createElement(View, null, children),
    }
})
jest.mock('react-native-keyboard-controller', () => {
    const React = require('react')
    const { View } = require('react-native')
    return {
        KeyboardProvider: ({ children }: { children?: React.ReactNode }) =>
            React.createElement(View, null, children),
    }
})
jest.mock('@lib/notifications/Notifications', () => ({
    useAppStateNotificationObserver: jest.fn(),
}))
jest.mock('@lib/state/ImageGeneration', () => {
    const estado = { init: jest.fn(async () => {}) }
    return {
        useImageGeneration: (selector?: (s: LockState) => unknown) =>
            selector ? selector(estado) : estado,
    }
})
jest.mock('@components/views/ImageViewer', () => () => null)

/** Ouvintes de `AppState` registrados pelo layout, na ordem. */
let ouvintes: ((estado: string) => void)[] = []

const disparar = (estado: string) => ouvintes.forEach((ouvinte) => ouvinte(estado))

const montar = (overrides: Partial<LockState> = {}) => {
    lockNowMock = jest.fn()
    mockLockState = {
        ready: true,
        locked: false,
        configured: true,
        failures: 0,
        lockoutSeconds: 0,
        lastReason: undefined,
        settings: {
            enabled: true,
            biometric: false,
            autoLockMinutes: 0,
            blockScreenshots: false,
            hideInNotifications: true,
        },
        init: jest.fn(async () => {}),
        lockNow: lockNowMock,
        ...overrides,
    }
    return render(<Layout />)
}

describe('"Bloquear ao sair" (AppState no portão real)', () => {
    beforeEach(() => {
        ouvintes = []
        jest.spyOn(AppState, 'addEventListener').mockImplementation(((
            _evento: string,
            ouvinte: (estado: string) => void
        ) => {
            ouvintes.push(ouvinte)
            return { remove: jest.fn() }
        }) as unknown as typeof AppState.addEventListener)
    })

    afterEach(() => jest.restoreAllMocks())

    it('política "ao sair": bloquear já na saída (antes de voltar)', () => {
        montar()
        disparar('background')

        expect(lockNowMock).toHaveBeenCalledTimes(1)
        expect(lockNowMock).toHaveBeenCalledWith('segundo-plano')
    })

    it('política "ao sair": voltar também exige desbloqueio', () => {
        montar()
        disparar('background')
        disparar('active')

        expect(lockNowMock).toHaveBeenCalledWith('segundo-plano')
        // uma vez na saída, outra na volta (ou nenhuma repetição além dessas)
        expect(lockNowMock.mock.calls.length).toBeGreaterThanOrEqual(1)
    })

    it('política de 5 minutos: sair e voltar rápido NÃO bloqueia', () => {
        montar({
            settings: {
                enabled: true,
                biometric: false,
                autoLockMinutes: 5,
                blockScreenshots: false,
                hideInNotifications: true,
            },
        })
        disparar('background')
        expect(lockNowMock).not.toHaveBeenCalled()

        disparar('active')
        expect(lockNowMock).not.toHaveBeenCalled()
    })

    it('política de 5 minutos: fora além do tempo, bloqueia na volta', () => {
        montar({
            settings: {
                enabled: true,
                biometric: false,
                autoLockMinutes: 5,
                blockScreenshots: false,
                hideInNotifications: true,
            },
        })
        const agora = Date.now()
        disparar('background')
        // dez minutos fora
        jest.spyOn(Date, 'now').mockReturnValue(agora + 10 * 60_000)
        disparar('active')

        expect(lockNowMock).toHaveBeenCalledWith('segundo-plano')
    })

    it('sem cofre configurado, o segundo plano não tenta bloquear', () => {
        montar({ configured: false, settings: { enabled: false, autoLockMinutes: 0 } })
        disparar('background')
        disparar('active')

        expect(lockNowMock).not.toHaveBeenCalled()
    })

    it('já bloqueado: voltar do segundo plano não repete a chamada', () => {
        montar({ locked: true })
        disparar('active')
        expect(lockNowMock).not.toHaveBeenCalled()
    })
})
