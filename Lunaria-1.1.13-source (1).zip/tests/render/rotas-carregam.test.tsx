/**
 * TODAS as rotas de `app/` precisam carregar um módulo com componente.
 *
 * Por que este arquivo existe: no aparelho, o aplicativo fechava na abertura com
 * `Cannot read property 'ErrorBoundary' of undefined`, em
 * `expo-router/build/useScreens.js:134` (`fromImport`), chamado pela raiz do
 * contexto. A causa (BUGS_FOUND.md §BG) era um ciclo de importação
 * (`AppLock → TTS → Chat → AppLock`) que fazia o módulo da rota **raiz** lançar
 * durante a avaliação; o runtime de produção do Metro transforma esse lançamento em
 * `undefined`, e o `fromImport` quebra ao desestruturar `undefined`.
 *
 * A prova causal está registrada em TEST_REPORT.md §16.7: reintroduzindo a aresta
 * antiga (`AppLock → TTS`) nesta árvore, este mesmo teste mostra
 * `contextKey=./_layout.tsx … loaded=LANCOU(Cannot read properties of undefined
 * (reading 'subscribe'))`; retirando a aresta, as 28 rotas carregam.
 *
 * Os dois módulos nativos abaixo são simulados porque só existem no aparelho; sem
 * eles, o Jest não consegue carregar as cadeias que passam pelo `Startup` — e era
 * por isso que a rota inicial não tinha nenhum teste de carregamento antes.
 */
jest.mock('@vali98/react-native-cpu-info', () => ({
    getCpuFeatures: async () => ({}),
    getThreads: async () => 4,
}))
jest.mock('@vali98/react-native-process-text', () => ({
    setTextIntentEnabled: () => {},
    useTextIntentOnForeground: () => {},
}))

import fs from 'node:fs'
import path from 'node:path'

const APP = path.resolve(__dirname, '..', '..', 'app')

const listarArquivos = (dir: string): string[] =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) =>
        e.isDirectory() ? listarArquivos(path.join(dir, e.name)) : [path.join(dir, e.name)]
    )

const chaveDeContexto = (absoluto: string) =>
    './' + path.relative(APP, absoluto).split(path.sep).join('/')

describe('toda rota de app/ carrega um componente', () => {
    const arquivos = listarArquivos(APP).sort()

    it('são as rotas esperadas (27 rotas + o layout raiz)', () => {
        expect(arquivos.length).toBe(28)
        expect(arquivos.filter((f) => f.endsWith('_layout.tsx'))).toHaveLength(1)
    })

    it.each(arquivos.map((f) => [chaveDeContexto(f), f]))(
        '%s carrega (loadRoute não devolve undefined)',
        (_chave, absoluto) => {
            let modulo: { default?: unknown } | undefined
            let erro: unknown = null
            try {
                modulo = require(absoluto)
            } catch (e) {
                erro = e
            }
            if (erro) {
                throw new Error(
                    `a rota ${_chave} lançou ao carregar — no aparelho isso vira ` +
                        `"loadRoute() === undefined" e o aplicativo fecha na abertura: ${String(
                            (erro as Error).message
                        )}`
                )
            }
            expect(modulo).toBeDefined()
            expect(typeof modulo?.default).toBe('function')
        }
    )
})
