/**
 * Fluxo REAL da geração de imagem contra o cofre.
 *
 * Reproduz o caminho que o aparelho percorre em `ImageGenerationScreen`:
 * `start()` -> provedor -> gravação cifrada no cofre -> biblioteca -> resultado.
 * O provedor é substituído por um gerador fixo (nada de rede aqui), mas **todo o
 * resto é o código de verdade** — inclusive o cofre e a cifra.
 *
 * Prova o que o relato de 20/09/2026 pediu:
 *  - com o cofre aberto (chave do aparelho, sem senha), a imagem é gerada,
 *    gravada, lida de volta e indexada — e o resultado aparece para a interface;
 *  - com o cofre FECHADO, a falha sai identificada como **VAULT_SAVE**, não como
 *    um "não foi possível" genérico nem como culpa do provedor;
 *  - a seed continua sendo enviada como **texto** (a correção anterior fica presa
 *    pelo teste do provedor e por este, que confere o pedido que chega lá).
 */
import * as SecureStore from 'expo-secure-store'

import { generateImage } from '@lib/imagegen/ImageProviders'
import { privateVault } from '@lib/security/PrivateStorage'
import { resolvePrivateImage } from '@lib/security/PrivateImageCache'
import { ensureDeviceVault } from '@lib/security/SecureVault'
import { useImageGeneration } from '@lib/state/ImageGeneration'
import { mmkv } from '@lib/storage/MMKV'

jest.mock('@lib/imagegen/ImageProviders', () => {
    const real = jest.requireActual('@lib/imagegen/ImageProviders')
    return { ...real, generateImage: jest.fn() }
})

const PIXEL = new Uint8Array([
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3, 4, 5, 6, 7, 8,
])
const gerada = {
    bytes: PIXEL,
    mime: 'image/png',
    extension: 'png',
    provider: 'horde' as const,
    model: 'stable_diffusion',
    seed: 364056,
    elapsedSeconds: 42,
}

const slots = () => (SecureStore as unknown as { __slots: Map<string, string> }).__slots
const arquivos = () =>
    (require('expo-file-system') as unknown as { __arquivos: Map<string, Uint8Array> }).__arquivos

beforeEach(() => {
    jest.clearAllMocks()
    slots().clear()
    mmkv.clearAll()
    arquivos().clear()
    privateVault.lock()
    useImageGeneration.setState({
        busy: false,
        library: [],
        result: undefined,
        error: undefined,
        draft: undefined,
        progress: undefined,
        controller: undefined,
    })
})

describe('geração de imagem x cofre (fluxo real, provedor simulado)', () => {
    it('cofre aberto: gera, grava cifrado, lê de volta e devolve o resultado à interface', async () => {
        privateVault.unlock(await ensureDeviceVault())
        ;(generateImage as jest.Mock).mockResolvedValue(gerada)

        const entrada = await useImageGeneration.getState().start({
            description: 'Lunaria gótica numa biblioteca à luz de velas',
            includeCharacter: true,
        })

        expect(entrada).toBeDefined()
        expect(entrada?.fileName.endsWith('.lunaenc')).toBe(true)
        expect(generateImage).toHaveBeenCalledTimes(1)

        // O pedido que chegou ao provedor: seed como TEXTO.
        const pedido = (generateImage as jest.Mock).mock.calls[0][0]
        expect(typeof pedido.seed === 'number' || typeof pedido.seed === 'string').toBe(true)

        // A imagem foi gravada CIFRADA (o conteúdo original não está no arquivo).
        const gravados = [...arquivos().values()]
        expect(gravados.length).toBe(1)
        expect(Buffer.from(gravados[0]).equals(Buffer.from(PIXEL))).toBe(false)

        // E o aplicativo consegue lê-la de volta para exibir (IMAGE_READ +
        // IMAGE_DISPLAY: é esta função que o componente `PrivateImage` chama).
        const exibivel = await resolvePrivateImage(`private://${entrada?.fileName}`)
        expect(typeof exibivel).toBe('string')
        expect(String(exibivel).length).toBeGreaterThan(0)

        // O estado final que a tela mostra.
        const estado = useImageGeneration.getState()
        expect(estado.busy).toBe(false)
        expect(estado.error).toBeUndefined()
        expect(estado.result?.fileName).toBe(entrada?.fileName)
        expect(estado.library[0]?.fileName).toBe(entrada?.fileName)
    })

    it('cofre FECHADO: a falha é identificada como VAULT_SAVE, não como culpa do provedor', async () => {
        ;(generateImage as jest.Mock).mockResolvedValue(gerada)

        const entrada = await useImageGeneration.getState().start({
            description: 'Lunaria gótica numa biblioteca à luz de velas',
            includeCharacter: true,
        })

        expect(entrada).toBeUndefined()
        const erro = useImageGeneration.getState().error
        expect(erro).toBeDefined()
        expect(erro?.kind).toBe('cofre')
        expect(erro?.hint).toMatch(/VAULT_SAVE/)
        // Não esconde a causa real nem joga a culpa no provedor.
        expect(erro?.message).not.toMatch(/provedor/i)
        expect(erro?.hint).toMatch(/Cofre bloqueado/)

        // O provedor foi chamado e respondeu: a imagem chegou, o cofre é que recusou.
        expect(generateImage).toHaveBeenCalledTimes(1)
        // Nada foi gravado pela metade.
        expect(arquivos().size).toBe(0)
    })

    it('cofre reaberto: "tentar de novo" funciona e guarda a nova imagem', async () => {
        ;(generateImage as jest.Mock).mockResolvedValue(gerada)

        // Primeira tentativa, cofre fechado -> erro de cofre.
        await useImageGeneration.getState().start({
            description: 'retrato gótico',
            includeCharacter: true,
        })
        expect(useImageGeneration.getState().error?.kind).toBe('cofre')

        // Usuário desbloqueia (chave do aparelho) e toca em "Tentar de novo".
        privateVault.unlock(await ensureDeviceVault())
        const entrada = await useImageGeneration.getState().retry()

        expect(entrada).toBeDefined()
        expect(useImageGeneration.getState().error).toBeUndefined()
        expect(useImageGeneration.getState().result?.fileName).toBe(entrada?.fileName)
        expect(arquivos().size).toBe(1)
    })
})
