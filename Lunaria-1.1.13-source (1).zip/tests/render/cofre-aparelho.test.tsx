/**
 * Cofre **sem senha** — a chave do aparelho.
 *
 * Defeito relatado em 20/09/2026 (BUGS_FOUND.md §BP): com o aplicativo aberto e
 * **sem senha configurada**, gerar imagem falhava em `VAULT_SAVE` com
 * "Cofre bloqueado: desbloqueie a Lunaria para acessar as imagens." A causa: o
 * cofre só ganhava chave no caminho da senha — sem senha, não havia chave nenhuma,
 * e `writeFile` sempre lançava. O `CHANGELOG` já prometia o desenho certo ("sem
 * senha, a chave fica só no Keystore"); o que faltava era o código.
 *
 * Este arquivo prova o ciclo inteiro:
 *   1. chave do aparelho é criada uma vez e reusada;
 *   2. com ela, gravar e ler imagem funciona (e o arquivo está **cifrado**);
 *   3. ao ativar a senha, a MESMA chave é promovida: a imagem antiga continua legível;
 *   4. ao desligar a proteção, a MESMA chave volta ao aparelho — nada de perder imagem;
 *   5. com o cofre fechado, a gravação falha com o erro **tipado** que a interface
 *      usa para dizer a etapa (VAULT_SAVE).
 */
import * as SecureStore from 'expo-secure-store'

import { privateVault } from '@lib/security/PrivateStorage'
import {
    degradeToDeviceKey,
    deviceKeyExists,
    ensureDeviceVault,
    protectExistingKey,
    vaultExists,
    unlockVault,
} from '@lib/security/SecureVault'
import { mmkv } from '@lib/storage/MMKV'

const SENHA = 'lunaria123'
const CONTEUDO = new TextEncoder().encode('imagem de teste da lunaria — conteúdo secreto')

const slots = () => (SecureStore as unknown as { __slots: Map<string, string> }).__slots
const arquivos = () =>
    (require('expo-file-system') as unknown as { __arquivos: Map<string, Uint8Array> }).__arquivos

const limpar = () => {
    slots().clear()
    mmkv.clearAll()
    arquivos().clear()
    privateVault.lock()
}

describe('cofre sem senha: chave do aparelho', () => {
    beforeEach(limpar)

    it('cria a chave do aparelho na primeira vez e reusa depois', async () => {
        expect(await deviceKeyExists()).toBe(false)

        const primeira = await ensureDeviceVault()
        expect(primeira.length).toBe(32)
        expect(await deviceKeyExists()).toBe(true)

        const segunda = await ensureDeviceVault()
        expect(Array.from(segunda)).toEqual(Array.from(primeira))
    })

    it('SEM senha: grava e lê imagem com a chave do aparelho — e o arquivo está cifrado', async () => {
        privateVault.unlock(await ensureDeviceVault())

        const salvo = privateVault.writeFile(CONTEUDO, 'gerada')
        expect(salvo.fileName.endsWith('.lunaenc')).toBe(true)

        // Inspeciona o que foi realmente gravado (o mapa do disco de mentira).
        const gravados = [...arquivos().values()]
        expect(gravados.length).toBe(1)
        const noDisco = gravados[0]
        const comoTexto = new TextDecoder().decode(noDisco)
        expect(comoTexto).not.toContain('conteúdo secreto')
        expect(comoTexto).not.toContain('lunaria')
        expect(Buffer.from(noDisco).equals(Buffer.from(CONTEUDO))).toBe(false)

        const lido = privateVault.readFile(salvo.fileName)
        expect(Buffer.from(lido).toString('utf8')).toBe(Buffer.from(CONTEUDO).toString('utf8'))
    })

    it('ativar a senha promove a MESMA chave: a imagem gravada antes continua legível', async () => {
        const dek = await ensureDeviceVault()
        privateVault.unlock(dek)
        const salvo = privateVault.writeFile(CONTEUDO, 'antes-da-senha')

        // Ativação do bloqueio (é isto que `enableLock` faz).
        await protectExistingKey(SENHA, dek)

        expect(await vaultExists()).toBe(true)
        expect(await deviceKeyExists()).toBe(false) // com senha, não fica cópia sem autenticação

        const dekAberto = await unlockVault(SENHA)
        expect(Array.from(dekAberto)).toEqual(Array.from(dek)) // a DEK é a mesma
        privateVault.unlock(dekAberto)
        const lido = privateVault.readFile(salvo.fileName)
        expect(Buffer.from(lido).toString('utf8')).toBe(Buffer.from(CONTEUDO).toString('utf8'))
    })

    it('desligar a proteção devolve a chave ao aparelho e NÃO perde a imagem', async () => {
        const dek = await ensureDeviceVault()
        await protectExistingKey(SENHA, dek)
        privateVault.unlock(await unlockVault(SENHA))
        const salvo = privateVault.writeFile(CONTEUDO, 'com-senha')

        // Desliga o bloqueio (é isto que `disableLock` faz agora).
        await degradeToDeviceKey(dek)
        expect(await vaultExists()).toBe(false)
        expect(await deviceKeyExists()).toBe(true)

        privateVault.unlock(await ensureDeviceVault())
        const lido = privateVault.readFile(salvo.fileName)
        expect(Buffer.from(lido).toString('utf8')).toBe(Buffer.from(CONTEUDO).toString('utf8'))
    })

    it('com o cofre FECHADO, gravar falha com erro tipado (o que a interface usa para dizer VAULT_SAVE)', async () => {
        privateVault.lock()
        let capturado: unknown
        try {
            privateVault.writeFile(CONTEUDO, 'sem-chave')
        } catch (error) {
            capturado = error
        }
        expect(capturado).toBeInstanceOf(Error)
        expect((capturado as Error).name).toBe('CofreBloqueadoError')
        expect(String((capturado as Error).message)).toMatch(/Cofre bloqueado/)
    })

    it('a senha não é guardada em lugar nenhum (só o envelope)', async () => {
        const dek = await ensureDeviceVault()
        await protectExistingKey(SENHA, dek)
        const tudo = [...slots().values()].join('|')
        expect(tudo.includes(SENHA)).toBe(false)
    })
})
