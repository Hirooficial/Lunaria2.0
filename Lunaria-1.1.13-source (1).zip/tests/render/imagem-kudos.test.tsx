/**
 * Testes do defeito de KUDOS (relato de 21/09/2026) — no nível da tela e do estado.
 *
 * O aparelho mandou gerar em 512x768 e recebeu:
 *
 *     HTTP 403 — "Due to heavy demand, for requests over 576x576 ... the client
 *     needs to already have the required kudos. This request requires 10.42 kudos
 *     to fulfil."
 *
 * e a tela respondeu **"O provedor recusou a credencial usada."** — mandando o
 * usuário mexer na chave por causa de um pedido grande demais.
 *
 * Aqui se prova, com o código que vai no APK:
 *   1. o erro de kudos é classificado como kudos e a tela oferece as saídas certas;
 *   2. "Usar configuração gratuita" tira a chave e tenta de novo;
 *   3. o aviso de resolução ajustada aparece com o texto pedido no relato;
 *   4. a chave inválida continua sendo erro de credencial — e só ela.
 *
 * O provedor de imagem é simulado (`generateImage`) porque o alvo aqui é o
 * comportamento do aplicativo; a regra de tamanho tem suíte própria
 * (`tests/limites-horde.test.mjs`, com a tabela medida contra a API real).
 */
import { act, render } from '@testing-library/react-native'
import React from 'react'

import { ImageGenerationError } from '@lib/imagegen/ImageProviders'
import { useImageGeneration } from '@lib/state/ImageGeneration'

jest.mock('@lib/imagegen/ImageProviders', () => {
    const actual = jest.requireActual('@lib/imagegen/ImageProviders')
    return { ...actual, generateImage: jest.fn() }
})

const { generateImage } = require('@lib/imagegen/ImageProviders') as {
    generateImage: jest.Mock
}

// A tela usa rota, imagem privada e tema; para o teste do erro basta o pedaço que
// monta a caixa de erro — o mesmo arquivo, com as dependências de navegação neutras.
jest.mock('expo-router', () => ({
    useRouter: () => ({ push: jest.fn(), back: jest.fn() }),
}))

const ImageGenerationScreen = require('@screens/ImageGenerationScreen').default

const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3])
const gerado = (overrides: Record<string, unknown> = {}) => ({
    bytes: PNG,
    mime: 'image/png',
    extension: 'png',
    provider: 'horde' as const,
    seed: 524766,
    elapsedSeconds: 3,
    ...overrides,
})

const erroDeKudos = () =>
    new ImageGenerationError(
        'kudos',
        'Esta configuração exige kudos no AI Horde.',
        'O provedor respondeu HTTP 403 porque a fila gratuita está em "heavy demand" e ' +
            'este tamanho/trabalho passa do orçamento anônimo (exige 10.42 kudos). ' +
            'Não é problema da sua chave: nenhuma chave resolve, o que resolve é uma ' +
            'configuração mais leve. Toque em "Usar configuração gratuita" (o app reduz ' +
            'a resolução e os passos e usa a chave anônima) ou espere o movimento baixar ' +
            'e tente de novo.',
        'PROVIDER_REQUEST'
    )

beforeEach(() => {
    jest.clearAllMocks()
    useImageGeneration.setState({
        error: undefined,
        aviso: undefined,
        avisoTipo: undefined,
        busy: false,
        result: undefined,
        draft: undefined,
        progress: undefined,
    })
})

describe('erro de kudos: separado do erro de credencial', () => {
    it('a tela mostra a mensagem de kudos e as três saídas do relato', async () => {
        const { getByText } = render(<ImageGenerationScreen />)
        // O erro é posto **depois** do render, como no aplicativo: o efeito de
        // montagem da tela limpa o erro anterior ao montar a prévia.
        act(() => useImageGeneration.setState({ error: erroDeKudos() }))

        expect(getByText(/Esta configuração exige kudos no AI Horde\./)).toBeTruthy()
        expect(getByText('Usar configuração gratuita')).toBeTruthy()
        expect(getByText('Tentar novamente')).toBeTruthy()
        expect(getByText('Editar descrição')).toBeTruthy()
        // e NADA de "credencial recusada" nessa caixa
        expect(() => getByText(/recusou a credencial|Credencial inválida/i)).toThrow()
    })

    it('erro de credencial continua com a caixa de sempre (sem botão de kudos)', async () => {
        const { findByText, getByText, queryByText } = render(<ImageGenerationScreen />)
        act(() =>
            useImageGeneration.setState({
                error: new ImageGenerationError(
                    'autenticacao',
                    'Credencial inválida.',
                    'A chave foi enviada no cabeçalho apikey e o provedor respondeu HTTP 401.',
                    'PROVIDER_REQUEST'
                ),
            })
        )

        // Regex, não texto exato: o título da caixa tem um ícone dentro do <Text>,
        // e o casamento exato do RNTL não encontra a mensagem nesse caso.
        expect(await findByText(/Credencial inválida\./)).toBeTruthy()
        expect(getByText('Tentar de novo')).toBeTruthy()
        expect(queryByText('Usar configuração gratuita')).toBeNull()
    })

    it('"usar configuração gratuita" tira a chave dos ajustes e tenta de novo', async () => {
        useImageGeneration.getState().setApiKey('chave-valida-sem-kudos')
        ;(generateImage as jest.Mock).mockResolvedValue(gerado({ avisoTipo: 'resolucao' }))

        const { getByText } = render(<ImageGenerationScreen />)
        act(() =>
            useImageGeneration.setState({
                error: erroDeKudos(),
                draft: {
                    prompt: 'retrato gótico',
                    negativePrompt: '',
                    preview: 'retrato gótico',
                    styleId: 'gotico',
                    aspectRatioId: 'retrato',
                    includeCharacter: false,
                    width: 512,
                    height: 768,
                    seed: 524766,
                    verdict: { allowed: true, reason: '', category: undefined },
                },
            })
        )

        const { fireEvent } = require('@testing-library/react-native')
        await act(async () => {
            fireEvent.press(getByText('Usar configuração gratuita'))
        })
        await new Promise((resolve) => setTimeout(resolve, 20))

        // A chave sai (a cota que aceita o pedido é a anônima) e o pedido é refeito.
        expect(useImageGeneration.getState().prefs.apiKey).toBe('')
        expect(generateImage).toHaveBeenCalled()
        const chamada = (generateImage as jest.Mock).mock.calls.at(-1)[0]
        expect(chamada.apiKey).toBe('')
    })

    it('o aviso de resolução ajustada chega à tela com o texto do relato', async () => {
        const { getByText } = render(<ImageGenerationScreen />)
        act(() =>
            useImageGeneration.setState({
                aviso:
                    'Modo gratuito: resolução ajustada para 384x576 para evitar cobrança de kudos.',
                avisoTipo: 'resolucao',
            })
        )

        expect(getByText('Resolução ajustada no modo gratuito')).toBeTruthy()
        expect(
            getByText(/Modo gratuito: resolução ajustada para 384x576 para evitar cobrança de kudos\./)
        ).toBeTruthy()
    })

    it('a tela avisa, junto da proporção, o que sai no modo gratuito', async () => {
        const { getByText } = render(<ImageGenerationScreen />)
        // Preset padrão é Retrato (512x768) -> equivalente gratuito medido.
        expect(getByText(/384×576/)).toBeTruthy()
    })
})
