/**
 * A PRIMEIRA TELA, executada de verdade (`app/index.tsx` → `src/screens/HomeScreen.tsx`).
 *
 * Por que este arquivo existe: o `lockgate.test.tsx` cobre o portão (o `_layout`),
 * e o `screens.test.tsx` cobre as telas novas. Ninguém renderizava o `Home` — a
 * tela que roda as migrações do banco, inicia a Lunaria e é o primeiro destino
 * depois do desbloqueio. É justamente onde uma falha apareceria como "fechou ao
 * abrir", sem mensagem.
 *
 * Aqui as três saídas ficam presas em teste:
 *   1. banco com erro  → tela de diagnóstico (nunca tela preta);
 *   2. início falhou   → tela de diagnóstico, com o motivo;
 *   3. tudo certo      → abertura registrada como concluída e a lista aparece.
 *
 * O que este teste NÃO prova: que as migrações do SQLite funcionam no aparelho
 * (o `expo-sqlite` é nativo e está simulado aqui), nem que nada pisca antes do
 * desbloqueio. Isso segue no checklist do aparelho.
 */
import { render, screen, waitFor } from '@testing-library/react-native'
import React from 'react'
import { Text } from 'react-native'

import Home from '../../src/screens/HomeScreen'
import { checkStartup, markStartupBegin, resetDiagStorage } from '../../lib/utils/Diagnostics'

// --- estado controlado pelo teste -------------------------------------------
let mockMigrations: { success: boolean; error?: Error } = { success: true }
let mockAuth = { authorized: true, retry: jest.fn() }
const mockStartupApp = jest.fn(async () => undefined)
const mockHideAsync = jest.fn(async () => undefined)

jest.mock('drizzle-orm/expo-sqlite/migrator', () => ({
    useMigrations: () => mockMigrations,
}))
jest.mock('@db', () => ({ db: {} }))
jest.mock('@lib/hooks/LocalAuth', () => ({
    __esModule: true,
    default: () => mockAuth,
}))
jest.mock('@lib/utils/Startup', () => ({
    startupApp: () => mockStartupApp(),
    loadChatOnInit: jest.fn(async () => undefined),
    useTextIntentFocus: () => undefined,
}))
jest.mock('@screens/CharacterListScreen', () => {
    const { Text } = require('react-native')
    return {
        __esModule: true,
        default: () => <Text>lista de personagens</Text>,
    }
})
jest.mock('@components/views/HeaderTitle', () => {
    const { Text } = require('react-native')
    return { __esModule: true, default: () => <Text>Lunaria</Text> }
})
jest.mock('@components/buttons/ThemedButton', () => {
    const { Text, Pressable } = require('react-native')
    return {
        __esModule: true,
        default: ({ label, onPress }: { label: string; onPress?: () => void }) => (
            <Pressable onPress={onPress}>
                <Text>{label}</Text>
            </Pressable>
        ),
    }
})
jest.mock('expo-router', () => ({
    SplashScreen: { preventAutoHideAsync: jest.fn(), hideAsync: () => mockHideAsync() },
    useRouter: () => ({ push: jest.fn(), navigate: jest.fn(), dismissAll: jest.fn() }),
}))
jest.mock('expo-clipboard', () => ({ setStringAsync: jest.fn(async () => true) }))
jest.mock('expo-application', () => ({
    nativeApplicationVersion: '1.1.3',
    nativeBuildVersion: '5',
}))
jest.mock('expo-device', () => ({
    modelName: 'SM-A055F',
    osName: 'Android',
    osVersion: '14',
    totalMemory: 6 * 1024 ** 3,
}))
jest.mock('@lib/utils/File', () => ({ readStringAsync: jest.fn(async () => undefined) }))

beforeEach(() => {
    resetDiagStorage()
    mockMigrations = { success: true }
    mockAuth = { authorized: true, retry: jest.fn() }
    mockStartupApp.mockClear()
    mockHideAsync.mockClear()
})

describe('primeira tela (rota / → src/screens/HomeScreen.tsx)', () => {
    it('com o banco em erro mostra o diagnóstico, não uma tela morta', async () => {
        mockMigrations = { success: false, error: new Error('banco corrompido') }

        render(<Home />)

        expect(await screen.findByText('Falha ao preparar o banco de dados')).toBeTruthy()
        expect(screen.getByText('banco corrompido')).toBeTruthy()
        // a tela de diagnóstico traz o caminho de saída
        expect(screen.getByText('Copiar diagnóstico')).toBeTruthy()
        expect(screen.queryByText('lista de personagens')).toBeNull()
    })

    it('se a inicialização falhar, mostra o motivo e permite tentar de novo', async () => {
        mockStartupApp.mockRejectedValueOnce(new Error('modelo local indisponível'))

        render(<Home />)

        expect(await screen.findByText('A Lunaria não conseguiu iniciar')).toBeTruthy()
        expect(screen.getByText('modelo local indisponível')).toBeTruthy()
        expect(screen.getByText('Tentar novamente')).toBeTruthy()
        expect(screen.queryByText('lista de personagens')).toBeNull()
    })

    it('sem autorização local não abre a lista', async () => {
        mockAuth = { authorized: false, retry: jest.fn() }

        render(<Home />)

        expect(await screen.findByText('Autenticação necessária')).toBeTruthy()
        expect(screen.queryByText('lista de personagens')).toBeNull()
    })

    it('com tudo certo, inicia uma única vez, registra a conclusão e mostra a lista', async () => {
        // simula uma abertura em andamento: se o app morresse aqui, a próxima
        // abertura contaria falha. Concluir tem de limpar esta marca.
        markStartupBegin()

        render(<Home />)

        expect(await screen.findByText('lista de personagens')).toBeTruthy()
        expect(mockStartupApp).toHaveBeenCalledTimes(1)

        // abertura concluída = a marca "em curso" saiu
        await waitFor(() => expect(checkStartup().failedLastTime).toBe(false))
    })

    it('não esconde a tela de abertura quando termina', async () => {
        render(<Home />)
        await screen.findByText('lista de personagens')
        await waitFor(() => expect(mockHideAsync).toHaveBeenCalled())
    })
})
