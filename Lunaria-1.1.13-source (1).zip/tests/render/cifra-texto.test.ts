/**
 * Cifra do **texto**: a coluna do banco e a memória de pesquisa.
 *
 * Este arquivo prova, no ambiente de teste, o que é verificável sem aparelho:
 * que a coluna do banco realmente cifra na gravação e decifra na leitura, que o
 * tipo da coluna continua `text` (portanto **sem migração de banco**), que dado
 * antigo em claro continua legível, e que sem cofre aberto nada estoura e nada é
 * apagado.
 *
 * O que **não** se prova aqui: que o banco no aparelho fica com o texto cifrado
 * documento por documento. Isso é a mesma prova que já existe para as imagens
 * (ver `CHECKLIST_APARELHO.md`, item 26), e é feita no aparelho, lendo o arquivo
 * do banco.
 */
import { chatSwipes } from '../../db/schema'
import {
    AVISO_CIFRADO,
    cifrarTexto,
    esquecerFonteDaChave,
    registrarFonteDaChave,
} from '@lib/security/PrivateText'
import { createMMKVStorageCifrado, leituraCifradaValida, mmkv } from '@lib/storage/MMKV'

const CHAVE = new Uint8Array(32).fill(11)

/** A coluna do banco, vista como o drizzle a usa (gravação/leitura do driver). */
const coluna = chatSwipes.swipe as unknown as {
    mapToDriverValue: (valor: string) => string
    mapFromDriverValue: (valor: string) => string
    getSQLType: () => string
    name: string
}

const comCofre = <T>(fn: () => T): T => {
    registrarFonteDaChave(() => CHAVE)
    try {
        return fn()
    } finally {
        esquecerFonteDaChave()
    }
}

// O adaptador do zustand aceita qualquer estado compatível com JSON; a tipagem do
// `StateStorage` só descreve o caso mais estreito (string), então aqui ele é visto
// como o `persist` de verdade o usa.
type Adaptador = {
    setItem: (nome: string, valor: unknown) => void
    getItem: (nome: string) => unknown
    removeItem: (nome: string) => void
}
const adaptador = (): Adaptador => createMMKVStorageCifrado() as unknown as Adaptador

/**
 * O ciclo real do zustand: **hidrata** (lê) antes de gravar. A leitura é o que
 * libera a chave para gravação — a trava que impede apagar o que nunca se leu.
 */
const hidratar = (storage: Adaptador, nome: string) => storage.getItem(nome)

describe('cifra do texto das conversas', () => {
    it('a coluna continua sendo TEXT: nenhuma migração de banco é necessária', () => {
        expect(coluna.getSQLType()).toBe('text')
        expect(coluna.name).toBe('swipe')
    })

    it('grava cifrado e lê de volta idêntico', () => {
        const mensagem = 'Boa noite, Hamura. Sente-se, vamos conversar.'
        const gravado = comCofre(() => coluna.mapToDriverValue(mensagem))
        expect(gravado).not.toBe(mensagem)
        expect(gravado.startsWith('enc:v1:')).toBe(true)
        expect(gravado).not.toContain('Hamura')
        expect(comCofre(() => coluna.mapFromDriverValue(gravado))).toBe(mensagem)
    })

    it('conversa antiga, gravada em claro, continua legível', () => {
        const antiga = 'mensagem de antes da cifra, sem marcador'
        expect(coluna.mapFromDriverValue(antiga)).toBe(antiga)
        expect(comCofre(() => coluna.mapFromDriverValue(antiga))).toBe(antiga)
    })

    it('sem cofre aberto: a leitura não estoura e devolve o aviso, não o conteúdo', () => {
        const mensagem = 'segredo que só a Lunaria e o Hamura sabem'
        const gravado = comCofre(() => coluna.mapToDriverValue(mensagem))
        esquecerFonteDaChave()
        expect(() => coluna.mapFromDriverValue(gravado)).not.toThrow()
        const lido = coluna.mapFromDriverValue(gravado)
        expect(lido).toBe(AVISO_CIFRADO)
        expect(lido).not.toContain('segredo')
        // e o dado não se perdeu: com a chave de volta, o texto reaparece
        expect(comCofre(() => coluna.mapFromDriverValue(gravado))).toBe(mensagem)
    })

    it('o aviso nunca é gravado no lugar do conteúdo (a trava de perda de dado)', () => {
        // Se uma tela lesse o aviso e salvasse de volta, a mensagem de verdade
        // seria apagada. A gravação tem de ser recusada.
        expect(() => comCofre(() => coluna.mapToDriverValue(AVISO_CIFRADO))).toThrow()
    })

    it('sem cofre configurado, o texto continua sendo gravado (em claro)', () => {
        esquecerFonteDaChave()
        expect(coluna.mapToDriverValue('texto de quem não usa proteção')).toBe(
            'texto de quem não usa proteção'
        )
    })
})

describe('cifra da memória de pesquisa', () => {
    const CHAVE_TESTE = 'memoria-de-pesquisa'

    it('grava cifrado no armazenamento e devolve o estado ao desbloquear', () => {
        const storage = adaptador()
        const conteudo = { fatos: ['Hamura gosta de chuva'], versao: 1 }

        // hidratação (vazia: nada gravado ainda) e então a gravação do zustand
        expect(hidratar(storage, CHAVE_TESTE)).toBeNull()
        comCofre(() => storage.setItem(CHAVE_TESTE, conteudo))

        // no disco (o armazenamento bruto): cifrado, sem o texto do usuário
        const bruto = mmkv.getString(CHAVE_TESTE)
        expect(bruto).toBeTruthy()
        expect(bruto!.startsWith('enc:v1:')).toBe(true)
        expect(bruto).not.toContain('chuva')

        // e a leitura com o cofre aberto devolve exatamente o que foi gravado
        expect(comCofre(() => storage.getItem(CHAVE_TESTE))).toEqual(conteudo)
    })

    it('com o cofre fechado: não lê e NÃO grava (o conteúdo cifrado não é apagado)', () => {
        const storage = adaptador()
        const conteudo = { fatos: ['fato guardado'] }
        const CHAVE_2 = 'memoria-cofre-fechado'
        hidratar(storage, CHAVE_2)
        comCofre(() => storage.setItem(CHAVE_2, conteudo))
        const brutoAntes = mmkv.getString(CHAVE_2)

        esquecerFonteDaChave()
        // leitura: devolve "nada" em vez do aviso (o aviso não é JSON e faria a
        // leitura do estado estourar)
        expect(() => storage.getItem(CHAVE_2)).not.toThrow()
        expect(storage.getItem(CHAVE_2)).toBeNull()
        // gravação: ignorada — senão o estado vazio apagaria a memória do usuário
        expect(() => storage.setItem(CHAVE_2, { fatos: [] })).not.toThrow()
        expect(mmkv.getString(CHAVE_2)).toBe(brutoAntes)

        // com a chave de volta, o conteúdo está lá, inteiro
        expect(comCofre(() => storage.getItem(CHAVE_2))).toEqual(conteudo)
    })

    it('memória antiga, gravada em claro, continua legível', () => {
        const storage = adaptador()
        const CHAVE_3 = 'memoria-antiga'
        mmkv.set(CHAVE_3, JSON.stringify({ fatos: ['fato antigo'] }))
        expect(comCofre(() => storage.getItem(CHAVE_3))).toEqual({ fatos: ['fato antigo'] })
    })

    it('apagar continua funcionando mesmo com o cofre fechado', () => {
        const storage = adaptador()
        const CHAVE_4 = 'memoria-apagar'
        hidratar(storage, CHAVE_4)
        comCofre(() => storage.setItem(CHAVE_4, { fatos: ['vai ser apagado'] }))
        esquecerFonteDaChave()
        storage.removeItem(CHAVE_4)
        expect(mmkv.getString(CHAVE_4)).toBeUndefined()
    })

    it('conteúdo cifrado ilegível devolve "nada" em vez de estourar na leitura do estado', () => {
        const storage = adaptador()
        const CHAVE_5 = 'memoria-ilegivel'
        mmkv.set(CHAVE_5, 'enc:v1:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
        expect(() => comCofre(() => storage.getItem(CHAVE_5))).not.toThrow()
        expect(comCofre(() => storage.getItem(CHAVE_5))).toBeNull()
    })
})

describe('a trava contra perda de dado: nunca gravar por cima do que nunca se leu', () => {
    it('a chave só é liberada para gravar depois de uma leitura que viu o conteúdo', () => {
        const storage = adaptador()
        const CHAVE_6 = 'memoria-trava-1'
        hidratar(storage, CHAVE_6)
        comCofre(() => storage.setItem(CHAVE_6, { fatos: ['antiga'] }))

        // leitura com o cofre aberto: viu o conteúdo, logo a chave fica liberada
        expect(comCofre(() => storage.getItem(CHAVE_6))).toEqual({ fatos: ['antiga'] })
        expect(leituraCifradaValida(CHAVE_6)).toBe(true)

        // e então gravar vale
        comCofre(() => storage.setItem(CHAVE_6, { fatos: ['antiga', 'nova'] }))
        expect(comCofre(() => storage.getItem(CHAVE_6))).toEqual({ fatos: ['antiga', 'nova'] })
    })

    it('o aplicativo abrindo BLOQUEADO não apaga a memória da sessão anterior', () => {
        // O cenário que motivou a trava, exatamente como acontece no aparelho:
        // a sessão anterior deixou a memória cifrada no disco; esta sessão abre
        // bloqueada, hidrata com o cofre fechado (estado vazio em memória) e o
        // usuário desbloqueia depois.
        const CHAVE_7 = 'memoria-trava-2'
        mmkv.set(
            CHAVE_7,
            comCofre(() => cifrarTexto(JSON.stringify({ fatos: ['guardada'] })))
        )
        const noDisco = mmkv.getString(CHAVE_7)

        // 1) hidratação com o cofre fechado
        const storage = adaptador()
        expect(storage.getItem(CHAVE_7)).toBeNull()
        expect(leituraCifradaValida(CHAVE_7)).toBe(false)

        // 2) qualquer gravação antes do desbloqueio é ignorada — nada é apagado
        storage.setItem(CHAVE_7, { fatos: [] })
        expect(mmkv.getString(CHAVE_7)).toBe(noDisco)

        // 3) desbloqueio: a releitura do estado (feita pelo aplicativo) libera a
        //    chave e o conteúdo antigo reaparece
        expect(comCofre(() => storage.getItem(CHAVE_7))).toEqual({ fatos: ['guardada'] })
        expect(leituraCifradaValida(CHAVE_7)).toBe(true)

        // 4) e a partir daí gravar volta a valer, sem perder o que havia
        comCofre(() => storage.setItem(CHAVE_7, { fatos: ['guardada', 'depois do desbloqueio'] }))
        expect(comCofre(() => storage.getItem(CHAVE_7))).toEqual({
            fatos: ['guardada', 'depois do desbloqueio'],
        })
    })

    it('conteúdo cifrado ilegível também não libera a chave para gravar', () => {
        const storage = adaptador()
        const CHAVE_8 = 'memoria-trava-3'
        mmkv.set(CHAVE_8, 'enc:v1:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
        expect(comCofre(() => storage.getItem(CHAVE_8))).toBeNull()
        expect(leituraCifradaValida(CHAVE_8)).toBe(false)
    })
})
