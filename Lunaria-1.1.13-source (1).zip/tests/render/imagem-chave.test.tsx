/**
 * Chave do provedor de imagem no aplicativo de verdade (relato de 21/09/2026).
 *
 * O aparelho mostrou "O provedor recusou a credencial usada." — medido contra a
 * API real, isso é HTTP 401 `InvalidAPIKey`: havia uma chave guardada que a AI
 * Horde não reconhece. Os testes aqui prendem as três garantias pedidas:
 *
 *   1. chave que o provedor não conhece **não é salva** (e a que estava salva sai);
 *   2. quando a chave salva é recusada na hora de gerar, a imagem ainda sai pelo
 *      modo gratuito **com aviso na tela** (nada escondido, nada preso);
 *   3. a seed continua sendo TEXTO em qualquer um dos caminhos.
 *
 * Cobre também o cofre: bloqueado, gerar para em VAULT_SAVE; desbloqueado, a
 * imagem é gravada cifrada e aparece no histórico.
 */
import { privateVault } from '@lib/security/PrivateStorage'
import { useAppLock } from '@lib/state/AppLock'
import { useImageGeneration } from '@lib/state/ImageGeneration'
import { mmkv } from '@lib/storage/MMKV'

jest.mock('@lib/imagegen/ImageProviders', () => {
    const real = jest.requireActual('@lib/imagegen/ImageProviders')
    return { ...real, generateImage: jest.fn() }
})
jest.mock('@lib/imagegen/ChaveDoProvedor', () => {
    const real = jest.requireActual('@lib/imagegen/ChaveDoProvedor')
    return { ...real, conferirChaveHorde: jest.fn() }
})

import { conferirChaveHorde } from '@lib/imagegen/ChaveDoProvedor'
import { generateImage } from '@lib/imagegen/ImageProviders'

const PREFS_KEY = 'lunaria-image-prefs-v1'
const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 9, 9, 9])
const senha = '123456'

const gerado = (overrides: Record<string, unknown> = {}) => ({
    bytes: PNG,
    mime: 'image/png',
    extension: 'png',
    provider: 'horde' as const,
    seed: 524766,
    elapsedSeconds: 3,
    ...overrides,
})

const arquivos = () =>
    (
        require('expo-file-system') as unknown as { __arquivos: Map<string, Uint8Array> }
    ).__arquivos

beforeEach(() => {
    mmkv.clearAll()
    useImageGeneration.setState({
        prefs: { provider: 'horde', styleId: 'gotico', aspectRatioId: 'retrato' },
        library: [],
        busy: false,
        aviso: undefined,
        conferenciaChave: undefined,
        conferindoChave: false,
        error: undefined,
        result: undefined,
        progress: undefined,
        controller: undefined,
    })
    ;(generateImage as jest.Mock).mockReset()
    ;(conferirChaveHorde as jest.Mock).mockReset()
    arquivos().clear()
    privateVault.lock()
})

describe('chave do provedor de imagem', () => {
    it('chave que a AI Horde não conhece não é salva (e o modo gratuito continua)', async () => {
        ;(conferirChaveHorde as jest.Mock).mockResolvedValue({
            estado: 'invalida',
            status: 404,
            mensagem: 'A AI Horde não conhece esta chave (HTTP 404). Ela não foi salva.',
        })

        const resultado = await useImageGeneration.getState().conferirESalvarChave('errada')

        expect(resultado.estado).toBe('invalida')
        expect(useImageGeneration.getState().prefs.apiKey).toBe('')
        expect(mmkv.getString(PREFS_KEY)).toContain('"apiKey":""')
        expect(useImageGeneration.getState().conferindoChave).toBe(false)
    })

    it('chave salva antes e agora recusada: é removida, sem prender o usuário no erro', async () => {
        useImageGeneration.getState().setApiKey('chave-antiga-guardada')
        ;(conferirChaveHorde as jest.Mock).mockResolvedValue({
            estado: 'invalida',
            status: 401,
            mensagem: 'A AI Horde recusou esta chave (HTTP 401). Ela não foi salva.',
        })

        await useImageGeneration.getState().conferirESalvarChave('chave-antiga-guardada')

        expect(useImageGeneration.getState().prefs.apiKey).toBe('')
    })

    it('chave aceita é guardada normalizada', async () => {
        ;(conferirChaveHorde as jest.Mock).mockResolvedValue({
            estado: 'valida',
            status: 200,
            usuario: 'Hamura',
            mensagem: 'Chave aceita pela AI Horde (Hamura).',
        })

        const resultado = await useImageGeneration.getState().conferirESalvarChave(' "Bearer boa123" ')

        expect(resultado.estado).toBe('valida')
        expect(useImageGeneration.getState().prefs.apiKey).toBe('boa123')
        expect(useImageGeneration.getState().conferenciaChave?.usuario).toBe('Hamura')
    })

    it('sem internet (indeterminada): não troca nada às cegas', async () => {
        useImageGeneration.getState().setApiKey('chave-que-ja-estava')

        ;(conferirChaveHorde as jest.Mock).mockResolvedValue({
            estado: 'indeterminada',
            mensagem: 'Não deu para conferir a chave agora (sem internet?).',
        })

        await useImageGeneration.getState().conferirESalvarChave('chave-nova')

        expect(useImageGeneration.getState().prefs.apiKey).toBe('chave-que-ja-estava')
    })

    it('"usar modo gratuito" tira a chave e limpa o aviso', () => {
        useImageGeneration.getState().setApiKey('alguma-chave')
        useImageGeneration.setState({ aviso: 'aviso antigo' })

        useImageGeneration.getState().usarModoGratuito()

        expect(useImageGeneration.getState().prefs.apiKey).toBe('')
        expect(useImageGeneration.getState().aviso).toBeUndefined()
    })

    it('cofre aberto: a imagem gerada é gravada cifrada, indexada e o aviso fica limpo', async () => {
        await useAppLock.getState().init() // sem senha: chave do aparelho
        ;(generateImage as jest.Mock).mockResolvedValue(gerado())

        const entrada = await useImageGeneration.getState().start({
            description: 'retrato gótico sob a chuva',
            includeCharacter: false,
        })

        expect(entrada).toBeDefined()
        expect(useImageGeneration.getState().library[0].fileName).toBe(entrada?.fileName)
        expect(useImageGeneration.getState().aviso).toBeUndefined()
        expect([...arquivos().values()].length).toBe(1)
        // gravado cifrado (envelope .lunaenc), não em claro
        expect(entrada?.fileName.endsWith('.lunaenc')).toBe(true)
    })

    it('a chave salva é recusada na geração: a imagem sai pelo modo gratuito COM aviso', async () => {
        await useAppLock.getState().init()
        useImageGeneration.getState().setApiKey('chave-recusada')
        ;(generateImage as jest.Mock).mockResolvedValue(
            gerado({
                aviso:
                    'A chave salva foi recusada pelo provedor (HTTP 401). Esta imagem saiu pelo ' +
                    '**modo gratuito** (chave anônima da AI Horde).',
                avisoTipo: 'credencial',
            })
        )

        const entrada = await useImageGeneration.getState().start({
            description: 'retrato',
            includeCharacter: false,
        })

        expect(entrada).toBeDefined()
        const aviso = useImageGeneration.getState().aviso
        expect(aviso).toMatch(/HTTP 401/)
        expect(aviso).toMatch(/modo gratuito/)
        // a chave ruim sai dos ajustes: a próxima imagem não repete o erro
        expect(useImageGeneration.getState().prefs.apiKey).toBe('')
        expect([...arquivos().values()].length).toBe(1)
    })

    it('cofre bloqueado: a geração para em VAULT_SAVE e não grava nada', async () => {
        await useAppLock.getState().init()
        await useAppLock.getState().enableLock(senha)
        // bloqueia de verdade: o cofre fecha
        useAppLock.getState().lockNow('manual')
        privateVault.lock() // garante o estado fechado neste teste
        ;(generateImage as jest.Mock).mockResolvedValue(gerado())

        const entrada = await useImageGeneration.getState().start({
            description: 'retrato',
            includeCharacter: false,
        })

        expect(entrada).toBeUndefined()
        const erro = useImageGeneration.getState().error
        expect(erro?.kind).toBe('cofre')
        expect(erro?.hint).toContain('VAULT_SAVE')
        expect([...arquivos().values()].length).toBe(0)

        // desbloqueado, a mesma geração funciona e a imagem é guardada
        await useAppLock.getState().unlock(senha)
        ;(generateImage as jest.Mock).mockResolvedValue(gerado())
        const segunda = await useImageGeneration.getState().start({
            description: 'retrato',
            includeCharacter: false,
        })
        expect(segunda).toBeDefined()
        expect([...arquivos().values()].length).toBe(1)
    })
})
