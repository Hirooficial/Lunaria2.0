/**
 * A SPLASH NÃO PODE FICAR PRESA QUANDO O APLICATIVO ESTÁ BLOQUEADO.
 *
 * Defeito relatado no aparelho em 21/09/2026 (Galaxy A05s), com a senha
 * configurada:
 *
 *   1. sai da Lunaria (bloqueio automático ligado);
 *   2. o bloqueio automático é acionado;
 *   3. volta para a Lunaria;
 *   4. **fica preso para sempre na tela do logo**, e a tela de senha nunca aparece.
 *
 * A causa está em `app/_layout.tsx`: quem escondia a splash era a `HomeScreen`
 * (`SplashScreen.hideAsync()` no fim de `startLunaria`), e a `HomeScreen` só existe
 * dentro do `<Stack>` — que o portão **não monta enquanto `locked` for verdadeiro**.
 * Com a senha configurada, o caminho era:
 *
 *     AppState ACTIVE -> hidratação -> locked=true
 *     -> o portão mostra a LockScreen e não monta o Stack
 *     -> a HomeScreen nunca monta
 *     -> hideAsync nunca é chamado -> splash infinita
 *
 * A tela de senha estava montada o tempo todo, atrás da splash.
 *
 * Este arquivo executa o portão **de verdade** (`app/_layout.tsx`), com a
 * `LockScreen` de verdade e o **estado real** (`lib/state/AppLock.ts`: cofre,
 * PBKDF2, verificador — só o armazenamento nativo é simulado, como em
 * `jest.setup.js`). A splash é dublada apenas para registrar QUANDO foi escondida.
 *
 * O que cada teste prova:
 *   1. abrir bloqueado: a splash sai no fim da hidratação e a tela de senha aparece;
 *   2. "Bloquear agora": não volta para a splash (não há nova splash a esconder);
 *   3. sair/voltar bloqueado: `APPSTATE_ACTIVE` refaz a decisão, sem prender nada;
 *   4. senha errada: continua na tela de desenho, sem splash;
 *   5. senha certa: destrava e o aplicativo aparece;
 *   6. hidratação que **falha** também termina: aparece bloqueado, não desaparece.
 */
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react-native'
import * as SecureStore from 'expo-secure-store'
import React from 'react'
import { AppState } from 'react-native'

import { privateVault } from '@lib/security/PrivateStorage'
import { useAppLock } from '@lib/state/AppLock'
import { mmkv } from '@lib/storage/MMKV'
import { clearDiagnostics, readSteps } from '@lib/utils/Diagnostics'

import Layout from '../../app/_layout'

const senha = '123456'

/* --------------------------------------------------------------- dublês ------- */

// A splash é dublada para registrar QUANDO o aplicativo a esconde. O que importa
// não é o pixel: é a ordem (escondida com o app ainda bloqueado, e nunca "só depois
// de digitar a senha"). As funções nascem **dentro** da fábrica porque o `jest.mock`
// é elevado acima das constantes deste arquivo (e o `app/_layout` chama a splash já
// na importação).
jest.mock('expo-router', () => {
    const React = require('react')
    const { View } = require('react-native')
    const Stack = ({ children }: { children?: React.ReactNode }) =>
        React.createElement(View, { testID: 'stack-do-app' }, children)
    Stack.Screen = () => null
    return {
        Stack,
        useRouter: () => ({ navigate: jest.fn(), push: jest.fn(), replace: jest.fn() }),
        // A navegação de verdade não existe fora do aparelho; o portão só LÊ.
        useNavigationContainerRef: () => ({ isReady: () => true }),
        SplashScreen: {
            preventAutoHideAsync: jest.fn(),
            hideAsync: jest.fn(async () => undefined),
        },
    }
})

/** A splash dublada: é aqui que se observa o momento exato do `hideAsync`. */
const splashDublada = require('expo-router').SplashScreen as {
    hideAsync: jest.Mock
    preventAutoHideAsync: jest.Mock
}
const esconderamASplash = () => splashDublada.hideAsync.mock.calls.length
jest.mock('expo-splash-screen', () => ({ setOptions: jest.fn(), hideAsync: jest.fn() }))
jest.mock('expo-screen-capture', () => ({
    preventScreenCaptureAsync: jest.fn(),
    allowScreenCaptureAsync: jest.fn(),
}))
jest.mock('react-native-gesture-handler', () => {
    const React = require('react')
    const { View } = require('react-native')
    return {
        GestureHandlerRootView: ({ children }: { children?: React.ReactNode }) =>
            React.createElement(View, null, children),
    }
})
jest.mock('react-native-keyboard-controller', () => {
    const React = require('react')
    const { View } = require('react-native')
    return {
        KeyboardProvider: ({ children }: { children?: React.ReactNode }) =>
            React.createElement(View, null, children),
    }
})
jest.mock('@lib/notifications/Notifications', () => ({
    useAppStateNotificationObserver: jest.fn(),
}))
jest.mock('@lib/state/ImageGeneration', () => {
    const estado = { viewerImage: null, init: jest.fn(async () => {}) }
    return {
        useImageGeneration: (selector?: (s: Record<string, unknown>) => unknown) =>
            selector ? selector(estado) : estado,
    }
})
jest.mock('@components/views/ImageViewer', () => {
    const React = require('react')
    const { View } = require('react-native')
    return () => React.createElement(View, { testID: 'visualizador-de-imagem' })
})

/* ------------------------------------------------------------- ambiente ------- */

/** Ouvintes de `AppState` registrados pelo portão, na ordem. */
let ouvintes: ((estado: string) => void)[] = []
const disparar = (estado: string) => act(() => ouvintes.forEach((ouvinte) => ouvinte(estado)))

const initOriginal = useAppLock.getState().init

const zeraEstado = () => {
    useAppLock.setState({
        ready: false,
        locked: true,
        configured: false,
        init: initOriginal,
        initError: undefined,
        failures: 0,
        lockoutSeconds: 0,
        lastReason: undefined,
        settings: {
            enabled: false,
            biometric: false,
            autoLockMinutes: 0, // política "ao sair" — é a do relato
            blockScreenshots: false,
            hideInNotifications: true,
        },
    })
    ;(SecureStore as unknown as { __slots: Map<string, string> }).__slots.clear()
    mmkv.clearAll()
    privateVault.lock()
    clearDiagnostics()
    splashDublada.hideAsync.mockClear()
    // `preventAutoHideAsync` NÃO é limpo de propósito: ele acontece uma única vez, na
    // importação do `app/_layout` (antes de qualquer teste), e é a prova de que havia
    // splash na frente — a premissa do defeito relatado.
    ouvintes = []
}

/** Deixa a senha configurada como se o usuário já tivesse configurado antes. */
const comSenhaConfigurada = async () => {
    await useAppLock.getState().init()
    // A política do relato é a "ao sair" (0 minutos) — e ela é lida do disco em
    // `init`, então precisa ser gravada aqui, e não só no estado do teste.
    await useAppLock.getState().setAutoLock(0)
    await useAppLock.getState().enableLock(senha)
    useAppLock.getState().lockNow('manual')
    // Abrir de novo, do zero: é o que o aparelho faz ao voltar depois de o sistema
    // recriar a janela/processo.
    useAppLock.setState({ ready: false, locked: true })
    privateVault.lock()
}

const trilha = () => readSteps().map((passo) => passo.label)

beforeEach(() => {
    jest.restoreAllMocks()
    zeraEstado()
    jest.spyOn(AppState, 'addEventListener').mockImplementation(((
        _evento: string,
        ouvinte: (estado: string) => void
    ) => {
        ouvintes.push(ouvinte)
        return { remove: jest.fn() }
    }) as unknown as typeof AppState.addEventListener)
})

afterEach(() => {
    jest.useRealTimers()
})

describe('voltar para a Lunaria bloqueada NÃO fica preso na splash', () => {
    it('TESTE 1 — abrir bloqueado: a splash sai no fim da hidratação e a tela de senha aparece', async () => {
        await comSenhaConfigurada()
        render(<Layout />)

        // (a) a splash sai **enquanto o aplicativo ainda está bloqueado** — ela não
        // espera senha nenhuma, e é isto que o relato pede.
        await waitFor(() => expect(splashDublada.hideAsync).toHaveBeenCalled())
        expect(useAppLock.getState().locked).toBe(true)

        // (b) a tela de desbloqueio está na frente — de verdade, e não só "montada".
        expect(await screen.findByText('Lunaria bloqueada')).toBeTruthy()

        // (c) nada do aplicativo foi montado atrás dela.
        expect(screen.queryByTestId('stack-do-app')).toBeNull()
        expect(screen.queryByTestId('visualizador-de-imagem')).toBeNull()

        // (d) a trilha conta a sequência inteira, na ordem em que aconteceu.
        await waitFor(() => expect(trilha().join('\n')).toMatch(/SPLASH_HIDDEN/))
        const percurso = trilha().join('\n')
        // A splash foi posta na frente na abertura do processo (`preventAutoHideAsync`
        // no topo do módulo) — é a premissa do defeito: havia splash para ficar presa.
        expect(splashDublada.preventAutoHideAsync).toHaveBeenCalled()
        expect(percurso).toMatch(/AUTH_HYDRATION_STARTED/)
        expect(percurso).toMatch(/AUTH_HYDRATION_COMPLETE locked=true/)
        expect(percurso).toMatch(/SPLASH_HIDE_REQUESTED/)
        expect(percurso).toMatch(/UNLOCK_SCREEN_REQUESTED/)
        expect(percurso).toMatch(/UNLOCK_SCREEN_MOUNTED/)
        expect(percurso).toMatch(/ROUTER_READY/)
    })

    it('TESTE 2 — "Bloquear agora" mostra a tela de desbloqueio e não traz splash de volta', async () => {
        await comSenhaConfigurada()
        render(<Layout />)
        await waitFor(() => expect(splashDublada.hideAsync).toHaveBeenCalled())

        // destrava como o usuário faz
        fireEvent.changeText(screen.getByPlaceholderText('----'), senha)
        await act(async () => {
            fireEvent.press(screen.getByText('Desbloquear'))
        })
        await waitFor(() => expect(screen.getByTestId('stack-do-app')).toBeTruthy())

        await act(async () => {
            useAppLock.getState().lockNow('manual')
        })

        expect(useAppLock.getState().locked).toBe(true)
        expect(await screen.findByText('Lunaria bloqueada')).toBeTruthy()
        expect(screen.queryByTestId('stack-do-app')).toBeNull()
        // Bloquear é decisão do portão: a splash continua fora. Nada a colocou na
        // frente de novo (uma única chamada de `preventAutoHideAsync`, a da abertura).
        expect(splashDublada.preventAutoHideAsync).toHaveBeenCalledTimes(1)
        expect(trilha().join('\n')).toMatch(/UNLOCK_SCREEN_REQUESTED/)
    })

    it('TESTE 5 — sair e voltar rápido, bloqueado: APPSTATE_ACTIVE refaz a decisão da splash', async () => {
        await comSenhaConfigurada()
        render(<Layout />)
        await waitFor(() => expect(splashDublada.hideAsync).toHaveBeenCalled())

        disparar('background')
        // política "ao sair": o estado já fica bloqueado na saída (vale mesmo se o
        // Android matar o processo enquanto o aplicativo está atrás).
        expect(useAppLock.getState().locked).toBe(true)
        const percursoSaida = trilha().join('\n')
        expect(percursoSaida).toMatch(/politica=ao sair/)
        expect(percursoSaida).toMatch(/APPSTATE_BACKGROUND/)
        expect(trilha().join('\n')).toMatch(/AUTO_LOCK_POLICY_APPLIED/)

        splashDublada.hideAsync.mockClear()
        disparar('active')

        // A volta ao primeiro plano toma a mesma decisão da abertura: se a janela
        // foi recriada (splash de volta na frente), ela sai de novo aqui.
        await waitFor(() => expect(splashDublada.hideAsync).toHaveBeenCalled())
        const percurso = trilha().join('\n')
        expect(percurso).toMatch(/APPSTATE_ACTIVE/)
        expect(percurso).toMatch(/SPLASH_HIDE_REQUESTED motivo=volta ao primeiro plano/)
        expect(percurso).toMatch(/SPLASH_HIDDEN/)
        expect(await screen.findByText('Lunaria bloqueada')).toBeTruthy()
    })

    it('TESTE 3 — senha errada: continua na tela de desbloqueio, sem splash', async () => {
        await comSenhaConfigurada()
        render(<Layout />)
        await waitFor(() => expect(splashDublada.hideAsync).toHaveBeenCalled())
        const chamadasAntes = splashDublada.hideAsync.mock.calls.length

        fireEvent.changeText(screen.getByPlaceholderText('----'), '999999')
        await act(async () => {
            fireEvent.press(screen.getByText('Desbloquear'))
        })

        expect(await screen.findByText('Senha ou PIN incorreto.')).toBeTruthy()
        expect(useAppLock.getState().locked).toBe(true)
        expect(screen.getByText('Lunaria bloqueada')).toBeTruthy()
        expect(screen.queryByTestId('stack-do-app')).toBeNull()
        // Senha errada não mexe em splash nenhuma: ela fica fora, e nada a recoloca
        // na frente (é o caminho que, antes, terminava na tela do logo para sempre).
        expect(splashDublada.preventAutoHideAsync).toHaveBeenCalledTimes(1)
        expect(trilha().join('\n')).toMatch(/UNLOCK_FAILED/)
    })

    it('TESTE 4 — senha certa: destrava e o aplicativo aparece (sem splash no meio)', async () => {
        await comSenhaConfigurada()
        render(<Layout />)
        await waitFor(() => expect(splashDublada.hideAsync).toHaveBeenCalled())

        fireEvent.changeText(screen.getByPlaceholderText('----'), senha)
        await act(async () => {
            fireEvent.press(screen.getByText('Desbloquear'))
        })

        await waitFor(() => expect(useAppLock.getState().locked).toBe(false))
        expect(screen.getByTestId('stack-do-app')).toBeTruthy()
        expect(screen.queryByText('Lunaria bloqueada')).toBeNull()
        expect(privateVault.isUnlocked).toBe(true)
        // A splash continua escondida. O portão pede o hide outra vez quando o estado
        // muda (é no-op no aparelho: escondida, `hideAsync` não faz nada), e a prova
        // de que ela **não voltou** é esta: nada a colocou na frente de novo desde a
        // abertura do processo.
        expect(splashDublada.preventAutoHideAsync).toHaveBeenCalledTimes(1)
        expect(trilha().join('\n')).toMatch(/UNLOCK_SUCCESS/)
    })

    it('TESTE 6 — hidratação que FALHA também termina: aparece bloqueado, nunca splash infinita', async () => {
        // Um cofre que estoura de um jeito que o próprio `init` não conteve. Sem o
        // fecho desta rodada, `ready` ficava falso para sempre: nenhuma tela (nem a
        // de senha) e a splash cobrindo tudo.
        await comSenhaConfigurada()
        useAppLock.setState({
            init: async () => {
                throw new Error('cofre indisponível neste aparelho')
            },
        })

        render(<Layout />)

        await waitFor(() => expect(splashDublada.hideAsync).toHaveBeenCalled())
        await waitFor(() => expect(useAppLock.getState().ready).toBe(true))
        expect(useAppLock.getState().locked).toBe(true)
        expect(useAppLock.getState().initError).toMatch(/cofre indisponível/)
        expect(await screen.findByText('Lunaria bloqueada')).toBeTruthy()
        const percurso = trilha().join('\n')
        expect(percurso).toMatch(/AUTH_HYDRATION_COMPLETE \(com falha\)/)
        expect(percurso).toMatch(/SPLASH_HIDDEN/)
    })
})
