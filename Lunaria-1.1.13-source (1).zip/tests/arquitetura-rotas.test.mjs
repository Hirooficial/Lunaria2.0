/**
 * Testes de arquitetura.
 *
 * Nasceram do defeito que derrubava o aplicativo na abertura (1.1.12): o `app/`
 * tinha 118 arquivos, todos descobertos pelo Expo Router como rota — inclusive
 * componentes, botões e pedaços de tela —, e um ciclo de importação entre
 * `AppLock`, `TTS` e `Chat` fazia o Metro avaliar o `TTS` com o `Chat` ainda em
 * avaliação. O `useInference.subscribe(...)` do fim do `TTS` lançava, o Metro
 * devolvia `undefined` no lugar do módulo da rota raiz e o aplicativo fechava
 * com "Cannot read property 'ErrorBoundary' of undefined".
 *
 * Estes testes vigiam as duas coisas: `app/` só com rotas/layouts, e o grafo de
 * importação sem ciclo de avaliação.
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'

const RAIZ = path.resolve(import.meta.dirname, '..')
const APP = path.join(RAIZ, 'app')

const listar = (dir) =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) =>
        e.isDirectory() ? listar(path.join(dir, e.name)) : [path.join(dir, e.name)]
    )

const relativo = (base, f) => path.relative(base, f).split(path.sep).join('/')

test('app/ contém apenas rotas e layouts do Expo Router', () => {
    const arquivos = listar(APP).map((f) => relativo(APP, f))
    assert.ok(arquivos.length > 0, 'app/ vazio')

    // Sub-rotas de tela usadas de verdade pela navegação (`router.push`). A
    // lista é curta de propósito: só entra aqui rota que o aplicativo abre.
    const subRotas = new Set([
        'screens/AppSettingsScreen/ChatStyleSettings.tsx',
        'screens/AppSettingsScreen/ColorSelector.tsx',
        'screens/ConnectionsManagerScreen/AddConnection.tsx',
        'screens/ConnectionsManagerScreen/TemplateManager.tsx',
    ])

    const rotasDeTopo = new Set(['_layout.tsx', 'index.tsx'])
    for (const rel of arquivos) {
        if (rotasDeTopo.has(rel)) continue
        assert.ok(rel.startsWith('screens/'), `arquivo que não é rota dentro de app/: ${rel}`)

        const partes = rel.split('/')
        const formatoValido =
            (partes.length === 2 && rel.endsWith('.tsx')) ||
            (partes.length === 3 && partes[2] === 'index.tsx') ||
            subRotas.has(rel)
        assert.ok(formatoValido, `formato de rota inesperado: ${rel}`)
    }

    // Nenhum componente, hook, serviço ou pedaço de tela mora em app/.
    assert.ok(
        !arquivos.some((rel) => /components|hooks|services|helpers|models/i.test(rel)),
        'componente/hook/serviço descoberto dentro de app/'
    )
})

test('cada arquivo de rota é fino: só reexporta a tela de src/', () => {
    for (const f of listar(APP)) {
        const rel = relativo(APP, f)
        if (rel === '_layout.tsx') continue // o layout raiz é código de verdade

        const txt = fs.readFileSync(f, 'utf8')
        const uteis = txt
            .split('\n')
            .map((l) => l.trim())
            .filter((l) => l && !l.startsWith('//'))
        assert.ok(uteis.length <= 2, `arquivo de rota com código demais (${uteis.length} linhas): ${rel}`)
        assert.match(txt, /export \{ default \} from '@screens\//, `rota sem reexport da tela: ${rel}`)
        assert.ok(!/@lib\/|\.\.\/lib\//.test(txt), `rota importando lib/ direto: ${rel}`)
    }
})

test('toda rota navegada pelo aplicativo tem arquivo em app/', () => {
    const rotas = new Set()
    const varrer = (dir) => {
        for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
            if (e.name === 'node_modules' || e.name.startsWith('.')) continue
            const p = path.join(dir, e.name)
            if (e.isDirectory()) {
                varrer(p)
                continue
            }
            if (!/\.(ts|tsx)$/.test(e.name)) continue
            const txt = fs.readFileSync(p, 'utf8')
            for (const m of txt.matchAll(/['"`](\/screens\/[A-Za-z0-9_\-/]+)['"`]/g)) rotas.add(m[1])
        }
    }
    varrer(APP)
    varrer(path.join(RAIZ, 'src'))
    varrer(path.join(RAIZ, 'lib'))

    assert.ok(rotas.size >= 20, `poucas rotas navegadas encontradas (${rotas.size}) — varredura quebrada?`)
    for (const r of rotas) {
        const comoArquivo = path.join(APP, `${r}.tsx`)
        const comoPasta = path.join(APP, r, 'index.tsx')
        assert.ok(
            fs.existsSync(comoArquivo) || fs.existsSync(comoPasta),
            `rota navegada sem arquivo em app/: ${r}`
        )
    }
})

test('o grafo de importação não tem ciclo de avaliação', () => {
    const EXTS = ['.ts', '.tsx', '.js', '.jsx']
    const ALIAS = {
        '@components/': 'src/components/',
        '@screens/': 'src/screens/',
        '@lib/': 'lib/',
        '@assets/': 'assets/',
        '@public/': 'public/',
        '@db': 'db/db',
    }
    const ESTATICO = /(?:^|\n)\s*(?:import|export)\b[^;\n]*?from\s*['"]([^'"]+)['"]/g

    const resolver = (base, spec) => {
        let cand = null
        for (const [k, v] of Object.entries(ALIAS)) {
            if (spec === k) {
                cand = v
                break
            }
            if (k.endsWith('/') && spec.startsWith(k)) {
                cand = v + spec.slice(k.length)
                break
            }
        }
        if (cand === null) {
            if (spec.startsWith('@') || (!spec.startsWith('.') && !spec.startsWith('/'))) return null
            cand = path.resolve(path.dirname(base), spec)
        }
        for (const e of EXTS) if (fs.existsSync(cand + e)) return cand + e
        for (const e of EXTS) if (fs.existsSync(path.join(cand, 'index' + e))) return path.join(cand, 'index' + e)
        return null
    }

    const grafo = new Map()
    const arquivos = []
    for (const raiz of ['app', 'lib', 'src']) {
        for (const f of listar(path.join(RAIZ, raiz))) {
            if (!EXTS.includes(path.extname(f))) continue
            arquivos.push(f)
        }
    }
    for (const f of arquivos) {
        const txt = fs.readFileSync(f, 'utf8')
        const alvos = new Set()
        for (const m of txt.matchAll(ESTATICO)) {
            const t = resolver(f, m[1])
            if (t && t !== f) alvos.add(t)
        }
        grafo.set(f, alvos)
    }

    // Busca em profundidade com marcação de "em avaliação" — é exatamente a
    // situação que quebrava o aparelho.
    const estado = new Map() // 0 = novo, 1 = em avaliação, 2 = pronto
    const pilha = []
    const ciclos = []

    const visitar = (no) => {
        estado.set(no, 1)
        pilha.push(no)
        for (const viz of grafo.get(no) ?? []) {
            const e = estado.get(viz) ?? 0
            if (e === 1) {
                const inicio = pilha.indexOf(viz)
                ciclos.push([...pilha.slice(inicio), viz].map((x) => relativo(RAIZ, x)))
            } else if (e === 0) {
                visitar(viz)
            }
        }
        pilha.pop()
        estado.set(no, 2)
    }
    for (const f of arquivos) if ((estado.get(f) ?? 0) === 0) visitar(f)

    assert.equal(
        ciclos.length,
        0,
        `ciclo de importação (quebra a avaliação de módulos no aparelho):\n${ciclos.map((c) => '  ' + c.join(' → ')).join('\n')}`
    )
    assert.ok(arquivos.length > 200, `grafo pequeno demais (${arquivos.length}) — varredura quebrada?`)
})
