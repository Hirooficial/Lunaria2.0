/**
 * Credencial do provedor de imagem — os cinco testes obrigatórios do relato de
 * 21/09/2026, do lado da lógica pura (sem rede real, sem módulo nativo).
 *
 * Contexto medido contra a API de verdade naquele dia:
 *
 *     apikey: 0000000000 (anônima)            -> HTTP 202
 *     apikey: <chave que a Horde não conhece>  -> HTTP 401 InvalidAPIKey
 *     sem o cabeçalho apikey                   -> HTTP 400
 *
 * O defeito no aparelho era: havia uma chave guardada que a Horde recusava, e o
 * aplicativo repetia o erro em toda tentativa, sem conferir no momento de salvar e
 * sem caminho de volta ao modo gratuito. Estes testes prendem a correção.
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import {
    avisoChaveRecusada,
    chaveParaEnviar,
    conferirChaveHorde,
    corpoSanitizado,
    credencialRecusada,
    descreverPedido,
    escolherCredencial,
    HORDE_ANONYMOUS_KEY,
    mascararChave,
    normalizarChave,
    rotuloDoModo,
} from '../lib/imagegen/ChaveDoProvedor.ts'

test('sem chave: o modo é gratuito e o cabeçalho leva a chave anônima pública', () => {
    for (const vazio of [undefined, null, '', '   ', '\n\t']) {
        const credencial = escolherCredencial(vazio)
        assert.equal(credencial.modo, 'gratuito')
        assert.equal(credencial.chave, undefined)
        assert.equal(chaveParaEnviar(credencial), HORDE_ANONYMOUS_KEY)
    }
})

test('chave do usuário: normalizada e enviada como está no cabeçalho apikey', () => {
    const credencial = escolherCredencial('  abc123def456  ')
    assert.equal(credencial.modo, 'chave')
    assert.equal(credencial.chave, 'abc123def456')
    assert.equal(chaveParaEnviar(credencial), 'abc123def456')
})

test('normalização conserta o que a pessoa realmente cola (aspas, prefixo, espaço)', () => {
    const casos = [
        ['"chave-com-aspas"', 'chave-com-aspas'],
        ["'chave-com-apostrofo'", 'chave-com-apostrofo'],
        ['“chave-com-aspas-tipograficas”', 'chave-com-aspas-tipograficas'],
        ['Bearer chave-com-prefixo', 'chave-com-prefixo'],
        ['bearer chave-com-prefixo', 'chave-com-prefixo'],
        ['apikey:chave-com-prefixo', 'chave-com-prefixo'],
        ['api-key=chave-com-prefixo', 'chave-com-prefixo'],
        ['chave quebrada em duas', 'chavequebradaemduas'],
        ['chave-com-quebra\nlinha', 'chave-com-quebralinha'],
        ['token:chave', 'chave'],
    ]
    for (const [entrada, esperado] of casos) {
        assert.equal(normalizarChave(entrada), esperado, `entrada: ${entrada}`)
    }
    // Normalizar nunca inventa chave onde não havia nada.
    assert.equal(normalizarChave('   '), undefined)
    assert.equal(normalizarChave('""'), undefined)
    assert.equal(normalizarChave(null), undefined)
})

test('a chave nunca aparece inteira em texto de tela, log ou diagnóstico', () => {
    const chave = '0123456789abcdef0123456789abcdef01234567'
    const mascarada = mascararChave(chave)
    assert.ok(!mascarada.includes(chave), 'a máscara não pode conter a chave inteira')
    assert.match(mascarada, /····4567/)
    assert.match(mascarada, /40 caracteres/)
    assert.equal(mascararChave(undefined), 'sem chave (modo gratuito)')

    // A própria Horde devolve a chave dentro da mensagem de erro
    // ("User with api_key 'abc123' not found"): o corpo é mascarado antes de virar
    // diagnóstico, senão a chave entraria no relatório que o usuário envia.
    const corpo = `{"message":"User with api_key '${chave}' not found.","rc":"NotFound"}`
    const limpo = corpoSanitizado(corpo, chave)
    assert.ok(!limpo.includes(chave), 'o corpo sanitizado não pode conter a chave')
    assert.ok(limpo.includes('····'))
    assert.ok(limpo.includes('not found'))
})

test('a linha de diagnóstico diz modo, cabeçalho e o TIPO da seed', () => {
    const comChave = descreverPedido({
        provedor: 'horde',
        prompt: 'retrato gótico',
        width: 512,
        height: 768,
        seed: '524766',
        credencial: escolherCredencial('abc123def456'),
    })
    assert.match(comChave, /provedor=horde/)
    assert.match(comChave, /modo=chave/)
    assert.match(comChave, /cabecalho_apikey=enviado/)
    assert.match(comChave, /seed=524766 \(tipo=string\)/)
    assert.ok(!comChave.includes('abc123def456'))

    const semChave = descreverPedido({
        provedor: 'horde',
        prompt: 'x',
        width: 512,
        height: 512,
        seed: undefined,
        credencial: escolherCredencial(undefined),
    })
    assert.match(semChave, /modo=gratuito/)
    assert.match(semChave, /cabecalho_apikey=anonimo/)
    assert.match(semChave, /seed=ausente \(tipo=undefined\)/)
})

test('credencial recusada é 401/403 — e mais nada', () => {
    assert.equal(credencialRecusada(401), true)
    assert.equal(credencialRecusada(403), true)
    assert.equal(credencialRecusada(400), false)
    assert.equal(credencialRecusada(404), false)
    assert.equal(credencialRecusada(429), false)
    assert.equal(credencialRecusada(500), false)
})

test('rótulo do modo é legível e não expõe a chave', () => {
    assert.match(rotuloDoModo(escolherCredencial(undefined)), /gratuito/)
    const comChave = rotuloDoModo(escolherCredencial('0123456789abcdef'))
    assert.match(comChave, /chave própria/)
    assert.ok(!comChave.includes('0123456789abcdef'))
})

test('conferir chave: 200 = aceita (e diz o dono); 404/401 = recusada', async () => {
    const ok200 = async () => ({
        status: 200,
        text: async () => JSON.stringify({ username: 'Hamura' }),
    })
    const aceita = await conferirChaveHorde('bom', ok200)
    assert.equal(aceita.estado, 'valida')
    assert.equal(aceita.usuario, 'Hamura')
    assert.match(aceita.mensagem, /Chave aceita/)

    const chaveDeVerdade = '0123456789abcdef0123456789abcdef01234567'
    const naoExiste = async () => ({
        status: 404,
        text: async () =>
            `{"message":"User with api_key '${chaveDeVerdade}' not found.","rc":"NotFound"}`,
    })
    const recusada = await conferirChaveHorde(chaveDeVerdade, naoExiste)
    assert.equal(recusada.estado, 'invalida')
    assert.equal(recusada.status, 404)
    assert.match(recusada.mensagem, /não conhece esta chave/)
    assert.ok(
        !recusada.detalhe?.includes(chaveDeVerdade),
        'a chave não entra no diagnóstico'
    )
    // O corpo é substituído por inteiro (sem os 4 últimos): o "qual chave" já
    // aparece no modo em vigor, mascarado com os 4 últimos — no texto da resposta
    // do provedor não fica nada do segredo.
    assert.match(recusada.detalhe ?? '', /····/)
    assert.ok(recusada.detalhe?.includes('not found'))

    // Chave curta demais para mascarar: o corpo é ocultado por inteiro.
    assert.equal(corpoSanitizado("api_key 'ab' not found", 'ab'), 'corpo oculto (chave curta demais para mascarar)')

    const semChave = async () => ({
        status: 401,
        text: async () => '{"rc":"InvalidAPIKey"}',
    })
    const recusada401 = await conferirChaveHorde('bom', semChave)
    assert.equal(recusada401.estado, 'invalida')
    assert.equal(recusada401.status, 401)
})

test('conferir chave: campo vazio não chama a rede; servidor fora devolve indeterminada', async () => {
    let chamou = false
    const fetchFalso = async () => {
        chamou = true
        return { status: 200, text: async () => '{}' }
    }
    const vazia = await conferirChaveHorde('   ', fetchFalso)
    assert.equal(vazia.estado, 'invalida')
    assert.equal(chamou, false, 'campo vazio não deve gastar rede')

    const caiu = async () => {
        throw new Error('sem internet')
    }
    const indeterminada = await conferirChaveHorde('bom', caiu)
    assert.equal(indeterminada.estado, 'indeterminada')
    assert.match(indeterminada.mensagem, /continua no modo em que estava/)

    const erro5xx = async () => ({ status: 503, text: async () => 'manutenção' })
    const servidorFora = await conferirChaveHorde('bom', erro5xx)
    assert.equal(servidorFora.estado, 'indeterminada')
    assert.equal(servidorFora.status, 503)
})

test('o aviso da chave recusada diz o status, o modo gratuito e o que fazer', () => {
    const texto = avisoChaveRecusada(401)
    assert.match(texto, /HTTP 401/)
    assert.match(texto, /modo gratuito/)
    assert.match(texto, /stablehorde\.net\/register/)
})
