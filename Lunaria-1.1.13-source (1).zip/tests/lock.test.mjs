import assert from 'node:assert/strict'
import test from 'node:test'

import {
    AUTO_LOCK_OPTIONS,
    describeAutoLock,
    FORGOT_SECRET_EXPLANATION,
    formatLockout,
    lockoutSecondsFor,
    MAX_LOCKOUT_SECONDS,
    MIN_SECRET_LENGTH,
    validarAtivacao,
    validateSecret,
} from '../lib/security/LockPolicy.ts'

test('exige pelo menos 6 dígitos ou caracteres', () => {
    assert.equal(MIN_SECRET_LENGTH, 6)
    assert.equal(validateSecret('12345').ok, false)
    assert.equal(validateSecret('123456').ok, true)
    assert.match(validateSecret('123').reason, /pelo menos 6/)
})

test('reconhece PIN (só dígitos) sem exigir só dígitos', () => {
    assert.equal(validateSecret('482913').isPin, true)
    assert.equal(validateSecret('minha-senha-1').isPin, false)
    assert.equal(validateSecret('minha-senha-1').ok, true)
})

test('recusa senha vazia e com espaço nas pontas', () => {
    assert.equal(validateSecret('').ok, false)
    assert.equal(validateSecret('  senha-boa  ').ok, false)
})

test('espera progressiva começa na terceira tentativa errada', () => {
    assert.equal(lockoutSecondsFor(1), 0)
    assert.equal(lockoutSecondsFor(2), 0)
    assert.equal(lockoutSecondsFor(3), 1)
    assert.equal(lockoutSecondsFor(4), 2)
    assert.equal(lockoutSecondsFor(5), 4)
    assert.equal(lockoutSecondsFor(6), 8)
})

test('espera progressiva tem teto de 5 minutos e nunca apaga dados', () => {
    assert.equal(lockoutSecondsFor(20), MAX_LOCKOUT_SECONDS)
    assert.equal(MAX_LOCKOUT_SECONDS, 300)
    // A função só devolve tempo — não existe caminho de apagar dado aqui.
    assert.equal(typeof lockoutSecondsFor(999), 'number')
})

test('mensagem da espera fala em segundos e em minutos', () => {
    assert.equal(formatLockout(0), '')
    assert.match(formatLockout(30), /30 s/)
    assert.match(formatLockout(120), /2 min/)
})

test('opções de bloqueio automático incluem "ao sair" e nunca são NaN', () => {
    assert.deepEqual([...AUTO_LOCK_OPTIONS], [0, 1, 5, 15, 60])
    assert.equal(describeAutoLock(0), 'Assim que sair do aplicativo')
    assert.match(describeAutoLock(5), /5 minutos/)
    assert.match(describeAutoLock(60), /1 hora/)
})

test('a explicação de senha esquecida deixa claro o que se perde e o que fica', () => {
    const text = FORGOT_SECRET_EXPLANATION.join(' ').toLowerCase()
    assert.match(text, /cofre de imagens|apagar o cofre/)
    assert.match(text, /conversas/)
    assert.match(text, /biometria/)
})

test('validateSecret não devolve exceção para entradas estranhas', () => {
    assert.doesNotThrow(() => validateSecret(undefined))
    assert.equal(validateSecret(undefined).ok, false)
})


/* ------------------------------------------------------------------ *
 * Formulário de ativação do bloqueio (os dois campos da tela).        *
 * Relato de 20/09/2026: o botão "Ativar bloqueio" não reagia e não     *
 * explicava o motivo. Estes casos são exatamente a lista pedida.       *
 * ------------------------------------------------------------------ */

test('ATIVAÇÃO: duas senhas iguais com 6+ caracteres -> liberado', () => {
    const v = validarAtivacao('lunaria', 'lunaria')
    assert.equal(v.ok, true)
    assert.equal(v.reason, undefined)
})

test('ATIVAÇÃO: senhas diferentes -> bloqueado, com a mensagem certa', () => {
    const v = validarAtivacao('lunaria', 'lunaris')
    assert.equal(v.ok, false)
    assert.equal(v.reason, 'As senhas não coincidem.')
})

test('ATIVAÇÃO: senha curta -> bloqueado, com a mensagem certa', () => {
    const v = validarAtivacao('12345', '12345')
    assert.equal(v.ok, false)
    assert.match(v.reason, /pelo menos 6 caracteres/)
})

test('ATIVAÇÃO: PIN numérico válido -> liberado (e reconhecido como PIN)', () => {
    const v = validarAtivacao('364056', '364056')
    assert.equal(v.ok, true)
    assert.equal(v.isPin, true)
})

test('ATIVAÇÃO: senha alfanumérica válida -> liberado (a tela promete "Senha ou PIN")', () => {
    const v = validarAtivacao('Lunaria2026', 'Lunaria2026')
    assert.equal(v.ok, true)
    assert.equal(v.isPin, false)
})

test('ATIVAÇÃO: apagar um campo -> volta a bloquear', () => {
    assert.equal(validarAtivacao('lunaria', '').ok, false)
    assert.equal(validarAtivacao('lunaria', '').reason, 'Repita a senha no segundo campo.')
    assert.equal(validarAtivacao('', 'lunaria').ok, false)
    assert.equal(validarAtivacao('', '').ok, false)
    assert.equal(validarAtivacao('', '').reason, 'Digite uma senha ou um PIN.')
})

test('ATIVAÇÃO: campo só com espaços não passa como senha de 6', () => {
    assert.equal(validarAtivacao('      ', '      ').ok, false)
})

test('ATIVAÇÃO: exatamente 6 caracteres é o limite (5 bloqueia, 6 libera)', () => {
    assert.equal(validarAtivacao('abcde', 'abcde').ok, false)
    assert.equal(validarAtivacao('abcdef', 'abcdef').ok, true)
    assert.equal(validarAtivacao('123456', '123456').ok, true)
})
