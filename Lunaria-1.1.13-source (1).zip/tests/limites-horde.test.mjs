/**
 * Limite de kudos do modo gratuito da AI Horde (relato de 21/09/2026).
 *
 * O defeito: no aparelho, um pedido de **512x768** voltou HTTP 403 com o texto
 * "Due to heavy demand, for requests over 576x576 or over the applicable
 * first-order-equivalent sampler work budget the client needs to already have the
 * required kudos. This request requires 10.42 kudos to fulfil." — e a tela dizia
 * **"O provedor recusou a credencial usada."**
 *
 * Não era credencial. Aqui ficam os seis testes obrigatórios do relato, mais a
 * bateria da regra pura.
 *
 * A tabela de resoluções usada aqui foi **medida contra a API real** em 21/09/2026
 * (chave anônima), com cada trabalho criado cancelado na hora para não gastar o
 * trabalho dos workers: 384x576, 576x384, 512x512, 512x384, 576x320, 384x384,
 * 448x576, 512x768, 768x512 e 512x640 -> 202; 640x640, 768x768 e 512x512 com 50
 * passos -> 403 por kudos; 768x432 -> 400 (não é múltiplo de 64).
 */

import assert from 'node:assert/strict'
import { Buffer } from 'node:buffer'
import test from 'node:test'

import {
    ajustarAoModoGratuito,
    ajustarMultiploDeHorde,
    cabeNoModoGratuito,
    dimensoesValidasParaHorde,
    ehBloqueioDeKudos,
    kudosExigidos,
    LIMITE_GRATUITO_HORDE,
    PASSOS_GRATUITOS_MAX,
    resolucaoGratuitaPara,
    resumoDoModoGratuito,
} from '../lib/imagegen/LimitesDaHorde.ts'
import { generateWithHorde, HORDE_ANONYMOUS_KEY } from '../lib/imagegen/ImageProviders.ts'

const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3])
const PNG_BASE64 = Buffer.from(PNG).toString('base64')
const noSleep = async () => {}
const fast = { sleepImpl: noSleep, pollIntervalMs: 1 }

const okJson = (body) => ({ ok: true, status: 200, json: async () => body, text: async () => '' })
const fail = (status, body = 'erro') => ({
    ok: false,
    status,
    json: async () => ({}),
    text: async () => body,
})

/** Texto exato que a AI Horde devolveu no aparelho (relato de 21/09/2026). */
const CORPO_DE_KUDOS =
    'Due to heavy demand, for requests over 576x576 or over the applicable ' +
    'first-order-equivalent sampler work budget the client needs to already have ' +
    'the required kudos. This request requires 10.42 kudos to fulfil.'

/**
 * Provedor falso que aceita **qualquer** pedido e devolve uma imagem, mas registra
 * tudo o que saiu do aplicativo. É assim que se verifica o que foi enviado de fato —
 * sem depender do serviço real e sem gastar a cota anônima de ninguém.
 */
const provedorQueRegistra = (respostaInicial = () => okJson({ id: 'job-1' })) => {
    const envios = []
    const fetchImpl = async (url, options = {}) => {
        if (String(url).endsWith('/generate/async')) {
            const corpo = JSON.parse(options.body)
            envios.push({ apikey: options.headers.apikey, params: corpo.params })
            return respostaInicial(envios.length)
        }
        return okJson({
            done: true,
            generations: [{ img: PNG_BASE64, model: 'stable_diffusion', seed: '524766' }],
        })
    }
    return { envios, fetchImpl }
}

/* ------------------------------------------------------------------ *
 * A regra pura                                                        *
 * ------------------------------------------------------------------ */

test('o limite do modo gratuito é 576 de dimensão e 30 passos (medidos)', () => {
    assert.equal(LIMITE_GRATUITO_HORDE, 576)
    assert.equal(PASSOS_GRATUITOS_MAX, 30)
})

test('os equivalentes gratuitos são exatamente os medidos contra a API real', () => {
    assert.deepEqual(resolucaoGratuitaPara({ width: 512, height: 768 }), { width: 384, height: 576 })
    assert.deepEqual(resolucaoGratuitaPara({ width: 768, height: 512 }), { width: 576, height: 384 })
    assert.deepEqual(resolucaoGratuitaPara({ width: 640, height: 640 }), { width: 512, height: 512 })
    assert.deepEqual(resolucaoGratuitaPara({ width: 512, height: 640 }), { width: 512, height: 384 })
    assert.deepEqual(resolucaoGratuitaPara({ width: 768, height: 448 }), { width: 576, height: 320 })
})

test('o limite é dinâmico: nenhum preset gratuito passa de 576 em NENHUMA dimensão', () => {
    // No aparelho a Horde anunciou 576x576; nos testes desta rodada, 634x634. A
    // regra do modo gratuito tem de valer para o pior caso dos dois.
    for (const preset of [
        { width: 512, height: 768 },
        { width: 768, height: 512 },
        { width: 640, height: 640 },
        { width: 512, height: 640 },
        { width: 768, height: 448 },
    ]) {
        const livre = resolucaoGratuitaPara(preset)
        assert.ok(livre.width <= LIMITE_GRATUITO_HORDE, `${livre.width} passou do limite`)
        assert.ok(livre.height <= LIMITE_GRATUITO_HORDE, `${livre.height} passou do limite`)
        assert.ok(
            dimensoesValidasParaHorde(livre.width, livre.height),
            `${livre.width}x${livre.height} não é múltiplo de 64`
        )
        // E o pedido ajustado cabe inteiro no modo gratuito.
        assert.ok(cabeNoModoGratuito(livre.width, livre.height, PASSOS_GRATUITOS_MAX))
    }
})

test('dimensão que não é múltipla de 64 é pedido inválido (medido: 768x432 -> 400)', () => {
    assert.equal(dimensoesValidasParaHorde(768, 432), false)
    assert.equal(dimensoesValidasParaHorde(768, 448), true) // 448 = 7 x 64
    assert.deepEqual(ajustarMultiploDeHorde(768, 432), { width: 768, height: 384 })
    // Nunca AUMENTA o pedido: arredonda para baixo.
    assert.deepEqual(ajustarMultiploDeHorde(500, 500), { width: 448, height: 448 })
})

test('o ajuste do modo gratuito também corta o orçamento de trabalho (passos)', () => {
    const ajuste = ajustarAoModoGratuito(512, 512, 50)
    assert.equal(ajuste.steps, PASSOS_GRATUITOS_MAX)
    assert.equal(ajuste.mudouPassos, true)
    assert.equal(ajuste.mudouResolucao, false)
    assert.match(ajuste.aviso, /Passos ajustados de 50 para 30/)

    const jaCabe = ajustarAoModoGratuito(384, 576, 30)
    assert.equal(jaCabe.mudouResolucao, false)
    assert.equal(jaCabe.mudouPassos, false)
    assert.equal(jaCabe.aviso, undefined)
})

test('o corpo REAL da Horde (21/09/2026) é reconhecido pelo rc KudosUpfront', () => {
    // Copiado da resposta de verdade, sem edição:
    //   POST /generate/async 768x768 anônimo -> HTTP 403
    const corpoReal =
        '{"message":"Due to heavy demand, for requests over 576x576 or over the ' +
        'applicable first-order-equivalent sampler work budget the client needs to ' +
        'already have the required kudos. This request requires 13.68 kudos to ' +
        'fulfil.","rc":"KudosUpfront"}'
    assert.equal(ehBloqueioDeKudos(corpoReal), true)
    assert.equal(kudosExigidos(corpoReal), 13.68)
})

test('o texto de kudos é reconhecido, e o de credencial NÃO', () => {
    assert.equal(ehBloqueioDeKudos(CORPO_DE_KUDOS), true)
    assert.equal(ehBloqueioDeKudos('{"message":"Due to heavy demand ... work budget"}'), true)
    assert.equal(kudosExigidos(CORPO_DE_KUDOS), 10.42)
    // Respostas de credencial (medidas) não podem ser confundidas com kudos.
    assert.equal(ehBloqueioDeKudos('{"rc":"InvalidAPIKey","message":"No user matching sent API Key"}'), false)
    assert.equal(ehBloqueioDeKudos("User with api_key 'abc123' not found"), false)
    assert.equal(ehBloqueioDeKudos('Unauthorized'), false)
    assert.equal(kudosExigidos('Unauthorized'), undefined)
})

test('o resumo mostrado na tela diz o que sai no modo gratuito', () => {
    assert.match(resumoDoModoGratuito({ width: 512, height: 768 }), /384×576/)
    assert.match(resumoDoModoGratuito({ width: 384, height: 576 }), /já cabe/)
})

/* ------------------------------------------------------------------ *
 * TESTE 1 — gratuito retrato 384x576                                   *
 * TESTE 2 — gratuito paisagem 576x384                                  *
 * TESTE 3 — gratuito quadrado 512x512                                  *
 * ------------------------------------------------------------------ */

for (const [nome, width, height] of [
    ['TESTE 1 · retrato', 384, 576],
    ['TESTE 2 · paisagem', 576, 384],
    ['TESTE 3 · quadrado', 512, 512],
]) {
    test(`${nome}: ${width}x${height} no modo gratuito sai como está e gera a imagem`, async () => {
        const { envios, fetchImpl } = provedorQueRegistra()
        const result = await generateWithHorde({
            prompt: 'gothic portrait',
            width,
            height,
            fetchImpl,
            ...fast,
        })

        assert.equal(envios.length, 1, 'um único pedido: nada de gastar cota duas vezes')
        assert.equal(envios[0].apikey, HORDE_ANONYMOUS_KEY)
        assert.equal(envios[0].params.width, width)
        assert.equal(envios[0].params.height, height)
        assert.ok(
            cabeNoModoGratuito(envios[0].params.width, envios[0].params.height, envios[0].params.steps),
            'pedido ficou fora do que a fila anônima aceita'
        )
        // Nada de aviso: não houve ajuste, então a tela não inventa explicação.
        assert.equal(result.aviso, undefined)
        assert.equal(result.avisoTipo, undefined)
        assert.equal(result.extension, 'png')
    })
}

/* ------------------------------------------------------------------ *
 * TESTE 4 — preset grande no modo gratuito                             *
 * ------------------------------------------------------------------ */

test('TESTE 4: 512x768 no modo gratuito é ajustado ANTES do request, para 384x576', async () => {
    const { envios, fetchImpl } = provedorQueRegistra()
    const result = await generateWithHorde({
        prompt: 'gothic portrait',
        width: 512,
        height: 768,
        fetchImpl,
        ...fast,
    })

    // O ponto do teste: **um** envio só, já no tamanho gratuito. O pedido que a
    // Horde recusaria por kudos não chegou a sair (o encargo é explícito: "NÃO
    // envie a requisição inválida primeiro").
    assert.equal(envios.length, 1)
    assert.equal(envios[0].params.width, 384)
    assert.equal(envios[0].params.height, 576)
    assert.equal(envios[0].apikey, HORDE_ANONYMOUS_KEY)

    // E a tela recebe o aviso, com o texto pedido no relato.
    assert.equal(result.avisoTipo, 'resolucao')
    assert.match(result.aviso, /Modo gratuito: resolução ajustada para 384x576/)
    assert.match(result.aviso, /kudos/)
})

test('TESTE 4b: com chave própria o tamanho pedido é respeitado (não se presume kudos)', async () => {
    const { envios, fetchImpl } = provedorQueRegistra()
    const result = await generateWithHorde({
        prompt: 'gothic portrait',
        width: 512,
        height: 768,
        apiKey: 'chave-do-usuario',
        fetchImpl,
        ...fast,
    })

    assert.equal(envios.length, 1)
    assert.equal(envios[0].apikey, 'chave-do-usuario')
    assert.equal(envios[0].params.width, 512, 'com chave o tamanho é o escolhido na tela')
    assert.equal(envios[0].params.height, 768)
    assert.equal(result.aviso, undefined)
})

test('TESTE 4c: Cinema (768x448) não sai mais como 432 — a Horde recusa com 400', async () => {
    const { envios, fetchImpl } = provedorQueRegistra()
    await generateWithHorde({ prompt: 'x', width: 768, height: 448, fetchImpl, ...fast })
    assert.equal(dimensoesValidasParaHorde(envios[0].params.width, envios[0].params.height), true)
    // No modo gratuito o Cinema sai no equivalente medido.
    assert.equal(envios[0].params.width, 576)
    assert.equal(envios[0].params.height, 320)
})

/* ------------------------------------------------------------------ *
 * TESTE 5 — HTTP 403 de kudos                                          *
 * ------------------------------------------------------------------ */

test('TESTE 5: 403 de kudos NÃO vira "credencial recusada" e diz o que é', async () => {
    const envios = []
    const fetchImpl = async (url, options = {}) => {
        if (String(url).endsWith('/generate/async')) {
            envios.push(options.headers.apikey)
            return fail(403, CORPO_DE_KUDOS)
        }
        return okJson({ done: false })
    }

    // Chave própria: é o caso em que o usuário TEM chave e mesmo assim falta kudos.
    await assert.rejects(
        () =>
            generateWithHorde({
                prompt: 'x',
                width: 512,
                height: 768,
                apiKey: 'chave-valida-sem-kudos',
                fetchImpl,
                ...fast,
            }),
        (erro) => {
            assert.equal(erro.kind, 'kudos')
            assert.equal(erro.message, 'Esta configuração exige kudos no AI Horde.')
            assert.doesNotMatch(erro.message, /credencial/i)
            assert.doesNotMatch(erro.hint, /Credencial inválida/i)
            assert.match(erro.hint, /kudos/)
            assert.match(erro.hint, /Usar configuração gratuita/)
            assert.match(erro.hint, /10\.42 kudos/)
            return true
        }
    )

    // E o ponto mais importante: **não** houve a segunda tentativa com a chave
    // anônima. Trocar de chave não resolve falta de kudos — só repetiria o 403.
    assert.deepEqual(envios, ['chave-valida-sem-kudos'])
})

test('TESTE 5b: 403 de kudos no modo gratuito também sai como kudos, com uma tentativa', async () => {
    const envios = []
    const fetchImpl = async (url, options = {}) => {
        if (String(url).endsWith('/generate/async')) {
            envios.push(options.headers.apikey)
            return fail(403, CORPO_DE_KUDOS)
        }
        return okJson({ done: false })
    }

    await assert.rejects(
        () => generateWithHorde({ prompt: 'x', width: 384, height: 576, fetchImpl, ...fast }),
        (erro) => erro.kind === 'kudos' && !/credencial/i.test(erro.message)
    )
    assert.deepEqual(envios, [HORDE_ANONYMOUS_KEY])
})

/* ------------------------------------------------------------------ *
 * TESTE 6 — chave inválida                                             *
 * ------------------------------------------------------------------ */

test('TESTE 6: só a chave inválida produz erro de credencial', async () => {
    const envios = []
    const fetchImpl = async (url, options = {}) => {
        if (String(url).endsWith('/generate/async')) {
            envios.push(options.headers.apikey)
            return fail(401, JSON.stringify({ rc: 'InvalidAPIKey' }))
        }
        return okJson({ done: false })
    }

    await assert.rejects(
        () =>
            generateWithHorde({
                prompt: 'x',
                width: 384,
                height: 576,
                apiKey: 'abc123',
                fetchImpl,
                ...fast,
            }),
        (erro) => {
            assert.equal(erro.kind, 'autenticacao')
            assert.equal(erro.message, 'Credencial inválida.')
            assert.match(erro.hint, /HTTP 401/)
            return true
        }
    )

    // Aqui a segunda tentativa existe e é a certa: a chave ruim sai de cena.
    assert.deepEqual(envios, ['abc123', HORDE_ANONYMOUS_KEY])
})

test('TESTE 6b: chave recusada cai no modo gratuito JÁ no tamanho gratuito', async () => {
    const envios = []
    const fetchImpl = async (url, options = {}) => {
        if (String(url).endsWith('/generate/async')) {
            const corpo = JSON.parse(options.body)
            envios.push({ apikey: options.headers.apikey, params: corpo.params })
            if (options.headers.apikey === 'abc123') return fail(401, '{"rc":"InvalidAPIKey"}')
            return okJson({ id: 'job-gratuito' })
        }
        return okJson({
            done: true,
            generations: [{ img: PNG_BASE64, model: 'stable_diffusion', seed: '524766' }],
        })
    }

    const result = await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 768,
        apiKey: 'abc123',
        fetchImpl,
        ...fast,
    })

    // Primeiro envio: a chave do usuário, no tamanho pedido.
    assert.equal(envios[0].apikey, 'abc123')
    assert.equal(envios[0].params.width, 512)
    // Segundo envio: anônimo **e** no tamanho que a fila anônima aceita — senão o
    // erro de credencial viraria um erro de kudos.
    assert.equal(envios[1].apikey, HORDE_ANONYMOUS_KEY)
    assert.equal(envios[1].params.width, 384)
    assert.equal(envios[1].params.height, 576)
    assert.equal(result.avisoTipo, 'credencial')
    assert.match(result.aviso, /chave salva foi recusada/i)
    assert.match(result.aviso, /resolução ajustada para 384x576/)
})

/* ------------------------------------------------------------------ *
 * A seed — que NÃO pode regredir                                       *
 * ------------------------------------------------------------------ */

test('a seed continua TEXTO em todos os caminhos (ajustado, com chave, anônimo)', async () => {
    // 1) modo gratuito com ajuste de resolução
    const gratuito = provedorQueRegistra()
    await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 768,
        seed: 970406,
        fetchImpl: gratuito.fetchImpl,
        ...fast,
    })
    assert.equal(gratuito.envios[0].params.seed, '970406')
    assert.equal(typeof gratuito.envios[0].params.seed, 'string')

    // 2) modo com chave
    const comChave = provedorQueRegistra()
    await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 768,
        seed: 970406,
        apiKey: 'chave-do-usuario',
        fetchImpl: comChave.fetchImpl,
        ...fast,
    })
    assert.equal(typeof comChave.envios[0].params.seed, 'string')

    // 3) reenvio anônimo depois da chave recusada
    const envios = []
    const fetchImpl = async (url, options = {}) => {
        if (String(url).endsWith('/generate/async')) {
            envios.push(JSON.parse(options.body).params)
            if (options.headers.apikey === 'abc123') return fail(401, '{"rc":"InvalidAPIKey"}')
            return okJson({ id: 'job' })
        }
        return okJson({ done: true, generations: [{ img: PNG_BASE64, seed: '970406' }] })
    }
    await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 768,
        seed: 970406,
        apiKey: 'abc123',
        fetchImpl,
        ...fast,
    })
    for (const params of envios) {
        assert.equal(params.seed, '970406')
        assert.equal(typeof params.seed, 'string')
    }

    // 4) sem seed: o campo NÃO é enviado (nada de null/undefined/NaN)
    const semSeed = provedorQueRegistra()
    await generateWithHorde({ prompt: 'x', width: 384, height: 576, fetchImpl: semSeed.fetchImpl, ...fast })
    assert.equal('seed' in semSeed.envios[0].params, false)
})
