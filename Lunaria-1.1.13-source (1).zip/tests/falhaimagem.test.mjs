/**
 * Classificação das falhas por etapa do fluxo (relato de 20/09/2026: "não
 * esconda a falha com uma mensagem genérica; diga em qual etapa parou").
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import {
    cofreEstaBloqueado,
    estagioLegivel,
    falhaAoGuardarNoCofre,
    falhaDesconhecida,
    NOME_COFRE_BLOQUEADO,
} from '../lib/imagegen/FalhaDeImagem.ts'

const erroDeCofre = () => {
    const e = new Error('Cofre bloqueado: desbloqueie a Lunaria para acessar as imagens.')
    e.name = NOME_COFRE_BLOQUEADO
    return e
}

test('reconhece o erro do cofre pelo nome (contrato com PrivateStorage)', () => {
    assert.equal(cofreEstaBloqueado(erroDeCofre()), true)
    assert.equal(cofreEstaBloqueado(new Error('outra coisa')), false)
    assert.equal(cofreEstaBloqueado(undefined), false)
    assert.equal(cofreEstaBloqueado(null), false)
})

test('cofre fechado na gravação -> kind "cofre" e etapa VAULT_SAVE', () => {
    const falha = falhaAoGuardarNoCofre(erroDeCofre())
    assert.equal(falha.kind, 'cofre')
    assert.equal(falha.stage, 'VAULT_SAVE')
    assert.match(falha.message, /cofre está fechado/)
    assert.match(falha.hint, /VAULT_SAVE/)
    // A mensagem real do cofre continua visível: nada de esconder a causa.
    assert.match(falha.hint, /Cofre bloqueado/)
    // E diz o que fazer, sem prometer que a imagem foi salva.
    assert.match(falha.hint, /senha ou a biometria/)
})

test('falha desconhecida mantém a mensagem real e diz a etapa quando sabe', () => {
    const semEtapa = falhaDesconhecida(new Error('erro cru do sistema'))
    assert.equal(semEtapa.kind, 'desconhecido')
    assert.equal(semEtapa.stage, undefined)
    assert.match(semEtapa.hint, /erro cru do sistema/)

    const comEtapa = falhaDesconhecida(new Error('socket fechou'), 'IMAGE_DOWNLOAD')
    assert.equal(comEtapa.stage, 'IMAGE_DOWNLOAD')
    assert.match(comEtapa.hint, /IMAGE_DOWNLOAD/)
})

test('cada etapa tem texto legível próprio', () => {
    const etapas = [
        'PROVIDER_REQUEST',
        'PROVIDER_RESPONSE',
        'IMAGE_DOWNLOAD',
        'VAULT_SAVE',
        'IMAGE_READ',
        'IMAGE_DISPLAY',
    ]
    for (const etapa of etapas) {
        const texto = estagioLegivel(etapa)
        assert.match(texto, new RegExp(etapa), `a etapa ${etapa} tem de aparecer no texto`)
    }
    assert.equal(estagioLegivel(undefined), '')
})
