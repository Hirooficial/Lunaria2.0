# Changelog

## 1.1.13 — abre de verdade, a imagem sai e o bloqueio bloqueia (21/09/2026)

**Quarta rodada do dia (mesma 1.1.13, mesmo versionCode 17):** com a senha ativa,
sair da Lunaria (bloqueio automático) e voltar prendia o aplicativo para sempre na
tela do logo — a tela de senha nunca aparecia. A splash era escondida pela
`HomeScreen`, que só existe **dentro do `<Stack>`**, e o portão não monta o `<Stack>`
enquanto está bloqueado: a tela de desbloqueio estava montada, atrás da splash. Agora
a splash sai **no fim da hidratação** (bloqueado ou não) e em **cada volta ao primeiro
plano**, e a hidratação termina **mesmo quando falha** (`ready=true`, `locked=true`,
fail-closed visível em vez de tela nenhuma). As marcas pedidas no relato ficaram na
trilha de diagnóstico — `APPSTATE_BACKGROUND`, `APPSTATE_ACTIVE`,
`AUTH_HYDRATION_COMPLETE`, `SPLASH_HIDE_REQUESTED`, `SPLASH_HIDDEN`,
`UNLOCK_SCREEN_REQUESTED`, `UNLOCK_SCREEN_MOUNTED`, `ROUTER_READY` — para nunca mais
existir "travou e não sei por quê".

**Rodada da tarde (mesma 1.1.13, mesmo versionCode 17):** o HTTP 403 que a tela
chamava de "credencial recusada" era o provedor pedindo **kudos** por um pedido
grande demais. Agora o modo gratuito **adapta a resolução antes de enviar**
(512x768 → 384x576, 768x512 → 576x384, 640x640 → 512x512, 512x640 → 512x384,
768x448 → 576x320; passos com teto de 30), com o aviso escrito na tela; o erro de
kudos ganhou mensagem e botões próprios ("Esta configuração exige kudos no AI
Horde.", com "Usar configuração gratuita" / "Tentar novamente" / "Editar
descrição"); e o erro de credencial de verdade continua existindo, agora dito
direto ("Credencial inválida."). Junto disso, dois achados da medição contra a API
real: o preset **Cinema (768x432) nunca funcionou** — a Horde exige múltiplos de 64
e respondia 400 (corrigido para 768x448) — e o **desbloqueio** derivava a chave
PBKDF2 duas vezes para a mesma resposta (agora uma vez só, sem afrouxar nada).

A versão que abriu no aparelho real depois de três rodadas de defeito. Cinco correções,
todas com causa medida — nada foi trocado de lugar para esconder sintoma, e nenhuma
versão nova foi criada para cada uma delas (a 1.1.13 foi reconstruída, sempre com o
mesmo `versionName`/`versionCode` 17).

- **Abertura (Expo Router)** — a tela morria antes de renderizar por causa da pilha de
  rotas; a árvore de rotas passou a ser conferida por teste e o modo seguro deixou de
  ligar sozinho (`markStartupOk()` nunca era chamado e toda abertura contava como
  falha). Validado no Galaxy A05s;
- **seed da AI Horde** — era enviada como NÚMERO e a API exige TEXTO
  (`params.seed: "364056 is not of type 'string'"`). Agora a seed sai sempre como
  string, em qualquer caminho (automática, manual, "Tentar de novo"), sem tocar na
  seed da Pollinations;
- **cofre de imagens** — o cofre só ganhava chave pelo caminho da senha; a geração
  morria em VAULT_SAVE com "Cofre bloqueado". A chave do aparelho (Keystore,
  `lunaria-dek-device`) destrava o cofre sem senha, e a MESMA chave é promovida ao
  ativar a senha e devolvida ao desativar — nenhuma imagem se perde;
- **credencial do provedor** — chave desconhecida fazia a AI Horde responder 401 em
  toda tentativa, e não havia como conferir, ver qual chave estava ativa nem voltar ao
  modo gratuito. Agora: a chave é normalizada (aspas, `Bearer`, espaços), conferida no
  `GET /find_user` antes de salvar, a recusa do provedor cai **uma vez** para a chave
  anônima **com aviso escrito na tela**, a chave ruim é removida e há o botão
  "Usar modo gratuito (remover chave)";
- **bloqueio** — "Bloquear agora" e "Ao sair" não faziam nada porque o cofre (durável)
  e a marca "ligado" (MMKV, que pode voltar vazia) discordavam, e `lockNow` tinha um
  `return` silencioso. O cofre passou a decidir o estado (com a preferência reescrita
  para concordar), `lockNow` muda o estado **primeiro** e responde quando não pode
  bloquear, e "Ao sair" bloqueia **na saída**;
- provas: unidade **208/208**, render **174/174** (22 suítes), `tsc` limpo, `eslint`
  0 erros, e prova ponta a ponta contra a rede real (chave inválida → 401 → queda para
  a chave anônima → imagem de 86.276 bytes em 39 s, com a seed em texto). Detalhes em
  `BUGS_FOUND.md` §BN–§BQ e `TEST_REPORT.md` §16.12–§16.15. Pendente no aparelho:
  itens 32 a 37 do `CHECKLIST_APARELHO.md`.

## 1.1.12 — o texto das conversas e da memória passou a ser cifrado (19/09/2026)

Até a 1.1.11, só as **imagens** privadas eram cifradas; o texto das conversas
(banco SQLite) e a memória de pesquisa (MMKV) ficavam em claro no disco. A lacuna
foi declarada com honestidade na 1.1.11 e fechada nesta versão.

- o texto das mensagens (`chat_swipes.swipe`) é gravado cifrado (AES-256-GCM, mesma
  chave do cofre, contexto próprio `lunaria-texto-v1`); o que fica no disco é
  `enc:v1:<base64>`. **Nenhuma migração de banco**: a coluna continua `TEXT`;
- a memória de pesquisa usa um adaptador de armazenamento cifrado próprio;
- a **busca de mensagens** foi reescrita: era um `LIKE` do SQL sobre o texto e
  passaria a devolver vazio **em silêncio** com o texto cifrado. Agora decifra
  durante a varredura (mesma regra de comparação de antes). Limite declarado: varre
  no máximo 5000 mensagens por pesquisa;
- conversa antiga (sem marca) continua legível — não há passo de migração que possa
  falhar e apagar histórico;
- com o cofre fechado, ler texto cifrado devolve um aviso honesto em vez de lançar
  uma exceção no meio da abertura; e esse aviso **nunca** é gravado por cima do
  conteúdo (a gravação é recusada). Na memória, cofre fechado não lê e não grava;
- ajustes do aplicativo (modo, modelo local, endereço de API, filtros) continuam em
  claro **de propósito**: são lidos antes do desbloqueio;
- provas: `test:unit` 173/173 (10 novos), `test:render` 102/102 em 14 suítes
  (10 novos), `tsc` e `eslint` sem erro. Pendente no aparelho: item 26 do
  `CHECKLIST_APARELHO.md`.

As rodadas 1.1.3 a 1.1.11 (estabilidade da abertura, instrumentos de diagnóstico,
geração de imagem e bloqueio) estão documentadas em `STATUS.md` e `BUGS_FOUND.md`.


## 1.1.2 — cancelar agora avisa o provedor (18/09/2026)

**Defeito corrigido, encontrado na revisão depois da 1.1.1:** o botão "Cancelar"
parava a espera no aplicativo, mas **não avisava o provedor**. O trabalho
continuava na fila e era gerado do mesmo jeito — medido com o serviço real: um
trabalho abandonado terminou sozinho, com imagem pronta, cerca de 60 s depois.
Resultado prático: a imagem era produzida por um worker voluntário e ninguém a
recebia, gastando a prioridade (kudos) de quem cancelou.

- ao cancelar, o aplicativo agora envia `DELETE /generate/status/{id}` e o
  trabalho sai da fila;
- geração concluída **não** envia cancelamento (a imagem pronta não é descartada);
- erros que não são cancelamento (401, 404) também não;
- conferido na API real: o `DELETE` funciona sem cabeçalho de chave.

Testes: 3 novos em `tests/imageprovider.test.mjs` (30 no arquivo). Suíte de
lógica: 104/104; renderização: 50/50.

Versão 1.1.2, versionCode 4 — atualiza por cima da 1.1.1 (mesma assinatura).


## 1.1.1 — correção do limite de consultas do provedor (18/09/2026)

**Defeito corrigido, encontrado testando o provedor de verdade:** com fila longa,
a chave anônima da AI Horde responde **429 (muitas consultas)** a uma consulta de
status — mesmo com tudo certo. O aplicativo tratava esse 429 como erro definitivo
e abortava a geração, mostrando "cota esgotada" para quem não tinha cota esgotada
nenhuma. Numa fila de 262 pedidos (situação observada hoje), a geração nunca
chegaria ao fim.

- consultas de status com **429** ou **5xx** agora são tratadas como passageiras:
  o aplicativo espera e tenta de novo, com espera crescente (5 s, 10 s, 20 s… até
  30 s) e respeitando o cabeçalho `Retry-After` quando o provedor manda;
- erros que **não** são passageiros continuam abortando na hora: 401/403
  (autenticação), 404 (trabalho não encontrado), 400 (pedido inválido);
- o intervalo entre consultas subiu de 3 s para **5 s**, reduzindo a chance de
  bater no limite;
- o cancelamento continua funcionando durante a espera.

Testes: 6 novos em `tests/imageprovider.test.mjs` (19 no arquivo) cobrindo 429
repetido, teto da espera, `Retry-After`, 5xx, 401 e 404. Suíte de lógica: 93/93.

Versão 1.1.1, versionCode 3 — atualiza por cima da 1.1.0 (mesma assinatura).

## 1.1.0 — rodada Arena 2 (18/09/2026)

### Geração de imagem
- botão **Gerar imagem** na conversa, com tela própria de descrição, proporção
  (retrato, vertical, quadrado, paisagem, cinema) e 8 estilos: gótico, sombrio,
  fantasia, anime, fotografia, ilustração, moda e romântico;
- perfil visual editável da Lunaria (adulta, cabelo, olhos, roupas, acessórios)
  usado quando o pedido é sobre ela, com aviso do limite de consistência do modelo;
- prévia da descrição final (o texto exato enviado), prompt negativo e semente;
- estados reais de conexão, fila, geração, conclusão, erro e cancelamento, com
  tempo decorrido e nova tentativa;
- imagem exibida na conversa com visualizador (zoom, salvar, compartilhar, apagar);
- política de conteúdo antes do envio: permite adulta, sensualidade não explícita,
  moda alternativa e romance; recusa nudez sexual, atos, menores e coerção.

### Provedores
- **AI Horde (imagem)** como padrão, com a chave anônima que já existia no app e
  suporte a chave pessoal gratuita;
- **Pollinations** como alternativa sem cadastro;
- provedores pagos desativados por padrão;
- mensagens específicas para falta de internet, cota estourada (429), provedor
  indisponível (5xx), recusa e resposta inválida.

### Bloqueio e privacidade
- senha ou PIN de no mínimo 6 dígitos, com biometria opcional;
- bloqueio ao abrir e ao voltar do segundo plano, com intervalo configurável e
  botão “Bloquear agora”;
- nenhuma tela é montada enquanto bloqueado; notificação com conversa fica
  pendente até o desbloqueio;
- conteúdo escondido nas notificações e na prévia de aplicativos recentes;
- opção de impedir capturas de tela (ligada automaticamente enquanto bloqueado);
- espera progressiva nas tentativas erradas, **sem apagar dados**;
- ao bloquear: para a leitura em voz alta, aborta o microfone, descarta a chave
  da memória e apaga as cópias decifradas temporárias;
- ativar, alterar e desativar exigem autenticação; procedimento de senha
  esquecida explicado antes de qualquer redefinição.

### Cifragem e migração
- imagens privadas em AES-256-GCM com chave no Android Keystore (sem senha,
  a chave fica só no Keystore; com senha, embrulhada por PBKDF2-HMAC-SHA256,
  150.000 iterações);
- pasta `private/` com nomes aleatórios e extensão `.lunaenc`;
- migração automática das imagens antigas em claro para o cofre, com verificação
  de leitura antes de apagar o original;
- cópia de segurança do Android desativada para os dados do app.

### Compatibilidade
- versão 1.1.0, versionCode 2, mesma assinatura de release da 1.0.0 (atualiza por
  cima sem desinstalar);
- nenhum recurso anterior removido: conversa, personalidade editável em pt-BR,
  tratamento masculino a Hamura, GGUF local, API remota, ditado, leitura em voz
  alta, Pesquisa/Fatos e memória continuam iguais.

## 1.0.0

- rebranding completo para Lunaria;
- cartão de personagem em português e preservação das respostas sem frases prontas;
- AI Horde anônimo como conexão online inicial;
- Pesquisa/Fatos com comparação de fontes e memória;
- ditado pt-BR, TTS e telas de privacidade traduzidas;
- execução local GGUF preservada;
- testes automatizados de persona e pesquisa.
- decodificação incremental de UTF-8, SSE e NDJSON;
- proteção contra envio duplicado e finalização duplicada de respostas;
- cancelamento de gerações antigas sem misturar novas mensagens;
- limite de tempo cobrindo a leitura completa da resposta online;
- pesquisa por links públicos como alternativa à indisponibilidade do buscador;
- salvamento explícito de pesquisas, com fontes e data;
- interrupção do ditado ao sair da conversa e idioma pt-BR no TTS;
- compilação manual no GitHub Actions, sem o servidor privado do projeto-base.

## 1.0.0 — rodada Arena (15/09/2026)

- **APK arm64 compilado e assinado** com chave própria da Lunaria (o template
  do Expo assinava o release com a chave de depuração);
- plugin `expo-build-plugins/lunaria-signing.plugin.js`, que sobrevive a
  `expo prebuild --clean` e usa `android/keystore.properties` quando existe;
- buffer de geração com dono (`lib/engine/StreamBuffer.ts`): texto de outra
  conversa, de outro swipe ou de uma resposta antiga nunca prefixa nem contamina
  a resposta nova — corrige a sobra de texto e a gravação contaminada;
- mesma separação no buffer da leitura em voz alta e na tela (`ChatTextLast`);
- pesquisa agrupa trechos repetidos por similaridade e informa quantos
  textos-base distintos existem; o contexto separa fatos, divergências,
  opiniões e evidências insuficientes;
- padrão local conservador para 6 GB de RAM (lote 256, contexto 4096, 4 threads,
  `ctx_shift`), tudo editável em Configurações → Modelo;
- 150 rótulos de interface herdados do ChatterUI traduzidos para português;
- 7 testes novos (26 no total), TypeScript e ESLint sem avisos.
