# Lunaria 1.1.2 — relatório de testes e validação (18/09/2026)

> **Documento de rodada antiga**, mantido como histórico. Os números atuais estão
> em `TEST_REPORT.md`: a rodada 1.1.12 está na **seção 15** (173 testes de lógica e
> 102 de renderização, 14 suítes — sem nenhum teste pulado, pela primeira vez), e
> as rodadas anteriores, nas seções 11 a 14.

> Terceira rodada do dia. A 1.1.0 entregou geração de imagem e bloqueio; a 1.1.1
> e a 1.1.2 corrigem **quatro** defeitos que só apareceram quando a geração foi
> executada **de ponta a ponta** contra o serviço real. Os números abaixo são os
> da árvore atual (1.1.2).

Resumo honesto: **o que foi testado de verdade**, o que depende do aparelho e o
que não pôde ser executado neste ambiente. Nada aqui foi marcado como aprovado
sem ter sido executado.

## 1. O que foi testado e passou (execução real nesta máquina)

| Verificação | Comando | Resultado |
| --- | --- | --- |
| Suíte automatizada completa (1.1.2) | `npm run test:unit` | **104 de 104** passaram, 0 falhas (87 da 1.1.0 + 17 novos: 429, endereço/base64, semente e cancelamento) |
| Criptografia do cofre | `tests/crypto.test.mjs` | 10 de 10 — AES-256-GCM, PBKDF2, senha errada recusada, adulteração detectada, base64 próprio, UTF-8 com acentos/emoji |
| Política de conteúdo | `tests/imagepolicy.test.mjs` | 9 de 9 — permite adulta/sensual/moda/romance; recusa explícito, menor, coerção, proibido |
| Montagem do prompt | `tests/imageprompt.test.mjs` | 10 de 10 — proporções, 8 estilos, perfil da Lunaria, prompt negativo, prévia, semente |
| Cliente dos provedores | `tests/imageprovider.test.mjs` | 13 de 13 — fila, imagem recebida, cancelamento, cota (429), provedor fora do ar (502), sem internet, resposta inválida, chaves |
| Bloqueio e migração | `tests/lock.test.mjs` | 9 de 9 — mínimo de 6, espera progressiva até 5 min, mensagens, plano de migração idempotente |
| Arquivos privados | `tests/privatefiles.test.mjs` | 10 de 10 — uri privada, nome da cópia de exibição, mime, tipo por bytes, nome de exportação |
| TypeScript | `npx tsc --noEmit` | sem erros |
| **Camada 2: renderização** | `npm run test:render` | **49 de 49** — executa o portão de bloqueio, a tela de desbloqueio, o ciclo real de senha (Crypto + SecureVault + AppLock), o cofre de arquivos, a tela de conversa (com o botão Gerar imagem) e as telas novas |
| ESLint | `npx eslint .` | 0 erros |

## 2. Chamadas reais aos provedores de imagem (linha de comando)

| Provedor | Resultado observado |
| --- | --- |
| AI Horde (imagem), chave anônima `0000000000` | WebP 512×768, 94.280 bytes, ~25 s com fila, `censored:false`, modelo `stable_diffusion` |
| AI Horde, `dry_run` adulto | aceito (kudos 9,0) |
| Pollinations, sem chave | JPEG 512×768, 37.291 bytes, ~2,0 s (HTTP 200) |

Os pedidos foram feitos com os mesmos parâmetros e cabeçalhos que o aplicativo
usa. Não foram feitos **pelo aplicativo** — isso depende do aparelho (seção 4).

## 3. APK

| Verificação | Resultado |
| --- | --- |
| `:app:assembleRelease` (arm64-v8a), 1.1.2 | Compilação a frio de ~3 h (R8 sozinho ~58 min de CPU em máquina de 2 núcleos/2 GB) com uma falha de **metaspace** no fim; retomada com o teto corrigido terminou em **1m 06s** reaproveitando o R8 em cache (`> Task :app:minifyReleaseWithR8 UP-TO-DATE`) — 41 tarefas executadas, 888 reaproveitadas |
| Assinatura | `apksigner verify`: **Verifies** — esquema v2, CN=Lunaria, digest SHA-256 `c0271509ad829da96e8fd205faa99b7103bf43c358a8501c0925606c7b55719a` — **o mesmo certificado da 1.0.0** (atualiza por cima, sem desinstalar) |
| Versão | `br.aurora.luna.lunaria.next` 1.1.2, versionCode 4, targetSdk 36, minSdk 24, arm64-v8a |
| SHA-256 do APK | `e39b3ae7f41614e95d9da83cfe3760e17761bfb9188f6628a2cd4df5f4fa319b` |
| Tamanho | 60.466.386 bytes (57,7 MiB) |
| Conteúdo conferido dentro do pacote | `assets/index.android.bundle` (6.428.024 bytes) com o identificador `Lunaria:1.1.2`; 53 bibliotecas `.so`; aviso de idioma, espera após 429, "Gerar imagem", "Bloquear agora" e Pesquisa presentes |
| Preservação dentro do APK entregue (1.1.2) | `python3 tools/verificar_preservacao.py <apk>` → **12 de 12 recursos** encontrados no bundle e no pacote: conversa, personalidade pt-BR, Hamura, Pesquisa/Fatos, memória, ditado, leitura em voz alta, API remota, GGUF local (`librnllama*.so` + `libggml-htp-*.so`), modelo embutido (`res/RT.gguf`, 7.818.140 bytes), geração de imagem e bloqueio/cofre |
| Verificação **sem SDK**, com a ferramenta entregue no próprio ZIP | `python3 tools/verificar_assinatura.py Lunaria-1.1.2-arm64-release.apk` → certificado 1410 bytes DER, sha256 `c0271509…5719a`, assinatura 512 bytes, algoritmo `0x0104` (RSA + SHA-512) |
| Prova criptográfica da assinatura | `openssl dgst -sha512 -verify` sobre os dados assinados, com a chave pública do certificado → **Verified OK**; chave do bloco igual à do certificado (comparação byte a byte) |
| O que a verificação offline **não** cobre | a conferência de que o conteúdo corresponde ao resumo assinado (árvore de Merkle) — feita pelo `apksigner` (linha acima) e declarada como limite pela própria ferramenta |
| Continua funcionando | `Pesquisa`, cofre (`lunaria-dek`), "Senha ou PIN" e "Bloquear agora" presentes no bundle — as rodadas 1.1.1/1.1.2 mexeram só no provedor de imagem |
| Tentativas de build até o sucesso | 10 nesta máquina (memória do daemon, NDK removido por erro meu, disco cheio, OOM e metaspace) — cadeia completa em `BUGS_FOUND.md`, seções D–K, W e Z |

## 3.1 O que a camada de renderização passou a provar (18/09)

Depois do APK pronto, os 87 testes de lógica foram complementados por 49 testes
que **executam** componentes de verdade (módulos nativos simulados):

- o portão de bloqueio não monta o aplicativo enquanto está bloqueado, e não
  mostra nada entre a abertura e a leitura do cofre;
- tocar em **Gerar imagem** na conversa abre a tela de geração;
- o ciclo de senha roda com o código real: ativar, bloquear, errar (com
  contagem e espera progressiva), acertar, trocar a senha (e o arquivo antigo
  continua abrindo com a nova) e desligar a proteção — sempre exigindo a atual;
- **nenhuma senha em claro** no keychain nem no armazenamento depois do uso;
- os bytes gravados pelo cofre **não contêm** o conteúdo original, dois arquivos
  iguais geram bytes diferentes e, com o cofre fechado, a leitura falha;
- as telas novas abrem e o campo de senha é mascarado.

Isso **não substitui** o teste no aparelho; tira da lista apenas o que era
verificação de código. O que continua pendente é o que depende de hardware,
sistema e rede.

## 4. Pendente: precisa do Galaxy A05s

### Geração de imagem
1. Gerar imagem real com o provedor padrão (AI Horde) pela interface.
2. Acompanhar fila/estados e cancelar no meio de uma geração.
3. Gerar pelo Pollinations e confirmar a mensagem do limite de 15 s na segunda
   tentativa seguida.
4. Desligar a internet e gerar: mensagem de conexão, sem travar a interface.
5. Descrever cena proibida (nudez/ato) e confirmar a recusa **antes** do envio.
6. “Usar na conversa”, ampliar com pinça, salvar na galeria (com o aviso),
   compartilhar e apagar.
7. Reabrir o aplicativo e confirmar que a imagem continua na conversa.

### Bloqueio
8. Criar senha de 6 dígitos, sair e voltar: pede senha.
9. Errar 3, 4 e 5 vezes: espera de 1 s, 2 s e 4 s.
10. Abrir o aplicativo com bloqueio ativo: **nenhuma** conversa pode aparecer
    antes da tela de desbloqueio (verificar gravando a tela).
11. Abrir por notificação estando bloqueado: precisa pedir senha antes de abrir a
    conversa.
12. Biometria: desbloquear com digital/rosto e depois com a senha.
13. Trocar a senha e confirmar que as imagens antigas continuam abrindo.
    (O comportamento em si já foi verificado aqui com o código real; falta a
    conferência no aparelho.)
14. Ativar “impedir capturas de tela” e testar; bloquear com TTS e ditado ativos
    e confirmar que a fala para e o microfone é liberado.

### Migração e atualização
15. Instalar a 1.1.0 **por cima** da 1.0.0 (mesma assinatura) e confirmar que
    conversas, personagem e ajustes permanecem.
16. Confirmar que imagens antigas de `Attachments/` passaram a `.lunaenc` em
    `private/` e continuam aparecendo na conversa.

## 5. Nota sobre a reconstrução

Este APK é uma **recompilação** depois da segunda reversão do workspace: o APK
anterior (`629894dd…`) foi perdido no limite do turno, o ZIP do código
sobreviveu e a árvore foi restaurada a partir dele (388 arquivos conferidos,
todos OK). O que não é recuperável são as medições antigas de *arquivo*; todos
os números acima foram remedidos nesta compilação. O que importa para a
atualização continua igual: a assinatura é a mesma da 1.0.0.

## 6. Limitação deste ambiente

Sem aparelho Android, sem emulador e sem `/dev/kvm`; o host é x86_64 e o APK é
arm64-v8a. O aplicativo **não executa** aqui. Os itens da seção 4 continuam
marcados como pendentes até serem feitos no aparelho.
