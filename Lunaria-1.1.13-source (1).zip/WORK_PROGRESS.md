# WORK_PROGRESS.md — retomada de trabalho da Lunaria

> **LEIA ESTE ARQUIVO ANTES DE QUALQUER COISA.**
> Se o ambiente do Arena falhar ("Something went wrong"), o próximo agente retoma
> **por aqui** e **não** recomeça do zero: nada de nova versão, nada de projeto novo,
> nada de build automático, nada de refazer o que já está feito.

---

## CAMPOS DE ESTADO

```
CURRENT_VERSION:
1.1.13  (versionCode 17)  — CONGELADA.

  Por que 1.1.13 e não 1.1.12: a regra diz "versionName = 1.1.12 OU mantenha
  exatamente a versão que já estiver no workspace". Mantive a que está, porque
  mudar o número agora desalinharia o código do APK de validação que já existe
  (código 17, sha a558df0d…) — e a regra é não gerar build novo. NENHUMA versão
  nova (1.1.14, 1.1.15…) será criada sem ordem expressa do usuário.

CURRENT_GOAL:
Garantir que o crash de inicialização (Expo Router / ErrorBoundary) está corrigido
de verdade no código atual e que o caminho até o release final passa pela validação
no aparelho — sem criar versões novas pelo caminho.

LAST_COMPLETED_STEP (21/09/2026, SEGUNDA RODADA — credencial da AI Horde + bloqueio):
DOIS DEFEITOS DO APARELHO, LIGADOS, CORRIGIDOS E PROVADOS (§BQ em BUGS_FOUND.md,
§16.15 no TEST_REPORT.md):
  A) "O provedor recusou a credencial usada." MEDIDO contra a API real: chave
     desconhecida -> 401 InvalidAPIKey; anônima -> 202; sem cabeçalho -> 400. Havia
     chave guardada que a Horde recusa, e o app a repetia em toda tentativa — sem
     conferir ao salvar, sem dizer qual chave estava ativa e sem caminho de volta ao
     modo gratuito. Agora: normalização (aspas/prefixo/espaço), conferência no
     GET /find_user antes de salvar (chave recusada NÃO é gravada e a antiga é
     removida), botão "Usar modo gratuito (remover chave)", linha do modo na tela e
     queda automática para a chave anônima quando a do usuário é recusada — com
     AVISO escrito e a chave ruim removida. Seed continua TEXTO (provado).
  B) "Bloquear agora" e "Ao sair" não bloqueavam. Causa: o cofre (durável, no
     armazenamento seguro) e a marca "ligado" (MMKV, que pode voltar vazia)
     discordavam; a tela mostrava o cofre pronto e o estado interno dizia "não
     configurado", com return silencioso em lockNow. Agora o cofre decide (e a
     preferência é reescrita para concordar), lockNow muda o estado PRIMEIRO
     (fail-closed) e responde quando não pode bloquear, "Ao sair" bloqueia na saída,
     e todo o fluxo grava LOCK_NOW_TRIGGERED / LOCK_STATE_CHANGED /
     AUTO_LOCK_POLICY_APPLIED / APPSTATE_* / UNLOCK_* / VAULT_*.
  EXTRA: markStartupOk() nunca era chamado -> toda abertura era contada como falha e
     o modo seguro ligava sozinho na segunda; passou a ser chamado quando a abertura
     termina.
PROVAS: unidade 208/208, render 174/174 (22 suítes), tsc limpo, eslint 0 erros, e
prova ponta a ponta com rede real (chave inválida -> queda para anônima -> 86.276
bytes WebP em 39 s). Medição crua: lunaria-build/logs/medicao-credencial-2026-09-21.txt

LAST_COMPLETED_STEP ANTERIOR (21/09/2026, primeira rodada):
DOIS DEFEITOS LIGADOS, CORRIGIDOS E PROVADOS (§BP em BUGS_FOUND.md, §16.13 no
TEST_REPORT.md):
  A) "Ativar bloqueio" sem validação na tela e sem tratamento de exceção em
     enableLock -> botão sem estado definido e toque silencioso. Agora:
     validarAtivacao() em LockPolicy (>=6 nos dois campos, iguais, sem espaços),
     botão aceso só quando válido, motivo escrito quando apagado, e a razão real
     do erro na tela + diagnóstico.
  B) Geração de imagem morria na etapa VAULT_SAVE com "Cofre bloqueado" porque o
     cofre só ganhava chave pelo caminho da senha. Implementada a chave do
     aparelho (Keystore), como o CHANGELOG prometia: ensureDeviceVault,
     protectExistingKey (promove a MESMA DEK ao ativar), degradeToDeviceKey
     (devolve a MESMA DEK ao desligar, sem perder imagem), e AppLock.init destrava
     o cofre sem senha. A etapa da falha agora é explícita (kind 'cofre',
     stage VAULT_SAVE) — nada de mensagem genérica.
PROVAS: unidade 193/193, render 151/151 (18 suítes), tsc limpo, eslint 0 erros.
AMBENTE: foi apagado no meio do trabalho (/opt e node_modules) e restaurado com
setup-toolchain.sh + npm ci; o projeto estava intacto.

LAST_COMPLETED_STEP ANTERIOR (20/09/2026):
CORREÇÃO DA SEED NO PAYLOAD DA AI HORDE. O aparelho abriu a 1.1.13 (VALIDADO pelo
usuário) e o defeito restante apareceu na geração de imagem:
`Input payload validation failed — params.seed: "364056 is not of type 'string'"`.
A Lunaria mandava `seed` como NÚMERO; a API exige TEXTO.
Corrigido SÓ nesta integração: `lib/imagegen/ImageProviders.ts` ganhou
`seedDaHorde()` (número→texto; ausente/vazio/NaN/Infinity → campo OMITIDO) e uma
validação antes do request (`typeof params.seed === 'string'`), que lança erro
claro em vez de esconder. A interface, a seed aleatória, a manual, o "Tentar de
novo", a resolução, os estilos e os outros provedores (Pollinations usa a seed na
URL, intacta) não foram tocados.
PROVAS: `tests/imageprovider.test.mjs` com os 5 testes pedidos — 34/34 no arquivo;
suíte de lógica 181/181; render 142/142 (a trava do startup segue 29/29);
`tsc` limpo; `eslint` 0 erros.

CURRENT_STEP:
ENTREGA PRONTA E CONFERIDA — nada mais a gerar.
RETOMADA (21/09, apos queda da interface): o estado foi verificado ANTES de agir.
  o build e o fechamento ja tinham terminado antes da queda (--- exit=0 ---,
  ENTREGA_OK no log, nenhum processo pendente), o APK NAO foi gerado de novo e a
  versao NAO mudou. Conferido na retomada: sha256sum -c SHA256.txt -> 6/6 OK; APK da
  entrega identico ao do build (fafa66db...); docs do ZIP identicas as soltas;
  versionCode 17 / versionName 1.1.13 por dentro do pacote; assinatura v2 verdadeira
  com o certificado c0271509...5719a.
  Corrigido nessa conferencia: o CHECKLIST_APARELHO.md ainda mandava instalar o APK
  ANTIGO (5bc2d000...) — passou a apontar para o desta rodada (fafa66db...), e o ZIP
  de fonte foi refeito com essa correcao (hash do ZIP mudou; nada de codigo mudou).
EMPACOTAMENTO (21/09, depois do aviso de "Invalid cross-device link"):
  o erro e de ESTRATEGIA DE COPIA, nao do aplicativo. O empacotador tinha duas
  exposicoes e as duas foram fechadas:
    - o palco era criado em /tmp (tmpfs): qualquer criacao de link cruzava
      filesystem.  Agora palco e conferencia nascem no MESMO filesystem da origem
      (/home/user/.empacotamento-*, /home/user/.conferencia-*) e um trap limpa tudo;
    - o tar nao usava --hard-dereference: hard link na arvore viraria link() na
      extracao.  Agora o tar desreferencia (hard link vira arquivo comum) e o script
      FALHA de proposito se contar qualquer hard link no palco.
  O empacotador tambem passou a reprovar o pacote se entrar node_modules,
  android/app/build, android/build, .gradle, .expo ou local.properties, e a exigir
  os arquivos de reconstrucao (package.json, package-lock.json, app.config.js,
  babel.config.js, metro.config.js, tsconfig.json, index.js, app/, src/, android/,
  assets/, lib/, db/, tests/).
  MEDIDO nesta rodada: hard links no projeto = 0 (fora e dentro de node_modules);
  ZIP sem node_modules e sem diretorios de build; todos os itens de reconstrucao
  presentes; APK NAO foi regenerado (fafa66db...) e o build NAO foi rodado de novo. O APK desta rodada esta em /home/user/entrega/
(Lunaria-1.1.13-arm64-release.apk, sha fafa66db...) junto com o ZIP de fonte refeito
e o SHA256.txt conferido (6/6). O que falta e o usuario instalar e seguir os itens
32 a 37 do CHECKLIST_APARELHO.md.

FILES_CHANGED NESTA RODADA (21/09 — credencial + bloqueio):
  1. lib/imagegen/ChaveDoProvedor.ts      NOVO (puro): normalizarChave, mascararChave,
                                          escolherCredencial, corpoSanitizado,
                                          conferirChaveHorde (GET /find_user),
                                          avisoChaveRecusada, rotuloDoModoPara
  2. lib/imagegen/ImageProviders.ts       credencial decidida no envio, queda única
                                          para a chave anônima com aviso, corpo
                                          sanitizado no erro de credencial, diagnóstico
                                          (onDiagnostic) e aviso no resultado
  3. lib/state/ImageGeneration.ts         conferirESalvarChave, usarModoGratuito, aviso,
                                          remoção automática da chave recusada,
                                          diagnóstico na trilha
  4. src/screens/ImageSettingsScreen.tsx  modo em vigor, "Conferir e salvar chave",
                                          "Usar modo gratuito (remover chave)"
  5. src/screens/ImageGenerationScreen.tsx linha do modo + caixa do aviso
  6. lib/state/AppLock.ts                 init: o cofre decide o "ligado"; lockNow muda
                                          o estado primeiro, responde e registra; UNLOCK_*/
                                          VAULT_* no diagnóstico
  7. app/_layout.tsx                      "ao sair" bloqueia na saída; APPSTATE_*;
                                          markStartupOk() chamado ao fim da abertura
  8. src/screens/LockSettingsScreen.tsx   resultado do botão + linha de estado real
  9. testes                               chave-provedor (10), imageprovider 34->39,
                                          imagem-chave (8), bloqueio-estado (9),
                                          bloqueio-ao-sair (6)

FILES_CHANGED NESTA RODADA (21/09 — cofre + botão):
  1. lib/security/SecureVault.ts        (chave do aparelho: ensureDeviceVault,
                                         protectExistingKey, degradeToDeviceKey,
                                         deviceKeyExists; novo slot lunaria-dek-device)
  2. lib/state/AppLock.ts               (init destrava com a chave do aparelho sem
                                         senha; enableLock promove a mesma DEK;
                                         disableLock degrada sem perder imagem)
  3. lib/security/PrivateStorage.ts     (CofreBloqueadoError — erro tipado)
  4. lib/security/LockPolicy.ts         (validarAtivacao + mensagens do formulário)
  5. src/screens/LockSettingsScreen.tsx (validação viva, botão com estado e motivo,
                                         try/catch com a razão real)
  6. lib/imagegen/ImageProviders.ts     (ImageStage; fase 'salvando'; etapas nos erros)
  7. lib/imagegen/FalhaDeImagem.ts      (NOVO — classificação por etapa, pura)
  8. lib/state/ImageGeneration.ts       (etapa VAULT_SAVE explícita + classificação)
  9. testes NOVOS: tests/falhaimagem.test.mjs (4),
     tests/render/cofre-aparelho.test.tsx (6), tests/render/imagem-cofre.test.tsx (3);
     tests/lock.test.mjs (+8)

FILES_CHANGED (rodadas anteriores da investigação 1.1.13, para histórico):
  1. lib/state/EventosBloqueio.ts       (NOVO — barramento sem importações)
  2. lib/state/AppLock.ts               (passou a usar avisarBloqueio; não importa TTS)
  3. lib/state/TTS.ts                   (registra aoBloquear(() => stopTTS()))
  4. app/ → src/                        (116 arquivos movidos; app/ ficou com 28)
  5. tsconfig.json                      (atalhos @screens/*, @components/*)
  6. package.json                       (jest: @vali98 em transformIgnorePatterns;
                                         moduleNameMapper)
  7. app.config.js                      (versão 1.1.13)
  8. android/app/build.gradle           (versionCode 15→16→17)
  9. lib/imagegen/ImageProviders.ts     (CLIENT_AGENT 1.1.13; e a correção de cota:
                                         500 com marca de limite vira erro de cota)
 10. testes NOVOS: tests/render/rotas-carregam.test.tsx (29),
     tests/render/raiz-carrega.test.tsx (5), tests/arquitetura-rotas.test.mjs (4),
     tests/render/bloqueio-silencia.test.ts (2); tests/imageprovider.test.mjs (+3)
 11. documentos: BUGS_FOUND.md (§BG, §BN), TEST_REPORT.md (§16.5–§16.11),
     STATUS.md, LEIA-ME.md, CHECKLIST_APARELHO.md (item 27), CORRECOES.md

ROOT_CAUSE_FOUND:
YES

ROOT_CAUSE:
CICLO DE IMPORTAÇÃO criado junto com a função de bloqueio:

    lib/state/AppLock.ts → lib/state/TTS.ts → lib/state/Chat.ts → AppLock.ts

O `app/_layout.tsx` (a RAIZ que o Expo Router carrega primeiro) importa o AppLock.
Ao avaliar essa cadeia, o TTS era avaliado com o Chat ainda "em avaliação"; toda
importação do Chat valia `undefined` e o `useInference.subscribe(...)` no fim do
TTS.ts (linha 99) lançava `Cannot read property 'subscribe' of undefined`.
Em produção, o Metro chama ErrorUtils.reportFatalError (é o
`FATAL EXCEPTION: mqt_v_native / JavascriptException`) e DEVOLVE `undefined` como
módulo. O `loadRoute()` da rota recebeu esse undefined e o `fromImport` do Expo
Router quebrou ao desestruturar — o `Cannot read property 'ErrorBoundary' of
undefined` do aparelho.

AS QUATRO RESPOSTAS OBRIGATÓRIAS:
  1. contextKey que falhou ....... ./_layout.tsx   (a raiz do contexto)
  2. arquivo real ................ app/_layout.tsx (arquivo inocente; a cadeia
     culpada é AppLock.ts → TTS.ts (linha 99) → Chat.ts)
  3. por que loadRoute() = undefined  porque o factory do módulo lançou e o runtime
     de produção do Metro converte isso em `undefined` (lido do bundle entregue:
     `publicModule.exports = void 0`)
  4. o que corrigiu .............. quebrar o ciclo com lib/state/EventosBloqueio.ts
     (zero importações) — o bloqueio avisa, o TTS escuta. Sem try/catch escondendo
     erro, sem ErrorBoundary por cima, sem tirar função.

PROVA CAUSAL (não dedução): reintroduzindo SÓ a aresta antiga (AppLock→TTS) na mesma
árvore, a chave ./_layout.tsx volta a falhar com a MESMA mensagem
(`LANCOU: Cannot read properties of undefined (reading 'subscribe')`, SEM_MODULO=1);
retirando a aresta, as 28 rotas carregam (TOTAL=28 SEM_MODULO=0).
Registro completo: TEST_REPORT.md §16.7. Trava permanente:
tests/render/rotas-carregam.test.tsx.

BUILD_STATUS:
SUCCESS — reconstrução do MESMO 1.1.13 (versionCode 17, sem incremento), agora com
as correções da credencial da AI Horde e do estado do bloqueio.
Build FRIO de verdade (o /opt inteiro foi apagado com o ambiente: sem cache de
transform, sem cache de build), 06:06:13 -> 06:32:05 UTC de 21/09,
BUILD SUCCESSFUL in 25m 49s (952 tarefas: 810 executadas, 142 do cache).
APK: 66.859.835 bytes, sha fafa66dbf1c3423deccf9928612fb7ef17d64613d86db2a553c648325f8ce458
Versao dentro do pacote: 1.1.13 / versionCode 17; assinatura v2 verdadeira; certificado
c0271509...5719a (o mesmo desde a 1.0.0: instala por cima).
Bundle: 6.683.492 bytes (+17.148) e com os literais DESTA rodada (find_user,
LOCK_NOW_TRIGGERED, AUTO_LOCK_POLICY_APPLIED, Conferir e salvar chave, Usar modo
gratuito, A imagem saiu pelo modo gratuito). O literal da rodada passada
(lunaria-dek-device) continua la.
ZIP de fonte refeito (as docs mudaram): 478 arquivos, nenhuma chave no pacote.
Tamanho e soma vigentes no SHA256.txt da entrega (editar uma doc muda o ZIP, entao o
hash do proprio ZIP nao fica escrito dentro dele). SHA256.txt conferido: 6/6 OK.
O toolchain foi reinstalado nesta rodada (setup-toolchain.sh -> TOOLCHAIN_OK).
Logs: lunaria-build/logs/gradle-46.log · verificacao-apk-46.log ·
comparacao-apk-46.log · finalizacao-46.log

BUILD ANTERIOR (bem-sucedido, fica no histórico de SHAs):
SUCCESS — reconstrução do MESMO 1.1.13 (versionCode 17, sem incremento), com as
correções do cofre e do botão "Ativar bloqueio".
Build FRIO (transforms do Gradle e /opt/lunaria-gradle-cache apagados antes):
iniciado 04:39:30 UTC, terminou 05:06:43 UTC de 21/09 — BUILD SUCCESSFUL in 27m 10s.
APK: 66.842.687 bytes, sha256
5bc2d0006a97e6a1abbaad4a468fb71579bd13fb88e3df125e0c4f316f753861, versionCode 17,
versionName 1.1.13, certificado c0271509ad829da96… (o MESMO desde a 1.0.0 — instala
por cima, sem desinstalar).
Conferência diferencial contra o APK anterior (gradle-44): as ÚNICAS diferenças são
o tamanho, o sha e o bundle Hermes (6.666.344 B contra 6.661.088 B). versionCode,
certificado, applicationId, as 26 chaves de rota e os 53 .so batem igual.
Marcadores do código NOVO conferidos DENTRO do bundle do APK: validarAtivacao,
"Use pelo menos … caracteres.", "As senhas não coincidem.", "Repita a senha no
segundo campo.", "Digite uma senha ou um PIN.", "Evite espaços no começo ou no fim.",
cofre-ativar, CofreBloqueadoError, VAULT_SAVE / IMAGE_READ / IMAGE_DISPLAY,
"salvando" e lunaria-dek-device.
Suites rerodadas na árvore congelada (nada mudou desde o build): 193/193 (lógica) e
151/151 (render).
Build anterior (20/09, 17:24 → 17:41): SUCCESS, sha 4865463ec55c4064… — abriu no
aparelho e entregou a correção da seed; fica no histórico de SHAs.

REAL_DEVICE_VALIDATION:
STARTUP: **VALIDADO PELO USUÁRIO** — "A LUNARIA 1.1.13 AGORA ABRE CORRETAMENTE NO
APARELHO REAL" (Samsung Galaxy A05s, Android 15).
SEED NO AI HORDE: validada no aparelho pelo erro que o serviço devolveu — a
correção foi feita e provada contra a API real (HTTP 202 com seed "364056"), e
continua TEXTO nesta rodada (provado de novo, com chave inválida no meio).
CREDENCIAL DA AI HORDE + BLOQUEIO: **pendente no aparelho** — itens 35, 36 e 37 do
CHECKLIST_APARELHO.md. As duas correções foram provadas aqui: medição contra a API
real (401/202/400, /find_user 200/404/401) e prova ponta a ponta com o código do
aplicativo (imagem real de 86.276 bytes saindo pelo modo gratuito depois da recusa).

NEXT_STEP (uma coisa só):
Instalar por cima o /home/user/entrega/Lunaria-1.1.13-arm64-release.apk
(fafa66db..., 66.859.835 bytes) e seguir os itens 32 a 37 do
CHECKLIST_APARELHO.md (os três últimos são desta rodada: 35 = chave de API,
36 = chave recusada caindo no modo gratuito com aviso, 37 = "Bloquear agora"/"Ao
sair"/temporizadores aplicando estado):
  32) preencher senha e "Repita" (6+ iguais) -> o botão "Ativar bloqueio" ACENDE;
      se estiver curto/diferente, ele fica apagado **com o motivo escrito**;
  33) ativar o bloqueio e confirmar que o cofre fica ativo (a tela passa a mostrar
      "Bloquear agora");
  34) gerar imagem no AI Horde (com e sem seed digitada). Esperado: imagem
      aparece no histórico, guardada cifrada no cofre — e, se o cofre estiver
      fechado, a mensagem diz a etapa (VAULT_SAVE) em vez de "não foi possível".
Se algo falhar, mandar a mensagem exata que a tela mostrou.
```

---

## ETAPAS (A a H) — estado real, com evidência

| etapa | o que é | estado | evidência |
| --- | --- | --- | --- |
| A | Mapear a árvore real do Expo Router | **CONCLUÍDA** | `app/` com 28 arquivos; saída do próprio Expo Router: `{"layout":1,"route":27}` |
| B | Listar todo arquivo tratado como rota | **CONCLUÍDA** | 27 rotas + 1 layout, auditadas arquivo por arquivo nesta retomada (nenhum componente/botão/hook dentro de `app/`) |
| C | Identificar rota/módulo que retorna `undefined` | **CONCLUÍDA** | `./_layout.tsx`; hoje **nenhuma** rota devolve undefined (`TOTAL=28 SEM_MODULO=0`) |
| D | Descobrir a causa do módulo inválido | **CONCLUÍDA** | ciclo `AppLock→TTS→Chat→AppLock`; `TTS.ts:99`; prova causal em `TEST_REPORT.md` §16.7 |
| E | Aplicar a menor correção estrutural | **CONCLUÍDA** | `lib/state/EventosBloqueio.ts` + `app/`→`src/` (feita **depois** de confirmar a ligação com o crash) |
| F | `expo-doctor` e validações | **CONCLUÍDA nesta retomada** | 18/20; os 2 avisos não têm relação com o crash (abaixo); suítes 142/142 + 180/180 |
| G | Bundle production e verificação das rotas | **CONCLUÍDA** | `expo export:embed` + instrumentação `LUNARIA_ROUTE_LOAD` (28/28, 0 sem módulo) e conferência do bundle Hermes **dentro do APK** |
| H | APK release final | **FEITO UMA VEZ** (código 17) — **nenhum build novo** até a validação no aparelho | `BUILD SUCCESSFUL in 16m 54s`; pacote 6/6 conferido |

---

## ETAPA F — o que o `expo-doctor` disse (20/09/2026)

`18/20 verificações passam`. As duas que falham, com leitura honesta:

1. **"Validate packages against React Native Directory package metadata"** —
   aviso informativo: `react-native-background-actions` não consta como testado na
   Nova Arquitetura, e os pacotes `@vali98/react-native-*` e `cui-llama.rn` não têm
   metadados no diretório (são módulos próprios do projeto / fork do llama.cpp).
   **Não é defeito** e não tem relação com o crash de abertura.
2. **"Check that packages match versions required by installed Expo SDK"** —
   dependências um pouco atrás do recomendado para o SDK 55 (muitas diferenças de
   *patch*, ex.: `expo` 55.0.17 vs ~55.0.31; `@types/jest` 30 vs 29.5.14;
   `react-native-keyboard-controller` minor). O projeto **compila e roda** com essas
   versões — os builds nº 16 e nº 17 são prova. Subir dependências agora seria
   migração grande, mudaria a árvore congelada e invalidaria o build de validação,
   **sem nenhuma ligação demonstrada com o crash**. Por isso **nada foi alterado**,
   conforme a regra: *não fazer migração grande sem antes confirmar que está ligado
   ao crash*.

---

## REGRAS ATIVAS (valem até o usuário revogar)

1. **Uma versão só, congelada.** `versionName`/`versionCode` não mudam durante a
   investigação. Nada de 1.1.14, 1.1.15, `Lunaria-final`, `Lunaria-fix`…
2. **Um projeto só.** Existe apenas `/home/user/lunaria-src/lunaria-next`. Não
   duplicar, não renomear, não copiar para pasta nova, não descartar o workspace.
3. **Nenhum build sem ordem.** Durante a investigação não se gera APK. Se um build
   falhar, corrige-se no MESMO projeto, na MESMA versão.
4. **Uma etapa por vez**, e `WORK_PROGRESS.md` atualizado depois de cada uma.
5. **Antes de continuar: verificar o estado** (`CURRENT_VERSION`, `app/`, `entrega/`).
6. **Não refazer o que já está feito** — as etapas A–G estão concluídas e com
   evidência apontada acima.
7. **Release final** só depois de `REAL_DEVICE_VALIDATION` deixar de ser
   NOT_TESTED, e mesmo assim será o **mesmo** build de validação.

## COMO RETOMAR (passo a passo do próximo agente)

1. Ler este arquivo até o fim.
2. Ler `STATUS.md` (últimas seções) e `TEST_REPORT.md` (§16.7 a §16.11).
3. Conferir: `grep -n "versionName\|versionCode" android/app/build.gradle`
   (tem de dizer 1.1.13 / 17) e `find app -type f | wc -l` (tem de dizer 28).
4. Executar o teste que trava o defeito do aparelho:
   `npx jest tests/render/rotas-carregam.test.tsx` → tem de dar **29/29**.
5. Continuar do `NEXT_STEP`. **Não** repetir etapas concluídas. **Não** mudar
   versão. **Não** iniciar build.

## RODADA DE 21/09/2026 (terceira do dia) — kudos, resolução e o preset Cinema

CURRENT_GOAL: resolver o HTTP 403 que a tela chamava de "credencial recusada"
quando o provedor estava pedindo **kudos**; adaptar o modo gratuito; e otimizar o
desbloqueio sem afrouxar segurança — sempre na MESMA 1.1.13 (versionCode 17).

LAST_COMPLETED_STEP (21/09/2026, terceira rodada):
  A) 403 de kudos classificado como kudos. Medido contra a API real: 640x640,
     768x768 e 512x512 com 50 passos -> 403 com corpo
     {"message":"Due to heavy demand ... requires 13.68 kudos to fulfil.",
      "rc":"KudosUpfront"}. O classificador do app roda sobre esse corpo real e
     acerta (true / 13.68). O erro saiu do balde "credencial" e ganhou texto,
     dica e BOTOES proprios; e a segunda tentativa com a chave anonima deixou de
     acontecer quando a recusa e por kudos (trocar de chave nao resolvia nada).
  B) Modo gratuito adapta ANTES do envio: 512x768 -> 384x576, 768x512 -> 576x384,
     640x640 -> 512x512, 512x640 -> 512x384, 768x448 -> 576x320; passos com teto de
     30. Tabela MEDIDA (todas 202). Fora da tabela, reduz a maior dimensao ate 576
     e arredonda para baixo em multiplos de 64. Com chave propria, nada muda: o
     tamanho pedido e respeitado (e nao se presume saldo de kudos).
  C) Preset CINEMA: era 768x432 e a Horde recusa com HTTP 400 (432 nao e multiplo
     de 64 — medido). Corrigido para 768x448 (202). Defeito separado, achado na
     medicao: o Cinema nunca funcionou na AI Horde, em modo nenhum.
  D) Desbloqueio: o caminho derivava PBKDF2-SHA256 DUAS vezes (secretIsCorrect +
     unlockVault, 150.000 iteracoes cada). Agora unlockVaultSeCorreto deriva uma vez
     e usa a mesma chave para o verificador e para o envelope. Nada afrouxado
     (mesmo PBKDF2, mesmo sal, mesmas 150.000 iteracoes). Medido aqui: 347 ms -> 666 ms
     era o custo de 1 vs 2 derivacoes. lockNow e o ouvinte do AppState foram medidos
     e NAO tem espera artificial: nao foram tocados.
  PROVAS: unidade 227/227 (era 208), render 184/184 (24 suites, era 174/22),
     tsc limpo, eslint 0 erros, e prova ponta a ponta em rede real (pedido anonimo de
     512x768 saindo como 384x576, imagem de 69.084 bytes em 35 s, aviso na tela).
  MEDICOES CRUAS: lunaria-build/logs/medicao-kudos-2026-09-21.txt,
     medicao-kudos-prova-real-2026-09-21.txt, medicao-bloqueio-2026-09-21.txt.

NOTA DE AMBIENTE: /opt (JDK/SDK) foi apagado de novo entre as sessoes — e fora do
workspace, nao persiste. Reinstalado com setup-toolchain.sh (TOOLCHAIN_OK, 46 s) e
node_modules restaurado com npm ci a partir do lockfile do proprio projeto.

CURRENT_STEP / BUILD_STATUS (rodada de 21/09/2026, terceira do dia):
  BUILD_STATUS: CONCLUIDO — APK novo gerado no MESMO 1.1.13/versionCode 17.
    - assembleRelease: BUILD SUCCESSFUL em 28m29s (952 tarefas; sem R8 nesta
      configuracao de teste, para o ciclo caber na sessao).
    - sha256 c51f867201051c80c60a10c82593c7a6bccfe2a2c2f954d18bbc3932ee68b241 · 66.868.595 bytes
    - bundle Hermes 6.692.252 bytes (entrega anterior: 6.683.492 = +8.760).
    - mesmo certificado da entrega anterior (c0271509…): instala por cima.
    - prova de que o codigo novo esta DENTRO do bundle: literais que NAO existiam no
      APK anterior e agora existem — "Esta configuração exige kudos no AI Horde.",
      "Modo gratuito: resolução ajustada", "Credencial inválida.", "Usar configuração
      gratuita", "768x448", "KudosUpfront", "heavy demand", "work budget".
  FILES_CHANGED: ver secao 8 do RELATORIO_RODADA_21-09_KUDOS_E_RESOLUCAO.md.
  REAL_DEVICE_VALIDATION: NOT_TESTED_i — itens 35 a 40 do CHECKLIST_APARELHO.md
    dependem do aparelho (38 = resolucao ajustada, 39 = erro de kudos, 40 = tempo do
    desbloqueio).
  NEXT_STEP: testar no A05s, comecando pelo item 39 (o defeito que voce relatou), e
    responder os itens do checklist marcando o que passou e o que nao passou.

## RODADA DE 21/09/2026 (quarta do dia) — splash infinita no retorno

CURRENT_GOAL: com a senha ativa, sair da Lunaria (bloqueio automático) e voltar
prendia o aplicativo para sempre na tela do logo. Fazer a splash sair quando a
hidratação termina — bloqueado ou não — e nunca depender de o usuário digitar a senha.
Mesma 1.1.13, versionCode 17.

LAST_COMPLETED_STEP (21/09/2026, quarta rodada):
  A) CAUSA: quem escondia a splash era a `HomeScreen` (hideAsync no fim de
     `startLunaria`), e ela só existe DENTRO do `<Stack>` — que o portão não monta
     enquanto `locked`. Caminho: APPSTATE_ACTIVE -> hidratação -> locked=true ->
     LockScreen na frente e Stack não montado -> HomeScreen nunca monta ->
     hideAsync nunca é chamado -> splash infinita. A tela de senha estava montada,
     atrás da splash.
  B) CORREÇÃO (`app/_layout.tsx`): `esconderSplash(motivo)` chamado no fim da
     hidratação e em cada volta ao primeiro plano (AppState ACTIVE). Sem flag de
     módulo (estado invisível foi o que criou o defeito anterior): `hideAsync` é
     chamado sempre que a decisão é tomada e é no-op depois de escondida. Expo Router
     lido por um invólucro que não derruba o portão se o hook faltar; `hideAsync`
     com `Promise.resolve` + try/catch.
  C) ESTADO QUE NÃO TERMINAVA: `ready` podia ficar falso para sempre se `init()`
     estourasse. `AppLock.markHydrationFailed` fecha a hidratação em falha
     (ready=true, locked=true) — fail-closed é aparecer bloqueado, não desaparecer.
  D) INSTRUMENTAÇÃO na trilha: SPLASH_VISIBLE, AUTH_HYDRATION_STARTED,
     AUTH_HYDRATION_COMPLETE, LOCK_STATE, SPLASH_HIDE_REQUESTED, SPLASH_HIDDEN,
     UNLOCK_SCREEN_REQUESTED, UNLOCK_SCREEN_MOUNTED, APPSTATE_BACKGROUND,
     APPSTATE_ACTIVE, AUTO_LOCK_POLICY_APPLIED, ROUTER_READY (+ UNLOCK_SUCCESS/
     UNLOCK_FAILED, que já existiam).
  E) PROVAS: `tests/render/splash-retorno.test.tsx` (novo, 6) com o portão REAL e o
     estado REAL; unidade 227/227; render 190/190 (25 suítes); tsc limpo; eslint 0
     erros; e geração REAL pela rede (82.636 bytes, 40 s, seed texto, aviso de
     resolução) para confirmar que o gerador não foi afetado.
  F) O que NÃO foi feito: nada de splash removida, bloqueio afrouxado, criptografia
     mexida, desbloqueio automático, cronômetro decidindo estado ou try/catch vazio.
     versionName/versionCode intactos.

BUILD_STATUS (rodada da splash, 21/09/2026 — quarta do dia): CONCLUIDO
  - assembleRelease: BUILD SUCCESSFUL em 26m11s (952 tarefas; sem R8 nesta
    configuracao de teste, como nas rodadas anteriores).
  - sha256 bf2087bb57b9a43a01103c72ef3cf18bb9434a5eaf2b7bb2bf321b1cf9008fa1 · 66.870.991 bytes · mesmo certificado (c0271509…) -> instala por cima.
  - versao intacta: 1.1.13 / versionCode 17 (sem 1.1.14, sem trocar versionName).
  - prova de que o codigo novo esta DENTRO do bundle: marcas que nao existiam no APK
    anterior e agora existem (SPLASH_HIDE_REQUESTED, AUTH_HYDRATION_STARTED,
    AUTH_HYDRATION_COMPLETE, AUTH_HYDRATION_LENTA, UNLOCK_SCREEN_MOUNTED,
    APPSTATE_ACTIVE, ROUTER_READY, ROUTER_READY indisponível).
  - REAL_DEVICE_VALIDATION: NOT_TESTED — itens 41 a 48 do CHECKLIST_APARELHO.md
    (o defeito relatado: sair/voltar bloqueado, senha errada e certa, bloquear agora,
    sair e voltar rapido, gerador depois de desbloquear, biometria).
  - NEXT_STEP: testar no A05s comecando pelo item 41 (sair, voltar, a splash sai e a
    tela de senha aparece) e responder os itens marcando o que passou e o que nao passou.

