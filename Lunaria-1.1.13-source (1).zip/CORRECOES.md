# Lunaria — correções encontradas testando o provedor de verdade (1.1.1 e 1.1.2 · 18/09/2026)

> **Atualização de 20/09/2026 (1.1.13)**: esta é a rodada que encontrou a causa do
> fechamento na abertura — um **ciclo de importação** entre o bloqueio, a leitura em
> voz alta e o estado da conversa
> (`AppLock → TTS → Chat → AppLock`). Ele fazia o Metro devolver `undefined` no lugar
> do módulo da rota raiz, e o Expo Router fechava o aplicativo com
> `Cannot read property 'ErrorBoundary' of undefined`. O relato completo, com as
> quatro perguntas obrigatórias respondidas e as provas, está em `BUGS_FOUND.md`
> (§BG) e no `STATUS.md` (rodada 1.1.13). Nesta rodada o `app/` também passou a conter
> **somente rotas** (28 arquivos, 27 rotas — antes 118 arquivos, 117 rotas com
> componentes no meio); o código foi para `src/`.

> **Documento de rodada antiga** (1.1.1 a 1.1.3), mantido como histórico.
> O estado atual está em `STATUS.md`; os testes, em `TEST_REPORT.md` (seção 11).

Este documento cobre as duas rodadas de correção do dia. Nenhuma delas trouxe
função nova: o que elas fizeram foi consertar **quatro defeitos reais** da geração
de imagem, todos descobertos porque a geração foi executada de ponta a ponta
contra o serviço real — em vez de só com rede simulada nos testes.

Resumo para quem tem pressa:

| # | Versão | Defeito | Efeito no aparelho | Estado |
| --- | --- | --- | --- | --- |
| 1 | 1.1.1 | Consulta de status com **429** derrubava a geração | Com fila grande (o caso comum), a imagem nunca chegava e a mensagem dizia "cota esgotada" — mentira | **Corrigido e testado** |
| 2 | 1.1.1 | Resultado em **endereço https** (e não base64) não era lido | Imagem gerada e paga em fila, e o app mostrava "base64 inválido" | **Corrigido e testado** |
| 3 | 1.1.1 | Pollinations devolvia **imagem de cache sem relação** com a descrição | Descrição em português totalmente ignorada | **Mitigado** (semente própria sempre enviada) + limite documentado na tela |
| 4 | 1.1.2 | Fechava ao abrir no aparelho (relato do Hamura, 18/09) | O aplicativo não abria — e não dizia por quê, porque em versão de produção não existe caixa vermelha | **Tratado na 1.1.3** — instrumentação + isolamento das camadas novas; causa raiz ainda **não confirmada** (§AF) |
| 5 | 1.1.2 | **Cancelar** parava a espera no app, mas não avisava o provedor | O trabalho continuava na fila e era gerado por um voluntário — imagem perdida e prioridade (kudos) de quem cancelou gasta à toa | **Corrigido e testado** |

A 1.1.3 acrescenta a camada de diagnóstico (migalhas de percurso, modo seguro,
relatório copiável, erro nativo em arquivo) — 11 testes de lógica e 5 de
renderização novos, descritos no `TEST_REPORT.md` §2.6. Este APK sai **sem R8**
(ver o motivo no `android/gradle.properties`): é build de diagnóstico, com a
mesma assinatura e a mesma versão, feito para o aplicativo falar em vez de fechar
calado.

Testes das duas rodadas: **104 de 104** na suíte de lógica (eram 87 na 1.1.1 —
**17 novos**) e **50 de 50** na suíte de renderização (eram 49 na 1.1.1 — **1
novo**). `tsc` sem erros, `eslint` sem erros.

Além disso, `tools/verificar_preservacao.py` abre o APK entregue e confirma
**12 de 12** recursos anteriores dentro do pacote (bundle e bibliotecas nativas).

---

## 1. O travamento por limite de consultas (429)

**Como apareceu.** Rodando uma geração real pela linha de comando: o pedido foi
aceito (HTTP 202, kudos 7,0, fila com **262 pedidos**, espera estimada em ~970 s)
e a consulta de status começou a responder **429 (Too Many Requests)**. A chave
anônima da AI Horde limita consultas repetidas — o 429 acontece mesmo com tudo
certo.

**Por que quebrava.** O laço de consulta fazia `if (!response.ok) throw`. Um 429
no meio da fila derrubava a geração inteira e mostrava "cota esgotada" para quem
não tinha cota nenhuma esgotada. E fila de 200+ pedidos é o caso **comum** com a
chave anônima, não a exceção.

**Correção.** 429 e 5xx na consulta passaram a ser passageiros: o app espera e
volta a consultar. Erros definitivos continuam abortando na hora.

| Situação | Antes | Agora |
| --- | --- | --- |
| 429 na consulta | abortava a geração, dizia "cota esgotada" | espera e continua (5 s → 10 s → 20 s, teto 30 s) |
| `Retry-After` do provedor | ignorado | respeitado (limitado a 30 s) |
| 5xx na consulta | abortava | espera e continua |
| 401 / 403 / 404 / 400 | abortava | aborta (correto) |
| intervalo entre consultas | 3 s | 5 s (menos chance de bater no limite) |
| cancelar durante a espera | — | funciona |

## 2. O resultado que vem como endereço, não como base64

**Como apareceu.** Na geração seguinte, a imagem ficou pronta — e o app respondeu
**"base64 inválido: tamanho não múltiplo de 4"**. Sondando a resposta real: o
campo `img` trazia
`https://a223539ccf6caa2d…r2.cloudflarestorage.com/…?X-Amz-Expires=3600`. Quando
o worker publica a imagem no armazenamento R2, a Horde devolve **endereço**, não
bytes. O app assumia base64 sempre.

**Correção.** Os dois formatos passaram a ser aceitos: endereço é baixado
(com verificação dos bytes recebidos, não da promessa do servidor), base64 é
decodificado. Falhas de leitura agora viram mensagem em português em vez de erro
técnico cru. Se o download falhar, a mensagem diz exatamente isso: a imagem foi
gerada, o download falhou, tente de novo.

## 3. Pollinations: a imagem de cache e o idioma

**Como apareceu.** A descrição pedia uma jovem de vestido vitoriano; a imagem
veio **sem nenhuma relação** — e reproduzível: mesmos 37.167 bytes em duas
execuções. Investigando com o próprio serviço:

- a Pollinations usa **semente 42** quando o pedido não traz semente;
- com semente própria, o mesmo pedido voltou **correto**;
- em inglês, o resultado saiu **fiel** (retrato gótico, cabelo preto, luz de
  vela); em português, saiu aleatório em todas as tentativas — é limitação do
  modelo, não filtro nem defeito do app.

**Correção e limite honesto.** O app passou a **sempre enviar semente** (sorteada
quando o usuário não escolhe, devolvida no resultado para poder repetir a mesma
imagem). Isso elimina a imagem de cache. O que **não** dá para corrigir no app é
a compreensão do idioma: por isso a tela de ajustes de imagem agora avisa, em
texto, que este provedor entende melhor inglês e que, para descrições em
português, a AI Horde se saiu melhor nos testes.

**Prova real (dois provedores, código do próprio app):**

| Provedor | Descrição | Resultado | Tempo | Arquivo |
| --- | --- | --- | --- | --- |
| AI Horde | retrato de uma jovem adulta lendo um livro antigo (pt-BR) | WebP **512×768**, 91.666 bytes | 18 s (fila real) | `exemplo_horde.webp` |
| Pollinations | retrato de uma jovem adulta de vestido vitoriano (pt-BR) | JPEG **512×768**, 38.095 bytes | 4 s | `exemplo_pollinations.jpg` |

Os dois arquivos estão nesta pasta: são imagens de verdade, geradas hoje, para
você ver a qualidade com os seus próprios olhos. São exemplos de teste — o
aplicativo não os inclui.

---

## O que mudou nos arquivos

- `lib/imagegen/ImageProviders.ts` — espera com teto para 429/5xx, leitura do
  resultado em endereço **ou** base64, semente sempre enviada na Pollinations,
  aviso de idioma no perfil do provedor, identificador do cliente atualizado para
  1.1.1.
- `app/screens/ImageSettingsScreen.tsx` — mostra o aviso de idioma medido.
- `tests/imageprovider.test.mjs` — 24 testes (11 novos) cobrindo 429 repetido,
  teto da espera, `Retry-After`, 5xx, 401, 404, resultado em endereço, endereço
  que responde erro, endereço que devolve lixo, base64 inválido, semente sempre
  presente e sementes distintas por geração.
- `tests/render/screens.test.tsx` — prova que o aviso de idioma aparece na tela.
- `eslint.config.js` — `import/first` e `import/order` desligados em `tests/**`
  (a formatação automática chegou a quebrar a suíte; registro em
  `BUGS_FOUND.md`, seção V).
- `BUILDING.md` / `build-apk-2.sh` — tetos de memória ajustados: o kernel matou o
  processo do Gradle por falta de memória com `-Xmx2560m` (registro em
  `BUGS_FOUND.md`, seção W).
- `CHANGELOG.md` — entrada da 1.1.1.

## O APK entregue foi verificado depois de pronto

Não basta o pacote ter sido assinado no momento da compilação: o arquivo que você
vai instalar foi conferido **de novo, depois de pronto**, das duas formas:

1. **Com o `apksigner`** (enquanto o SDK estava instalado): `Verifies`, esquema
   v2, certificado `c0271509…5719a` — o mesmo da 1.0.0.
2. **Sem SDK nenhum**, com a ferramenta que vai dentro do próprio ZIP
   (`tools/verificar_assinatura.py`) e o `openssl` que qualquer computador tem:
   certificado e sua impressão digital, chave do bloco igual à do certificado, e
   a assinatura RSA conferida sobre os dados assinados → **Verified OK**.

O único ponto que a ferramenta offline não cobre é conferir que o conteúdo do
pacote corresponde ao resumo assinado (árvore de Merkle) — isso foi feito pelo
`apksigner`, e a ferramenta diz isso na própria saída, em vez de dar como certo.

Transparência sobre a compilação: a versão 1.1.2 levou **três horas** para ser
compilada a frio nesta máquina (2 núcleos, 2 GB de memória) e falhou uma vez no
fim por falta de memória do processo Java. Corrigi o limite, retomei a compilação
aproveitando a parte já feita — e ela terminou em **1 minuto e 6 segundos**. Em
nenhum momento apaguei o resultado parcial, que é justamente o que permitiu
retomar. Detalhe técnico em `BUGS_FOUND.md`, seção Z.

## O que continua **não** verificado

Nada aqui foi marcado como aprovado sem ter sido executado. Continua **pendente
de aparelho** (o ambiente desta máquina não tem emulador):

- gerar imagem **pelo botão dentro do aplicativo** (o caminho do provedor foi
  exercitado por linha de comando, com o mesmo código);
- cancelar uma geração em andamento pelo botão Cancelar;
- conferir o aviso de idioma na tela de ajustes no aparelho;
- todo o checklist de bloqueio (senha, biometria, retorno do segundo plano,
  notificação, migração), que segue em `CHECKLIST_APARELHO.md`.

A lista completa, com o que já tem prova automática e o que depende de você, está
em `RELATORIO_DE_TESTES.md` e em `MATRIZ_DE_CRITERIOS.md`.
