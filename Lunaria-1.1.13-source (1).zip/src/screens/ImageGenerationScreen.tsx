/**
 * Tela "Gerar imagem".
 *
 * Ordem que a tela impõe, de propósito:
 *   descrição → estilo e proporção → **descrição final visível** → gerar.
 * Nada sai do aparelho sem o usuário ver exatamente o texto que será enviado.
 *
 * Estados cobertos: preparando, na fila (com posição), gerando (com tempo),
 * concluído, cancelado e erro — com cancelar, editar e tentar de novo.
 */

import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import React, { useEffect, useMemo, useState } from 'react'
import { ScrollView, StyleSheet, Text, View } from 'react-native'

import ThemedButton from '@components/buttons/ThemedButton'
import HorizontalSelector from '@components/input/HorizontalSelector'
import ThemedSwitch from '@components/input/ThemedSwitch'
import ThemedTextInput from '@components/input/ThemedTextInput'
import SectionTitle from '@components/text/SectionTitle'
import PrivateImage from '@components/views/PrivateImage'
import { rotuloDoModoPara } from '@lib/imagegen/ChaveDoProvedor'
import { PROVIDER_LABEL } from '@lib/imagegen/ImageProviders'
import {
    ASPECT_RATIOS,
    ASPECT_RATIO_LIST,
    CONSISTENCY_NOTE,
    IMAGE_STYLE_LIST,
    POLICY_NOTE,
} from '@lib/imagegen/ImageStyles'
import { resumoDoModoGratuito } from '@lib/imagegen/LimitesDaHorde'
import { detectImageType, toPrivateUri } from '@lib/security/PrivateNames'
import { useChatInputTextStore } from '@lib/state/components/ChatInput'
import { useImageViewer } from '@lib/state/components/ImageViewer'
import { useImageGeneration } from '@lib/state/ImageGeneration'
import { Theme } from '@lib/theme/ThemeManager'

const ImageGenerationScreen: React.FC = () => {
    const router = useRouter()
    const styles = useStyles()

    const prefs = useImageGeneration((state) => state.prefs)
    const profile = useImageGeneration((state) => state.profile)
    const busy = useImageGeneration((state) => state.busy)
    const progress = useImageGeneration((state) => state.progress)
    const error = useImageGeneration((state) => state.error)
    const aviso = useImageGeneration((state) => state.aviso)
    const avisoTipo = useImageGeneration((state) => state.avisoTipo)
    const usarModoGratuito = useImageGeneration((state) => state.usarModoGratuito)
    const usarConfiguracaoGratuita = useImageGeneration((state) => state.usarConfiguracaoGratuita)
    const result = useImageGeneration((state) => state.result)
    const preview = useImageGeneration((state) => state.preview)
    const start = useImageGeneration((state) => state.start)
    const cancel = useImageGeneration((state) => state.cancel)
    const retry = useImageGeneration((state) => state.retry)
    const discard = useImageGeneration((state) => state.discard)
    const setStyle = useImageGeneration((state) => state.setStyle)
    const setAspectRatio = useImageGeneration((state) => state.setAspectRatio)
    const saveImageToGallery = useImageGeneration((state) => state.saveImageToGallery)
    const shareImage = useImageGeneration((state) => state.shareImage)
    const deleteImage = useImageGeneration((state) => state.deleteImage)
    const init = useImageGeneration((state) => state.init)

    const attach = useChatInputTextStore((state) => state.attach)
    const openViewer = useImageViewer((state) => state.openUri)

    const [description, setDescription] = useState('')
    const [includeCharacter, setIncludeCharacter] = useState(false)

    useEffect(() => {
        init()
    }, [init])

    // A prévia é recalculada enquanto o usuário escreve: é o que ele vai enviar.
    const draft = useMemo(
        () => preview({ description, includeCharacter }),
        [preview, description, includeCharacter, prefs.styleId, prefs.aspectRatioId, profile]
    )

    const refused = !draft.verdict.allowed

    const handleAttach = () => {
        if (!result) return
        attach({
            uri: toPrivateUri(result.fileName),
            type: 'image',
            name: `lunaria-${result.id}.${detectImageType(new Uint8Array()).extension === 'bin' ? 'webp' : 'webp'}`,
        })
        discard()
        router.back()
    }

    return (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.container}>
            <SectionTitle>Gerar imagem</SectionTitle>

            {/* Modo de credencial escrito na tela: com chave ou gratuito. Sem isto o
                usuário não tinha como saber que uma chave estava ativa — foi o que
                tornou o erro de credencial de 21/09/2026 tão confuso. */}
            <Text style={styles.hint}>
                {PROVIDER_LABEL[prefs.provider]} · modo{' '}
                {rotuloDoModoPara(prefs.provider, prefs.apiKey)}
            </Text>

            <ThemedTextInput
                label="Descrição"
                description="Escreva o que você quer ver. A Lunaria acrescenta o estilo escolhido e a âncora de idade adulta."
                value={description}
                onChangeText={setDescription}
                multiline
                numberOfLines={4}
                containerStyle={{ minHeight: 104 }}
            />

            <ThemedSwitch
                label="Incluir a aparência da Lunaria"
                description="Usa o perfil visual editável (cabelo, olhos, roupas, acessórios). Ajuda no estilo geral, mas não garante o mesmo rosto entre imagens."
                value={includeCharacter}
                onChangeValue={setIncludeCharacter}
            />

            <HorizontalSelector
                label="Estilo"
                values={IMAGE_STYLE_LIST.map((style) => ({ label: style.label, value: style.id }))}
                selected={prefs.styleId}
                onPress={setStyle}
            />
            <Text style={styles.hint}>
                {IMAGE_STYLE_LIST.find((style) => style.id === prefs.styleId)?.description}
            </Text>

            <HorizontalSelector
                label="Proporção"
                values={ASPECT_RATIO_LIST.map((ratio) => ({
                    label: `${ratio.label} ${ratio.width}×${ratio.height}`,
                    value: ratio.id,
                }))}
                selected={prefs.aspectRatioId}
                onPress={setAspectRatio}
            />
            <Text style={styles.hint}>
                {resumoDoModoGratuito(ASPECT_RATIOS[prefs.aspectRatioId])}
            </Text>

            <SectionTitle>Descrição final (antes de enviar)</SectionTitle>
            <View style={styles.previewBox}>
                <Text style={styles.previewText} selectable>
                    {draft.preview}
                </Text>
            </View>
            <Text style={styles.hint}>
                Provedor: {PROVIDER_LABEL[prefs.provider]} · Estilo {prefs.styleId} · {draft.width}×
                {draft.height}
            </Text>

            {refused && (
                <View style={styles.errorBox}>
                    <Text style={styles.errorTitle}>Pedido recusado pela política da Lunaria</Text>
                    <Text style={styles.errorText}>{draft.verdict.reason}</Text>
                    <Text style={styles.errorText}>
                        Termo identificado: “{draft.verdict.match}”. Ajuste a descrição e a prévia
                        atualiza sozinha.
                    </Text>
                </View>
            )}

            <View style={styles.actions}>
                {!busy ? (
                    <ThemedButton
                        label={result ? 'Gerar outra' : 'Gerar imagem'}
                        iconName="picture"
                        variant={refused ? 'disabled' : 'primary'}
                        onPress={() => start({ description, includeCharacter })}
                        opacity={refused ? 0.5 : 1}
                    />
                ) : (
                    <ThemedButton label="Cancelar geração" variant="critical" onPress={cancel} />
                )}
            </View>

            {busy && progress && (
                <View style={styles.progressBox}>
                    <Text style={styles.progressTitle}>{progress.message}</Text>
                    <Text style={styles.progressText}>
                        {progress.queuePosition !== undefined && progress.queuePosition > 0
                            ? `Posição na fila: ${progress.queuePosition}`
                            : 'Na fila comunitária — a espera depende de quantas pessoas estão gerando agora.'}
                    </Text>
                    {progress.elapsedSeconds !== undefined && (
                        <Text style={styles.progressText}>
                            Tempo decorrido: {progress.elapsedSeconds}s
                        </Text>
                    )}
                    <Text style={styles.progressText}>
                        Você pode sair desta tela; a geração continua e o resultado aparece no
                        histórico.
                    </Text>
                </View>
            )}

            {aviso && (
                <View style={styles.errorBox}>
                    <Text style={styles.errorTitle}>
                        {avisoTipo === 'resolucao'
                            ? 'Resolução ajustada no modo gratuito'
                            : 'A imagem saiu pelo modo gratuito'}
                    </Text>
                    <Text style={styles.errorText}>{aviso}</Text>
                    <View style={styles.actions}>
                        <ThemedButton
                            label="Usar modo gratuito"
                            variant="secondary"
                            buttonStyle={{ flex: 1 }}
                            onPress={usarModoGratuito}
                        />
                        <ThemedButton
                            label="Ajustes de imagem"
                            variant="tertiary"
                            buttonStyle={{ flex: 1 }}
                            onPress={() => router.push('/screens/ImageSettingsScreen')}
                        />
                    </View>
                </View>
            )}

            {error && (
                <View style={styles.errorBox}>
                    <Text style={styles.errorTitle}>
                        <Ionicons name="alert-circle-outline" size={14} /> {error.message}
                    </Text>
                    <Text style={styles.errorText}>{error.hint}</Text>
                    {/*
                        Erro de kudos e erro de credencial são diferentes, e a saída
                        de cada um também: kudos se resolve com uma configuração mais
                        leve, credencial com outra chave. Antes os dois caíam na
                        mesma caixa e o usuário ia mexer na chave por causa de um
                        pedido grande demais (relato de 21/09/2026).
                    */}
                    {error.kind === 'kudos' ? (
                        <>
                            <View style={styles.actions}>
                                <ThemedButton
                                    label="Usar configuração gratuita"
                                    variant="secondary"
                                    onPress={() => void usarConfiguracaoGratuita()}
                                    buttonStyle={{ flex: 1 }}
                                />
                                <ThemedButton
                                    label="Tentar novamente"
                                    iconName="reload"
                                    variant="tertiary"
                                    onPress={() => void retry()}
                                    buttonStyle={{ flex: 1 }}
                                />
                            </View>
                            <View style={styles.actions}>
                                <ThemedButton
                                    label="Editar descrição"
                                    variant="tertiary"
                                    buttonStyle={{ flex: 1 }}
                                    onPress={discard}
                                />
                                <ThemedButton
                                    label="Ajustes de imagem"
                                    variant="tertiary"
                                    buttonStyle={{ flex: 1 }}
                                    onPress={() => router.push('/screens/ImageSettingsScreen')}
                                />
                            </View>
                        </>
                    ) : (
                        <View style={styles.actions}>
                            <ThemedButton
                                label="Tentar de novo"
                                iconName="reload"
                                variant="secondary"
                                onPress={() => retry()}
                                buttonStyle={{ flex: 1 }}
                            />
                            <ThemedButton
                                label="Editar descrição"
                                variant="tertiary"
                                buttonStyle={{ flex: 1 }}
                                onPress={discard}
                            />
                        </View>
                    )}
                </View>
            )}

            {result && (
                <>
                    <SectionTitle>Resultado</SectionTitle>
                    <PrivateImage
                        uri={toPrivateUri(result.fileName)}
                        style={styles.result}
                        resizeMode="contain"
                    />
                    <Text style={styles.hint}>
                        {result.width}×{result.height} · {Math.round(result.bytes / 1024)} KB ·{' '}
                        {result.seconds}s · guardada cifrada no cofre da Lunaria
                    </Text>
                    <View style={styles.actions}>
                        <ThemedButton
                            label="Ver"
                            iconName="eye"
                            variant="secondary"
                            buttonStyle={{ flex: 1 }}
                            onPress={() => openViewer(toPrivateUri(result.fileName))}
                        />
                        <ThemedButton
                            label="Anexar à conversa"
                            iconName="link"
                            variant="primary"
                            buttonStyle={{ flex: 1 }}
                            onPress={handleAttach}
                        />
                    </View>
                    <View style={styles.actions}>
                        <ThemedButton
                            label="Salvar na galeria"
                            iconName="download"
                            variant="secondary"
                            buttonStyle={{ flex: 1 }}
                            onPress={() => saveImageToGallery(result)}
                        />
                        <ThemedButton
                            label="Compartilhar"
                            iconName="share-alt"
                            variant="secondary"
                            buttonStyle={{ flex: 1 }}
                            onPress={() => shareImage(result)}
                        />
                        <ThemedButton
                            label="Apagar"
                            iconName="delete"
                            variant="critical"
                            buttonStyle={{ flex: 1 }}
                            onPress={() => deleteImage(result)}
                        />
                    </View>
                </>
            )}

            <SectionTitle>Ajustes</SectionTitle>
            <View style={styles.actions}>
                <ThemedButton
                    label="Provedor, estilos e aparência"
                    variant="tertiary"
                    buttonStyle={{ flex: 1 }}
                    onPress={() => router.push('/screens/ImageSettingsScreen')}
                />
            </View>

            <Text style={styles.note}>{POLICY_NOTE}</Text>
            <Text style={styles.note}>{CONSISTENCY_NOTE}</Text>
        </ScrollView>
    )
}

export default ImageGenerationScreen

const useStyles = () => {
    const { color, spacing, fontSize, borderRadius } = Theme.useTheme()

    return StyleSheet.create({
        container: {
            padding: spacing.xl,
            rowGap: spacing.m,
            paddingBottom: spacing.xl3,
        },
        previewBox: {
            backgroundColor: color.neutral._200,
            borderRadius: borderRadius.m,
            padding: spacing.l,
        },
        previewText: {
            color: color.text._100,
            fontSize: fontSize.s,
            lineHeight: 19,
        },
        hint: {
            color: color.text._300,
            fontSize: fontSize.s,
            lineHeight: 18,
        },
        note: {
            color: color.text._400,
            fontSize: fontSize.s,
            lineHeight: 18,
        },
        actions: {
            flexDirection: 'row',
            columnGap: spacing.s,
            marginTop: spacing.s,
        },
        progressBox: {
            backgroundColor: color.neutral._200,
            borderRadius: borderRadius.m,
            padding: spacing.l,
            rowGap: 4,
        },
        progressTitle: {
            color: color.text._100,
            fontSize: fontSize.l,
        },
        progressText: {
            color: color.text._300,
            fontSize: fontSize.s,
        },
        errorBox: {
            backgroundColor: color.neutral._300,
            borderRadius: borderRadius.m,
            padding: spacing.l,
            rowGap: 6,
        },
        errorTitle: {
            color: color.text._100,
            fontSize: fontSize.l,
        },
        errorText: {
            color: color.text._200,
            fontSize: fontSize.s,
            lineHeight: 18,
        },
        result: {
            width: '100%',
            aspectRatio: 1,
            borderRadius: borderRadius.m,
        },
    })
}
