// Tela inicial do aplicativo (a rota `/`). Ela mora aqui, e não em `app/`,
// para o Expo Router descobrir apenas rotas — ver LEIA-ME.md.
import { AntDesign } from '@expo/vector-icons'
import { useMigrations } from 'drizzle-orm/expo-sqlite/migrator'
import { SplashScreen } from 'expo-router'
import { useCallback, useEffect, useRef, useState } from 'react'
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'

import ThemedButton from '@components/buttons/ThemedButton'
import DiagnosticReport from '@components/views/DiagnosticReport'
import HeaderTitle from '@components/views/HeaderTitle'
import { db } from '@db'
import useLocalAuth from '@lib/hooks/LocalAuth'
import { Theme } from '@lib/theme/ThemeManager'
import { markStartupOk } from '@lib/utils/Diagnostics'
import { marcarEtapaJs } from '@lib/utils/TrilhaJs'
import { loadChatOnInit, startupApp, useTextIntentFocus } from '@lib/utils/Startup'
import CharacterList from '@screens/CharacterListScreen'

import migrations from '../../db/migrations/migrations'

const Home = () => {
    const { color } = Theme.useTheme()
    const styles = useStyles()
    const { success, error } = useMigrations(db, migrations)
    const { authorized, retry } = useLocalAuth()

    const [firstRender, setFirstRender] = useState<boolean>(true)
    const [startupFailure, setStartupFailure] = useState('')
    const startupInFlight = useRef(false)

    useTextIntentFocus()

    useEffect(() => {
        if (authorized && success && !firstRender && !startupFailure) {
            loadChatOnInit()
        }
    }, [authorized, success, firstRender, startupFailure])

    const startLunaria = useCallback(async () => {
        if (startupInFlight.current) return
        startupInFlight.current = true
        setFirstRender(true)
        setStartupFailure('')
        try {
            await startupApp()
            marcarEtapaJs('7/8 Lunaria iniciada')
            // Só aqui a abertura conta como concluída: se o aplicativo morrer
            // antes disto, a próxima vez sabe que a anterior não terminou.
            markStartupOk()
        } catch (startupError) {
            const detail = startupError instanceof Error ? startupError.message : `${startupError}`
            console.error('Falha ao iniciar a Lunaria:', startupError)
            marcarEtapaJs(`! falha ao iniciar a Lunaria: ${detail.slice(0, 120)}`)
            setStartupFailure(detail)
        } finally {
            startupInFlight.current = false
            setFirstRender(false)
            await SplashScreen.hideAsync()
        }
    }, [])

    useEffect(() => {
        if (success) {
            marcarEtapaJs('6/8 banco migrado')
            void startLunaria()
        }
        if (error) void SplashScreen.hideAsync()
    }, [success, error, startLunaria])

    // Última etapa: a lista de conversas está de fato na tela. É o que separa
    // "o aplicativo montou" de "o Hamura está vendo as conversas".
    const listaNaTela = !firstRender && success && !startupFailure && authorized
    useEffect(() => {
        if (listaNaTela) marcarEtapaJs('8/8 lista de conversas na tela')
    }, [listaNaTela])

    if (error)
        return (
            <DiagnosticReport
                title="Falha ao preparar o banco de dados"
                detail={error.message}
                onRetry={() => void startLunaria()}
            />
        )

    if (startupFailure)
        return (
            <DiagnosticReport
                title="A Lunaria não conseguiu iniciar"
                detail={startupFailure}
                onRetry={() => void startLunaria()}
            />
        )

    if (!authorized)
        return (
            <View style={[styles.centeredContainer, { rowGap: 60 }]}>
                <HeaderTitle />
                <AntDesign
                    name="lock"
                    size={120}
                    style={{ marginBottom: 12 }}
                    color={color.text._500}
                />
                <Text style={styles.title}>Autenticação necessária</Text>
                <TouchableOpacity onPress={retry} style={styles.button}>
                    <Text style={styles.buttonText}>Tentar novamente</Text>
                </TouchableOpacity>
            </View>
        )
    if (!firstRender && success) return <CharacterList />
    return <HeaderTitle />
}

export default Home

const useStyles = () => {
    const { color, spacing, fontSize, borderWidth } = Theme.useTheme()
    return StyleSheet.create({
        centeredContainer: {
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
        },

        title: {
            color: color.text._300,
            fontSize: fontSize.xl2,
        },

        subtitle: {
            color: color.text._400,
            marginHorizontal: 24,
            textAlign: 'center',
        },

        errorLog: {
            color: color.text._400,
            fontSize: fontSize.s,
            paddingHorizontal: spacing.xl,
            paddingVertical: spacing.l,
            borderRadius: 12,
            margin: spacing.xl2,
            backgroundColor: 'black',
        },

        buttonText: {
            color: color.text._100,
        },

        button: {
            paddingVertical: spacing.l,
            paddingHorizontal: spacing.xl2,
            columnGap: spacing.m,
            borderRadius: spacing.xl2,
            borderWidth: borderWidth.m,
            borderColor: color.primary._500,
        },
    })
}
