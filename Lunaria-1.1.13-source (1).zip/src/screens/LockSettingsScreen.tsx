/**
 * Configurações de bloqueio.
 *
 * Duas regras atravessam esta tela: (1) nenhuma ação sensível acontece sem a
 * senha atual — trocar, ligar biometria ou desligar a proteção; (2) o usuário vê
 * as consequências **antes** de confirmar, inclusive no reinício do cofre.
 */

import { Ionicons } from '@expo/vector-icons'
import React, { useEffect, useState } from 'react'
import { ScrollView, StyleSheet, Text, View } from 'react-native'

import ThemedButton from '@components/buttons/ThemedButton'
import HorizontalSelector from '@components/input/HorizontalSelector'
import ThemedSwitch from '@components/input/ThemedSwitch'
import ThemedTextInput from '@components/input/ThemedTextInput'
import SectionTitle from '@components/text/SectionTitle'
import Alert from '@components/views/Alert'
import {
    AUTO_LOCK_OPTIONS,
    describeAutoLock,
    DISABLE_WARNING,
    FORGOT_SECRET_EXPLANATION,
    validarAtivacao,
    validateSecret,
} from '@lib/security/LockPolicy'
import { migrateExistingImages, MigrationOutcome } from '@lib/security/Migration'
import { useAppLock } from '@lib/state/AppLock'
import { Theme } from '@lib/theme/ThemeManager'
import { recordError } from '@lib/utils/Diagnostics'

const LockSettingsScreen: React.FC = () => {
    const styles = useStyles()

    const settings = useAppLock((state) => state.settings)
    const configured = useAppLock((state) => state.configured)
    const locked = useAppLock((state) => state.locked)
    const lastReason = useAppLock((state) => state.lastReason)
    const failures = useAppLock((state) => state.failures)
    const enableLock = useAppLock((state) => state.enableLock)
    const changeSecret = useAppLock((state) => state.changeSecret)
    const disableLock = useAppLock((state) => state.disableLock)
    const setAutoLock = useAppLock((state) => state.setAutoLock)
    const setBlockScreenshots = useAppLock((state) => state.setBlockScreenshots)
    const setHideInNotifications = useAppLock((state) => state.setHideInNotifications)
    const setBiometric = useAppLock((state) => state.setBiometric)
    const lockNow = useAppLock((state) => state.lockNow)
    const resetVaultKeepingChats = useAppLock((state) => state.resetVaultKeepingChats)

    const [secret, setSecret] = useState('')
    const [confirmSecret, setConfirmSecret] = useState('')
    const [currentSecret, setCurrentSecret] = useState('')
    const [nextSecret, setNextSecret] = useState('')
    const [error, setError] = useState<string | undefined>(undefined)
    const [migration, setMigration] = useState<MigrationOutcome | undefined>(undefined)
    const [migrating, setMigrating] = useState(false)

    /**
     * Validação dos dois campos, recalculada a cada tecla (sem `useMemo` de
     * propósito: é barato e o valor tem de estar sempre em dia com o que está na
     * tela). O botão só fica aceso quando as duas digitações existem, têm 6+ e
     * coincidem; e o motivo de estar apagado aparece escrito — nunca fica um
     * botão cinza sem explicação.
     */
    const ativacao = validarAtivacao(secret, confirmSecret)
    const podeAtivar = ativacao.ok
    const motivoDoBotao = !secret
        ? undefined
        : ativacao.reason && ativacao.reason !== 'Digite uma senha ou um PIN.'
          ? ativacao.reason
          : undefined

    // A migração roda sozinha quando o cofre passa a existir: as imagens antigas
    // (em claro) viram imagens cifradas sem o usuário precisar pedir.
    useEffect(() => {
        if (!configured || migrating) return
        let cancelled = false
        setMigrating(true)
        migrateExistingImages(true)
            .then((outcome) => {
                if (!cancelled) setMigration(outcome)
            })
            .finally(() => {
                if (!cancelled) setMigrating(false)
            })
        return () => {
            cancelled = true
        }
    }, [configured, migrating])

    const handleEnable = async () => {
        const verdict = validarAtivacao(secret, confirmSecret)
        if (!verdict.ok) {
            setError(verdict.reason)
            return
        }
        // `enableLock` conversa com o armazenamento seguro do sistema: ele pode
        // **lançar** (Keystore indisponível, por exemplo). Antes, uma exceção aqui
        // não aparecia em lugar nenhum — o toque parecia não fazer nada. Agora a
        // razão real vai para a tela e para o diagnóstico.
        try {
            const result = await enableLock(secret)
            if (!result.ok) {
                setError(result.error)
                return
            }
        } catch (exception) {
            recordError('cofre-ativar', exception)
            setError(String((exception as Error)?.message ?? exception))
            return
        }
        setError(undefined)
        setSecret('')
        setConfirmSecret('')
    }

    const handleChange = async () => {
        const result = await changeSecret(currentSecret, nextSecret)
        if (!result.ok) {
            setError(result.error)
            return
        }
        setError(undefined)
        setCurrentSecret('')
        setNextSecret('')
        Alert.alert({
            title: 'Senha alterada',
            description:
                'A chave que cifra suas imagens continua a mesma; só o envelope mudou. Nenhuma imagem precisou ser recifrada.',
            buttons: [{ label: 'Entendi' }],
        })
    }

    const handleDisable = () => {
        Alert.alert({
            title: 'Desligar a proteção',
            description: DISABLE_WARNING,
            alignButtons: 'left',
            buttons: [
                { label: 'Manter ligada', type: 'default' },
                {
                    label: 'Desligar',
                    type: 'warning',
                    onPress: () => {
                        if (!currentSecret) {
                            setError(
                                'Digite a senha atual no campo acima para desligar a proteção.'
                            )
                            return
                        }
                        disableLock(currentSecret).then((result) => {
                            if (!result.ok) setError(result.error)
                            else {
                                setError(undefined)
                                setCurrentSecret('')
                            }
                        })
                    },
                },
            ],
        })
    }

    const handleForgot = () => {
        Alert.alert({
            title: 'Esqueci a senha',
            description: FORGOT_SECRET_EXPLANATION.join('\n\n'),
            alignButtons: 'left',
            buttons: [
                { label: 'Voltar', type: 'default' },
                {
                    label: 'Redefinir (apaga o cofre)',
                    type: 'warning',
                    onPress: () => {
                        resetVaultKeepingChats(nextSecret || '').then((result) => {
                            if (!result.ok) setError(result.error)
                            else setError(undefined)
                        })
                    },
                },
            ],
        })
    }

    return (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.container}>
            <SectionTitle>Bloqueio</SectionTitle>

            {!configured ? (
                <View style={styles.section}>
                    <Text style={styles.paragraph}>
                        A proteção usa uma senha ou PIN de pelo menos 6 dígitos. A senha não é
                        guardada: ela vira uma chave que cifra suas imagens. Sem ela, o cofre não
                        abre — nem para a Lunaria.
                    </Text>
                    <ThemedTextInput
                        label="Senha ou PIN"
                        value={secret}
                        onChangeText={setSecret}
                        secureTextEntry
                    />
                    <ThemedTextInput
                        label="Repita"
                        value={confirmSecret}
                        onChangeText={setConfirmSecret}
                        secureTextEntry
                    />
                    {error && <Text style={styles.error}>{error}</Text>}
                    {motivoDoBotao && motivoDoBotao !== error && (
                        <Text style={styles.note}>{motivoDoBotao}</Text>
                    )}
                    <ThemedButton
                        label="Ativar bloqueio"
                        iconName="lock"
                        variant={podeAtivar ? 'primary' : 'disabled'}
                        disabled={!podeAtivar}
                        onPress={handleEnable}
                    />
                    <Text style={styles.note}>
                        Depois de ativar, as imagens antigas das conversas são movidas para o cofre
                        cifrado automaticamente, com conferência de conteúdo antes de apagar o
                        original.
                    </Text>
                </View>
            ) : (
                <>
                    <View style={styles.section}>
                        <ThemedButton
                            label="Bloquear agora"
                            iconName="lock"
                            variant="primary"
                            onPress={() => {
                                // O resultado é mostrado: antes, sem cofre, a ação
                                // saía em silêncio e o toque parecia não fazer nada
                                // (relato de 21/09/2026).
                                const resultado = lockNow('manual')
                                if (!resultado.ok) setError(resultado.error)
                                else setError(undefined)
                            }}
                        />
                        {migration && <Text style={styles.note}>{migration.message}</Text>}
                        {/*
                          Estado do bloqueio escrito na tela.

                          Por que isto está aqui: o relato do aparelho foi "a tela
                          mostra o cofre pronto e nada bloqueia". Sem ver o estado
                          real, não há como distinguir "não está configurado" de
                          "está configurado e ainda assim não bloqueia" — e foi
                          exatamente essa confusão que custou uma rodada. São os
                          mesmos dados que vão para o diagnóstico do sistema.
                        */}
                        <Text style={styles.note}>
                            Estado agora: cofre {configured ? 'configurado' : 'não configurado'} ·
                            proteção {configured ? 'ligada' : 'desligada'} · aplicativo{' '}
                            {locked ? `bloqueado${lastReason ? ` (${lastReason})` : ''}` : 'aberto'}{' '}
                            · política{' '}
                            {settings.autoLockMinutes === 0
                                ? 'ao sair'
                                : `${settings.autoLockMinutes} min fora`}
                        </Text>
                    </View>

                    <SectionTitle>Entrada</SectionTitle>
                    <View style={styles.section}>
                        <ThemedTextInput
                            label="Senha atual"
                            description="Necessária para trocar senha, mexer na biometria ou desligar a proteção."
                            value={currentSecret}
                            onChangeText={setCurrentSecret}
                            secureTextEntry
                        />
                        {error && <Text style={styles.error}>{error}</Text>}
                        <ThemedTextInput
                            label="Nova senha ou PIN"
                            value={nextSecret}
                            onChangeText={setNextSecret}
                            secureTextEntry
                        />
                        <ThemedButton
                            label="Trocar senha"
                            variant="secondary"
                            onPress={handleChange}
                        />
                        <ThemedSwitch
                            label="Abrir com biometria"
                            description="Atalho de conveniência: guarda a chave no armazenamento seguro do sistema. A senha continua sendo a proteção principal e é exigida para ativar ou desativar."
                            value={settings.biometric}
                            onChangeValue={(value) =>
                                setBiometric(value, currentSecret).then((result) => {
                                    if (!result.ok) setError(result.error)
                                    else setError(undefined)
                                })
                            }
                        />
                        {failures > 0 && (
                            <Text style={styles.note}>
                                {failures} tentativa(s) incorreta(s) registrada(s). A espera cresce
                                a cada erro e nunca apaga dados.
                            </Text>
                        )}
                    </View>

                    <SectionTitle>Retorno ao aplicativo</SectionTitle>
                    <View style={styles.section}>
                        <HorizontalSelector
                            label="Bloquear depois de"
                            description="Quanto tempo fora do aplicativo antes de exigir a senha de novo."
                            values={AUTO_LOCK_OPTIONS.map((minutes) => ({
                                label:
                                    minutes === 0
                                        ? 'Ao sair'
                                        : minutes < 60
                                          ? `${minutes} min`
                                          : `${minutes / 60} h`,
                                value: minutes,
                            }))}
                            selected={settings.autoLockMinutes}
                            onPress={(minutes) => setAutoLock(minutes)}
                        />
                        <Text style={styles.note}>
                            Selecionado: {describeAutoLock(settings.autoLockMinutes)}.
                        </Text>
                    </View>

                    <SectionTitle>Privacidade</SectionTitle>
                    <View style={styles.section}>
                        <ThemedSwitch
                            label="Impedir capturas de tela"
                            description="Bloqueia print e gravação da tela do Android enquanto a Lunaria está à frente. Vale para o aplicativo inteiro."
                            value={settings.blockScreenshots}
                            onChangeValue={setBlockScreenshots}
                        />
                        <ThemedSwitch
                            label="Esconder conteúdo nos avisos"
                            description="Notificações e prévia de aplicativos recentes não mostram o texto das conversas nem as imagens."
                            value={settings.hideInNotifications}
                            onChangeValue={setHideInNotifications}
                        />
                    </View>

                    <SectionTitle>Segurança da conta</SectionTitle>
                    <View style={styles.section}>
                        <ThemedButton
                            label="Esqueci a senha (reiniciar cofre)"
                            variant="tertiary"
                            onPress={handleForgot}
                        />
                        <ThemedButton
                            label="Desligar proteção"
                            iconName="unlock"
                            variant="critical"
                            onPress={handleDisable}
                        />
                        <Text style={styles.note}>
                            <Ionicons name="information-circle-outline" size={12} /> Nada aqui apaga
                            conversas, personagens, memória ou ajustes: só o cofre de imagens é
                            afetado, e apenas quando você confirma.
                        </Text>
                    </View>
                </>
            )}
        </ScrollView>
    )
}

export default LockSettingsScreen

const useStyles = () => {
    const { color, spacing, fontSize, borderRadius } = Theme.useTheme()

    return StyleSheet.create({
        container: {
            padding: spacing.xl,
            rowGap: spacing.l,
            paddingBottom: spacing.xl3,
        },
        section: {
            rowGap: spacing.m,
            backgroundColor: color.neutral._200,
            borderRadius: borderRadius.m,
            padding: spacing.l,
        },
        paragraph: {
            color: color.text._200,
            fontSize: fontSize.m,
            lineHeight: 21,
        },
        note: {
            color: color.text._300,
            fontSize: fontSize.s,
            lineHeight: 19,
        },
        error: {
            color: color.text._100,
            fontSize: fontSize.m,
        },
    })
}
