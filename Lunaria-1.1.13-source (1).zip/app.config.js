const IS_DEV = process.env.APP_VARIANT === 'development'

module.exports = {
    expo: {
        name: IS_DEV ? 'Lunaria (DEV)' : 'Lunaria',
        newArchEnabled: true,
        slug: 'lunaria',
        version: '1.1.13',
        orientation: 'default',
        icon: './assets/images/icon.png',
        scheme: 'lunaria',
        userInterfaceStyle: 'automatic',
        assetBundlePatterns: ['**/*'],
        ios: {
            icon: {
                dark: './assets/images/ios-dark.png',
                light: './assets/images/ios-light.png',
                tinted: './assets/images/icon.png',
            },
            supportsTablet: true,
            package: IS_DEV ? 'br.aurora.luna.lunaria.next.dev' : 'br.aurora.luna.lunaria.next',
            bundleIdentifier: IS_DEV
                ? 'br.aurora.luna.lunaria.next.dev'
                : 'br.aurora.luna.lunaria.next',
        },
        android: {
            adaptiveIcon: {
                foregroundImage: './assets/images/adaptive-icon-foreground.png',
                backgroundImage: './assets/images/adaptive-icon-background.png',
                monochromeImage: './assets/images/adaptive-icon-foreground.png',
                backgroundColor: '#000',
            },
            package: IS_DEV ? 'br.aurora.luna.lunaria.next.dev' : 'br.aurora.luna.lunaria.next',
            userInterfaceStyle: 'dark',
            permissions: [
                'android.permission.FOREGROUND_SERVICE',
                'android.permission.WAKE_LOCK',
                'android.permission.FOREGROUND_SERVICE_DATA_SYNC',
            ],
        },
        web: {
            bundler: 'metro',
            output: 'static',
            favicon: './assets/images/adaptive-icon.png',
        },
        plugins: [
            [
                'expo-asset',
                {
                    assets: ['./assets/models/llama3tokenizer.gguf'],
                },
            ],
            [
                'expo-build-properties',
                {
                    android: {
                        largeHeap: true,
                        usesCleartextTraffic: false,
                        enableProguardInReleaseBuilds: true,
                        enableShrinkResourcesInReleaseBuilds: true,
                        useLegacyPackaging: true,
                        extraProguardRules: '-keep class com.rnllama.** { *; }',
                    },
                },
            ],
            [
                'expo-splash-screen',
                {
                    backgroundColor: '#000000',
                    image: './assets/images/adaptive-icon.png',
                    imageWidth: 200,
                },
            ],
            [
                'expo-notifications',
                {
                    icon: './assets/images/notification.png',
                },
            ],
            [
                './expo-build-plugins/androidattributes.plugin.js',
                {
                    'android:largeHeap': true,
                },
            ],
            ['@vali98/react-native-process-text', { label: 'Perguntar à Lunaria' }],
            [
                'expo-camera',
                {
                    cameraPermission: 'Permitir que a Lunaria acesse sua câmera',
                },
            ],
            [
                'expo-speech-recognition',
                {
                    microphonePermission: 'Permitir que a Lunaria use o microfone',
                    speechRecognitionPermission:
                        'Permitir que a Lunaria converta sua fala em texto',
                    androidSpeechServicePackages: [
                        'com.google.android.googlequicksearchbox',
                        'com.google.android.as',
                        'com.samsung.android.bixby.agent',
                    ],
                },
            ],
            ['expo-sqlite', { withSQLiteVecExtension: true }],
            'expo-localization',
            'expo-router',
            'expo-font',
            'expo-image',
            './expo-build-plugins/bgactions.plugin.js',
            './expo-build-plugins/usercert.plugin.js',
            './expo-build-plugins/rnllama.plugin.js',
            './expo-build-plugins/copyhtp.plugin.js',
            './expo-build-plugins/lunaria-signing.plugin.js',
        ],
        experiments: {
            typedRoutes: true,
            reactCompiler: true,
        },
        extra: {
            router: {
                origin: false,
            },
        },
    },
}
