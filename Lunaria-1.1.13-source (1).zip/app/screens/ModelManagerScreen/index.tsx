// Arquivo de rota do Expo Router — só isto mora em `app/`.
// O código de verdade fica em `src/`, para o roteador não descobrir
// componente, hook ou serviço como se fosse rota (ver LEIA-ME.md).
export { default } from '@screens/ModelManagerScreen'
