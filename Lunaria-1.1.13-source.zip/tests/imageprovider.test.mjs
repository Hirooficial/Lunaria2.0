import assert from 'node:assert/strict'
import { Buffer } from 'node:buffer'
import { readFileSync } from 'node:fs'
import test from 'node:test'

import {
    CLIENT_AGENT,
    generateImage,
    generateWithHorde,
    generateWithPollinations,
    HORDE_ANONYMOUS_KEY,
    ImageGenerationError,
    MAX_IMAGE_BYTES,
    POLL_INTERVAL_MS,
    POLL_RETRY_BASE_MS,
    POLL_RETRY_MAX_MS,
    seedDaHorde,
} from '../lib/imagegen/ImageProviders.ts'

const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3])
const PNG_BASE64 = Buffer.from(PNG).toString('base64')

const okJson = (body) => ({ ok: true, status: 200, json: async () => body, text: async () => '' })
const okBytes = (bytes, type = 'image/png') => ({
    ok: true,
    status: 200,
    headers: { get: () => type },
    arrayBuffer: async () =>
        bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
})
const fail = (status, body = 'erro') => ({
    ok: false,
    status,
    json: async () => ({}),
    text: async () => body,
})

const noSleep = async () => {}
const fast = { sleepImpl: noSleep, pollIntervalMs: 1 }

test('a chave anônima e o identificador de cliente são os esperados', () => {
    assert.equal(HORDE_ANONYMOUS_KEY, '0000000000')
    // O identificador leva a versão do aplicativo. Comparar com o `package.json`
    // (em vez de fixar o número aqui) é o que impede este teste de apodrecer a
    // cada salto de versão — foi exatamente o que aconteceu na 1.1.3.
    const { version: versao } = JSON.parse(
        readFileSync(new URL('../package.json', import.meta.url), 'utf8')
    )
    assert.match(CLIENT_AGENT, /^Lunaria:\d+\.\d+\.\d+:/)
    assert.ok(
        CLIENT_AGENT.startsWith(`Lunaria:${versao}:`),
        `identificador "${CLIENT_AGENT}" deveria começar com "Lunaria:${versao}:"`
    )
    assert.equal(POLL_INTERVAL_MS, 5000)
})

test('Horde: entra na fila, informa posição e devolve a imagem pronta', async () => {
    const phases = []
    let statusCalls = 0
    const fetchImpl = async (url, options) => {
        if (String(url).endsWith('/generate/async')) {
            assert.equal(options.headers.apikey, HORDE_ANONYMOUS_KEY)
            assert.equal(options.headers['Client-Agent'], CLIENT_AGENT)
            const body = JSON.parse(options.body)
            assert.equal(body.nsfw, false)
            assert.equal(body.censor_nsfw, true)
            assert.equal(body.params.width, 512)
            return okJson({ id: 'job-1', kudos: 6 })
        }
        statusCalls += 1
        if (statusCalls === 1) {
            return okJson({ done: false, queue_position: 3, wait_time: 20 })
        }
        return okJson({
            done: true,
            generations: [{ img: PNG_BASE64, model: 'stable_diffusion', seed: '42' }],
        })
    }

    const result = await generateWithHorde({
        prompt: 'gothic portrait',
        width: 512,
        height: 768,
        fetchImpl,
        onProgress: (progress) => phases.push(progress.phase),
        ...fast,
    })

    assert.equal(result.provider, 'horde')
    assert.equal(result.extension, 'png')
    assert.equal(result.mime, 'image/png')
    assert.equal(result.seed, 42)
    assert.deepEqual(phases, ['preparando', 'enfileirado', 'enfileirado', 'concluido'])
})

test('Horde: fila que trava é cancelada no provedor e vira erro de tempo', async () => {
    let deleted = false
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'DELETE') {
            deleted = true
            return okJson({})
        }
        if (String(url).endsWith('/generate/async')) return okJson({ id: 'job-2' })
        return okJson({ done: false, queue_position: 99 })
    }

    await assert.rejects(
        generateWithHorde({
            prompt: 'x',
            width: 512,
            height: 512,
            fetchImpl,
            maxWaitMs: 3,
            ...fast,
        }),
        (error) => {
            assert.ok(error instanceof ImageGenerationError)
            assert.equal(error.kind, 'timeout')
            return true
        }
    )
    assert.equal(deleted, true, 'o pedido precisa ser removido da fila ao desistir')
})

test('Horde: recusa do provedor (faulted) vira erro de recusa', async () => {
    const fetchImpl = async (url) => {
        if (String(url).endsWith('/generate/async')) return okJson({ id: 'job-3' })
        return okJson({ done: false, faulted: true, message: 'no worker could process' })
    }
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => error.kind === 'recusa'
    )
})

test('cota esgotada (429) tem mensagem e dica próprias', async () => {
    const fetchImpl = async () => fail(429)
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'cota')
            assert.match(error.hint, /Espere alguns minutos|chave/)
            return true
        }
    )
})

test('sem internet o erro é explícito e sugere conferir a conexão', async () => {
    const fetchImpl = async () => {
        throw new TypeError('Network request failed')
    }
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'rede')
            assert.match(error.hint, /internet/)
            return true
        }
    )
})

test('recusa do provedor em 400/422 vira erro de recusa com o texto do serviço', async () => {
    const fetchImpl = async () => fail(400, 'prompt blocked')
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'recusa')
            assert.match(error.hint, /prompt blocked/)
            return true
        }
    )
})

test('provedor indisponível (5xx) não é tratado como culpa do aparelho', async () => {
    const fetchImpl = async () => fail(503)
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'rede')
            assert.match(error.message, /indisponível/)
            return true
        }
    )
})

test('500 que por dentro é limite de uso vira erro de COTA, não de indisponibilidade', async () => {
    // Corpo real capturado em 20/09/2026 da Pollinations (ver
    // lunaria-build/logs/medicao-provedores-2026-09-20.txt):
    const corpoReal =
        '{"error":"Internal Server Error","message":"Gen Sana request failed with 429: ' +
        '{\\"success\\":false,\\"error\\":{\\"message\\":\\"Per-user limit of 300 RPM exceeded ' +
        'for model lykon/dreamshaper-8-lcm\\",\\"code\\":\\"community_model_rate_limit\\"}}}'
    const fetchImpl = async () => fail(500, corpoReal)
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'cota')
            assert.match(error.message, /limitando os pedidos|limite de uso/)
            assert.match(error.hint, /Espere alguns minutos/)
            return true
        }
    )
})

test('500 genérico (sem marca de limite) continua sendo indisponibilidade', async () => {
    const fetchImpl = async () => fail(500, '{"error":"Internal Server Error"}')
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'rede')
            assert.match(error.message, /indisponível/)
            return true
        }
    )
})

test('Pollinations: o mesmo limite embrulhado em 500 também vira cota', async () => {
    const fetchImpl = async () => fail(502, 'Gen request failed with 429: too many requests')
    await assert.rejects(
        generateWithPollinations({ prompt: 'x', width: 512, height: 512, fetchImpl }),
        (error) => error.kind === 'cota' && /limitando/.test(error.message)
    )
})

test('RESPOSTA FINAL AO DEFEITO: seed da Horde vai como TEXTO, nunca como número', async () => {
    // Defeito relatado pelo aparelho em 20/09/2026, seed manual na tela:
    //   Input payload validation failed — params.seed: "364056 is not of type 'string'"
    // Estes cinco testes cobrem, na ordem pedida, os cinco cenários.

    const corpoEnviado = (capturado) => JSON.parse(capturado)
    let capturado
    const capturar = () => {
        capturado = undefined
        return async (url, options) => {
            if (String(url).endsWith('/generate/async')) {
                capturado = options.body
                return okJson({ id: 'job-seed' })
            }
            return okJson({ done: true, generations: [{ img: PNG_BASE64, seed: '1' }] })
        }
    }

    // ---- TESTE 1: seed AUTOMÁTICA (gerada pela própria Lunaria) ----
    const { randomSeed } = await import('../lib/imagegen/ImagePrompt.ts')
    const automatica = randomSeed()
    assert.equal(typeof automatica, 'number', 'a Lunaria continua gerando a seed como número')

    const fetchAuto = capturar()
    await generateWithHorde({ prompt: 'x', width: 512, height: 512, seed: automatica, fetchImpl: fetchAuto, ...fast })
    const payloadAuto = corpoEnviado(capturado)
    console.log(`  TESTE 1 (automática): payload.params.seed = ${JSON.stringify(payloadAuto.params.seed)}`)
    assert.equal(typeof payloadAuto.params.seed, 'string')
    assert.equal(payloadAuto.params.seed, String(automatica))
    assert.ok(!/^"seed":\s*\d+/.test(capturado), 'o corpo não pode ter seed como número')

    // ---- TESTE 2: seed MANUAL (como o usuário digita) ----
    const fetchManual = capturar()
    await generateWithHorde({ prompt: 'x', width: 512, height: 512, seed: 364056, fetchImpl: fetchManual, ...fast })
    const payloadManual = corpoEnviado(capturado)
    console.log(`  TESTE 2 (manual 364056): payload.params.seed = ${JSON.stringify(payloadManual.params.seed)}`)
    assert.equal(payloadManual.params.seed, '364056')
    assert.equal(typeof payloadManual.params.seed, 'string')

    // ---- TESTE 3: "Tentar de novo" (mesma seed reaproveitada) ----
    for (const tentativa of [1, 2, 3]) {
        const fetchRetry = capturar()
        await generateWithHorde({ prompt: 'x', width: 512, height: 512, seed: 364056, fetchImpl: fetchRetry, ...fast })
        const p = corpoEnviado(capturado)
        console.log(`  TESTE 3 (nova tentativa ${tentativa}): payload.params.seed = ${JSON.stringify(p.params.seed)}`)
        assert.equal(typeof p.params.seed, 'string', 'o retry não pode devolver a seed para número')
        assert.equal(p.params.seed, '364056')
    }

    // ---- TESTE 4: seed AUSENTE ou VAZIA — o campo tem de ser OMITIDO ----
    const casos = [
        ['ausente', undefined],
        ['nula', null],
        ['vazia', ''],
        ['só espaços', '   '],
        ['NaN', NaN],
        ['Infinity', Infinity],
    ]
    for (const [nome, valor] of casos) {
        const fetchVazio = capturar()
        await generateWithHorde({ prompt: 'x', width: 512, height: 512, seed: valor, fetchImpl: fetchVazio, ...fast })
        const p = corpoEnviado(capturado)
        console.log(`  TESTE 4 (${nome}): "seed" presente no corpo? ${'seed' in p.params} | valor = ${JSON.stringify(p.params.seed)}`)
        assert.equal('seed' in p.params, false, `seed ${nome} não pode virar campo no payload`)
        assert.ok(!/null|NaN|undefined/.test(JSON.stringify(p.params)), 'nada de null/NaN/undefined no payload')
    }

    // ---- TESTE 5: os OUTROS provedores não foram tocados ----
    // A Pollinations recebe a seed como parâmetro de URL (comportamento próprio) e
    // continua recebendo o que recebia; só a Horde converte para texto.
    let urlPollinations
    const fetchPolli = async (url) => {
        urlPollinations = String(url)
        return { ok: true, status: 200, arrayBuffer: async () => PNG.buffer.slice(0) }
    }
    const resultadoPolli = await generateWithPollinations({
        prompt: 'x', width: 512, height: 512, seed: 42, fetchImpl: fetchPolli,
    })
    console.log(`  TESTE 5 (Pollinations): seed na URL = ${urlPollinations.match(/seed=([^&]*)/)?.[1]}`)
    assert.equal(urlPollinations.match(/seed=([^&]*)/)?.[1], '42')
    assert.equal(resultadoPolli.provider, 'pollinations')

    // A fachada continua escolhendo o provedor pedido.
    const fetchHorde = capturar()
    const viaFachada = await generateImage({ provider: 'horde', prompt: 'x', width: 512, height: 512, seed: 7, fetchImpl: fetchHorde, ...fast })
    assert.equal(viaFachada.provider, 'horde')
    assert.equal(corpoEnviado(capturado).params.seed, '7')

    // ---- a tabela da função de normalização, sozinha ----
    assert.equal(seedDaHorde(123), '123')
    assert.equal(seedDaHorde('123'), '123')
    assert.equal(seedDaHorde(0), '0')
    assert.equal(seedDaHorde(undefined), undefined)
    assert.equal(seedDaHorde(null), undefined)
    assert.equal(seedDaHorde(''), undefined)
    assert.equal(seedDaHorde('  '), undefined)
    assert.equal(seedDaHorde(NaN), undefined)
    assert.equal(seedDaHorde(Infinity), undefined)
})

test('resposta que não é imagem é recusada com erro de formato', async () => {
    const fetchImpl = async (url) => {
        if (String(url).endsWith('/generate/async')) return okJson({ id: 'job-4' })
        return okJson({
            done: true,
            generations: [{ img: Buffer.from('não é imagem').toString('base64') }],
        })
    }
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => error.kind === 'formato'
    )
})

test('imagem gigante é rejeitada antes de ocupar memória do aparelho', async () => {
    const huge = new Uint8Array(MAX_IMAGE_BYTES + 1)
    huge.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
    const fetchImpl = async (url) => {
        if (String(url).endsWith('/generate/async')) return okJson({ id: 'job-5' })
        return okJson({ done: true, generations: [{ img: Buffer.from(huge).toString('base64') }] })
    }
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => error.kind === 'formato'
    )
})

test('cancelar aborta e devolve erro de cancelamento', async () => {
    const controller = new AbortController()
    const fetchImpl = async (url, options) => {
        if (String(url).endsWith('/generate/async')) {
            controller.abort()
            return okJson({ id: 'job-6' })
        }
        return okJson({ done: false })
    }
    await assert.rejects(
        generateWithHorde({
            prompt: 'x',
            width: 512,
            height: 512,
            fetchImpl,
            signal: controller.signal,
            ...fast,
        }),
        (error) => error.kind === 'cancelado'
    )
})

test('Pollinations: pedido direto devolve a imagem e usa parâmetros seguros', async () => {
    const seen = {}
    const fetchImpl = async (url) => {
        seen.url = String(url)
        return okBytes(PNG)
    }
    const result = await generateWithPollinations({
        prompt: 'gothic portrait',
        width: 768,
        height: 512,
        seed: 7,
        fetchImpl,
    })
    assert.equal(result.provider, 'pollinations')
    assert.equal(result.extension, 'png')
    assert.match(seen.url, /width=768/)
    assert.match(seen.url, /height=512/)
    assert.match(seen.url, /nologo=true/)
    assert.match(seen.url, /private=true/)
    assert.match(seen.url, /safe=true/)
})

test('a fachada generateImage escolhe o provedor pedido', async () => {
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-7' })
        if (String(url).includes('aihorde'))
            return okJson({ done: true, generations: [{ img: PNG_BASE64 }] })
        return okBytes(PNG)
    }
    const horde = await generateImage({
        provider: 'horde',
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
        ...fast,
    })
    const pollinations = await generateImage({
        provider: 'pollinations',
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
    })
    assert.equal(horde.provider, 'horde')
    assert.equal(pollinations.provider, 'pollinations')
})

// ---------------------------------------------------------------------------
// Limite de consultas do provedor (429) e instabilidade (5xx).
//
// Descoberto com o provedor de verdade, em 18/09: com fila longa a chave
// anônima da Horde responde 429 a uma consulta de status — mesmo com tudo
// certo. Antes desta correção, esse 429 derrubava a geração e mostrava
// "cota esgotada" para o usuário, que não tinha cota esgotada nenhuma.
// ---------------------------------------------------------------------------

test('429 na consulta de status não cancela a geração: espera e continua', async () => {
    let consultas = 0
    const esperas = []
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-429' })
        consultas += 1
        if (consultas <= 2) return fail(429, 'Too Many Requests')
        return okJson({ done: true, generations: [{ img: PNG_BASE64, model: 'stable_diffusion' }] })
    }

    const gerado = await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
        sleepImpl: async (ms) => esperas.push(ms),
        pollIntervalMs: 1,
        maxWaitMs: 60_000,
    })

    assert.equal(gerado.provider, 'horde')
    assert.equal(consultas, 3, 'continuou consultando depois dos 429')
    // esperou mais do que o intervalo normal em cada 429 (espera crescente)
    const esperasExtras = esperas.filter((ms) => ms >= POLL_RETRY_BASE_MS)
    assert.equal(esperasExtras.length, 2, 'esperou depois de cada 429')
    assert.equal(esperasExtras[0], POLL_RETRY_BASE_MS)
    assert.equal(esperasExtras[1], POLL_RETRY_BASE_MS * 2, 'a segunda espera é maior')
})

test('a espera após 429 tem teto (não cresce sem limite)', async () => {
    let consultas = 0
    const esperas = []
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-429-muitos' })
        consultas += 1
        if (consultas <= 8) return fail(429)
        return okJson({ done: true, generations: [{ img: PNG_BASE64 }] })
    }

    await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
        sleepImpl: async (ms) => esperas.push(ms),
        pollIntervalMs: 1,
        maxWaitMs: 600_000,
    })

    const maiores = Math.max(...esperas)
    assert.ok(maiores <= POLL_RETRY_MAX_MS, `espera ${maiores}ms passou do teto`)
})

test('Retry-After do provedor é respeitado quando vem', async () => {
    let consultas = 0
    const esperas = []
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-retry-after' })
        consultas += 1
        if (consultas === 1)
            return {
                ok: false,
                status: 429,
                headers: { get: (nome) => (nome === 'Retry-After' ? '7' : null) },
                text: async () => 'calma',
            }
        return okJson({ done: true, generations: [{ img: PNG_BASE64 }] })
    }

    await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
        sleepImpl: async (ms) => esperas.push(ms),
        pollIntervalMs: 1,
        maxWaitMs: 60_000,
    })

    assert.ok(esperas.includes(7000), 'esperou os 7 segundos pedidos pelo provedor')
})

test('erro 5xx na consulta também é tolerado (provedor instável)', async () => {
    let consultas = 0
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-502' })
        consultas += 1
        if (consultas <= 2) return fail(502, 'Bad Gateway')
        return okJson({ done: true, generations: [{ img: PNG_BASE64 }] })
    }

    const gerado = await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
        sleepImpl: noSleep,
        pollIntervalMs: 1,
        maxWaitMs: 60_000,
    })
    assert.equal(gerado.provider, 'horde')
})

test('401 na consulta continua sendo erro de autenticação (não é passageiro)', async () => {
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-401' })
        return fail(401, 'Unauthorized')
    }
    await assert.rejects(
        () =>
            generateWithHorde({
                prompt: 'x',
                width: 512,
                height: 512,
                fetchImpl,
                sleepImpl: noSleep,
                pollIntervalMs: 1,
                maxWaitMs: 60_000,
            }),
        (erro) => erro.kind === 'autenticacao'
    )
})

test('404 na consulta (trabalho não encontrado) continua sendo erro', async () => {
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-404' })
        return fail(404, 'Not Found')
    }
    await assert.rejects(
        () =>
            generateWithHorde({
                prompt: 'x',
                width: 512,
                height: 512,
                fetchImpl,
                sleepImpl: noSleep,
                pollIntervalMs: 1,
                maxWaitMs: 60_000,
            }),
        (erro) => erro instanceof ImageGenerationError
    )
})

// ---------------------------------------------------------------------------
// O resultado pode vir como ENDEREÇO, não só como base64.
//
// Descoberto com o provedor de verdade em 18/09, à noite: a geração terminou e o
// campo `img` trazia "https://<bucket>.r2.cloudflarestorage.com/...". O
// aplicativo tentava decodificar isso como base64, falhava com "base64 inválido"
// e o usuário ficava sem a imagem que já tinha sido gerada (e já tinha custado
// cota). Agora os dois formatos funcionam.
// ---------------------------------------------------------------------------

const URL_RESULTADO =
    'https://a223539ccf6caa2d76459c9727d276e6.r2.cloudflarestorage.com/imagem.webp?X-Amz-Expires=3600'

test('resultado em base64 continua funcionando', async () => {
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-b64' })
        return okJson({ done: true, generations: [{ img: PNG_BASE64, model: 'stable_diffusion' }] })
    }
    const imagem = await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
        ...fast,
    })
    assert.equal(imagem.bytes.length, PNG.length)
    assert.equal(imagem.mime, 'image/png')
    assert.equal(imagem.extension, 'png')
})

test('resultado como endereço https é baixado (caso real da Horde/R2)', async () => {
    let baixouDe = ''
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-url' })
        if (
            String(url).startsWith('https://') &&
            String(url).includes('r2.cloudflarestorage.com')
        ) {
            baixouDe = String(url)
            return okBytes(PNG, 'image/webp')
        }
        return okJson({
            done: true,
            generations: [{ img: URL_RESULTADO, model: 'stable_diffusion' }],
        })
    }

    const imagem = await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
        ...fast,
    })

    assert.equal(baixouDe, URL_RESULTADO, 'baixou exatamente o endereço devolvido')
    assert.equal(imagem.bytes.length, PNG.length)
    assert.equal(imagem.extension, 'png', 'a extensão vem dos bytes, não do endereço')
    assert.equal(imagem.provider, 'horde')
})

test('endereço que responde erro vira mensagem clara (imagem gerada, download falhou)', async () => {
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-url-erro' })
        if (String(url).includes('r2.cloudflarestorage.com')) return fail(403, 'expired')
        return okJson({ done: true, generations: [{ img: URL_RESULTADO }] })
    }

    await assert.rejects(
        () =>
            generateWithHorde({
                prompt: 'x',
                width: 512,
                height: 512,
                fetchImpl,
                ...fast,
            }),
        (erro) =>
            erro instanceof ImageGenerationError &&
            erro.kind === 'rede' &&
            /baixar a imagem/i.test(erro.message)
    )
})

test('endereço que devolve algo que não é imagem é recusado', async () => {
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-url-lixo' })
        if (String(url).includes('r2.cloudflarestorage.com'))
            return okBytes(new Uint8Array([0x3c, 0x68, 0x74, 0x6d, 0x6c, 0x3e]), 'text/html')
        return okJson({ done: true, generations: [{ img: URL_RESULTADO }] })
    }

    await assert.rejects(
        () =>
            generateWithHorde({
                prompt: 'x',
                width: 512,
                height: 512,
                fetchImpl,
                ...fast,
            }),
        (erro) => erro instanceof ImageGenerationError && erro.kind === 'formato'
    )
})

test('base64 inválido (não é endereço nem base64) dá erro de formato, não de cota', async () => {
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-lixo' })
        return okJson({ done: true, generations: [{ img: 'isto não é imagem' }] })
    }
    await assert.rejects(
        () =>
            generateWithHorde({
                prompt: 'x',
                width: 512,
                height: 512,
                fetchImpl,
                ...fast,
            }),
        (erro) => erro instanceof ImageGenerationError && erro.kind === 'formato'
    )
})

// ---------------------------------------------------------------------------
// Pollinations: a semente precisa ir sempre no pedido.
//
// Medido em 18/09 com a API real: sem semente, o serviço usa a semente 42 e
// devolveu uma imagem de cache sem relação com a descrição (duas execuções,
// mesmos 37.167 bytes). Com semente própria, o mesmo pedido voltou correto.
// ---------------------------------------------------------------------------

test('Pollinations sempre envia uma semente, mesmo sem o usuário escolher', async () => {
    let urlChamada = ''
    const fetchImpl = async (url) => {
        urlChamada = String(url)
        return okBytes(PNG, 'image/jpeg')
    }

    const semSemente = await generateWithPollinations({
        prompt: 'uma jovem de cabelo longo preto, pintura digital',
        width: 512,
        height: 512,
        fetchImpl,
    })

    assert.match(urlChamada, /[?&]seed=\d+/, 'a URL levou uma semente')
    const sementeNaUrl = Number(new URL(urlChamada).searchParams.get('seed'))
    assert.ok(
        Number.isInteger(sementeNaUrl) && sementeNaUrl > 0,
        `semente válida (${sementeNaUrl})`
    )
    assert.equal(semSemente.seed, sementeNaUrl, 'a semente devolvida é a que foi enviada')

    const comSemente = await generateWithPollinations({
        prompt: 'x',
        width: 512,
        height: 512,
        seed: 7,
        fetchImpl,
    })
    assert.match(urlChamada, /[?&]seed=7\b/, 'semente escolhida pelo usuário é respeitada')
    assert.equal(comSemente.seed, 7)
})

test('duas gerações seguidas sem semente usam sementes diferentes (imagem não repete)', async () => {
    const sementes = []
    const fetchImpl = async (url) => {
        sementes.push(Number(new URL(String(url)).searchParams.get('seed')))
        return okBytes(PNG, 'image/jpeg')
    }
    for (let i = 0; i < 5; i++) {
        await generateWithPollinations({ prompt: 'x', width: 512, height: 512, fetchImpl })
    }
    assert.equal(
        new Set(sementes).size,
        sementes.length,
        `sementes distintas: ${sementes.join(', ')}`
    )
})

test('o perfil do provedor informa o limite de idioma medido na API real (18/09)', async () => {
    const { PROVIDER_INFO } = await import('../lib/imagegen/ImageProviders.ts')
    assert.equal(PROVIDER_INFO.pollinations.free, true)
    assert.equal(PROVIDER_INFO.pollinations.needsKey, false)
    assert.ok(
        typeof PROVIDER_INFO.pollinations.languageNote === 'string' &&
            /inglês/i.test(PROVIDER_INFO.pollinations.languageNote),
        'a limitação de idioma da Pollinations está registrada no perfil do provedor'
    )
    assert.ok(
        /gratuito|sem cadastro/i.test(PROVIDER_INFO.horde.limits),
        'a Horde é apresentada como gratuita e sem cadastro'
    )
})

// ---------------------------------------------------------------------------
// Cancelar precisa avisar o provedor.
//
// Descoberto na revisão de 18/09 (à noite), com o serviço real: um trabalho da
// Horde abandonado (ninguém consultando) **termina sozinho** — medido: `done=true`
// com 1 imagem cerca de 60 s depois. Ou seja: antes desta correção, tocar em
// "Cancelar" parava a espera no aplicativo, mas um worker voluntário seguia
// gerando a imagem e a prioridade (kudos) de quem cancelou era gasta do mesmo
// jeito. O aplicativo precisa avisar o provedor.
// ---------------------------------------------------------------------------

const criarColetor = () => {
    const chamadas = []
    const fetchImpl = async (url, options = {}) => {
        chamadas.push({ url: String(url), metodo: options.method ?? 'GET' })
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-cancelavel' })
        if (options.method === 'DELETE') return okJson({})
        return okJson({ done: false, queue_position: 5, wait_time: 30 })
    }
    return { chamadas, fetchImpl }
}

test('cancelar avisa o provedor (DELETE) e a geração termina como cancelada', async () => {
    const { chamadas, fetchImpl } = criarColetor()
    const controller = new AbortController()

    // cancela logo depois da primeira consulta de status
    const fetchComCancelamento = async (url, options = {}) => {
        const resposta = await fetchImpl(url, options)
        if (String(url).includes('/generate/status/') && (options.method ?? 'GET') === 'GET')
            controller.abort()
        return resposta
    }

    await assert.rejects(
        () =>
            generateWithHorde({
                prompt: 'x',
                width: 512,
                height: 512,
                fetchImpl: fetchComCancelamento,
                signal: controller.signal,
                sleepImpl: noSleep,
                pollIntervalMs: 1,
                maxWaitMs: 60_000,
            }),
        (erro) => erro instanceof ImageGenerationError && erro.kind === 'cancelado'
    )

    const cancelamentos = chamadas.filter((c) => c.metodo === 'DELETE')
    assert.equal(cancelamentos.length, 1, 'avisou o provedor exatamente uma vez')
    assert.match(
        cancelamentos[0].url,
        /\/generate\/status\/job-cancelavel$/,
        'avisou o cancelamento do trabalho certo'
    )
})

test('geração concluída NÃO manda cancelamento (não joga fora a imagem pronta)', async () => {
    const { chamadas, fetchImpl } = criarColetor()
    const fetchImplComImagem = async (url, options = {}) => {
        const resposta = await fetchImpl(url, options)
        if (
            String(url).includes('/generate/status/') &&
            (options.method ?? 'GET') === 'GET' &&
            !String(url).includes('job-cancelavel')
        )
            return resposta
        if ((options.method ?? 'GET') === 'GET')
            return okJson({ done: true, generations: [{ img: PNG_BASE64 }] })
        return resposta
    }

    const imagem = await generateWithHorde({
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl: fetchImplComImagem,
        ...fast,
    })

    assert.equal(imagem.provider, 'horde')
    assert.equal(
        chamadas.filter((c) => c.metodo === 'DELETE').length,
        0,
        'nenhum cancelamento foi enviado depois do sucesso'
    )
})

test('erro que não é cancelamento não manda cancelamento', async () => {
    const chamadas = []
    const fetchImpl = async (url, options = {}) => {
        chamadas.push({ url: String(url), metodo: options.method ?? 'GET' })
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-401' })
        if (options.method === 'DELETE') return okJson({})
        return fail(401, 'Unauthorized')
    }

    await assert.rejects(
        () =>
            generateWithHorde({
                prompt: 'x',
                width: 512,
                height: 512,
                fetchImpl,
                sleepImpl: noSleep,
                pollIntervalMs: 1,
                maxWaitMs: 60_000,
            }),
        (erro) => erro.kind === 'autenticacao'
    )
    assert.equal(chamadas.filter((c) => c.metodo === 'DELETE').length, 0)
})
