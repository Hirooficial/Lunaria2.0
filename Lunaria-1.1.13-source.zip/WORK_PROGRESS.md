# WORK_PROGRESS.md — retomada de trabalho da Lunaria

> **LEIA ESTE ARQUIVO ANTES DE QUALQUER COISA.**
> Se o ambiente do Arena falhar ("Something went wrong"), o próximo agente retoma
> **por aqui** e **não** recomeça do zero: nada de nova versão, nada de projeto novo,
> nada de build automático, nada de refazer o que já está feito.

---

## CAMPOS DE ESTADO

```
CURRENT_VERSION:
1.1.13  (versionCode 17)  — CONGELADA.

  Por que 1.1.13 e não 1.1.12: a regra diz "versionName = 1.1.12 OU mantenha
  exatamente a versão que já estiver no workspace". Mantive a que está, porque
  mudar o número agora desalinharia o código do APK de validação que já existe
  (código 17, sha a558df0d…) — e a regra é não gerar build novo. NENHUMA versão
  nova (1.1.14, 1.1.15…) será criada sem ordem expressa do usuário.

CURRENT_GOAL:
Garantir que o crash de inicialização (Expo Router / ErrorBoundary) está corrigido
de verdade no código atual e que o caminho até o release final passa pela validação
no aparelho — sem criar versões novas pelo caminho.

LAST_COMPLETED_STEP (20/09/2026, agora):
CORREÇÃO DA SEED NO PAYLOAD DA AI HORDE. O aparelho abriu a 1.1.13 (VALIDADO pelo
usuário) e o defeito restante apareceu na geração de imagem:
`Input payload validation failed — params.seed: "364056 is not of type 'string'"`.
A Lunaria mandava `seed` como NÚMERO; a API exige TEXTO.
Corrigido SÓ nesta integração: `lib/imagegen/ImageProviders.ts` ganhou
`seedDaHorde()` (número→texto; ausente/vazio/NaN/Infinity → campo OMITIDO) e uma
validação antes do request (`typeof params.seed === 'string'`), que lança erro
claro em vez de esconder. A interface, a seed aleatória, a manual, o "Tentar de
novo", a resolução, os estilos e os outros provedores (Pollinations usa a seed na
URL, intacta) não foram tocados.
PROVAS: `tests/imageprovider.test.mjs` com os 5 testes pedidos — 34/34 no arquivo;
suíte de lógica 181/181; render 142/142 (a trava do startup segue 29/29);
`tsc` limpo; `eslint` 0 erros.

CURRENT_STEP:
Nenhum. Build concluído com sucesso (mesma versão).

FILES_CHANGED (durante toda a investigação 1.1.13, na ordem em que aconteceram):
  1. lib/state/EventosBloqueio.ts       (NOVO — barramento sem importações)
  2. lib/state/AppLock.ts               (passou a usar avisarBloqueio; não importa TTS)
  3. lib/state/TTS.ts                   (registra aoBloquear(() => stopTTS()))
  4. app/ → src/                        (116 arquivos movidos; app/ ficou com 28)
  5. tsconfig.json                      (atalhos @screens/*, @components/*)
  6. package.json                       (jest: @vali98 em transformIgnorePatterns;
                                         moduleNameMapper)
  7. app.config.js                      (versão 1.1.13)
  8. android/app/build.gradle           (versionCode 15→16→17)
  9. lib/imagegen/ImageProviders.ts     (CLIENT_AGENT 1.1.13; e a correção de cota:
                                         500 com marca de limite vira erro de cota)
 10. testes NOVOS: tests/render/rotas-carregam.test.tsx (29),
     tests/render/raiz-carrega.test.tsx (5), tests/arquitetura-rotas.test.mjs (4),
     tests/render/bloqueio-silencia.test.ts (2); tests/imageprovider.test.mjs (+3)
 11. documentos: BUGS_FOUND.md (§BG, §BN), TEST_REPORT.md (§16.5–§16.11),
     STATUS.md, LEIA-ME.md, CHECKLIST_APARELHO.md (item 27), CORRECOES.md

ROOT_CAUSE_FOUND:
YES

ROOT_CAUSE:
CICLO DE IMPORTAÇÃO criado junto com a função de bloqueio:

    lib/state/AppLock.ts → lib/state/TTS.ts → lib/state/Chat.ts → AppLock.ts

O `app/_layout.tsx` (a RAIZ que o Expo Router carrega primeiro) importa o AppLock.
Ao avaliar essa cadeia, o TTS era avaliado com o Chat ainda "em avaliação"; toda
importação do Chat valia `undefined` e o `useInference.subscribe(...)` no fim do
TTS.ts (linha 99) lançava `Cannot read property 'subscribe' of undefined`.
Em produção, o Metro chama ErrorUtils.reportFatalError (é o
`FATAL EXCEPTION: mqt_v_native / JavascriptException`) e DEVOLVE `undefined` como
módulo. O `loadRoute()` da rota recebeu esse undefined e o `fromImport` do Expo
Router quebrou ao desestruturar — o `Cannot read property 'ErrorBoundary' of
undefined` do aparelho.

AS QUATRO RESPOSTAS OBRIGATÓRIAS:
  1. contextKey que falhou ....... ./_layout.tsx   (a raiz do contexto)
  2. arquivo real ................ app/_layout.tsx (arquivo inocente; a cadeia
     culpada é AppLock.ts → TTS.ts (linha 99) → Chat.ts)
  3. por que loadRoute() = undefined  porque o factory do módulo lançou e o runtime
     de produção do Metro converte isso em `undefined` (lido do bundle entregue:
     `publicModule.exports = void 0`)
  4. o que corrigiu .............. quebrar o ciclo com lib/state/EventosBloqueio.ts
     (zero importações) — o bloqueio avisa, o TTS escuta. Sem try/catch escondendo
     erro, sem ErrorBoundary por cima, sem tirar função.

PROVA CAUSAL (não dedução): reintroduzindo SÓ a aresta antiga (AppLock→TTS) na mesma
árvore, a chave ./_layout.tsx volta a falhar com a MESMA mensagem
(`LANCOU: Cannot read properties of undefined (reading 'subscribe')`, SEM_MODULO=1);
retirando a aresta, as 28 rotas carregam (TOTAL=28 SEM_MODULO=0).
Registro completo: TEST_REPORT.md §16.7. Trava permanente:
tests/render/rotas-carregam.test.tsx.

BUILD_STATUS:
SUCCESS — reconstrução do MESMO 1.1.13 (versionCode 17, SEM incremento):
17:24:45 → 17:41:32 UTC, "BUILD SUCCESSFUL in 16m 44s".
APK: 66.837.431 bytes, sha 4865463ec55c40643e8f099d8400e4b18a558f1f333467613693df200232a577,
certificado c0271509…5719a (o mesmo desde a 1.0.0), versionCode 17 (conferido no
arquivo JÁ COPIADO para entrega/), e a correção dentro do bundle (conferida:
seedDaHorde / "precisa ser texto"). Congelamento durante o build: nenhum arquivo.

REAL_DEVICE_VALIDATION:
STARTUP: **VALIDADO PELO USUÁRIO** — "A LUNARIA 1.1.13 AGORA ABRE CORRETAMENTE NO
APARELHO REAL" (Samsung Galaxy A05s, Android 15). O defeito de abertura está
encerrado.
GERAÇÃO DE IMAGEM (seed): pendente — é o que o APK desta rodada (item 32 do
CHECKLIST_APARELHO.md) vai validar no aparelho.

NEXT_STEP (uma coisa só):
No aparelho, gerar uma imagem escolhendo **AI Horde** e **digitando uma seed**
(por exemplo 364056). Esperado: a imagem sai, sem o erro
`params.seed: "364056 is not of type 'string'"`. Se aparecer qualquer erro, mande
a mensagem exata — volto à integração, no MESMO projeto e na MESMA versão.
```

---

## ETAPAS (A a H) — estado real, com evidência

| etapa | o que é | estado | evidência |
| --- | --- | --- | --- |
| A | Mapear a árvore real do Expo Router | **CONCLUÍDA** | `app/` com 28 arquivos; saída do próprio Expo Router: `{"layout":1,"route":27}` |
| B | Listar todo arquivo tratado como rota | **CONCLUÍDA** | 27 rotas + 1 layout, auditadas arquivo por arquivo nesta retomada (nenhum componente/botão/hook dentro de `app/`) |
| C | Identificar rota/módulo que retorna `undefined` | **CONCLUÍDA** | `./_layout.tsx`; hoje **nenhuma** rota devolve undefined (`TOTAL=28 SEM_MODULO=0`) |
| D | Descobrir a causa do módulo inválido | **CONCLUÍDA** | ciclo `AppLock→TTS→Chat→AppLock`; `TTS.ts:99`; prova causal em `TEST_REPORT.md` §16.7 |
| E | Aplicar a menor correção estrutural | **CONCLUÍDA** | `lib/state/EventosBloqueio.ts` + `app/`→`src/` (feita **depois** de confirmar a ligação com o crash) |
| F | `expo-doctor` e validações | **CONCLUÍDA nesta retomada** | 18/20; os 2 avisos não têm relação com o crash (abaixo); suítes 142/142 + 180/180 |
| G | Bundle production e verificação das rotas | **CONCLUÍDA** | `expo export:embed` + instrumentação `LUNARIA_ROUTE_LOAD` (28/28, 0 sem módulo) e conferência do bundle Hermes **dentro do APK** |
| H | APK release final | **FEITO UMA VEZ** (código 17) — **nenhum build novo** até a validação no aparelho | `BUILD SUCCESSFUL in 16m 54s`; pacote 6/6 conferido |

---

## ETAPA F — o que o `expo-doctor` disse (20/09/2026)

`18/20 verificações passam`. As duas que falham, com leitura honesta:

1. **"Validate packages against React Native Directory package metadata"** —
   aviso informativo: `react-native-background-actions` não consta como testado na
   Nova Arquitetura, e os pacotes `@vali98/react-native-*` e `cui-llama.rn` não têm
   metadados no diretório (são módulos próprios do projeto / fork do llama.cpp).
   **Não é defeito** e não tem relação com o crash de abertura.
2. **"Check that packages match versions required by installed Expo SDK"** —
   dependências um pouco atrás do recomendado para o SDK 55 (muitas diferenças de
   *patch*, ex.: `expo` 55.0.17 vs ~55.0.31; `@types/jest` 30 vs 29.5.14;
   `react-native-keyboard-controller` minor). O projeto **compila e roda** com essas
   versões — os builds nº 16 e nº 17 são prova. Subir dependências agora seria
   migração grande, mudaria a árvore congelada e invalidaria o build de validação,
   **sem nenhuma ligação demonstrada com o crash**. Por isso **nada foi alterado**,
   conforme a regra: *não fazer migração grande sem antes confirmar que está ligado
   ao crash*.

---

## REGRAS ATIVAS (valem até o usuário revogar)

1. **Uma versão só, congelada.** `versionName`/`versionCode` não mudam durante a
   investigação. Nada de 1.1.14, 1.1.15, `Lunaria-final`, `Lunaria-fix`…
2. **Um projeto só.** Existe apenas `/home/user/lunaria-src/lunaria-next`. Não
   duplicar, não renomear, não copiar para pasta nova, não descartar o workspace.
3. **Nenhum build sem ordem.** Durante a investigação não se gera APK. Se um build
   falhar, corrige-se no MESMO projeto, na MESMA versão.
4. **Uma etapa por vez**, e `WORK_PROGRESS.md` atualizado depois de cada uma.
5. **Antes de continuar: verificar o estado** (`CURRENT_VERSION`, `app/`, `entrega/`).
6. **Não refazer o que já está feito** — as etapas A–G estão concluídas e com
   evidência apontada acima.
7. **Release final** só depois de `REAL_DEVICE_VALIDATION` deixar de ser
   NOT_TESTED, e mesmo assim será o **mesmo** build de validação.

## COMO RETOMAR (passo a passo do próximo agente)

1. Ler este arquivo até o fim.
2. Ler `STATUS.md` (últimas seções) e `TEST_REPORT.md` (§16.7 a §16.11).
3. Conferir: `grep -n "versionName\|versionCode" android/app/build.gradle`
   (tem de dizer 1.1.13 / 17) e `find app -type f | wc -l` (tem de dizer 28).
4. Executar o teste que trava o defeito do aparelho:
   `npx jest tests/render/rotas-carregam.test.tsx` → tem de dar **29/29**.
5. Continuar do `NEXT_STEP`. **Não** repetir etapas concluídas. **Não** mudar
   versão. **Não** iniciar build.
