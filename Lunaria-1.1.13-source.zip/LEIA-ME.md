# Entrega — Lunaria 1.1.13 (20/09/2026)

> **Rodada atual (1.1.13) — a causa do fechamento na abertura foi encontrada e corrigida.**
>
> A 1.1.12 **não estava corrigida**, e o seu teste no A05s provou isso: mesma exceção,
> `Cannot read property 'ErrorBoundary' of undefined`, fechando antes de qualquer tela.
> Esta rodada não fez outro build às cegas (você proibiu, com razão), não escondeu o
> erro com `try/catch`, não pôs `ErrorBoundary` por cima e não tirou nenhuma função.
>
> **O que era:** um **ciclo de importação** criado junto com a função de bloqueio:
>
> ```
> lib/state/AppLock.ts  →  lib/state/TTS.ts  →  lib/state/Chat.ts  →  lib/state/AppLock.ts
> ```
>
> O `app/_layout.tsx` — a **raiz** que o Expo Router carrega primeiro — importa o
> `AppLock`. Ao avaliar essa cadeia, o Metro chegava ao `TTS.ts` com o `Chat.ts` ainda
> "em avaliação"; nessa situação toda importação do `Chat` vale `undefined`, e o
> `useInference.subscribe(...)` que fecha o `TTS.ts` (linha 99) lançava
> `Cannot read property 'subscribe' of undefined`.
>
> **O que faltava entender no logcat:** em produção, o Metro envolve a avaliação de cada
> módulo e, quando ela lança, chama `ErrorUtils.reportFatalError` (é o
> `FATAL EXCEPTION … JavascriptException` que você viu) e **devolve `undefined`**. O
> `loadRoute()` da rota recebeu esse `undefined` e o `fromImport` do Expo Router quebrou
> ao desestruturar — exatamente a mensagem do seu telefone. A chave da rota **estava**
> no bundle (conferi no bytecode Hermes do APK que você instalou); o que estava errado
> era o grafo de importação.
>
> **O que mudou:** o bloqueio deixou de conhecer a leitura em voz alta. Quando você
> bloqueia, o `AppLock` avisa por um barramento novo
> (`lib/state/EventosBloqueio.ts`, um arquivo sem nenhuma importação) e o `TTS` escuta.
> O comportamento é o mesmo de antes — a voz para no ato —, e o ciclo desapareceu.
>
> **E a segunda parte do seu pedido:** `app/` virou só rotas. Antes eram **118
> arquivos, todos descobertos como rota** pelo Expo Router (inclusive botões, folhas e
> pedaços de tela). Agora: **28 arquivos em `app/`, 27 rotas — só telas**, e cada rota
> é um arquivo de uma linha que reexporta a tela de `src/`. O código foi para
> `src/components/**` e `src/screens/**`, e a navegação continua **idêntica**
> (`/screens/ChatScreen`, `/screens/AppSettingsScreen/ColorSelector` etc. — as quatro
> sub-rotas de verdade continuam existindo e têm teste que as confere).
>
> **Provas desta rodada** (todas no ambiente, não no aparelho):
> `tests/render/rotas-carregam.test.tsx` **29/29** — carrega **todas as 28 rotas de
> `app/`**, uma a uma, como o aplicativo faz na abertura; é esta suíte que reprova se o
> defeito do seu telefone voltar (prova causal em `TEST_REPORT.md` §16.7);
> `raiz-carrega` **5/5** — a falha exata do seu telefone, agora presa a uma suíte;
> `arquitetura-rotas` **4/4** — `app/` só com rotas, toda rota navegada tem arquivo e
> **o grafo não tem ciclo**; `bloqueio-silencia` **2/2** — o bloqueio para a voz pelo
> caminho novo; render **142/142** (17 suítes); unitários **180/180** (os 3 últimos são
> do limite de uso que chega embrulhado em erro de servidor — §16.10); `tsc` limpo;
> `eslint` com 0 erros. E o teto de 5.000 mensagens da busca, que era só projetado,
> agora está **medido** (§16.11).
>
> **O que continua sem prova, sem enfeite: se o aplicativo abre no A05s.** Isso é o
> item 29 do `CHECKLIST_APARELHO.md` e é o único teste que fecha este assunto.

Esta entrega é a anterior (**geração de imagem** e **bloqueio por senha/PIN**, com o
texto das conversas e a memória cifrados) com a correção acima. Continua tudo o que já
funcionava desde a 1.0.0: conversa, personalidade editável em pt-BR, tratamento
masculino ao Hamura, GGUF local, API remota, ditado, leitura em voz alta,
Pesquisa/Fatos e memória opcional.

| Arquivo | O que é |
| --- | --- |
| `Lunaria-1.1.13-arm64-release.apk` | **É este que você instala.** Versão 1.1.13 (código 17), arm64, assinado com a mesma chave de sempre — atualiza por cima da 1.0.0/1.1.x sem desinstalar. Sai com o R8 desligado de propósito (fica maior, e é o que permite o relatório de diagnóstico vir à tela em vez de silêncio) |
| `Lunaria-1.1.13-source.zip` | Código-fonte desta versão (sem **nenhum** keystore, sem senha, sem chave) |
| `Lunaria-1.0.0-source.zip` | Fonte da 1.0.0, guardada para recompilar a base se for preciso |
| `CORRECOES.md` | O que mudou em cada rodada, com a prova de cada correção |
| `exemplo_horde.webp` / `exemplo_pollinations.jpg` / `exemplo_horde_429_recuperado.webp` | Três imagens geradas de verdade (exemplos de teste, não fazem parte do app) |
| `TEST_REPORT.md` | **Relatório de testes**, separando o que foi executado aqui (lógica, arquitetura e renderização), o que não pôde ser (emulador, com o motivo técnico) e o que depende do seu aparelho. A rodada 1.1.13 está na seção 16 |
| `BUGS_FOUND.md` | Todos os defeitos, um por um, com a prova — a causa do fechamento na abertura está no **§BG** |
| `STATUS.md` | Estado da entrega por rodada; a 1.1.13 é a última, com o diagnóstico e as quatro perguntas obrigatórias respondidas |
| `RELATORIO_DE_TESTES.md` | Relatório das rodadas anteriores (histórico) |
| `INSTALACAO_E_CONFIGURACAO.md` | Passo a passo de instalação, provedor de imagem e ajustes |
| `GERACAO_DE_IMAGEM_E_BLOQUEIO.md` | Como as duas funções novas funcionam, por dentro |
| `CHECKLIST_APARELHO.md` | **Comece por aqui depois de instalar**: as verificações que só o aparelho responde. Os itens **29, 30 e 31** são desta rodada; o **29** é o que decide se o fechamento acabou |
| `MATRIZ_DE_CRITERIOS.md` | Cada pedido do encargo → onde está no código → o que já foi testado → o que falta |
| `SHA256.txt` | Conferência de integridade dos dois arquivos principais |

Se você quiser compilar em modo de **depuração** a partir do ZIP, o Android exige
um keystore de depuração. Ele não vai no pacote (nenhum keystore vai), e recriar é
uma linha:

```bash
keytool -genkeypair -v -keystore android/app/debug.keystore -storepass android \
  -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=Android Debug,O=Android,C=US"
```

Fora desta pasta: `lunaria-assinatura/` com o keystore e a senha (**nunca
publicar**) e `lunaria-src/lunaria-next/` com o projeto completo.

## Onde cada coisa mora agora

| pasta | o que tem | regra |
| --- | --- | --- |
| `app/` | **só rotas e o layout** (28 arquivos) | cada rota é um arquivo de uma linha: `export { default } from '@screens/…'`. Nada de componente, hook ou serviço aqui — há teste automático que reprova quem tentar |
| `src/screens/**` | as telas de verdade (o que `app/` reexporta) | — |
| `src/components/**` | componentes visuais (botões, folhas, avatar, visualizador de imagem…) | — |
| `lib/**` | estado, segurança, motor de inferência, utilitários | inalterado |
| `db/**`, `assets/**`, `public/**` | banco, imagens, páginas locais | inalterado |
| `tests/**` | unitários (`test:unit`), render (`test:render`) e **arquitetura** | a suíte de arquitetura é nova e vigia os dois defeitos desta rodada |

Aliases do projeto (`tsconfig.json`): `@screens/*` → `src/screens/*`,
`@components/*` → `src/components/*`, `@lib/*` → `lib/*`.

## Leia isto antes de instalar

**Este APK é uma recompilação nova** (não é o arquivo da 1.1.12 reempacotado). A
assinatura é a mesma de sempre — `CN=Lunaria`, digest SHA-256 `c0271509…5719a` — então
a instalação por cima funciona sem desinstalar nem apagar dados.

Os números abaixo foram medidos **nesta** compilação. Nenhuma medição antiga foi
reaproveitada.

## Estado real, sem enfeite

**Medido nesta máquina (x86_64, 2 núcleos, ~1,9 GB de RAM, 25 GB de disco):**

- **Compila**: `:app:assembleRelease` para arm64-v8a terminou com
  **BUILD SUCCESSFUL in 20m 18s** no build principal, **3m 59s** na reconstrução
  intermediária, **16m 34s** na reconstrução final (código 16) e **16m 54s** no build
  que entrega a correção de cota (código 17) — 952 tarefas em cada. O ambiente desta sessão havia sido apagado de novo (JDK e SDK em
  `/opt` não sobrevivem entre turnos); o panorama completo e o script de restauração
  estão em `BUGS_FOUND.md` e em `lunaria-build/RESTAURAR_AMBIENTE.md`.
- **Assinado**: `apksigner verify` OK, mesmo certificado da 1.0.0 — a atualização por
  cima continua funcionando.
- **Tamanho**: 66.836.927 bytes (63,7 MiB). SHA-256 em `SHA256.txt`.
- **Testes de lógica**: **180 de 180** (`npm run test:unit`) — os 173 anteriores, os 4 de
  arquitetura (rotas finas, rotas navegadas com arquivo, grafo sem ciclo) e os 3 novos do
  limite de uso embrulhado em erro de servidor.
- **Testes de renderização**: **142 de 142** (`npm run test:render`, 17 suítes) — os
  106 anteriores, mais 5 que carregam a **raiz do contexto**, a **rota inicial** e a
  rota da conversa exatamente como o aplicativo faz na abertura, mais 2 que provam que
  o bloqueio silencia a leitura em voz alta pelo caminho novo, mais **29**
  (`tests/render/rotas-carregam.test.tsx`) que carregam **uma por uma todas as 28 rotas
  de `app/`** — a trava que reproduz o defeito de abertura: reintroduzindo a aresta
  antiga, essa suíte reprova na chave `./_layout.tsx` com a mesma mensagem do aparelho
  (prova em `TEST_REPORT.md` §16.7).
- **Tipos e estilo**: `tsc --noEmit` limpo; `eslint app db lib src` com 0 erros
  (58 avisos antigos, nenhum novo).
- **Estrutura conferida pelo próprio Expo Router**: `{"layout":1,"route":27}` e
  **27 rotas, todas com componente** — contra 117 rotas (com componentes no meio) na
  1.1.12.
- **APK conferido por dentro**: `versionName=1.1.13`, `versionCode=15`, pacote
  `br.aurora.luna.lunaria.next`, 48 bibliotecas `.so` arm64, `allowBackup=false`,
  `res/RT.gguf` (7,8 MB) e o bundle Hermes com as telas de bloqueio e de geração de
  imagem e o barramento novo (`EventosBloqueio`).

**Sobre as ferramentas deste ambiente**: `/opt` (JDK e SDK Android) não sobrevive
entre as sessões. Se for preciso recompilar, `bash lunaria-build/setup-toolchain.sh`
reinstala tudo (levou ~6 min nesta rodada) e `lunaria-build/build-apk-2.sh` já traz no
cabeçalho os quatro requisitos aprendidos (memória, disco, os dois NDKs e o R8 em modo
de compatibilidade). O keystore e a senha estão em `lunaria-assinatura/`.

**Não testado no aparelho** — este ambiente não tem aparelho, nem emulador, nem
`/dev/kvm`, e o APK é arm64. Ficam pendentes e **não** são apresentados como validados:
abrir no A05s (item 29), o bloqueio parando a voz (30), a navegação pelas telas e
sub-rotas (31), e tudo o que já estava pendente das rodadas anteriores (instalação,
geração de imagem no aparelho, cancelamento, queda de rede, cota esgotada,
salvar/compartilhar/apagar imagem, senha errada, reinício, volta do segundo plano,
abertura por notificação, biometria, troca de senha, migração dos dados e a conferência
de que nada protegido aparece antes do desbloqueio).

O que dá para afirmar com segurança: o APK instala em Android 7 ou superior (arm64),
atualiza por cima da 1.0.0/1.1.x e a causa do fechamento na abertura está identificada
e corrigida no código, com reprodução em casa do mesmo `TypeError` antes e depois.
O que só o seu aparelho pode responder: **se ele abre**.
