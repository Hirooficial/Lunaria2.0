import { SplashScreen, Stack, useRouter } from 'expo-router'
import { setOptions } from 'expo-splash-screen'
import { useEffect, useRef, useState } from 'react'
import { AppState, View } from 'react-native'
import { GestureHandlerRootView } from 'react-native-gesture-handler'
import { KeyboardProvider } from 'react-native-keyboard-controller'

import { AlertProvider } from '@components/views/Alert'
import DiagnosticBoundary from '@components/views/DiagnosticBoundary'
import ImageViewer from '@components/views/ImageViewer'
import { PortalHost } from '@components/views/Portal'
import { useAppStateNotificationObserver } from '@lib/notifications/Notifications'
import { useAppLock } from '@lib/state/AppLock'
import { useImageGeneration } from '@lib/state/ImageGeneration'
import { Theme } from '@lib/theme/ThemeManager'
import {
    breadcrumb,
    checkStartup,
    installGlobalErrorCapture,
    markStartupBegin,
    markStartupOk,
    recordError,
} from '@lib/utils/Diagnostics'
import { marcarEtapaJs } from '@lib/utils/TrilhaJs'
import LockScreen from '@screens/LockScreen'

SplashScreen.preventAutoHideAsync()
setOptions({
    fade: true,
    duration: 350,
})

// Antes de qualquer tela: um erro na montagem do React não passa por try/catch
// de componente, então é aqui que ele deixa de ser silencioso.
installGlobalErrorCapture()

/**
 * Primeira linha de qualquer coisa lançada, cortada — o suficiente para a trilha
 * dizer o que falhou sem carregar texto longo (e sem carregar dado pessoal).
 */
const textoCurto = (erro: unknown) =>
    `${erro instanceof Error ? `${erro.name}: ${erro.message}` : erro}`.split('\n')[0].slice(0, 120)

const Layout = () => {
    const { color } = Theme.useTheme()
    const router = useRouter()
    useAppStateNotificationObserver()

    const ready = useAppLock((state) => state.ready)
    const locked = useAppLock((state) => state.locked)
    const configured = useAppLock((state) => state.configured)
    const autoLockMinutes = useAppLock((state) => state.settings.autoLockMinutes)
    const blockScreenshots = useAppLock((state) => state.settings.blockScreenshots)
    const init = useAppLock((state) => state.init)
    const lockNow = useAppLock((state) => state.lockNow)
    const initImage = useImageGeneration((state) => state.init)

    const backgroundedAt = useRef<number | undefined>(undefined)

    // Lido **uma vez**, no primeiro render: se a abertura anterior não chegou ao
    // fim, isto conta a falha e decide o modo seguro. Em `useState` (e não em
    // `useRef`) porque o valor inicial é calculado só na primeira vez.
    const [startup] = useState(() => checkStartup())

    // Uma vez por abertura: descobre se existe senha configurada antes de
    // mostrar qualquer coisa. Enquanto `ready` for falso, a tela fica em branco
    // (fail-closed) — nenhuma conversa aparece nesse intervalo.
    //
    // Cada passo é registrado e cada falha é contida: uma camada nova com
    // defeito derruba a si mesma, nunca o aplicativo inteiro.
    useEffect(() => {
        const abrir = async () => {
            // A partir daqui o React montou uma tela: é o primeiro ponto em que o
            // JavaScript pode contar que chegou vivo. Se o processo morrer daqui
            // para frente sem exceção, a trilha mostrará esta linha — e não só o
            // "4/5 tela criada" do lado nativo.
            marcarEtapaJs('3/8 tela inicial montou')
            markStartupBegin()
            breadcrumb(`abertura: modo seguro ${startup.safeMode ? 'ligado' : 'desligado'}`)
            if (startup.failedLastTime)
                breadcrumb(`abertura: a anterior nao terminou (${startup.failures}x)`)

            try {
                breadcrumb('bloqueio: lendo')
                await init()
                breadcrumb('bloqueio: pronto')
                marcarEtapaJs('4/8 bloqueio pronto')
            } catch (error) {
                recordError('bloqueio', error)
                marcarEtapaJs(`! falha ao preparar o bloqueio: ${textoCurto(error)}`)
            }

            if (startup.safeMode) {
                breadcrumb('imagens: puladas (modo seguro)')
                marcarEtapaJs('5/8 imagens puladas (modo seguro)')
                return
            }
            try {
                breadcrumb('imagens: lendo ajustes')
                initImage()
                breadcrumb('imagens: pronto')
                marcarEtapaJs('5/8 imagens prontas')
            } catch (error) {
                recordError('imagens', error)
                marcarEtapaJs(`! falha ao preparar as imagens: ${textoCurto(error)}`)
            }
        }
        void abrir()
    }, [init, initImage, startup])

    // Retorno do segundo plano: exige a senha depois do tempo configurado.
    //
    // Defeito relatado em 21/09/2026: "Bloquear ao sair" não funcionava. Duas
    // correções aqui: (1) com a política "ao sair" (0 min) o bloqueio acontece
    // **na saída**, não só na volta — o estado fica trancado mesmo se o Android
    // matar o processo enquanto o aplicativo está atrás; (2) cada decisão deixa
    // registro (`APPSTATE_BACKGROUND`, `APPSTATE_ACTIVE`,
    // `AUTO_LOCK_POLICY_APPLIED`), para não existir mais "não bloqueou e não sei
    // por quê". Quem manda no "está configurado" é o cofre (ver `AppLock.init`).
    useEffect(() => {
        const listener = AppState.addEventListener('change', (nextState) => {
            if (nextState === 'background' || nextState === 'inactive') {
                backgroundedAt.current = Date.now()
                breadcrumb(`APPSTATE_BACKGROUND`)
                if (!configured) return
                if (autoLockMinutes === 0) {
                    breadcrumb('AUTO_LOCK_POLICY_APPLIED politica=ao sair -> bloqueando na saída')
                    lockNow('segundo-plano')
                }
                return
            }
            if (nextState !== 'active') return
            breadcrumb('APPSTATE_ACTIVE')
            if (!configured) return

            const away = backgroundedAt.current ? Date.now() - backgroundedAt.current : 0
            backgroundedAt.current = undefined
            // `0` minutos significa "bloqueia assim que sai da frente".
            const deveBloquear = autoLockMinutes === 0 || away >= autoLockMinutes * 60_000
            breadcrumb(
                `AUTO_LOCK_POLICY_APPLIED politica=${
                    autoLockMinutes === 0 ? 'ao sair' : `${autoLockMinutes} min`
                } fora=${Math.round(away / 1000)}s bloquear=${deveBloquear}`
            )
            // `locked` é lido do estado vivo: se já bloqueou na saída (ou pelo
            // botão), não repete a chamada.
            if (deveBloquear && !useAppLock.getState().locked) lockNow('segundo-plano')
        })
        return () => listener.remove()
    }, [autoLockMinutes, configured, lockNow])

    // Abertura concluída: `markStartupOk` estava escrito e **nunca** era chamado —
    // então toda abertura deixava a marca "em curso" para trás e a abertura
    // seguinte era contada como falha; com duas, o aplicativo entrava em modo
    // seguro sozinho e para sempre (o relatório de diagnóstico dizia "aberturas
    // seguidas sem terminar" sem que nada tivesse falhado). Chegar aqui com
    // `ready` é justamente a definição de abertura concluída.
    useEffect(() => {
        if (!ready) return
        markStartupOk()
        breadcrumb('abertura: concluída')
    }, [ready])

    // Impedir capturas de tela (opcional, desligado por padrão).
    //
    // Carregado **tardiamente**, de propósito: se este módulo nativo tiver
    // qualquer problema no aparelho, ele deixa de funcionar — e só ele. Um
    // `import` no topo do arquivo, como estava, fazia a falha dele virar falha
    // da abertura inteira.
    useEffect(() => {
        if (!blockScreenshots || startup.safeMode) return
        let cancelado = false

        import('expo-screen-capture')
            .then((ScreenCapture) => {
                if (cancelado) return
                return ScreenCapture.preventScreenCaptureAsync('lunaria')
            })
            .catch((error) => recordError('capturas', error))

        return () => {
            cancelado = true
            import('expo-screen-capture')
                .then((ScreenCapture) => ScreenCapture.allowScreenCaptureAsync('lunaria'))
                .catch(() => undefined)
        }
    }, [blockScreenshots, startup.safeMode])

    // Depois de desbloquear, **relê a memória de pesquisa**.
    //
    // Por que isto existe: a memória é cifrada. Se o aplicativo abriu bloqueado, a
    // primeira leitura aconteceu com o cofre fechado e devolveu "nada" — o estado
    // em memória nasceu vazio. Sem esta releitura, a primeira nota nova seria
    // gravada por cima de todas as antigas (o adaptador recusa essa gravação por
    // segurança, mas a memória ficaria sem gravar até a próxima abertura).
    //
    // Roda quando o bloqueio termina (e no primeiro efeito, se não houver bloqueio
    // configurado). Qualquer falha fica contida: memória não é motivo para derrubar
    // a abertura.
    useEffect(() => {
        if (locked) return
        Promise.resolve()
            .then(() => import('@lib/state/ResearchMemory'))
            .then(({ useResearchMemoryStore }) => useResearchMemoryStore.persist.rehydrate())
            .catch((error) => recordError('memoria', error))
    }, [locked])

    // Depois de desbloquear, atende a notificação que motivou a abertura.
    useEffect(() => {
        if (locked) return
        const pending = useAppLock.getState().pendingChat
        if (!pending) return
        useAppLock.getState().setPendingChat(undefined)
        Promise.all([import('@lib/state/Characters'), import('@lib/state/Chat')])
            .then(async ([{ Characters }, { Chats }]) => {
                await Chats.useChatState.getState().load(pending.chatId)
                await Characters.useCharacterStore.getState().setCard(pending.characterId)
                router.navigate('/screens/ChatScreen')
            })
            .catch(() => undefined)
    }, [locked, router])

    return (
        <DiagnosticBoundary>
            <GestureHandlerRootView style={{ flex: 1 }}>
                <KeyboardProvider>
                    <AlertProvider />
                    {!ready ? (
                        // Ainda não se sabe se há bloqueio: não mostra nada do app.
                        <View style={{ flex: 1, backgroundColor: color.neutral._100 }} />
                    ) : locked ? (
                        <LockScreen />
                    ) : (
                        <Stack
                            screenOptions={{
                                headerBackButtonDisplayMode: 'minimal',
                                headerStyle: { backgroundColor: color.neutral._100 },
                                headerTitleStyle: { color: color.text._100 },
                                headerTintColor: color.text._100,
                                contentStyle: { backgroundColor: color.neutral._100 },
                                headerShadowVisible: false,
                                headerTitleAlign: 'center',
                                statusBarStyle: 'auto',
                            }}>
                            <Stack.Screen name="index" options={{ animation: 'fade' }} />
                        </Stack>
                    )}
                    {/* O visualizador fica fora do gate: ele só é aberto por dentro do
                    aplicativo já desbloqueado, e ao bloquear é fechado. */}
                    {!locked && <ImageViewer />}
                    <PortalHost />
                </KeyboardProvider>
            </GestureHandlerRootView>
        </DiagnosticBoundary>
    )
}

export default Layout
