/**
 * Cofre de arquivos privados.
 *
 * Toda imagem gerada é gravada **cifrada** em `document/private/`, com o
 * envelope `.lunaenc` (iv + ciphertext + tag). O arquivo em claro só existe
 * quando o usuário abre a imagem ou exporta de propósito — e nesse caso vive em
 * `cache/`, apagado ao bloquear o aplicativo.
 *
 * O cofre mantém a chave de dados (DEK) só em memória, e só depois do
 * desbloqueio: com o aplicativo bloqueado, nem o próprio app consegue ler as
 * imagens.
 */

import { Directory, File, Paths } from 'expo-file-system'

import { detectImageType, ENVELOPE_SUFFIX, viewFileName } from '@lib/security/PrivateNames'

import { decryptBytes, encryptBytes } from './Crypto'
import { registrarFonteDaChave } from './PrivateText'

const PRIVATE_DIR_NAME = 'private'

export const privateDirectory = () => new Directory(Paths.document, PRIVATE_DIR_NAME)

export const ensurePrivateDirectory = (): Directory => {
    const directory = privateDirectory()
    if (!directory.exists) {
        directory.create({ intermediates: true, idempotent: true })
    }
    return directory
}

const randomSuffix = () => Math.random().toString(36).slice(2, 8)

export type VaultFile = {
    fileName: string
    bytes: number
    modified: number
}

class PrivateVault {
    private key: Uint8Array | undefined

    /** Chamado depois de autenticar. A chave fica só na memória do processo. */
    unlock = (key: Uint8Array) => {
        this.key = key
    }

    /** Chamado ao bloquear: some com o acesso aos arquivos cifrados. */
    lock = () => {
        this.key = undefined
    }

    /**
     * A chave do cofre, para quem precisa cifrar **texto** (banco e memória de
     * pesquisa) com a mesma proteção das imagens. Síncrona de propósito: o banco
     * lê e grava de forma síncrona, e uma chave assíncrona não serviria lá.
     */
    chaveAtual = (): Uint8Array | undefined => this.key

    get isUnlocked() {
        return this.key !== undefined
    }

    private requireKey = (): Uint8Array => {
        if (!this.key) {
            throw new Error('Cofre bloqueado: desbloqueie a Lunaria para acessar as imagens.')
        }
        return this.key
    }

    /**
     * Grava bytes cifrados. O nome termina em `.lunaenc` e a extensão interna é
     * descoberta pelo conteúdo (o provedor manda WebP ou JPEG, não escolhemos).
     */
    writeFile = (bytes: Uint8Array, label?: string): { fileName: string; uri: string } => {
        const key = this.requireKey()
        const directory = ensurePrivateDirectory()
        const detected = detectImageType(bytes)
        const base = label?.trim()
            ? label.trim().replace(/[^a-zA-Z0-9-_]/g, '')
            : `${Date.now()}-${randomSuffix()}`
        const fileName = `${base}.${detected.extension}${ENVELOPE_SUFFIX}`

        const envelope = encryptBytes(key, bytes)
        const target = new File(directory, fileName)
        target.write(envelope)

        return { fileName, uri: `private://${fileName}` }
    }

    readFile = (fileName: string): Uint8Array => {
        const key = this.requireKey()
        const source = new File(ensurePrivateDirectory(), fileName)
        if (!source.exists) throw new Error(`Imagem não encontrada no cofre: ${fileName}`)
        return decryptBytes(key, source.bytesSync())
    }

    deleteFile = (fileName: string): void => {
        const target = new File(ensurePrivateDirectory(), fileName)
        if (target.exists) target.delete()
    }

    listFiles = (): VaultFile[] => {
        const directory = ensurePrivateDirectory()
        return directory
            .list()
            .filter((item): item is File => item instanceof File)
            .filter((item) => item.name.endsWith(ENVELOPE_SUFFIX))
            .map((item) => ({
                fileName: item.name,
                bytes: item.size ?? 0,
                modified: item.modificationTime ?? 0,
            }))
    }

    /**
     * Decifra para um arquivo temporário em `cache/` e devolve o URI que o
     * visualizador consegue abrir. O nome **não** pode terminar em `.lunaenc`,
     * senão a visualização recusa o arquivo (ver `viewFileName`).
     */
    exportToCache = (fileName: string): { uri: string; name: string } => {
        const bytes = this.readFile(fileName)
        const name = viewFileName(fileName)
        const target = new File(Paths.cache, name)
        if (target.exists) target.delete()
        target.write(bytes)
        return { uri: target.uri, name }
    }

    /** Apaga um temporário específico (ao apagar uma imagem ou bloquear). */
    removeFromCache = (fileName: string): void => {
        const target = new File(Paths.cache, viewFileName(fileName))
        if (target.exists) target.delete()
    }

    /** Limpeza geral dos temporários: chamada em todo bloqueio. */
    clearCache = (): void => {
        const cache = new Directory(Paths.cache)
        for (const item of cache.list()) {
            if (item instanceof File && item.name.startsWith('view-')) item.delete()
        }
    }
}

export const privateVault = new PrivateVault()

// Liga a cifra de **texto** (conversas e memória) à chave do cofre. A ligação fica
// aqui, e não no `PrivateText`, para aquele arquivo continuar puro e testável em
// Node sem carregar nada nativo. Se este módulo nunca for avaliado, a cifra de
// texto simplesmente não acontece — e nada quebra por isso.
registrarFonteDaChave(() => privateVault.chaveAtual())
