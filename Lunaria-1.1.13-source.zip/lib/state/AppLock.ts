/**
 * Estado do bloqueio por senha/PIN.
 *
 * Princípios que este arquivo respeita (pedidos explicitamente):
 *  - o aplicativo começa **fechado** (`ready: false` trata como bloqueado);
 *    nada de conversa ou imagem aparecendo antes da autenticação;
 *  - autenticação é exigida para entrar, para trocar a senha e para desligar a
 *    proteção;
 *  - erros seguidos geram espera progressiva e **nunca** apagam dados;
 *  - ao bloquear: para a leitura em voz alta, desliga o microfone, fecha o cofre
 *    e limpa os temporários de imagem;
 *  - a senha nunca é guardada — só o verificador derivado dela.
 */

import type * as LocalAuthenticationModule from 'expo-local-authentication'
import { AppStateStatus } from 'react-native'
import { create } from 'zustand'

import {
    DEFAULT_AUTO_LOCK_MINUTES,
    lockoutSecondsFor,
    MIN_SECRET_LENGTH,
    validateSecret,
} from '@lib/security/LockPolicy'
import { clearPrivateImageCache } from '@lib/security/PrivateImageCache'
import { privateVault } from '@lib/security/PrivateStorage'
import {
    biometricAccessEnabled,
    changeSecret as changeVaultSecret,
    createVault,
    destroyVault,
    disableBiometricAccess,
    enableBiometricAccess,
    secretIsCorrect,
    unlockVault,
    unlockWithBiometric,
    vaultExists,
} from '@lib/security/SecureVault'
import { avisarBloqueio } from '@lib/state/EventosBloqueio'
import { mmkv } from '@lib/storage/MMKV'
import { breadcrumb, describeError, recordError } from '@lib/utils/Diagnostics'
import { carregarModuloNativo } from '@lib/utils/NativeModules'

/**
 * A biometria é carregada sob demanda: importar `expo-local-authentication` no
 * topo faria o aplicativo fechar na abertura em aparelho sem o módulo, antes
 * mesmo de a tela de bloqueio existir. Ver `lib/utils/NativeModules.ts`.
 */
const carregarLocalAuthentication = () =>
    carregarModuloNativo<typeof LocalAuthenticationModule>('expo-local-authentication', () =>
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        require('expo-local-authentication')
    )

const SETTINGS_KEY = 'lunaria-lock-settings-v1'

/** Motivo do bloqueio — vai para o log e para o texto da tela. */
export type LockReason = 'inicio' | 'segundo-plano' | 'manual' | 'tempo'

export type LockSettings = {
    /** Proteção ligada? Desligada por padrão. */
    enabled: boolean
    /** Atalho de biometria (exige senha para ativar/desativar). */
    biometric: boolean
    /** Minutos fora do aplicativo até bloquear. `0` = ao sair da frente. */
    autoLockMinutes: number
    /** Impede captura de tela e esconde o conteúdo no seletor de apps. */
    blockScreenshots: boolean
    /** Esconde o texto da mensagem nas notificações. */
    hideInNotifications: boolean
}

const DEFAULT_SETTINGS: LockSettings = {
    enabled: false,
    biometric: false,
    autoLockMinutes: DEFAULT_AUTO_LOCK_MINUTES,
    blockScreenshots: false,
    hideInNotifications: true,
}

const readSettings = (): LockSettings => {
    const raw = mmkv.getString(SETTINGS_KEY)
    if (!raw) return { ...DEFAULT_SETTINGS }
    try {
        return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<LockSettings>) }
    } catch {
        return { ...DEFAULT_SETTINGS }
    }
}

const writeSettings = (settings: LockSettings) => {
    mmkv.set(SETTINGS_KEY, JSON.stringify(settings))
}

const FAILURES_KEY = 'lunaria-lock-failures-v1'

type AppLockState = {
    /** `false` até a inicialização terminar: nesse estado o app não mostra conteúdo. */
    ready: boolean
    /** `true` = tela de bloqueio na frente. */
    locked: boolean
    /** Existe senha configurada? */
    configured: boolean
    /** Nome do histórico que aguardava destravar (vingo de notificação). */
    pendingChat?: { chatId: number; characterId: number }
    settings: LockSettings
    failures: number
    /** Segundos restantes de espera após erros seguidos. */
    lockoutSeconds: number
    biometricAvailable: boolean
    lastReason?: LockReason

    init: () => Promise<void>
    /** Falha ao consultar o cofre nesta abertura (vazio quando deu tudo certo). */
    initError?: string
    unlock: (secret: string) => Promise<boolean>
    unlockWithBiometrics: () => Promise<boolean>
    lockNow: (reason: LockReason) => void
    /** Primeira configuração: cria o cofre e liga a proteção. */
    enableLock: (secret: string) => Promise<{ ok: boolean; error?: string }>
    changeSecret: (current: string, next: string) => Promise<{ ok: boolean; error?: string }>
    disableLock: (secret: string) => Promise<{ ok: boolean; error?: string }>
    /** Esqueceu a senha: apaga o cofre e mantém as conversas. */
    resetVaultKeepingChats: (nextSecret: string) => Promise<{ ok: boolean; error?: string }>
    setAutoLock: (minutes: number) => Promise<void>
    setBlockScreenshots: (value: boolean) => Promise<void>
    setHideInNotifications: (value: boolean) => Promise<void>
    setBiometric: (value: boolean, secret: string) => Promise<{ ok: boolean; error?: string }>
    setPendingChat: (value?: { chatId: number; characterId: number }) => void
    registerFailure: () => void
    clearFailures: () => void
    tickLockout: () => void
}

const stopAudioAndMic = async () => {
    // Quem para a leitura em voz alta e o microfone são os ouvintes do
    // barramento (o TTS, por exemplo). Importar o TTS daqui criava o ciclo
    // AppLock → TTS → Chat → AppLock, que derrubava o aplicativo na abertura.
    // Ver o comentário longo em `EventosBloqueio.ts`.
    await avisarBloqueio()
}

export const useAppLock = create<AppLockState>()((set, get) => ({
    ready: false,
    // Começa bloqueado; `init` decide se há proteção configurada.
    locked: true,
    configured: false,
    settings: readSettings(),
    failures: Number(mmkv.getString(FAILURES_KEY) ?? 0),
    lockoutSeconds: 0,
    biometricAvailable: false,
    initError: undefined,

    init: async () => {
        breadcrumb('cofre: lendo ajustes')
        const settings = readSettings()
        let configured = false
        let initError: string | undefined

        // A leitura do cofre conversa com o Keystore do aparelho. Se ela falhar,
        // o aplicativo **não** pode morrer por isso: registra, avisa na tela e
        // segue com a proteção desligada. O conteúdo cifrado continua cifrado —
        // o que muda é que a falha fica visível em vez de virar tela preta.
        try {
            configured = await vaultExists()
            breadcrumb(`cofre: ${configured ? 'existe' : 'nao configurado'}`)
        } catch (error) {
            initError = describeError(error)
            recordError('cofre', error)
        }

        let biometricAvailable = false
        const biometria = carregarLocalAuthentication()
        try {
            biometricAvailable = biometria ? await biometria.hasHardwareAsync() : false
        } catch {
            biometricAvailable = false
        }

        // Sem senha configurada, o aplicativo abre direto — mas só aqui, depois
        // de ler o disco. Antes disto, `locked` continua `true` (fail-closed).
        set({
            settings,
            configured,
            biometricAvailable,
            locked: settings.enabled && configured,
            ready: true,
            initError,
        })
    },

    unlock: async (secret) => {
        const { failures } = get()
        const wait = lockoutSecondsFor(failures)
        if (wait > 0 && get().lockoutSeconds > 0) return false

        const ok = await secretIsCorrect(secret)
        if (!ok) {
            const nextFailures = failures + 1
            mmkv.set(FAILURES_KEY, nextFailures)
            set({ failures: nextFailures, lockoutSeconds: lockoutSecondsFor(nextFailures) })
            return false
        }

        const dek = await unlockVault(secret)
        privateVault.unlock(dek)
        get().clearFailures()
        set({ locked: false, lastReason: undefined })
        return true
    },

    unlockWithBiometrics: async () => {
        const enabled = await biometricAccessEnabled()
        if (!enabled) return false
        const biometria = carregarLocalAuthentication()
        if (!biometria) return false
        const result = await biometria.authenticateAsync({
            promptMessage: 'Desbloquear a Lunaria',
            cancelLabel: 'Usar senha',
        })
        if (!result.success) return false
        const dek = await unlockWithBiometric()
        if (!dek) return false
        privateVault.unlock(dek)
        get().clearFailures()
        set({ locked: false, lastReason: undefined })
        return true
    },

    lockNow: (reason) => {
        const { settings, configured } = get()
        if (!settings.enabled || !configured) return
        // Ordem importa: corta áudio/microfone, fecha o cofre e limpa temporários.
        stopAudioAndMic()
        privateVault.lock()
        clearPrivateImageCache()
        set({ locked: true, lastReason: reason })
    },

    enableLock: async (secret) => {
        const verdict = validateSecret(secret)
        if (!verdict.ok) return { ok: false, error: verdict.reason }

        const dek = await createVault(secret)
        privateVault.unlock(dek)
        const settings: LockSettings = { ...get().settings, enabled: true }
        writeSettings(settings)
        set({ settings, configured: true, locked: false })
        get().clearFailures()
        return { ok: true }
    },

    changeSecret: async (current, next) => {
        if (!(await secretIsCorrect(current))) {
            get().registerFailure()
            return { ok: false, error: 'A senha atual não confere.' }
        }
        const verdict = validateSecret(next)
        if (!verdict.ok) return { ok: false, error: verdict.reason }
        await changeVaultSecret(current, next)
        // A DEK não mudou; se a biometria estava ligada, continua válida.
        get().clearFailures()
        return { ok: true }
    },

    disableLock: async (secret) => {
        if (!(await secretIsCorrect(secret))) {
            get().registerFailure()
            return { ok: false, error: 'Senha incorreta.' }
        }
        // Desligar a proteção apaga o cofre: as imagens cifradas não teriam mais
        // como ser abertas. O usuário é avisado disso antes, na tela.
        await destroyVault()
        await disableBiometricAccess()
        privateVault.lock()
        clearPrivateImageCache()
        const settings: LockSettings = { ...get().settings, enabled: false, biometric: false }
        writeSettings(settings)
        set({ settings, configured: false, locked: false })
        get().clearFailures()
        return { ok: true }
    },

    resetVaultKeepingChats: async (nextSecret) => {
        const verdict = validateSecret(nextSecret)
        if (!verdict.ok) return { ok: false, error: verdict.reason }
        await destroyVault()
        const dek = await createVault(nextSecret)
        privateVault.unlock(dek)
        const settings: LockSettings = { ...get().settings, enabled: true }
        writeSettings(settings)
        set({ settings, configured: true, locked: false })
        get().clearFailures()
        return { ok: true }
    },

    setAutoLock: async (minutes) => {
        const settings: LockSettings = { ...get().settings, autoLockMinutes: minutes }
        writeSettings(settings)
        set({ settings })
    },

    setBlockScreenshots: async (value) => {
        const settings: LockSettings = { ...get().settings, blockScreenshots: value }
        writeSettings(settings)
        set({ settings })
    },

    setHideInNotifications: async (value) => {
        const settings: LockSettings = { ...get().settings, hideInNotifications: value }
        writeSettings(settings)
        set({ settings })
    },

    setBiometric: async (value, secret) => {
        if (!(await secretIsCorrect(secret))) {
            get().registerFailure()
            return { ok: false, error: 'Senha incorreta: a biometria só muda com autenticação.' }
        }
        if (value) {
            const dek = await unlockVault(secret)
            await enableBiometricAccess(dek)
        } else {
            await disableBiometricAccess()
        }
        const settings: LockSettings = { ...get().settings, biometric: value }
        writeSettings(settings)
        set({ settings })
        return { ok: true }
    },

    setPendingChat: (value) => set({ pendingChat: value }),

    registerFailure: () => {
        const nextFailures = get().failures + 1
        mmkv.set(FAILURES_KEY, nextFailures)
        set({ failures: nextFailures, lockoutSeconds: lockoutSecondsFor(nextFailures) })
    },

    clearFailures: () => {
        mmkv.remove(FAILURES_KEY)
        set({ failures: 0, lockoutSeconds: 0 })
    },

    tickLockout: () => {
        const current = get().lockoutSeconds
        if (current > 0) set({ lockoutSeconds: current - 1 })
    },
}))

/** Rótulo de minutos usado na tela: 0 é uma opção legítima ("ao sair"). */
export const MIN_SECRET = MIN_SECRET_LENGTH

export const shouldLockAfterBackground = (
    state: AppStateStatus,
    autoLockMinutes: number,
    secondsAway: number
): boolean => {
    if (state !== 'background' && state !== 'inactive') return false
    if (autoLockMinutes === 0) return true
    return secondsAway >= autoLockMinutes * 60
}
