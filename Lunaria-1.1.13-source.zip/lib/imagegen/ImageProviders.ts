/**
 * Provedores de geração de imagem.
 *
 * Decisão de projeto (registrada em `IMAGEM_LOCAL_VIABILIDADE.md`): gerar
 * **na nuvem**, não no aparelho. O Galaxy A05s tem Snapdragon 680, sem NPU de
 * IA, então um modelo de difusão local gastaria mais de 40 s por imagem,
 * 1,5–2,5 GB de RAM e boa parte da bateria — inviável para o uso diário.
 *
 * Provedor padrão: **AI Horde** — gratuito, documentado, sem cadastro
 * obrigatório e com chave anônima pública. Alternativa: **Pollinations**, que
 * também é gratuito e sem chave, porém com limite de 1 pedido a cada 15 s para
 * anônimos e possibilidade de marca d'água. Serviços pagos ficam desligados por
 * padrão e só entram se o usuário configurar a própria chave.
 *
 * Toda falha vira um `ImageGenerationError` com `kind`, para a tela mostrar a
 * mensagem certa: sem internet, cota esgotada, recusa do provedor, tempo
 * esgotado, cancelamento ou resposta em formato inesperado.
 *
 * Testado em `tests/imageprovider.test.mjs` com `fetch` falso — sem rede real.
 */

import { detectImageType } from '@lib/security/PrivateNames'
import { base64ToBytes } from '@lib/utils/Binary'

export type ImageProviderId = 'horde' | 'pollinations'

export type FailureKind =
    | 'rede'
    | 'cota'
    | 'autenticacao'
    | 'recusa'
    | 'timeout'
    | 'cancelado'
    | 'formato'
    | 'desconhecido'

export type GenerationPhase =
    'preparando' | 'enfileirado' | 'gerando' | 'concluido' | 'cancelado' | 'erro'

export type GenerationProgress = {
    phase: GenerationPhase
    message: string
    queuePosition?: number
    waitSeconds?: number
    elapsedSeconds?: number
    model?: string
}

export class ImageGenerationError extends Error {
    kind: FailureKind
    /** Sugestão prática do que fazer, em português. */
    hint: string

    constructor(kind: FailureKind, message: string, hint: string) {
        super(message)
        this.name = 'ImageGenerationError'
        this.kind = kind
        this.hint = hint
    }
}

export const HORDE_ANONYMOUS_KEY = '0000000000'
export const HORDE_API = 'https://aihorde.net/api/v2'
export const POLLINATIONS_API = 'https://image.pollinations.ai/prompt'
/** A AI Horde pede identificação do cliente no formato Nome:Versão:Contato. */
// O identificador leva a versão do aplicativo (o teste `imageprovider` confere
// contra o `package.json`, e foi ele que apontou que esta linha tinha ficado na
// 1.1.12 numa entrega 1.1.13). Ao subir a versão, subir aqui também.
export const CLIENT_AGENT = 'Lunaria:1.1.13:(github.com/Hirooficial/Lunaria2.0)'

export const POLL_INTERVAL_MS = 5_000
/**
 * A chave anônima da Horde limita consultas repetidas: um pedido de status pode
 * voltar 429 mesmo estando tudo certo (aconteceu de verdade durante os testes,
 * com fila longa). Enquanto a geração está na fila, 429 e erros 5xx do provedor
 * são passageiros: em vez de abortar, o aplicativo espera e tenta de novo.
 */
export const POLL_RETRY_BASE_MS = 5_000
export const POLL_RETRY_MAX_MS = 30_000
/** Teto de espera na fila. Depois disso o usuário recebe erro e pode tentar de novo. */
export const MAX_QUEUE_WAIT_MS = 300_000
export const POLLINATIONS_TIMEOUT_MS = 120_000
/** 16 MB: acima disso é resposta errada, não imagem. */
export const MAX_IMAGE_BYTES = 16 * 1024 * 1024

export type GenerateImageRequest = {
    provider?: ImageProviderId
    prompt: string
    negativePrompt?: string
    width: number
    height: number
    seed?: number
    /** Chave do usuário; vazia usa a chave pública anônima da Horde. */
    apiKey?: string
    model?: string
    steps?: number
    onProgress?: (progress: GenerationProgress) => void
    signal?: AbortSignal
    /** Injetáveis para os testes; em produção usa `fetch` global e `setTimeout`. */
    fetchImpl?: typeof fetch
    sleepImpl?: (ms: number) => Promise<void>
    pollIntervalMs?: number
    maxWaitMs?: number
}

export type GeneratedImage = {
    bytes: Uint8Array
    mime: string
    extension: string
    provider: ImageProviderId
    model?: string
    seed?: number
    elapsedSeconds: number
}

const defaultSleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms))

const networkHint =
    'Confira se o aparelho está com internet (dados móveis ou Wi-Fi) e tente de novo.'

/** Traduz erro de rede/cota/autenticação em algo que o usuário entenda. */
const errorFromStatus = (status: number, body: string): ImageGenerationError => {
    const trimmed = (body ?? '').slice(0, 240)
    if (status === 429) {
        return new ImageGenerationError(
            'cota',
            'A cota gratuita do provedor foi atingida.',
            'Espere alguns minutos e tente de novo. Se precisar de mais imagens por hora, dá para usar sua própria chave nas configurações de imagem.'
        )
    }
    if (status === 401 || status === 403) {
        return new ImageGenerationError(
            'autenticacao',
            'O provedor recusou a credencial usada.',
            'Confira a chave nas configurações de imagem ou volte para a opção gratuita (AI Horde sem chave).'
        )
    }
    if (status === 400 || status === 422) {
        return new ImageGenerationError(
            'recusa',
            'O provedor recusou este pedido.',
            `Reescreva a descrição com outras palavras.${trimmed ? ` Resposta do provedor: ${trimmed}` : ''}`
        )
    }
    if (status >= 500) {
        // Medido em 20/09/2026 com a Pollinations: o serviço devolve 500 embrulhando
        // o erro real de cota do modelo de trás —
        //   {"error":"Internal Server Error","message":"Gen Sana request failed with
        //    429: {...,\"message\":\"Per-user limit of 300 RPM exceeded for model ...\"}"}
        // Dizer "indisponível" nesse caso manda o usuário esperar o problema errado:
        // é limite de uso, e o texto certo é o de cota. A leitura do corpo é só para
        // rotular a mensagem — nada de esconder o erro nem de tentar de novo sozinho.
        const marcaDeLimite = /rate[_ -]?limit|rpm exceeded|too many requests|429\s*:/i
        if (marcaDeLimite.test(trimmed)) {
            return new ImageGenerationError(
                'cota',
                'O serviço gratuito está limitando os pedidos agora (limite de uso atingido).',
                'Não é problema do seu aparelho nem da descrição. Espere alguns minutos e tente de novo — tentar de novo logo em seguida costuma esbarrar no mesmo limite.'
            )
        }
        return new ImageGenerationError(
            'rede',
            'O provedor está indisponível no momento.',
            'Não é problema do seu aparelho. Espere um pouco e tente de novo.'
        )
    }
    return new ImageGenerationError(
        'desconhecido',
        `O provedor respondeu com erro ${status}.`,
        trimmed || 'Tente novamente em alguns instantes.'
    )
}

const throwIfAborted = (signal?: AbortSignal) => {
    if (signal?.aborted) {
        throw new ImageGenerationError(
            'cancelado',
            'Geração cancelada.',
            'Você cancelou esta imagem.'
        )
    }
}

const describeFetchFailure = (error: unknown): ImageGenerationError => {
    const name = (error as { name?: string })?.name
    if (name === 'AbortError') {
        return new ImageGenerationError(
            'cancelado',
            'Geração cancelada.',
            'Você cancelou esta imagem.'
        )
    }
    const message = (error as { message?: string })?.message ?? String(error)
    return new ImageGenerationError('rede', `Falha de conexão: ${message}`, networkHint)
}

/** Converte a resposta crua em bytes de imagem, checando tipo e tamanho. */
const decodeImage = (
    payload: Uint8Array,
    provider: ImageProviderId,
    label: string
): { bytes: Uint8Array; mime: string; extension: string } => {
    if (payload.length === 0) {
        throw new ImageGenerationError(
            'formato',
            'O provedor devolveu uma imagem vazia.',
            'Tente gerar de novo.'
        )
    }
    if (payload.length > MAX_IMAGE_BYTES) {
        throw new ImageGenerationError(
            'formato',
            'A imagem recebida é grande demais.',
            'Tente outra proporção (por exemplo, Quadrado).'
        )
    }
    const detected = detectImageType(payload)
    if (detected.kind === 'desconhecido') {
        throw new ImageGenerationError(
            'formato',
            `O ${label} devolveu um arquivo que não é imagem reconhecida.`,
            'Tente de novo ou troque de provedor nas configurações de imagem.'
        )
    }
    return {
        bytes: payload,
        mime: detected.mime,
        extension: detected.extension,
        ...{ provider },
    }
}

/* ------------------------------------------------------------------ *
 * AI Horde (padrão) — assíncrono: entra na fila e o app consulta o    *
 * andamento. É por isso que a tela consegue mostrar posição na fila.  *
 * ------------------------------------------------------------------ */

type HordeStatusResponse = {
    done?: boolean
    faulted?: boolean
    is_possible?: boolean
    wait_time?: number
    queue_position?: number
    kudos?: number
    message?: string
    generations?: { img?: string; model?: string; seed?: string | number; worker_name?: string }[]
}

/**
 * A seed como a AI Horde exige: **texto**.
 *
 * Defeito real, relatado pelo aparelho em 20/09/2026, com a seed digitada na tela:
 *
 *     Input payload validation failed — params.seed: "364056 is not of type 'string'"
 *
 * O schema da Horde recusa número em `params.seed`. A Lunaria mandava o número cru
 * (`...(seed !== undefined ? { seed } : {})`). A interface continua tratando a seed
 * como número — aleatória ou digitada —, e a conversão acontece **aqui**, na última
 * camada antes do envio, e **só** para a Horde: a Pollinations usa a seed como
 * parâmetro de URL e não é tocada.
 *
 * Ausente, vazia ou não numérica (NaN/Infinity) vira `undefined`, e o campo é
 * **omitido** do corpo — que é o comportamento que a API aceita. Nunca `null`,
 * nunca `undefined` explícito, nunca `NaN`.
 */
export const seedDaHorde = (
    seed: number | string | null | undefined
): string | undefined => {
    if (seed === null || seed === undefined) return undefined
    if (typeof seed === 'number') return Number.isFinite(seed) ? String(seed) : undefined
    const texto = seed.trim()
    return texto === '' ? undefined : texto
}

export const generateWithHorde = async (request: GenerateImageRequest): Promise<GeneratedImage> => {
    const {
        prompt,
        negativePrompt,
        width,
        height,
        seed,
        apiKey,
        model,
        steps = 30,
        onProgress,
        signal,
        fetchImpl = fetch,
        sleepImpl = defaultSleep,
        pollIntervalMs = POLL_INTERVAL_MS,
        maxWaitMs = MAX_QUEUE_WAIT_MS,
    } = request

    const startedAt = Date.now()
    onProgress?.({ phase: 'preparando', message: 'Preparando o pedido…' })
    throwIfAborted(signal)

    const seedNormalizada = seedDaHorde(seed)

    const paramsDaHorde: Record<string, unknown> = {
        width,
        height,
        steps,
        cfg_scale: 7,
        sampler_name: 'k_euler_a',
        n: 1,
        // O campo entra só quando há valor válido; ausente é ausente, não `null`.
        ...(seedNormalizada !== undefined ? { seed: seedNormalizada } : {}),
    }

    // Validação exigida antes do request: o schema da Horde recusa número
    // (`params.seed: "364056 is not of type 'string'"`). Se algum dia este valor
    // deixar de ser texto, é defeito de programação e tem de aparecer — não ser
    // escondido por try/catch.
    if (paramsDaHorde.seed !== undefined && typeof paramsDaHorde.seed !== 'string') {
        throw new ImageGenerationError(
            'desconhecido',
            'Pedido inválido: a seed enviada à AI Horde precisa ser texto.',
            'Isto é defeito do aplicativo, não do provedor. Registre no repositório para ser corrigido.'
        )
    }

    const body: Record<string, unknown> = {
        prompt,
        params: paramsDaHorde,
        // Conteúdo sexualmente explícito fica fora, por decisão de projeto:
        // a Lunaria trabalha com sensualidade sem nudez.
        nsfw: false,
        censor_nsfw: true,
        trusted_workers: false,
        slow_workers: true,
        r2: true,
        ...(negativePrompt ? { params_negative: negativePrompt } : {}),
    }

    let created: Response
    try {
        created = await fetchImpl(`${HORDE_API}/generate/async`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                apikey: apiKey?.trim() ? apiKey.trim() : HORDE_ANONYMOUS_KEY,
                'Client-Agent': CLIENT_AGENT,
            },
            body: JSON.stringify(body),
            signal,
        })
    } catch (error) {
        throw describeFetchFailure(error)
    }

    if (!created.ok) throw errorFromStatus(created.status, await created.text().catch(() => ''))

    const job = (await created.json().catch(() => null)) as { id?: string; message?: string } | null
    if (!job?.id) {
        throw new ImageGenerationError(
            'desconhecido',
            'O provedor não confirmou o pedido.',
            job?.message || 'Tente novamente em alguns instantes.'
        )
    }

    onProgress?.({
        phase: 'enfileirado',
        message: 'Na fila do provedor…',
        queuePosition: undefined,
    })

    let consultasSeguidasComErro = 0
    try {
        while (Date.now() - startedAt < maxWaitMs) {
            throwIfAborted(signal)
            await sleepImpl(pollIntervalMs)
            throwIfAborted(signal)

            let status: HordeStatusResponse
            try {
                const response = await fetchImpl(`${HORDE_API}/generate/status/${job.id}`, {
                    signal,
                })
                if (!response.ok) {
                    // Passageiro: o provedor pediu calma (429) ou está com problema
                    // momentâneo (5xx). A geração continua na fila; só a consulta falhou.
                    if (response.status === 429 || response.status >= 500) {
                        consultasSeguidasComErro += 1
                        const retryAfterSeconds = Number(
                            response.headers?.get?.('Retry-After') ?? ''
                        )
                        const espera =
                            Number.isFinite(retryAfterSeconds) && retryAfterSeconds > 0
                                ? Math.min(retryAfterSeconds * 1000, POLL_RETRY_MAX_MS)
                                : Math.min(
                                      POLL_RETRY_BASE_MS * 2 ** (consultasSeguidasComErro - 1),
                                      POLL_RETRY_MAX_MS
                                  )
                        onProgress?.({
                            phase: 'enfileirado',
                            message:
                                response.status === 429
                                    ? 'O provedor limitou as consultas; aguardando um pouco…'
                                    : 'O provedor está instável; tentando de novo…',
                            elapsedSeconds: Math.round((Date.now() - startedAt) / 1000),
                        })
                        await sleepImpl(espera)
                        continue
                    }
                    throw errorFromStatus(response.status, await response.text().catch(() => ''))
                }
                consultasSeguidasComErro = 0
                status = (await response.json()) as HordeStatusResponse
            } catch (error) {
                if (error instanceof ImageGenerationError) throw error
                throw describeFetchFailure(error)
            }

            const elapsedSeconds = Math.round((Date.now() - startedAt) / 1000)

            if (status.done) {
                const generation = status.generations?.[0]
                if (!generation?.img) {
                    throw new ImageGenerationError(
                        'formato',
                        'O provedor disse que terminou, mas não devolveu imagem.',
                        'Tente gerar de novo.'
                    )
                }
                const decoded = await readHordeResult(generation.img, fetchImpl, signal)
                onProgress?.({
                    phase: 'concluido',
                    message: 'Imagem pronta.',
                    elapsedSeconds,
                    model: generation.model,
                })
                return {
                    bytes: decoded.bytes,
                    mime: decoded.mime,
                    extension: decoded.extension,
                    provider: 'horde',
                    model: generation.model ?? model,
                    seed: generation.seed !== undefined ? Number(generation.seed) : seed,
                    elapsedSeconds,
                }
            }

            if (status.faulted || status.is_possible === false) {
                throw new ImageGenerationError(
                    'recusa',
                    'O provedor não conseguiu gerar esta imagem.',
                    status.message ||
                        'Tente outra descrição. Nomes de pessoas reais e pedidos muito específicos costumam ser recusados.'
                )
            }

            onProgress?.({
                phase:
                    status.queue_position && status.queue_position > 0 ? 'enfileirado' : 'gerando',
                message:
                    status.queue_position && status.queue_position > 0
                        ? `Na fila — posição ${status.queue_position}.`
                        : 'Gerando a imagem…',
                queuePosition: status.queue_position,
                waitSeconds: status.wait_time,
                elapsedSeconds,
            })
        }
    } catch (error) {
        // Cancelamento do usuário: o trabalho já está na fila do provedor e, se
        // o aplicativo só parar de consultar, ele **continua sendo gerado** por
        // um worker voluntário — a imagem sai e ninguém a recebe, gastando a
        // cota/prioridade (kudos) de quem cancelou.
        //
        // Medido em 18/09 com o serviço real: um trabalho abandonado (ninguém
        // consultando) terminou sozinho — `done=true`, 1 imagem — cerca de 60 s
        // depois. Por isso, ao cancelar, avisa-se o provedor.
        if (signal?.aborted) await cancelHordeJob(job.id, fetchImpl)
        throw error
    }

    // Estourou o tempo: cancela no provedor para não gastar a cota do usuário.
    await fetchImpl(`${HORDE_API}/generate/status/${job.id}`, { method: 'DELETE' }).catch(
        () => undefined
    )
    throw new ImageGenerationError(
        'timeout',
        'A fila demorou mais do que o limite e a geração foi cancelada.',
        'Tente de novo em outro horário — a fila gratuita é maior à noite.'
    )
}

/**
 * O resultado da Horde nem sempre vem em base64: quando o worker publica a
 * imagem no armazenamento R2 (caso observado em 18/09, com dados reais), o
 * campo `img` traz um **endereço https**. Antes desta correção o aplicativo
 * tentava decodificar o endereço como base64 e mostrava "base64 inválido" — a
 * geração tinha dado certo e o usuário não recebia a imagem.
 */
const isHttpUrl = (value: string): boolean => /^https?:\/\//i.test(value.trim())

const downloadImage = async (
    url: string,
    fetchImpl: typeof fetch,
    label: string,
    signal?: AbortSignal
): Promise<{ bytes: Uint8Array; mime: string; extension: string }> => {
    let response: Response
    try {
        response = await fetchImpl(url, { signal })
    } catch (error) {
        if (signal?.aborted) throw describeFetchFailure(error) // já devolve o erro de cancelamento pronto
        throw describeFetchFailure(error)
    }
    if (!response.ok) {
        throw new ImageGenerationError(
            'rede',
            `Não deu para baixar a imagem pronta do ${label} (código ${response.status}).`,
            'A imagem foi gerada, mas o download falhou. Tente de novo ou troque de provedor nas configurações de imagem.'
        )
    }
    const buffer = await response.arrayBuffer().catch(() => undefined)
    if (!buffer) {
        throw new ImageGenerationError(
            'rede',
            `O download da imagem do ${label} foi interrompido.`,
            'Tente de novo.'
        )
    }
    // decodeImage confere tamanho e formato pelos bytes reais (não pelo que o
    // servidor diz) e devolve bytes, tipo e extensão correspondentes.
    return decodeImage(new Uint8Array(buffer), 'horde', label)
}

/**
 * Lê o resultado da Horde nos dois formatos possíveis (endereço https ou
 * base64) e traduz qualquer falha de leitura numa mensagem que o usuário
 * entenda — antes, um base64 malformado vazava o erro técnico
 * "base64 inválido: tamanho não múltiplo de 4" para a tela.
 */
const readHordeResult = async (
    img: string,
    fetchImpl: typeof fetch,
    signal?: AbortSignal
): Promise<{ bytes: Uint8Array; mime: string; extension: string }> => {
    if (isHttpUrl(img)) return downloadImage(img, fetchImpl, 'AI Horde', signal)
    try {
        return decodeImage(base64ToBytes(img.trim()), 'horde', 'AI Horde')
    } catch (error) {
        if (error instanceof ImageGenerationError) throw error
        throw new ImageGenerationError(
            'formato',
            'O provedor devolveu a imagem num formato que não deu para ler.',
            'Tente gerar de novo. Se repetir, troque de provedor nas configurações de imagem.'
        )
    }
}

/** Remove o pedido da fila ao cancelar (libera a cota imediatamente). */
export const cancelHordeJob = async (
    jobId: string,
    fetchImpl: typeof fetch = fetch
): Promise<void> => {
    await fetchImpl(`${HORDE_API}/generate/status/${jobId}`, { method: 'DELETE' }).catch(
        () => undefined
    )
}

/* ------------------------------------------------------------------ *
 * Pollinations (alternativa) — síncrono: a imagem volta na resposta.  *
 * ------------------------------------------------------------------ */

export const generateWithPollinations = async (
    request: GenerateImageRequest
): Promise<GeneratedImage> => {
    const {
        prompt,
        width,
        height,
        seed,
        apiKey,
        model,
        onProgress,
        signal,
        fetchImpl = fetch,
        maxWaitMs = POLLINATIONS_TIMEOUT_MS,
    } = request

    const startedAt = Date.now()
    onProgress?.({ phase: 'preparando', message: 'Preparando o pedido…' })
    throwIfAborted(signal)

    // A Pollinations usa a semente 42 quando o pedido não traz nenhuma — e
    // nesse caso devolveu, nos testes reais de 18/09, uma **imagem velha de
    // cache sem relação com a descrição** (reproduzível: mesmos 37.167 bytes em
    // duas execuções, com "a young woman with long black hair" valendo). Com uma
    // semente própria o mesmo pedido voltou correto. Por isso a semente é
    // sempre enviada: sorteada quando o usuário não escolhe — e devolvida no
    // resultado, para poder repetir a mesma imagem depois.
    const usedSeed = seed ?? Math.floor(Math.random() * 2_147_483_647) + 1

    const params = new URLSearchParams({
        width: String(width),
        height: String(height),
        nologo: 'true',
        private: 'true',
        safe: 'true',
        seed: String(usedSeed),
        ...(model ? { model } : {}),
    })
    const url = `${POLLINATIONS_API}/${encodeURIComponent(prompt)}?${params.toString()}`

    // A Pollinations é síncrona: aqui o timeout é do pedido inteiro.
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), maxWaitMs)
    const onAbort = () => controller.abort()
    signal?.addEventListener('abort', onAbort)

    try {
        onProgress?.({ phase: 'gerando', message: 'Gerando a imagem…' })
        const response = await fetchImpl(url, {
            headers: apiKey?.trim() ? { Authorization: `Bearer ${apiKey.trim()}` } : undefined,
            signal: controller.signal,
        })
        if (!response.ok)
            throw errorFromStatus(response.status, await response.text().catch(() => ''))

        const buffer = await response.arrayBuffer()
        const decoded = decodeImage(new Uint8Array(buffer), 'pollinations', 'Pollinations')
        const elapsedSeconds = Math.round((Date.now() - startedAt) / 1000)
        onProgress?.({ phase: 'concluido', message: 'Imagem pronta.', elapsedSeconds })
        return {
            bytes: decoded.bytes,
            mime: decoded.mime,
            extension: decoded.extension,
            provider: 'pollinations',
            model,
            seed: usedSeed,
            elapsedSeconds,
        }
    } catch (error) {
        if (error instanceof ImageGenerationError) throw error
        if ((error as { name?: string })?.name === 'AbortError') {
            if (signal?.aborted) {
                throw new ImageGenerationError(
                    'cancelado',
                    'Geração cancelada.',
                    'Você cancelou esta imagem.'
                )
            }
            throw new ImageGenerationError(
                'timeout',
                'A geração demorou mais do que o limite.',
                'Tente de novo ou troque para a AI Horde nas configurações de imagem.'
            )
        }
        throw describeFetchFailure(error)
    } finally {
        clearTimeout(timer)
        signal?.removeEventListener('abort', onAbort)
    }
}

/** Porta de entrada única: escolhe o provedor pelo identificador. */
export const generateImage = async (
    request: GenerateImageRequest & { provider: ImageProviderId }
): Promise<GeneratedImage> =>
    request.provider === 'pollinations'
        ? generateWithPollinations(request)
        : generateWithHorde(request)

export const PROVIDER_LABEL: Record<ImageProviderId, string> = {
    horde: 'AI Horde (imagem)',
    pollinations: 'Pollinations',
}

export const PROVIDER_INFO: Record<
    ImageProviderId,
    { label: string; free: boolean; needsKey: boolean; limits: string; languageNote?: string }
> = {
    horde: {
        label: 'AI Horde (imagem)',
        free: true,
        needsKey: false,
        limits: 'Gratuito e sem cadastro, com a chave anônima pública. Fila comunitária: a espera real varia de segundos a alguns minutos, e o limite é por prioridade (kudos), não por número fixo de imagens.',
    },
    pollinations: {
        label: 'Pollinations',
        free: true,
        needsKey: false,
        limits: 'Gratuito e sem chave. Para quem não tem conta: 1 pedido a cada 15 s e possibilidade de marca d’água. Com conta gratuita ("Seed") o intervalo cai para 5 s.',
        // Limite medido em 18/09 com a API real: descrição em português foi
        // ignorada em três tentativas seguidas (devolveu imagens sem relação com
        // o pedido); a mesma descrição em inglês saiu fiel. Não é filtro nem
        // defeito do aplicativo: é limitação do modelo. Fica avisado na tela.
        languageNote:
            'Este provedor entende melhor descrições em inglês. Nos testes feitos aqui, descrição em português foi ignorada e a imagem saiu sem relação com o pedido — em inglês, saiu fiel. Para descrições em português, o provedor AI Horde se saiu melhor.',
    },
}
