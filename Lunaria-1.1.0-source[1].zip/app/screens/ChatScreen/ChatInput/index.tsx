import { MaterialIcons } from '@expo/vector-icons'
import { randomUUID } from 'expo-crypto'
import { getDocumentAsync } from 'expo-document-picker'
import { Image } from 'expo-image'
import { useRouter } from 'expo-router'
import React, { useRef, useState } from 'react'
import { TextInput, TouchableOpacity, View } from 'react-native'
import { useMMKVBoolean } from 'react-native-mmkv'
import Animated, {
    BounceIn,
    FadeIn,
    FadeOut,
    LinearTransition,
    ZoomOut,
} from 'react-native-reanimated'
import { create } from 'zustand'
import { useShallow } from 'zustand/react/shallow'

import ThemedButton from '@components/buttons/ThemedButton'
import Alert from '@components/views/Alert'
import CameraSheet from '@components/views/CameraSheet'
import ContextMenu from '@components/views/ContextMenu'
import { XAxisOnlyTransition } from '@lib/animations/transitions'
import { AppSettings } from '@lib/constants/GlobalValues'
import { APIManager } from '@lib/engine/API/APIManagerState'
import { generateResponse } from '@lib/engine/Inference'
import { useUnfocusTextInput } from '@lib/hooks/UnfocusTextInput'
import { useAppModeStore } from '@lib/state/AppMode'
import { Characters } from '@lib/state/Characters'
import { Chats, useInference } from '@lib/state/Chat'
import { useChatInputTextStore } from '@lib/state/components/ChatInput'
import { Logger } from '@lib/state/Logger'
import { mmkv } from '@lib/storage/MMKV'
import { Theme } from '@lib/theme/ThemeManager'

import ChatOptions from './ChatInputOptions'
import VoiceInputButton from './VoiceInputButton'

export type Attachment = {
    uri: string
    type: 'image' | 'audio' | 'document'
    name: string
}

const AnimatedTextInput = Animated.createAnimatedComponent(TextInput)

type ChatInputHeightStoreProps = {
    height: number
    setHeight: (n: number) => void
}

export const useInputHeightStore = create<ChatInputHeightStoreProps>()((set) => ({
    height: 54,
    setHeight: (n) => set({ height: Math.ceil(n) }),
}))

const ChatInput = () => {
    const inputRef = useUnfocusTextInput()
    const router = useRouter()
    const sending = useRef(false)

    const { color, borderRadius, spacing } = Theme.useTheme()
    const [sendOnEnter] = useMMKVBoolean(AppSettings.SendOnEnter)
    const [attachments, setAttachments] = useState<Attachment[]>([])
    const pendingAttachments = useChatInputTextStore((state) => state.pendingAttachments)
    const consumeAttachments = useChatInputTextStore((state) => state.consumeAttachments)

    // Imagem gerada em outra tela entra aqui como anexo normal do compositor.
    React.useEffect(() => {
        if (pendingAttachments.length === 0) return
        const incoming = consumeAttachments()
        if (incoming.length === 0) return
        setAttachments((current) => {
            const missing = incoming.filter((item) => !current.some((a) => a.uri === item.uri))
            return missing.length > 0 ? [...current, ...missing] : current
        })
    }, [pendingAttachments, consumeAttachments])
    const [hideOptions, setHideOptions] = useState(false)
    const [showCamera, setShowCamera] = useState(false)
    const { addEntry } = Chats.useEntry()
    const { nowGenerating, abortFunction } = useInference(
        useShallow((state) => ({
            nowGenerating: state.nowGenerating,
            abortFunction: state.abortFunction,
        }))
    )
    const setHeight = useInputHeightStore(useShallow((state) => state.setHeight))

    const { charName } = Characters.useCharacterStore(
        useShallow((state) => ({
            charName: state?.card?.name,
        }))
    )

    const { userName } = Characters.useUserStore(
        useShallow((state) => ({ userName: state.card?.name }))
    )

    const { newMessage, setNewMessage } = useChatInputTextStore(
        useShallow((state) => ({
            newMessage: state.text,
            setNewMessage: state.setText,
        }))
    )

    const abortResponse = async () => {
        Logger.info(`Aborting Generation`)
        if (abortFunction) await abortFunction()
    }

    const sendMessage = async () => {
        if (sending.current || useInference.getState().nowGenerating) return
        if (newMessage.trim() === '' && attachments.length === 0) return
        sending.current = true
        try {
            await addEntry(
                userName ?? '',
                true,
                newMessage,
                attachments.map((item) => item.uri)
            )
            const swipeId = await addEntry(charName ?? '', false, '')
            if (swipeId === undefined) throw new Error('Não foi possível criar a resposta.')
            setNewMessage('')
            setAttachments([])
            await generateResponse(swipeId)
        } catch (error) {
            Logger.errorToast(`Falha ao enviar: ${error}`)
        } finally {
            sending.current = false
        }
    }

    const handleSend = async () => {
        const appMode = useAppModeStore.getState().appMode
        const apiState = APIManager.useConnectionsStore.getState()
        const activeAPI = apiState.values[apiState.activeIndex]
        const needsConsent =
            appMode === 'remote' &&
            activeAPI?.configName === 'Horde' &&
            !mmkv.getBoolean(AppSettings.RemotePrivacyAccepted)

        if (!needsConsent) {
            await sendMessage()
            return
        }

        Alert.alert({
            title: 'Antes de usar a IA online gratuita',
            description:
                'Suas mensagens, o contexto do chat e trechos usados em “Fatos” serão enviados à rede comunitária AI Horde e podem ser processados por operadores voluntários. Não envie senhas, documentos privados ou dados sensíveis.',
            buttons: [
                { label: 'Cancelar' },
                {
                    label: 'Entendi e continuar',
                    onPress: () => {
                        mmkv.set(AppSettings.RemotePrivacyAccepted, true)
                        void sendMessage()
                    },
                },
            ],
        })
    }

    const handlePickImage = async () => {
        const result = await getDocumentAsync({
            type: 'image/*',
            multiple: true,
            copyToCacheDirectory: true,
        })
        if (result.canceled || result.assets.length < 1) return

        const newAttachments = result.assets
            .map((item) => ({
                uri: item.uri,
                type: 'image',
                name: item.name,
            }))
            .filter((item) => !attachments.some((a) => a.name === item.name)) as Attachment[]
        setAttachments([...attachments, ...newAttachments])
    }

    return (
        <View
            onLayout={(e) => {
                setHeight(e.nativeEvent.layout.height)
            }}
            style={{
                position: 'absolute',
                width: '98%',
                alignSelf: 'center',
                bottom: 4,
                paddingVertical: spacing.sm,
                paddingHorizontal: spacing.sm,
                backgroundColor: color.neutral._100 + 'cc',
                borderWidth: 1,
                borderColor: color.neutral._200,
                boxShadow: [
                    {
                        offsetX: 1,
                        offsetY: 1,
                        color: color.shadow,
                        spreadDistance: 1,
                        blurRadius: 4,
                    },
                ],
                borderRadius: 16,
                rowGap: spacing.m,
            }}>
            <Animated.FlatList
                itemLayoutAnimation={LinearTransition}
                style={{
                    display: attachments.length > 0 ? 'flex' : 'none',
                    padding: spacing.l,
                    backgroundColor: color.neutral._200,
                    borderRadius: borderRadius.m,
                }}
                horizontal
                contentContainerStyle={{ columnGap: spacing.xl }}
                data={attachments}
                keyExtractor={(item) => item.uri}
                renderItem={({ item }) => {
                    return (
                        <Animated.View
                            entering={BounceIn}
                            exiting={ZoomOut.duration(100)}
                            style={{ alignItems: 'center', rowGap: 8 }}>
                            <Image
                                source={{ uri: item.uri }}
                                style={{
                                    width: 128,
                                    height: undefined,
                                    aspectRatio: 1,
                                    borderRadius: borderRadius.m,
                                    borderWidth: 1,
                                    borderColor: color.primary._500,
                                }}
                            />

                            <ThemedButton
                                iconName="close"
                                iconSize={20}
                                buttonStyle={{
                                    borderWidth: 0,
                                    paddingHorizontal: 2,
                                    paddingVertical: 2,
                                    position: 'absolute',
                                    alignSelf: 'flex-end',
                                    margin: -8,
                                    backgroundColor: color.neutral._500,
                                }}
                                onPress={() => {
                                    setAttachments(attachments.filter((a) => a.uri !== item.uri))
                                }}
                            />
                        </Animated.View>
                    )
                }}
            />
            <CameraSheet
                onTakePicture={(picture) => {
                    setAttachments((attachments) => [
                        ...attachments,
                        {
                            name: randomUUID().toString(),
                            uri: picture.uri,
                            type: 'image',
                        },
                    ])
                }}
                visible={showCamera}
                setVisible={setShowCamera}
            />
            <View style={{ flexDirection: 'row', columnGap: spacing.sm }}>
                <ThemedButton
                    label="Pesquisa"
                    iconName="search"
                    variant="secondary"
                    buttonStyle={{ flex: 1, paddingHorizontal: 6, paddingVertical: 8 }}
                    onPress={() => router.push('/screens/ResearchScreen')}
                />
                <ThemedButton
                    label="Fatos"
                    iconName="check-circle"
                    variant={newMessage.trim() && !nowGenerating ? 'secondary' : 'disabled'}
                    buttonStyle={{ flex: 1, paddingHorizontal: 6, paddingVertical: 8 }}
                    onPress={() => {
                        if (!newMessage.trim()) return
                        router.push({
                            pathname: '/screens/ResearchScreen',
                            params: { q: newMessage.trim(), auto: '1' },
                        })
                    }}
                />
                <VoiceInputButton disabled={nowGenerating} />
            </View>
            <View style={{ flexDirection: 'row', columnGap: spacing.sm, marginTop: spacing.s }}>
                <ThemedButton
                    label="Gerar imagem"
                    iconName="picture"
                    variant="secondary"
                    buttonStyle={{ flex: 1, paddingHorizontal: 6, paddingVertical: 8 }}
                    onPress={() => router.push('/screens/ImageGenerationScreen')}
                />
            </View>
            <View
                style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    columnGap: spacing.m,
                }}>
                <Animated.View layout={XAxisOnlyTransition}>
                    {!hideOptions && (
                        <Animated.View
                            entering={FadeIn}
                            exiting={FadeOut}
                            style={{
                                flexDirection: 'row',
                                columnGap: 8,
                                alignItems: 'center',
                            }}>
                            <ChatOptions />
                            <ContextMenu
                                triggerIcon="paper-clip"
                                triggerIconSize={20}
                                buttons={[
                                    {
                                        label: 'Tirar foto',
                                        icon: 'camera',
                                        onPress: (close) => {
                                            setShowCamera(true)
                                            close()
                                        },
                                    },
                                    {
                                        label: 'Adicionar imagem',
                                        icon: 'picture',
                                        onPress: async (close) => {
                                            close()
                                            handlePickImage()
                                        },
                                    },
                                ]}
                                triggerStyle={{
                                    color: color.text._400,
                                    padding: 6,
                                    backgroundColor: color.neutral._200,
                                    borderRadius: 16,
                                }}
                                placement="top"
                            />
                        </Animated.View>
                    )}
                    {hideOptions && (
                        <Animated.View entering={FadeIn} exiting={FadeOut}>
                            <ThemedButton
                                iconSize={18}
                                iconStyle={{
                                    color: color.text._400,
                                }}
                                buttonStyle={{
                                    padding: 5,
                                    backgroundColor: color.neutral._200,
                                    borderRadius: 32,
                                }}
                                variant="tertiary"
                                iconName="right"
                                onPress={() => setHideOptions(false)}
                            />
                        </Animated.View>
                    )}
                </Animated.View>
                <AnimatedTextInput
                    layout={XAxisOnlyTransition}
                    ref={inputRef}
                    style={{
                        color: color.text._100,
                        backgroundColor: color.neutral._100,
                        flex: 1,
                        borderWidth: 2,
                        borderColor: color.primary._300,
                        borderRadius: borderRadius.l,
                        paddingHorizontal: spacing.m,
                        paddingVertical: spacing.m,
                    }}
                    onPress={() => {
                        setHideOptions(!!newMessage)
                    }}
                    numberOfLines={8}
                    placeholder="Converse ou pesquise sobre…"
                    placeholderTextColor={color.text._700}
                    value={newMessage}
                    onChangeText={(text) => {
                        setHideOptions(!!text)
                        setNewMessage(text)
                    }}
                    multiline
                    submitBehavior={sendOnEnter ? 'blurAndSubmit' : 'newline'}
                    onSubmitEditing={sendOnEnter ? handleSend : undefined}
                />
                <Animated.View layout={XAxisOnlyTransition}>
                    <TouchableOpacity
                        style={{
                            borderRadius: borderRadius.m,
                            backgroundColor: nowGenerating ? color.error._500 : color.primary._500,
                            padding: spacing.m,
                        }}
                        onPress={nowGenerating ? abortResponse : handleSend}>
                        <MaterialIcons
                            name={nowGenerating ? 'stop' : 'send'}
                            color={color.neutral._100}
                            size={24}
                        />
                    </TouchableOpacity>
                </Animated.View>
            </View>
        </View>
    )
}

export default ChatInput
