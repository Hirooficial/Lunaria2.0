import { SplashScreen, Stack, useRouter } from 'expo-router'
import * as ScreenCapture from 'expo-screen-capture'
import { setOptions } from 'expo-splash-screen'
import { useEffect, useRef } from 'react'
import { AppState, View } from 'react-native'
import { GestureHandlerRootView } from 'react-native-gesture-handler'
import { KeyboardProvider } from 'react-native-keyboard-controller'

import { AlertProvider } from '@components/views/Alert'
import ImageViewer from '@components/views/ImageViewer'
import { PortalHost } from '@components/views/Portal'
import { useAppStateNotificationObserver } from '@lib/notifications/Notifications'
import { useAppLock } from '@lib/state/AppLock'
import { useImageGeneration } from '@lib/state/ImageGeneration'
import { Theme } from '@lib/theme/ThemeManager'
import LockScreen from '@screens/LockScreen'

SplashScreen.preventAutoHideAsync()
setOptions({
    fade: true,
    duration: 350,
})

const Layout = () => {
    const { color } = Theme.useTheme()
    const router = useRouter()
    useAppStateNotificationObserver()

    const ready = useAppLock((state) => state.ready)
    const locked = useAppLock((state) => state.locked)
    const configured = useAppLock((state) => state.configured)
    const autoLockMinutes = useAppLock((state) => state.settings.autoLockMinutes)
    const blockScreenshots = useAppLock((state) => state.settings.blockScreenshots)
    const init = useAppLock((state) => state.init)
    const lockNow = useAppLock((state) => state.lockNow)
    const initImage = useImageGeneration((state) => state.init)

    const backgroundedAt = useRef<number | undefined>(undefined)

    // Uma vez por abertura: descobre se existe senha configurada antes de
    // mostrar qualquer coisa. Enquanto `ready` for falso, a tela fica em branco
    // (fail-closed) — nenhuma conversa aparece nesse intervalo.
    useEffect(() => {
        init()
        initImage()
    }, [init, initImage])

    // Retorno do segundo plano: exige a senha depois do tempo configurado.
    useEffect(() => {
        const listener = AppState.addEventListener('change', (nextState) => {
            if (nextState === 'background' || nextState === 'inactive') {
                backgroundedAt.current = Date.now()
                return
            }
            if (nextState !== 'active') return
            if (!configured) return

            const away = backgroundedAt.current ? Date.now() - backgroundedAt.current : 0
            backgroundedAt.current = undefined
            // `0` minutos significa "bloqueia assim que sai da frente".
            if (autoLockMinutes === 0 || away >= autoLockMinutes * 60_000) {
                lockNow('segundo-plano')
            }
        })
        return () => listener.remove()
    }, [autoLockMinutes, configured, lockNow])

    // Impedir capturas de tela (opcional, desligado por padrão).
    useEffect(() => {
        if (blockScreenshots) {
            ScreenCapture.preventScreenCaptureAsync('lunaria')
            return () => {
                ScreenCapture.allowScreenCaptureAsync('lunaria')
            }
        }
    }, [blockScreenshots])

    // Depois de desbloquear, atende a notificação que motivou a abertura.
    useEffect(() => {
        if (locked) return
        const pending = useAppLock.getState().pendingChat
        if (!pending) return
        useAppLock.getState().setPendingChat(undefined)
        Promise.all([import('@lib/state/Characters'), import('@lib/state/Chat')])
            .then(async ([{ Characters }, { Chats }]) => {
                await Chats.useChatState.getState().load(pending.chatId)
                await Characters.useCharacterStore.getState().setCard(pending.characterId)
                router.navigate('/screens/ChatScreen')
            })
            .catch(() => undefined)
    }, [locked, router])

    return (
        <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
                <AlertProvider />
                {!ready ? (
                    // Ainda não se sabe se há bloqueio: não mostra nada do app.
                    <View style={{ flex: 1, backgroundColor: color.neutral._100 }} />
                ) : locked ? (
                    <LockScreen />
                ) : (
                    <Stack
                        screenOptions={{
                            headerBackButtonDisplayMode: 'minimal',
                            headerStyle: { backgroundColor: color.neutral._100 },
                            headerTitleStyle: { color: color.text._100 },
                            headerTintColor: color.text._100,
                            contentStyle: { backgroundColor: color.neutral._100 },
                            headerShadowVisible: false,
                            headerTitleAlign: 'center',
                            statusBarStyle: 'auto',
                        }}>
                        <Stack.Screen name="index" options={{ animation: 'fade' }} />
                    </Stack>
                )}
                {/* O visualizador fica fora do gate: ele só é aberto por dentro do
                    aplicativo já desbloqueado, e ao bloquear é fechado. */}
                {!locked && <ImageViewer />}
                <PortalHost />
            </KeyboardProvider>
        </GestureHandlerRootView>
    )
}

export default Layout
