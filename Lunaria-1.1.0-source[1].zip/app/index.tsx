import { AntDesign } from '@expo/vector-icons'
import { useMigrations } from 'drizzle-orm/expo-sqlite/migrator'
import { SplashScreen } from 'expo-router'
import { useCallback, useEffect, useRef, useState } from 'react'
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'

import ThemedButton from '@components/buttons/ThemedButton'
import HeaderTitle from '@components/views/HeaderTitle'
import { db } from '@db'
import useLocalAuth from '@lib/hooks/LocalAuth'
import { Theme } from '@lib/theme/ThemeManager'
import { loadChatOnInit, startupApp, useTextIntentFocus } from '@lib/utils/Startup'
import CharacterList from '@screens/CharacterListScreen'

import migrations from '../db/migrations/migrations'

const Home = () => {
    const { color } = Theme.useTheme()
    const styles = useStyles()
    const { success, error } = useMigrations(db, migrations)
    const { authorized, retry } = useLocalAuth()

    const [firstRender, setFirstRender] = useState<boolean>(true)
    const [startupFailure, setStartupFailure] = useState('')
    const startupInFlight = useRef(false)

    useTextIntentFocus()

    useEffect(() => {
        if (authorized && success && !firstRender && !startupFailure) {
            loadChatOnInit()
        }
    }, [authorized, success, firstRender, startupFailure])

    const startLunaria = useCallback(async () => {
        if (startupInFlight.current) return
        startupInFlight.current = true
        setFirstRender(true)
        setStartupFailure('')
        try {
            await startupApp()
        } catch (startupError) {
            const detail = startupError instanceof Error ? startupError.message : `${startupError}`
            console.error('Falha ao iniciar a Lunaria:', startupError)
            setStartupFailure(detail)
        } finally {
            startupInFlight.current = false
            setFirstRender(false)
            await SplashScreen.hideAsync()
        }
    }, [])

    useEffect(() => {
        if (success) void startLunaria()
        if (error) void SplashScreen.hideAsync()
    }, [success, error, startLunaria])

    if (error)
        return (
            <View style={styles.centeredContainer}>
                <HeaderTitle />
                <Text style={styles.title}>Falha ao preparar o banco de dados</Text>
                <Text style={styles.errorLog}>{error.message}</Text>
                <Text style={styles.subtitle}>
                    Feche e abra o aplicativo novamente. Se continuar, guarde uma captura desta
                    mensagem para o diagnóstico.
                </Text>
            </View>
        )

    if (startupFailure)
        return (
            <View style={[styles.centeredContainer, { rowGap: 18 }]}>
                <HeaderTitle />
                <Text style={styles.title}>A Lunaria não conseguiu iniciar</Text>
                <Text style={styles.errorLog}>{startupFailure}</Text>
                <Text style={styles.subtitle}>
                    Nenhum dado foi apagado. Toque abaixo para tentar novamente.
                </Text>
                <ThemedButton label="Tentar novamente" onPress={() => void startLunaria()} />
            </View>
        )

    if (!authorized)
        return (
            <View style={[styles.centeredContainer, { rowGap: 60 }]}>
                <HeaderTitle />
                <AntDesign
                    name="lock"
                    size={120}
                    style={{ marginBottom: 12 }}
                    color={color.text._500}
                />
                <Text style={styles.title}>Autenticação necessária</Text>
                <TouchableOpacity onPress={retry} style={styles.button}>
                    <Text style={styles.buttonText}>Tentar novamente</Text>
                </TouchableOpacity>
            </View>
        )
    if (!firstRender && success) return <CharacterList />
    return <HeaderTitle />
}

export default Home

const useStyles = () => {
    const { color, spacing, fontSize, borderWidth } = Theme.useTheme()
    return StyleSheet.create({
        centeredContainer: {
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
        },

        title: {
            color: color.text._300,
            fontSize: fontSize.xl2,
        },

        subtitle: {
            color: color.text._400,
            marginHorizontal: 24,
            textAlign: 'center',
        },

        errorLog: {
            color: color.text._400,
            fontSize: fontSize.s,
            paddingHorizontal: spacing.xl,
            paddingVertical: spacing.l,
            borderRadius: 12,
            margin: spacing.xl2,
            backgroundColor: 'black',
        },

        buttonText: {
            color: color.text._100,
        },

        button: {
            paddingVertical: spacing.l,
            paddingHorizontal: spacing.xl2,
            columnGap: spacing.m,
            borderRadius: spacing.xl2,
            borderWidth: borderWidth.m,
            borderColor: color.primary._500,
        },
    })
}
