import assert from 'node:assert/strict'
import { Buffer } from 'node:buffer'
import test from 'node:test'

import {
    CLIENT_AGENT,
    generateImage,
    generateWithHorde,
    generateWithPollinations,
    HORDE_ANONYMOUS_KEY,
    ImageGenerationError,
    MAX_IMAGE_BYTES,
    POLL_INTERVAL_MS,
} from '../lib/imagegen/ImageProviders.ts'

const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3])
const PNG_BASE64 = Buffer.from(PNG).toString('base64')

const okJson = (body) => ({ ok: true, status: 200, json: async () => body, text: async () => '' })
const okBytes = (bytes, type = 'image/png') => ({
    ok: true,
    status: 200,
    headers: { get: () => type },
    arrayBuffer: async () =>
        bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
})
const fail = (status, body = 'erro') => ({
    ok: false,
    status,
    json: async () => ({}),
    text: async () => body,
})

const noSleep = async () => {}
const fast = { sleepImpl: noSleep, pollIntervalMs: 1 }

test('a chave anônima e o identificador de cliente são os esperados', () => {
    assert.equal(HORDE_ANONYMOUS_KEY, '0000000000')
    assert.match(CLIENT_AGENT, /^Lunaria:1\.1\.0:/)
    assert.equal(POLL_INTERVAL_MS, 3000)
})

test('Horde: entra na fila, informa posição e devolve a imagem pronta', async () => {
    const phases = []
    let statusCalls = 0
    const fetchImpl = async (url, options) => {
        if (String(url).endsWith('/generate/async')) {
            assert.equal(options.headers.apikey, HORDE_ANONYMOUS_KEY)
            assert.equal(options.headers['Client-Agent'], CLIENT_AGENT)
            const body = JSON.parse(options.body)
            assert.equal(body.nsfw, false)
            assert.equal(body.censor_nsfw, true)
            assert.equal(body.params.width, 512)
            return okJson({ id: 'job-1', kudos: 6 })
        }
        statusCalls += 1
        if (statusCalls === 1) {
            return okJson({ done: false, queue_position: 3, wait_time: 20 })
        }
        return okJson({
            done: true,
            generations: [{ img: PNG_BASE64, model: 'stable_diffusion', seed: '42' }],
        })
    }

    const result = await generateWithHorde({
        prompt: 'gothic portrait',
        width: 512,
        height: 768,
        fetchImpl,
        onProgress: (progress) => phases.push(progress.phase),
        ...fast,
    })

    assert.equal(result.provider, 'horde')
    assert.equal(result.extension, 'png')
    assert.equal(result.mime, 'image/png')
    assert.equal(result.seed, 42)
    assert.deepEqual(phases, ['preparando', 'enfileirado', 'enfileirado', 'concluido'])
})

test('Horde: fila que trava é cancelada no provedor e vira erro de tempo', async () => {
    let deleted = false
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'DELETE') {
            deleted = true
            return okJson({})
        }
        if (String(url).endsWith('/generate/async')) return okJson({ id: 'job-2' })
        return okJson({ done: false, queue_position: 99 })
    }

    await assert.rejects(
        generateWithHorde({
            prompt: 'x',
            width: 512,
            height: 512,
            fetchImpl,
            maxWaitMs: 3,
            ...fast,
        }),
        (error) => {
            assert.ok(error instanceof ImageGenerationError)
            assert.equal(error.kind, 'timeout')
            return true
        }
    )
    assert.equal(deleted, true, 'o pedido precisa ser removido da fila ao desistir')
})

test('Horde: recusa do provedor (faulted) vira erro de recusa', async () => {
    const fetchImpl = async (url) => {
        if (String(url).endsWith('/generate/async')) return okJson({ id: 'job-3' })
        return okJson({ done: false, faulted: true, message: 'no worker could process' })
    }
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => error.kind === 'recusa'
    )
})

test('cota esgotada (429) tem mensagem e dica próprias', async () => {
    const fetchImpl = async () => fail(429)
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'cota')
            assert.match(error.hint, /Espere alguns minutos|chave/)
            return true
        }
    )
})

test('sem internet o erro é explícito e sugere conferir a conexão', async () => {
    const fetchImpl = async () => {
        throw new TypeError('Network request failed')
    }
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'rede')
            assert.match(error.hint, /internet/)
            return true
        }
    )
})

test('recusa do provedor em 400/422 vira erro de recusa com o texto do serviço', async () => {
    const fetchImpl = async () => fail(400, 'prompt blocked')
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'recusa')
            assert.match(error.hint, /prompt blocked/)
            return true
        }
    )
})

test('provedor indisponível (5xx) não é tratado como culpa do aparelho', async () => {
    const fetchImpl = async () => fail(503)
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => {
            assert.equal(error.kind, 'rede')
            assert.match(error.message, /indisponível/)
            return true
        }
    )
})

test('resposta que não é imagem é recusada com erro de formato', async () => {
    const fetchImpl = async (url) => {
        if (String(url).endsWith('/generate/async')) return okJson({ id: 'job-4' })
        return okJson({
            done: true,
            generations: [{ img: Buffer.from('não é imagem').toString('base64') }],
        })
    }
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => error.kind === 'formato'
    )
})

test('imagem gigante é rejeitada antes de ocupar memória do aparelho', async () => {
    const huge = new Uint8Array(MAX_IMAGE_BYTES + 1)
    huge.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
    const fetchImpl = async (url) => {
        if (String(url).endsWith('/generate/async')) return okJson({ id: 'job-5' })
        return okJson({ done: true, generations: [{ img: Buffer.from(huge).toString('base64') }] })
    }
    await assert.rejects(
        generateWithHorde({ prompt: 'x', width: 512, height: 512, fetchImpl, ...fast }),
        (error) => error.kind === 'formato'
    )
})

test('cancelar aborta e devolve erro de cancelamento', async () => {
    const controller = new AbortController()
    const fetchImpl = async (url, options) => {
        if (String(url).endsWith('/generate/async')) {
            controller.abort()
            return okJson({ id: 'job-6' })
        }
        return okJson({ done: false })
    }
    await assert.rejects(
        generateWithHorde({
            prompt: 'x',
            width: 512,
            height: 512,
            fetchImpl,
            signal: controller.signal,
            ...fast,
        }),
        (error) => error.kind === 'cancelado'
    )
})

test('Pollinations: pedido direto devolve a imagem e usa parâmetros seguros', async () => {
    const seen = {}
    const fetchImpl = async (url) => {
        seen.url = String(url)
        return okBytes(PNG)
    }
    const result = await generateWithPollinations({
        prompt: 'gothic portrait',
        width: 768,
        height: 512,
        seed: 7,
        fetchImpl,
    })
    assert.equal(result.provider, 'pollinations')
    assert.equal(result.extension, 'png')
    assert.match(seen.url, /width=768/)
    assert.match(seen.url, /height=512/)
    assert.match(seen.url, /nologo=true/)
    assert.match(seen.url, /private=true/)
    assert.match(seen.url, /safe=true/)
})

test('a fachada generateImage escolhe o provedor pedido', async () => {
    const fetchImpl = async (url, options = {}) => {
        if (options.method === 'POST' || String(url).endsWith('/generate/async'))
            return okJson({ id: 'job-7' })
        if (String(url).includes('aihorde'))
            return okJson({ done: true, generations: [{ img: PNG_BASE64 }] })
        return okBytes(PNG)
    }
    const horde = await generateImage({
        provider: 'horde',
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
        ...fast,
    })
    const pollinations = await generateImage({
        provider: 'pollinations',
        prompt: 'x',
        width: 512,
        height: 512,
        fetchImpl,
    })
    assert.equal(horde.provider, 'horde')
    assert.equal(pollinations.provider, 'pollinations')
})
