# Relatório de testes — Lunaria 1.0.0 (15/09/2026)

## Resumo em uma linha

O APK arm64 **compila, é assinado com chave própria e passa 26 de 26 testes,
TypeScript e ESLint sem avisos**; a validação no Galaxy A05s **não foi
executada** porque este ambiente não tem aparelho, emulador nem `/dev/kvm`.

## 1. Artefatos entregues

| Arquivo | Tamanho | SHA-256 |
| --- | --- | --- |
| `Lunaria-1.0.0-arm64-release.apk` | 59.322.407 bytes (57 MiB) | `6b8d707854a83c9e763064d3e94bf3c7a4fe07d298660bae12ce8bb02c4fc97d` |
| `Lunaria-1.0.0-source.zip` | 6.147.035 bytes | ver `sha256sum` ao lado do arquivo |

APK:

```
package   br.aurora.luna.lunaria.next
versão    1.0.0 (versionCode 1)
minSdk    24 (Android 7)          targetSdk 36 (Android 16)   compileSdk 36
ABI       arm64-v8a (apenas) — arquitetura do Galaxy A05s
libs      53 bibliotecas nativas
assinatura  APK Signature Scheme v2
assinante   CN=Lunaria, OU=Projeto Lunaria, O=Lunaria, L=Sao Paulo, ST=SP, C=BR
SHA-256 do certificado  c0271509ad829da96e8fd205faa99b7103bf43c358a8501c0925606c7b55719a
```

## 2. Verificações executadas neste ambiente

| Verificação | Resultado observado |
| --- | --- |
| `npm ci` | 1018 pacotes, `patch-package` aplicado |
| `npm run test:unit` | **26 testes, 26 aprovados, 0 falhas** |
| `npx tsc --noEmit` | sem erros |
| `npx eslint app db lib --max-warnings=0` | sem erros, sem avisos |
| `npx expo prebuild --platform android` | concluído; plugin de assinatura aplicado |
| `./gradlew :app:assembleRelease -PreactNativeArchitectures=arm64-v8a` | **BUILD SUCCESSFUL** (14m32s, 951 tarefas) |
| `apksigner verify --print-certs` | *Verifies* — v2, 1 assinante, RSA 4096 |
| `aapt dump badging` | pacote, versão, SDKs e ABI acima |
| Símbolos OpenMP nas 14 `librnllama*.so` | **0** indefinidos `__kmpc*`/`omp_*` |
| Dependências de `librnllama.so` | só `liblog`, `libandroid`, `libm`, `libdl`, `libc` |
| Tokenizador no APK | `res/RT.gguf` = 7.818.140 bytes (o `llama3tokenizer.gguf`) |
| AI Horde anônima (serviço externo) | resposta correta em **7,8 s**, fila 0, sem falha de nó |

### Testes automatizados

19 testes já existiam e continuam passando. Foram adicionados 7:

- **Buffer de geração (5)**: acúmulo normal, descarte de sobra de outra conversa
  antes de começar resposta nova, texto ainda sem dono, pedaço vazio e
  acentos/emoji na concatenação.
- **Pesquisa (2)**: dois sites repetindo o mesmo texto-base contam como um único
  indício; o contexto enviado ao modelo informa quantos textos-base distintos
  existem e separa fatos, divergências, opiniões e evidências insuficientes.

## 3. Correções feitas nesta rodada

| Sintoma relatado | Causa encontrada | Correção |
| --- | --- | --- |
| Resposta antiga aparecendo depois de iniciar outra conversa | O buffer de geração era uma string global sem dono: sobra de uma conversa podia prefixar a resposta seguinte e ser gravada junto | `lib/engine/StreamBuffer.ts`; todo texto carrega o **swipe** de origem e texto de outro swipe é descartado |
| Trechos de outra conversa na tela | A tela mostrava o buffer sem checar a quem pertencia | `ChatTextLast.tsx` só renderiza o buffer do swipe exibido |
| Áudio de leitura misturando respostas | Buffer de TTS também era global | `lib/state/TTS.ts` separa por swipe e limpa ao iniciar geração |
| Vários sites repetindo a mesma notícia como se fossem confirmações | O contexto só avisava genericamente | `groupIndependentSources` mede similaridade de trechos e informa os textos-base distintos |
| Consumo de memória alto no modo local | Lote de 512 buffers por passo | Lote padrão 256 (continua editável) |

## 4. O que **não** foi testado e por quê

Este ambiente é **x86_64, sem `/dev/kvm`, sem aparelho conectado e sem emulador
Android instalado**. O APK é arm64-v8a. Não existe forma de executar o
aplicativo aqui — nem por USB, nem por emulador. Por isso, nada abaixo foi
validado:

- instalação, primeira abertura, migrações do SQLite e reinício sem perder dados;
- duas mensagens neutras diferentes gerando duas respostas distintas;
- cancelar durante a preparação e durante a fila remota, e reenviar depois;
- acentos e emoji durante a geração **local** (o transporte remoto é coberto por
  teste; o modo local depende da decodificação do `llama.rn`, que só se observa
  no aparelho);
- ditado em pt-BR, encerramento do microfone ao sair e leitura em voz alta;
- pesquisa real, comparação, salvar memória, reiniciar e apagar;
- importar um GGUF e medir memória, tempo até o primeiro token e tokens por
  segundo;
- geração em segundo plano e notificação de conclusão;
- instalar uma segunda versão por cima da primeira.

**Nenhuma função acima deve ser descrita como validada.** O que existe é
inspeção de código, teste automatizado do transporte e do estado, análise dos
binários nativos e um teste real do serviço remoto.

## 5. Medições reais obtidas

| Medida | Valor | Onde |
| --- | --- | --- |
| Envio do pedido à AI Horde | 1,3 s | ambiente de desenvolvimento |
| Espera na fila | 0 s (fila vazia no momento) |  |
| Resposta completa da AI Horde | 7,8 s |  |
| Compilação completa do APK | 14m32s (retomada: 7m31s) | 2 núcleos, 1,9 GB de RAM, com swap |
| Pesquisa lendo NASA e ESA | ~8,4 s | checkpoint anterior |

Não há medição de tempo até o primeiro token no aparelho. No modo online isso
nem existe: a API pública da AI Horde devolve o texto completo no fim; o
aplicativo mostra fila e espera em vez de tokens parciais.

## 6. Limitações conhecidas do ambiente de compilação

- Com 2 núcleos e 1,9 GB de RAM o Gradle morre por memória; foi preciso swap e
  `--max-workers=1`. Em máquina com 8 GB o build é direto.
- O disco do ambiente encheu durante o build e a tarefa
  `:cui-llama.rn:copyReleaseJniLibsProjectOnly` falhou com *No space left on
  device*. Era o ambiente: liberando espaço, o build passou. Registrado aqui
  para não ser confundido com bug do projeto.

## 7. Próximo passo para fechar a entrega

1. Instalar o APK no Galaxy A05s (veja `INSTALACAO_E_CONFIGURACAO.md`).
2. Rodar a lista de testes da seção 4 e anotar o que falhar, com a tela de erro
   e o final de Configurações → Registros.
3. No modo local, começar com um GGUF de 1–3 B Q4_K_M, contexto 4096 e lote 256;
   anotar memória livre, tempo até o primeiro token e tokens por segundo.
