/**
 * Gestão de chaves do cofre privado.
 *
 * Como funciona, sem enrolação:
 *  1. A senha/PIN do usuário **nunca** é guardada — nem em texto, nem com hash.
 *  2. Ela é transformada em chave (PBKDF2-SHA256, 150 mil iterações, sal
 *     aleatório por cofre).
 *  3. Essa chave não cifra arquivos: ela cifra (envelopa) a **chave de dados**
 *     (DEK), que é aleatória e faz o trabalho pesado. O envelope fica no
 *     armazenamento seguro do sistema (`expo-secure-store`, apoiado no
 *     Keystore do Android).
 *  4. Trocar a senha reescreve só o envelope — nenhuma imagem é recifrada.
 *
 * Isso é gestão de chave no padrão da plataforma, como foi pedido. O arquivo é
 * específico do aparelho: importa módulo nativo, por isso os testes automatizados
 * não o carregam (as primitivas puras ficam em `Crypto.ts`).
 */

import * as Crypto from 'expo-crypto'
import * as SecureStore from 'expo-secure-store'

import { base64ToBytes, bytesToBase64 } from '@lib/utils/Binary'

import {
    decryptFromBase64,
    deriveKeyFromSecret,
    encryptToBase64,
    generateKey,
    randomSalt,
    setRandomSource,
    verifierFor,
    verifierMatches,
} from './Crypto'

// O Hermes não expõe `crypto`; o expo-crypto é a fonte no aparelho.
setRandomSource((length: number) => Crypto.getRandomBytes(length))

const SLOTS = {
    /** DEK envelopada pela chave derivada da senha. */
    wrapped: 'lunaria-dek-wrapped',
    /** Sal do PBKDF2 (não é segredo, mas fica junto para não se perder). */
    salt: 'lunaria-vault-salt',
    /** Verificador: confere a senha sem decifrar arquivo (§ ver Crypto.verifierFor). */
    verifier: 'lunaria-verifier',
    /** Cópia da DEK liberada pela biometria (só existe se o usuário ativar). */
    biometric: 'lunaria-dek-biometric',
    /** Metadados do cofre: versão, data de criação, iterações. */
    meta: 'lunaria-vault-meta',
} as const

export type VaultMeta = {
    version: number
    createdAt: string
    iterations: number
    biometric: boolean
}

const readSlot = async (key: string): Promise<string | null> => {
    try {
        return await SecureStore.getItemAsync(key)
    } catch {
        return null
    }
}

const writeSlot = async (key: string, value: string): Promise<void> => {
    await SecureStore.setItemAsync(key, value)
}

const clearSlot = async (key: string): Promise<void> => {
    try {
        await SecureStore.deleteItemAsync(key)
    } catch {
        // Nada a fazer: apagar o que não existe não é erro.
    }
}

export const vaultExists = async (): Promise<boolean> => (await readSlot(SLOTS.wrapped)) !== null

export const readVaultMeta = async (): Promise<VaultMeta | undefined> => {
    const raw = await readSlot(SLOTS.meta)
    if (!raw) return undefined
    try {
        return JSON.parse(raw) as VaultMeta
    } catch {
        return undefined
    }
}

/**
 * Cria o cofre: gera a DEK, o sal, o envelope e o verificador.
 * Devolve a DEK já destravada para uso imediato.
 */
export const createVault = async (secret: string): Promise<Uint8Array> => {
    const salt = randomSalt()
    const key = deriveKeyFromSecret(secret, salt)
    const dek = generateKey()

    await writeSlot(SLOTS.salt, encodeSalt(salt))
    await writeSlot(SLOTS.wrapped, encryptToBase64(key, dek))
    await writeSlot(SLOTS.verifier, verifierFor(key))
    await writeSlot(
        SLOTS.meta,
        JSON.stringify({
            version: 1,
            createdAt: new Date().toISOString(),
            iterations: 150_000,
            biometric: false,
        } satisfies VaultMeta)
    )

    return dek
}

// Codificador do projeto (sem `btoa`, que o Hermes não garante).
export const encodeSalt = (salt: Uint8Array): string => bytesToBase64(salt)

export const decodeSalt = (value: string): Uint8Array => base64ToBytes(value)

/**
 * Confere a senha sem decifrar arquivo. Usado antes de qualquer operação
 * sensível (trocar senha, desligar bloqueio, reiniciar cofre).
 */
export const secretIsCorrect = async (secret: string): Promise<boolean> => {
    const [saltValue, verifier] = await Promise.all([
        readSlot(SLOTS.salt),
        readSlot(SLOTS.verifier),
    ])
    if (!saltValue || !verifier) return false
    const key = deriveKeyFromSecret(secret, decodeSalt(saltValue))
    return verifierMatches(key, verifier)
}

/** Abre o cofre e devolve a DEK. Lança erro se a senha estiver errada. */
export const unlockVault = async (secret: string): Promise<Uint8Array> => {
    const [saltValue, wrapped] = await Promise.all([readSlot(SLOTS.salt), readSlot(SLOTS.wrapped)])
    if (!saltValue || !wrapped) throw new Error('Cofre não configurado')
    const key = deriveKeyFromSecret(secret, decodeSalt(saltValue))
    const dek = decryptFromBase64(key, wrapped)
    if (dek.length !== 32) throw new Error('Chave de dados inválida')
    return dek
}

/**
 * Troca a senha reescrevendo só o envelope da DEK.
 * Exige a senha atual: não existe troca sem autenticação.
 */
export const changeSecret = async (currentSecret: string, nextSecret: string): Promise<void> => {
    const dek = await unlockVault(currentSecret)
    const salt = randomSalt()
    const nextKey = deriveKeyFromSecret(nextSecret, salt)
    await writeSlot(SLOTS.salt, encodeSalt(salt))
    await writeSlot(SLOTS.wrapped, encryptToBase64(nextKey, dek))
    await writeSlot(SLOTS.verifier, verifierFor(nextKey))
}

/* ------------------------- biometria (opcional) ------------------------- */

/**
 * Guarda uma cópia da DEK no armazenamento seguro protegido pelo sistema para
 * que a biometria possa abrir o aplicativo sem senha.
 *
 * Honestidade sobre o que isso significa: a proteção aqui é o Keystore do
 * Android (`EncryptedSharedPreferences`/StrongBox quando disponível) e o app
 * exige sucesso em `expo-local-authentication` antes de ler o slot. Quem tiver
 * o aparelho desbloqueado e conseguir ler esse armazenamento não precisa da
 * senha. É um atalho de conveniência, desligado por padrão e removível na tela
 * de bloqueio — a senha continua sendo a proteção principal.
 */
export const enableBiometricAccess = async (dek: Uint8Array): Promise<void> => {
    await writeSlot(SLOTS.biometric, bytesToBase64(dek))
    const meta = await readVaultMeta()
    await writeSlot(SLOTS.meta, JSON.stringify({ ...meta, biometric: true, version: 1 }))
}

export const disableBiometricAccess = async (): Promise<void> => {
    await clearSlot(SLOTS.biometric)
    const meta = await readVaultMeta()
    if (meta) await writeSlot(SLOTS.meta, JSON.stringify({ ...meta, biometric: false }))
}

export const biometricAccessEnabled = async (): Promise<boolean> =>
    (await readSlot(SLOTS.biometric)) !== null

/** Lê a DEK liberada pela biometria. Só chamar depois de autenticar de verdade. */
export const unlockWithBiometric = async (): Promise<Uint8Array | undefined> => {
    const stored = await readSlot(SLOTS.biometric)
    if (!stored) return undefined
    const dek = base64ToBytes(stored)
    return dek.length === 32 ? dek : undefined
}

/**
 * Apaga o cofre (procedimento de "esqueci a senha").
 * As chaves somem e, com elas, o acesso às imagens cifradas — por isso a tela
 * explica as consequências antes. Não toca no banco de conversas.
 */
export const destroyVault = async (): Promise<void> => {
    await Promise.all([
        clearSlot(SLOTS.wrapped),
        clearSlot(SLOTS.salt),
        clearSlot(SLOTS.verifier),
        clearSlot(SLOTS.biometric),
        clearSlot(SLOTS.meta),
    ])
}
