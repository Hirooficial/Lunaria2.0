# Correções e pendências

Este arquivo lista o que foi corrigido, o que foi **verificado nesta rodada** e
o que continua pendente por falta de aparelho.

## Corrigido e verificado no código (com teste automatizado)

| Problema | Alteração | Verificação |
| --- | --- | --- |
| Acentos/emoji quebrados entre partes da resposta | Decodificação UTF-8 incremental e eventos SSE completos em `lib/engine/StreamDecoder.ts` e `lib/engine/SSEFetch.ts` | `tests/stream.test.mjs`, 5 testes, incluindo todos os cortes de byte de uma mensagem com emoji |
| Sobra de outra resposta/conversa prefixando uma resposta nova | O buffer de geração agora tem dono: `lib/engine/StreamBuffer.ts` + swipe informado por `Inference.ts`, `LocalInference.ts`, `Chat.ts` e `TTS.ts` | `tests/buffer.test.mjs`, 5 testes |
| Texto de outra conversa aparecendo na tela | `ChatTextLast.tsx` só renderiza o buffer do swipe exibido | inspeção de código + teste de `bufferBelongsToSwipe` |
| Frases prontas, eco e perda da formatação | `lib/persona/ResponseGuard.ts` preserva Markdown, links, números e emoji; remove só controles, prefixo e eco exato | `tests/persona.test.mjs`, 4 testes |
| Cópias da mesma notícia tratadas como confirmações separadas | Agrupamento por similaridade de trechos (`groupIndependentSources`) e prompt que separa fatos, divergências, opiniões e evidências insuficientes | `tests/research.test.mjs`, 2 testes novos |
| Pesquisa com leitura sem limites, URLs locais e fontes repetidas | Limites de corpo/tempo, validação de URL e redirecionamento, diversidade de domínios, links manuais | `tests/research.test.mjs` |
| Contagem de tokens sem tokenizador | Estimativa conservadora por bytes UTF-8 em `lib/engine/Tokenizer.ts` | inspeção de código |
| Voz padrão em idioma inadequado | Padrão pt-BR em `lib/state/TTS.ts` | inspeção de código |
| Chat carregado antes da preparação inicial | Inicialização coordenada em `app/index.tsx` | inspeção de código |
| Pesquisa ativa persistindo indevidamente | Só as notas são gravadas; o salvamento é explícito | `lib/state/ResearchMemory.ts`, `app/screens/ResearchScreen.tsx` |

## Verificado nesta rodada (sem aparelho)

- **Compilação arm64**: `:app:assembleRelease` terminou (`BUILD SUCCESSFUL`,
  14m32s). O erro de `Binary store`/`EOFException` da tentativa anterior **não
  reapareceu**; ele não se reproduziu com `-Pkotlin.incremental=false` e com um
  único worker. A causa real da falha anterior não pôde ser confirmada — o
  ambiente foi reiniciado antes do fim —, então o registro honesto é: não
  reproduzido agora, possível cache inconsistente.
- **Falta de espaço em disco**: durante o build o sistema ficou com 0 bytes
  livres e a tarefa `:cui-llama.rn:copyReleaseJniLibsProjectOnly` falhou com
  `No space left on device`. Era o ambiente, não o projeto; resolvido liberando
  espaço. Registrado para quem compilar com pouco disco.
- **OpenMP**: as 14 bibliotecas `librnllama*.so` arm64 do APK têm **zero**
  símbolos indefinidos `__kmpc*`/`omp_*` e só dependem de `liblog`, `libandroid`,
  `libm`, `libdl` e `libc`. O `UnsatisfiedLinkError` de `__kmpc_fork_call` da
  versão antiga não pode vir destes binários.
- **Tokenizador embutido**: `assets/models/llama3tokenizer.gguf` entra no APK
  como `res/RT.gguf` (o otimizador de recursos encurta o nome). O aviso
  `expo-asset: .gguf is not a supported asset type` é sobre o plugin de assets e
  não impede o arquivo de ser empacotado como recurso `raw`.
- **IA remota**: pedido real à AI Horde anônima, com os mesmos parâmetros do
  aplicativo, respondeu corretamente (7,8 s, fila 0, sem falha de nó).

## Pendências que exigem o aparelho

### 1. Instalação e inicialização

Não houve instalação: este ambiente não tem aparelho por USB, emulador Android
nem `/dev/kvm` (e é x86_64, enquanto o APK é arm64-v8a). Conferir no A05s:
instalação, primeira abertura, migrações do SQLite e reinício sem perder dados.

### 2. Carregamento do GGUF e inferência local

Falta importar um GGUF compatível e medir memória, tempo até o primeiro token e
tokens por segundo. O padrão conservador (contexto 4096, lote 256, 4 threads,
`ctx_shift`) foi escolhido para 6 GB de RAM, mas **não foi medido em aparelho**.
Sugestão para o A05s: modelo de 1 B a 3 B com quantização Q4_K_M; comece pelo
contexto 2048 se notar reinício do aplicativo.

### 3. Caracteres, cancelamento e repetição no uso real

Os testes cobrem o transporte e o estado, não o comportamento do modelo. Falta
observar no aparelho: acentos e emoji durante a geração local, cancelar na fila
remota, cancelar no meio da resposta local, reenviar depois de cancelar e
alternar entre duas conversas durante a geração.

### 4. Busca automática (DuckDuckGo)

No ambiente de desenvolvimento a busca automática foi bloqueada. O aplicativo
explica a indisponibilidade e aceita dois ou mais links HTTPS. Testar a busca
automática na rede do celular; se continuar bloqueada em uso normal, avaliar
outro provedor documentando limites e privacidade.

### 5. Voz, notificações e segundo plano

Faltam: ditar em pt-BR e conferir o encerramento do microfone ao sair da
conversa; ler uma resposta em voz alta; verificar a geração com o aplicativo em
segundo plano e a notificação de conclusão.

### 6. Assinatura e atualização

O APK desta entrega é assinado com a chave de release da Lunaria (fora do ZIP).
Falta confirmar no aparelho que uma segunda instalação por cima da primeira
funciona sem desinstalar.

## Critério para fechar uma pendência

Só marcar como resolvido com: reprodução, mudança aplicada, comando/teste
executado e resultado observado. Sem aparelho, modelo ou rede, a pendência
continua aberta e registrada como tal.

---

# Rodada 2 (18/09/2026) — geração de imagem e bloqueio por senha

## Falhas encontradas durante a implementação (e corrigidas)

### 1. Política de conteúdo bloqueava pedidos legítimos com negação explícita

**Como apareceu:** teste automatizado `imagepolicy.test.mjs` — a descrição
“Lunaria com choker de renda e vestido longo, pose sensual, sem nudez” era
recusada, porque o filtro via a palavra “nudez” e não entendia a negação.

**Correção:** a lista de explícito agora ignora ocorrências negadas
(“sem”, “não”, “evitar”, “nada de”, “without”). A exceção vale **apenas** para a
lista de explícito: menores e coerção continuam sem qualquer flexibilização.
**Estado:** corrigido e coberto por teste (`permite ... sem nudez`).

### 2. Copiar imagem gerada para `Attachments/` duplicaria conteúdo em claro

**Como apareceu:** revisão do caminho de anexo — `createAttachment` copia o
arquivo para `documentos/Attachments/`, o que desfaria a cifragem no exato
momento de anexar.

**Correção:** anexo de imagem gerada não é copiado; a linha do banco aponta para
`private://nome`, o arquivo continua só no cofre cifrado. Apagar o anexo também
apaga o arquivo cifrado e o índice.
**Estado:** corrigido; verificação no aparelho pendente.

### 3. Com o app bloqueado, a notificação abriria a conversa sem autenticação

**Como apareceu:** revisão do caminho de entrada — o observador de notificações
chamava `loadChat` + `router.navigate` sem consultar o bloqueio, e a navegação
aconteceria antes da tela de desbloqueio.

**Correção:** com o bloqueio ativo, a intenção fica guardada (`pendingChat`) e só
é executada depois do desbloqueio; a notificação é limpa, não fica pendurada.
**Estado:** corrigido; teste no aparelho pendente.

### 4. Salvar na galeria falhava por permissão não declarada

**Como apareceu:** revisão do manifesto — `READ_MEDIA_IMAGES` não estava
declarado, então `requestPermissionsAsync` retornaria negado no Android 13+ e o
salvamento seria abortado mesmo quando o sistema permitiria gravar (API 29+ grava
via MediaStore sem permissão).

**Correção:** permissão declarada no manifesto e o fluxo de salvamento tenta a
gravação de qualquer forma, com mensagem clara se o sistema recusar.
**Estado:** corrigido; verificação no aparelho pendente.

### 5. PBKDF2 inicialmente caro demais para um aparelho de entrada

**Como apareceu:** medição no desktop com 210.000 iterações (≈473 ms). Num
aparelho modesto isso poderia passar de 1,5 s a cada desbloqueio.

**Correção:** 150.000 iterações (≈358 ms no desktop), ainda acima do mínimo
recomendado pela OWASP para PBKDF2-HMAC-SHA256. O valor é um único ponto de
ajuste em `lib/security/Crypto.ts`.
**Estado:** ajustado; medição real no A05s pendente.

## Pendências desta rodada (não são falhas, são verificações que exigem aparelho)

1. Gerar imagem real pelo aplicativo nos dois provedores, com internet do
   celular; conferir fila, tempo, cancelamento e nova tentativa.
2. Salvar na galeria e compartilhar, conferindo o aviso de perda de proteção.
3. Apagar imagem pelo visualizador e confirmar que o arquivo cifrado sumiu.
4. Bloqueio: senha errada (espera progressiva), reinício do aplicativo, volta do
   segundo plano, abertura por notificação, biometria, troca de senha.
5. Migração: atualizar por cima de uma instalação 1.0.0 com imagens em
   `Attachments/` e confirmar que aparecem normalmente depois da migração.
6. Conferir que nenhum conteúdo aparece antes da tela de desbloqueio (teste
   visual, gravando a tela).

## Critério para fechar uma pendência

Inalterado: só marcar como resolvido com reprodução, mudança aplicada,
comando/teste executado e resultado observado.

---

# Rodada 2 — falhas do build nesta máquina (registro honesto)

O código compila, mas o ambiente de build (2 núcleos, 1,9 GB de RAM, sem
`/dev/kvm`) derrubou o build duas vezes. Registro do que aconteceu e do que foi
feito, porque isso não pode virar “funcionou de primeira”:

### A. Daemon do Gradle morto por falta de memória (1ª tentativa, exit=1)

- **Sintoma**: `Gradle build daemon disappeared unexpectedly` ao compilar
  `llama.cpp` (`cui-llama.rn`), com três processos `clang++` consumindo mais de
  1,3 GB somados numa máquina de 1,9 GB.
- **Causa**: eu havia rodado `tsc`, `eslint` e a suíte de testes **em paralelo**
  com o build (um `tsc` ficou órfão ocupando ~400 MB). O kernel escolheu o maior
  processo e matou o daemon.
- **Correção**: encerrar os processos paralelos, esperar as compilações órfãs
  terminarem (o trabalho delas é reaproveitado pelo CMake) e repetir o build sem
  nada mais rodando junto.

### B. `OutOfMemoryError: Metaspace` no lint de bibliotecas (2ª tentativa, exit=1)

- **Sintoma**: `:react-native-gesture-handler:lintVitalAnalyzeRelease FAILED`,
  com dezenas de `metaspace` esgotado no log.
- **Causa**: o `lintVitalAnalyzeRelease` roda para **cada** módulo de biblioteca
  e é o maior consumidor de Metaspace do build de release. Eu tinha reduzido
  `-XX:MaxMetaspaceSize` para 384 MB ao mesmo tempo em que tirei memória do heap
  — combinação que quebra o lint, não o aplicativo.
- **Correção**: `android/build.gradle` desativa `lintVital*` **apenas nos módulos
  de biblioteca** (não no `:app`), com o motivo comentado no próprio arquivo, e o
  Metaspace voltou para 512 MB. O lint é análise estática: **não** faz parte do
  APK e não altera comportamento. Em máquina com memória sobrando, basta remover
  o bloco para voltar a rodá-lo.
- **Registrado como limitação do ambiente**, não como correção de código.

### C. Tentativas repetidas de build em ambiente apertado

- **Correção**: parâmetro `CMAKE_BUILD_PARALLEL_LEVEL=2` em
  `lunaria-build/build-apk-2.sh` para limitar a compilação nativa paralela, e a
  disciplina de não rodar nada pesado durante o build.

Nenhuma dessas três ocorrências tem relação com a geração de imagem, com o
bloqueio por senha ou com qualquer código desta entrega.

---

# Incidente de 18/09 — perda do workspace e reconstrução da rodada 2

Isto não é um bug do aplicativo, é um registro do que aconteceu com o ambiente e
do que foi feito. Está aqui porque o pedido foi claro: nada de esconder problema.

## O que aconteceu

Entre uma sessão de trabalho e a seguinte, o workspace da máquina de build foi
**revertido**: a árvore de código voltou ao estado anterior à rodada 2 (a versão
1.0.0), e sumiram junto:

- todos os arquivos novos da rodada 2 (`lib/security/`, `lib/imagegen/`,
  `lib/utils/Binary.ts`, telas de geração de imagem e de bloqueio, componentes);
- o APK 1.1.0 que já havia sido compilado e verificado;
- o toolchain em `/opt` (JDK, SDK, NDK) e o `node_modules`;
- os caches do Gradle e as saídas de build.

**Sobreviveram**: o keystore de assinatura (com a senha, fora do projeto), os
scripts de build, os documentos (`STATUS.md`, `TEST_REPORT.md`, este arquivo,
`CHANGELOG.md`, `IMAGEM_LOCAL_VIABILIDADE.md`, `GERACAO_DE_IMAGEM_E_BLOQUEIO.md`)
e o `package.json`/`package-lock.json` com todas as dependências da 1.1.0.

## O que foi feito

1. O código da rodada 2 foi **reescrito do zero**, usando os documentos
   sobreviventes como especificação (provedor, política de conteúdo, parâmetros
   de criptografia, chaves de configuração, comportamento da tela de bloqueio).
   Mesmo critério de antes: nada de resposta pronta, nada de atalho.
2. Toolchain reinstalado (`setup-toolchain.sh`) e dependências reinstaladas
   (`npm ci`) a partir do lockfile original — as versões são as mesmas.
3. Todos os portões foram rodados de novo nesta máquina, do zero: suíte de
   testes, `tsc` e ESLint. Os números estão em `TEST_REPORT.md`.
4. O APK foi recompilado e reassinado com **o mesmo keystore**, então a
   atualização continua instalando por cima da 1.0.0.

## Aprendizado registrado

- O keystore guardado **fora** do projeto (em `lunaria-assinatura/`) foi o que
  salvou a compatibilidade de atualização. Se ele tivesse ficado só dentro da
  árvore de build, os usuários teriam de desinstalar para instalar a 1.1.0.
- Documento que descreve decisão de projeto (provedor, criptografia, política)
  vale tanto quanto código: foi o que permitiu reconstruir sem adivinhar.
- `CHECKSUMS.sha256` e o ZIP de código-fonte **precisam** ser refeitos a cada
  build; um ZIP gerado antes de uma perda de arquivos parece válido e não é.

---

# Build da reconstrução (18/09) — três tentativas, duas falhas de ambiente

Registro do que atrapalhou o build depois da reconstrução. Nenhuma delas é bug do
aplicativo, e todas estão reproduzidas porque não se deve apresentar "compilou de
primeira" quando não foi.

### D. `minifyReleaseWithR8` sem heap depois de 1h52 (`java.lang.OutOfMemoryError: Java heap space`)

- **Sintoma**: o build ficou quase duas horas e morreu em
  `:app:minifyReleaseWithR8` com `OutOfMemoryError: Java heap space`. A máquina
  tem 2 GB de RAM e entrou em troca de página pesada (2,3 GB de swap em uso).
- **Causa**: o R8 em modo completo (full mode) precisa de muito mais heap do que
  os 1536 MB reservados para ele, ainda mais num APK que embute `llama.cpp`,
  Firebase/MLKit e 48 bibliotecas nativas.
- **Correção**: `android.enableR8.fullMode=false` em `android/gradle.properties`
  (modo de compatibilidade: continua fazendo shrinking e ofuscação, só não aplica
  as otimizações mais caras), heap em 2560 MB e `-XX:+UseSerialGC`.
- **Resultado**: build completo em **5m 33s** (929 tarefas, 331 executadas).
- **Impacto no aplicativo**: nenhum no comportamento; muda o nível de otimização
  do bytecode. Em máquina com folga de RAM, a linha pode ser removida.
- **Ressalva honesta**: o executável `:app:minifyReleaseWithR8` da reconstrução
  não é byte a byte o mesmo que o da tentativa anterior, mas o APK é equivalente
  em funcionalidade. O que **precisou** coincidir — o certificado de assinatura —
  coincide: `c0271509…5719a`, o mesmo da 1.0.0.

### E. Primeira tentativa de build da reconstrução: daemon do Gradle derrubado

- **Sintoma**: `Gradle build daemon disappeared unexpectedly` durante a
  compilação nativa, com o `kswapd0` consumindo CPU sem parar.
- **Causa**: `-Xmx1536m` somado às compilações `clang++` do `llama.cpp` estourou a
  memória física da máquina.
- **Correção**: nada pesado em paralelo com o build (nem testes, nem `tsc`) e
  limite de paralelismo nativo em 2 (`CMAKE_BUILD_PARALLEL_LEVEL=2`, já no
  `build-apk-2.sh`).

### F. Terceira tentativa: sucesso

`BUILD SUCCESSFUL in 5m 33s`, com as tarefas nativas já compiladas sendo
reaproveitadas. APK arm64-v8a de 60.463.298 bytes, assinado, com
`READ_MEDIA_IMAGES`, `allowBackup=false` e `dataExtractionRules` aplicados.

---

# Segunda perda de workspace e a cadeia de builds até o APK final (18/09, tarde)

O resumo honesto: o APK que eu já havia entregue (`629894dd…`) **deixou de existir**
quando o workspace foi revertido de novo no limite do turno. O ZIP do código
sobreviveu, foi de lá que eu restaurei tudo, e o APK final saiu de **sete**
tentativas de build nesta máquina. Nenhuma das falhas é bug do aplicativo; todas
são limite de ambiente (memória, disco, NDK removido por erro meu). Estão aqui
porque o relatório tem que dizer o que realmente aconteceu.

### G. Rollback nº 2: o APK perdido, o ZIP salvo

- **Sintoma**: ao retomar o trabalho, `lib/security/`, `lib/imagegen/`, as telas
  novas e as imagens nativas… nada disso estava na árvore; a entrega tinha
  `Lunaria-1.1.0-source.zip` (intacto, sha `5f789b6a…`, conferido) mas o APK
  havia desaparecido.
- **Causa**: mesmo comportamento de snapshot do ambiente já registrado na seção C
  (uma reversão no limite do turno). Os arquivos grandes são os primeiros a
  sumir; o ZIP de 7,5 MB sobreviveu, o APK de 57,7 MB não.
- **Correção**: `unzip` do ZIP em diretório limpo → 388 arquivos, conferidos
  contra o próprio `CHECKSUMS.sha256` do pacote → **todos OK**. O
  `android/keystore.properties` local (fora do ZIP, por segurança) foi devolvido
  a partir da cópia preservada.
- **Lição aplicada**: a partir de agora o ZIP do código é a fonte de recuperação
  e é regerado a cada mudança relevante; a entrega fica com o mínimo de arquivos
  grandes possível.

### H. Build nº 4: o kernel matou o Gradle (`Out of memory: Killed process`)

- **Sintoma**: `DaemonDisappearedException` depois de 40 min, com
  `dmesg` mostrando `oom-kill: … task=java,pid=13525` e
  `anon-rss:1691656kB`. Naquele momento o R8 **já tinha passado** — ou seja, a
  correção da seção D funcionou.
- **Causa raiz**: o daemon do Kotlin herdava `-Xmx2560m` do Gradle. Dois JVMs
  pedindo 2,5 GB numa máquina de 1,9 GB → o kernel escolheu um e matou.
- **Correção**: `kotlin.daemon.jvmargs=-Xmx1024m -XX:MaxMetaspaceSize=256m` em
  `android/gradle.properties` (teto explícito, em vez de herdar).
- **Não era**: falta de swap no primeiro momento — mas foi o que me levou a
  criar swap extra, que depois atrapalhou por consumir disco (seção K).

### I. Build nº 5: NDK apagado por engano (erro meu, não do projeto)

- **Sintoma**: `BUILD FAILED in 43s`, com AGP tentando instalar
  `NDK (Side by side) 27.0.12077973` e falhando com
  `java.io.IOException: No space left on device`.
- **Causa**: para liberar disco eu apaguei o NDK 27.0.12077973, deduzindo pelo
  plugin de compatibilidade do Expo que o projeto usaria só o 27.1.12297006.
  Errado: o script de toolchain instala **os dois de propósito** — o app compila
  com 27.1 e uma dependência Expo exige o 27.0 (isso já estava anotado em
  `COMECE_AQUI_ARENA.md`, eu não reli).
- **Correção**: `sdkmanager --install "ndk;27.0.12077973"` (27 s de download) e
  espaço em disco liberado antes. Registro para não repetir: **não remover NDK
  nenhum deste projeto**.

### J. Build nº 6: disco cheio (`No space left on device`)

- **Sintoma**: build morreu aos 14 min com `No space left on device`; o disco
  ficou em 100% (1,4 MB livres).
- **Causa**: as tentativas anteriores regeneraram transforms do Gradle
  (~2,9 GB) e `merged_native_libs` (~500 MB) em cima de um disco de 25 GB já
  ocupado por SDK (4,9 GB), dois NDKs (4 GB), `node_modules` (2,7 GB) e 6,8 GB de
  swap em arquivo.
- **Correção**: devolver o swap extra (`swapfile2`, 2,8 GB) — o motivo real da
  falta de memória era o daemon do Kotlin, já limitado — e remover bibliotecas
  de ciência de dados do Python da imagem base que este trabalho não usa.
  Espaço livre passou de 1,4 MB para 3,9 GB.

### K. Build nº 7: sucesso

```
> Task :app:minifyReleaseWithR8
BUILD SUCCESSFUL in 3m 17s
929 actionable tasks: 120 executed, 809 up-to-date
--- exit=0 Fri Sep 18 13:49:28 UTC 2026 ---
```

APK arm64-v8a de **60.463.298 bytes**, SHA-256
`6bcbede3ae8a2bf40aebc5f3549062a2ebe5dfd749ce3cf96a2559e2d1236608`, assinado
com o mesmo certificado da 1.0.0 (`c0271509…5719a`).

O `assets/index.android.bundle` saiu com **6.424.936 bytes** e o
`res/RT.gguf` com **7.818.140 bytes** — exatamente os mesmos tamanhos do APK
perdido, o que mostra que o código reconstruído é o mesmo; o que muda entre as
duas compilações é só o bytecode de assinatura/timestamps.

### Mudanças permanentes em `android/gradle.properties` por causa disso

- `android.enableR8.fullMode=false` — R8 em modo de compatibilidade (seção D).
- `kotlin.daemon.jvmargs=-Xmx1024m -XX:MaxMetaspaceSize=256m` — teto do daemon
  do Kotlin (seção H).
Nenhuma das duas altera o comportamento do aplicativo: uma muda o nível de
otimização do bytecode, a outra limita a memória de um processo de compilação.

### L. Causa provável das duas perdas de arquivo: teto de tamanho do workspace

- **Sintoma**: em duas ocasiões seguidas os artefatos grandes da entrega
  desapareceram entre um turno e outro — primeiro a árvore inteira da rodada 2,
  depois só o APK de 57,7 MB, sempre com os arquivos pequenos sobrevivendo
  (inclusive o ZIP de 7,5 MB).
- **Causa provável**: o workspace desta máquina é salvo com teto de
  aproximadamente **128 MB**. Medido agora: a pasta `/home/user` (sem os
  diretórios que ficam fora do snapshot, como `node_modules` e caches) somava
  **152 MB**, sendo 128 MB só da pasta `entrega` — com dois APKs de ~58 MB cada.
  Ou seja: o snapshot não cabia, e os arquivos maiores foram os sacrificados.
- **Correção aplicada**: manter na entrega apenas o artefato atual (APK 1.1.0 +
  ZIP do código) e remover o APK da 1.0.0, que está superado e pode ser
  reconstruído a partir de `Lunaria-1.0.0-source.zip` com o mesmo keystore.
  Total do snapshot caiu para ~95 MB, com folga em relação ao teto.
- **Lição**: a entrega é regenerável, mas o **ZIP do código é o item mais
  valioso em caso de perda** — é pequeno, sobrevive, e foi ele que permitiu
  restaurar tudo nas duas vezes.
