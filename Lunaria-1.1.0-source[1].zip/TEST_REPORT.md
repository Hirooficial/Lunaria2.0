# Verificação da Lunaria 1.1.0 — 18/09/2026 (rodada Arena 2)

Relatório da versão 1.0.0 preservado em `TEST_REPORT-1.0.0.md`. Aqui só entram
resultados **observados**, separando o que roda nesta máquina (automático), o
que exige emulador (não disponível aqui) e o que exige o Galaxy A05s.

## 1. Testes automatizados (executados nesta máquina — resultado real)

| Verificação | Comando | Resultado |
| --- | --- | --- |
| Suíte completa | `node --import tsx --test tests/*.test.mjs` | **87 de 87** passaram, 0 falhas |
| Criptografia do cofre | `node --import tsx --test tests/crypto.test.mjs` | 9 de 9 (AES-256-GCM, PBKDF2, senha errada, senha certa, adulteração detectada, base64 próprio, UTF-8 com acentos e emoji) |
| Política de conteúdo | `tests/imagepolicy.test.mjs` | 8 de 8 (permite adulto/sensual/moda/romance; recusa explícito, menor, coerção, proibido) |
| Montagem do prompt | `tests/imageprompt.test.mjs` | 10 de 10 (proporções, 8 estilos, perfil, negativo, prévia, semente) |
| Cliente dos provedores | `tests/imageprovider.test.mjs` | 12 de 12 (fila, imagem, cancelamento, 429, 502, sem rede, não-imagem, chaves) |
| Bloqueio e migração (regras) | `tests/lock.test.mjs` | 9 de 9 (mínimo de 6, espera progressiva, teto de 5 min, plano de migração idempotente) |
| Suíte anterior (persona, pesquisa, streaming) | mesmos comandos | 26 de 26 continuam passando |
| TypeScript | `npx tsc --noEmit` | sem erros |
| ESLint | `npx eslint .` | 0 erros (32 avisos de estilo, nenhum novo de lógica) |

### Diferença entre teste com rede simulada e teste real

Os 12 testes do cliente de provedor usam um `fetch` falso **de propósito**: eles
verificam como o aplicativo reage a fila, cota estourada (429), provedor fora do
ar (502), arquivo que não é imagem e cancelamento sem depender da sorte da rede.
O que foi testado **contra os serviços reais** está na seção 2.

## 2. Chamadas reais aos provedores (executadas nesta máquina)

| Provedor | Pedido | Resultado observado |
| --- | --- | --- |
| AI Horde (imagem), chave anônima `0000000000` | `POST https://aihorde.net/api/v2/generate/async`, 512×768, 24 passos, `nsfw:true` | `{"id":"1f154d33…","kudos":6.0}`; status `done` com `generations[0].img` em base64 (WebP 512×768, 94.280 bytes) em ~25 s, `censored:false`, modelo `stable_diffusion` |
| AI Horde, `dry_run` com conteúdo adulto | mesmo endpoint | aceito, `kudos` 9.0 (autoriza o pedido sem gastar fila) |
| AI Horde (texto), confirmação do caminho existente | `POST /generate/text/async` | resposta correta em 7,8 s, fila 0 |
| Pollinations, sem chave | `GET image.pollinations.ai/prompt/...?width=512&height=768&seed=42` | HTTP 200, JPEG 512×768, 37.291 bytes em ~2,0 s |

Nada disso foi executado **pelo aplicativo** — foi o mesmo pedido, com os mesmos
parâmetros e cabeçalhos, feito por linha de comando. Reproduzir pelo aplicativo
é item da seção 4.

## 2.1. Build do APK (executado nesta máquina)

| Verificação | Resultado |
| --- | --- |
| `:app:assembleRelease` arm64 | **BUILD SUCCESSFUL in 3m 17s** (929 tarefas) |
| Assinatura | `apksigner verify`: CN=Lunaria, digest SHA-256 `c0271509…5719a` — **idêntico ao da 1.0.0** (atualiza por cima) |
| Versão / pacote | `br.aurora.luna.lunaria.next`, versionCode 2, versionName 1.1.0, targetSdk 36, minSdk 24, arm64-v8a |
| Manifesto | `READ_MEDIA_IMAGES` presente; `allowBackup=false`; `fullBackupContent=false`; `dataExtractionRules` aplicado |
| Recursos | `assets/index.android.bundle` (Hermes, 6.424.936 bytes), `res/RT.gguf` (7.818.140 bytes), 48 `.so` arm64 |
| Módulos novos no dex | `ScreenCapture`, `SecureStore`, `MediaLibrary`, `Sharing`, `LocalAuthentication` |
| Código novo no bundle | `lunaria-lock-settings-v1`, `lunaria-image-prefs-v1`, `lunaria-migration-images-v2`, `private://`, `.lunaenc`, `Gerar imagem`, `Proteção por senha` |
| SHA-256 do APK | `6bcbede3ae8a2bf40aebc5f3549062a2ebe5dfd749ce3cf96a2559e2d1236608` |
| Tentativas até o sucesso | 7 (memória da máquina, NDK removido por erro, disco cheio) — ver `BUGS_FOUND.md` seções D–K |

## 3. Testes que exigem emulador — indisponíveis neste ambiente

| Verificação | Situação |
| --- | --- |
| Executar o aplicativo em emulador Android | **Impossível aqui**: não há `/dev/kvm`, não há emulador instalado, e o APK é arm64-v8a enquanto o host é x86_64 |
| Captura de tela preta com `preventScreenCaptureAsync` | exige aparelho/emulador |
| Comportamento do Android Keystore / `expo-secure-store` | exige aparelho/emulador |

Não há resultado a reportar: nunca foi executado. Registrado como limitação, não
como aprovação.

## 4. Testes que exigem o Galaxy A05s — **pendentes**

Marcados como pendentes até serem executados no aparelho, com resultado anotado.

### Geração de imagem

1. Abrir uma conversa → “Gerar imagem” → descrever uma cena com o estilo gótico.
2. Conferir a prévia da descrição final e confirmar o envio.
3. Acompanhar os estados: preparando, fila (posição e espera), gerando, pronto.
4. Cancelar no meio de uma geração e conferir que a fila para.
5. Desligar a internet e gerar: deve aparecer mensagem de conexão, sem travar.
6. Estourar o limite do Pollinations (duas gerações seguidas): deve aparecer a
   explicação do limite de 15 s, não um erro técnico.
7. Gerar com descrição proibida (“nua”, “ato sexual”): deve ser recusado antes
   de qualquer chamada de rede.
8. Usar a imagem na conversa, ampliar com pinça, salvar na galeria (aceitando o
   aviso), compartilhar e apagar.
9. Reiniciar o aplicativo e conferir que a imagem continua na conversa.

### Bloqueio

10. Criar senha de 6 dígitos, sair do aplicativo e voltar: deve pedir senha.
11. Errar a senha 3, 4 e 5 vezes: conferir a espera progressiva (1 s, 2 s, 4 s).
12. Fechar o aplicativo de vez e abrir: bloqueio deve aparecer **sem** que
    qualquer conversa apareça antes.
13. Trocar para outro aplicativo e voltar depois do intervalo configurado.
14. Ativar biometria, bloquear e desbloquear com digital; conferir que a senha
    continua funcionando como alternativa.
15. Abrir o aplicativo tocando numa notificação de resposta pronta: deve pedir
    senha **antes** de mostrar a conversa.
16. Ativar “impedir capturas de tela” e tentar tirar print.
17. Ativar leitura em voz alta e bloquear: a fala deve parar; iniciar ditado e
    bloquear: o microfone deve ser liberado.
18. Trocar a senha e conferir que as imagens antigas continuam abrindo.
19. Testar “Esqueci a senha” entendendo o aviso, e confirmar que nada é apagado
    sem confirmação.

### Migração de dados (atualização por cima da 1.0.0)

20. Numa instalação 1.0.0 com imagens anexadas, instalar a 1.1.0 **por cima**
    (sem desinstalar) e conferir que as conversas continuam e que as imagens
    antigas aparecem normalmente.
21. Conferir em `documentos/private/` que os arquivos antigos passaram a
    `.lunaenc` e que a pasta `Attachments/` foi esvaziada.

## 5. Resumo

| Categoria | Passou | Falhou | Pendente |
| --- | --- | --- | --- |
| Automático (esta máquina) | 87 testes + tsc + eslint + build do APK | 0 | — |
| Serviço real (linha de comando) | 4 verificações (Horde imagem, Horde texto, Pollinations, dry-run adulto) | 0 | — |
| Emulador | — | — | impossível neste ambiente |
| Aparelho (Galaxy A05s) | — | — | 21 verificações listadas acima |

Nenhuma verificação de aparelho foi marcada como aprovada sem ter sido feita.
