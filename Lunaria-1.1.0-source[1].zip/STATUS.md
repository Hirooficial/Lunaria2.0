# Estado da entrega — 18/09/2026 · Lunaria 1.1.0 (rodada Arena 2)

## Resultado desta rodada

| Item | Situação |
| --- | --- |
| Versão comparada com o ZIP “Lunaria2.0” | **Idêntica** — o ZIP publicado é o mesmo arquivo da entrega anterior (sha256 `c5ea31ed…`); o código local era o mais novo |
| Geração de imagem (2 provedores gratuitos) | **Implementada e verificada contra os serviços reais** |
| Bloqueio por senha/PIN + biometria | **Implementado**; regras puras testadas, comportamento de tela depende do aparelho |
| Cifragem das imagens privadas | **Implementada** (AES-256-GCM, chave no Keystore do Android) |
| Migração de imagens antigas em claro | **Implementada e testada** (planejamento); execução real depende do aparelho com dados |
| Bloqueio de cópia de segurança do Android | **Ativado** (`allowBackup=false` + regras de exclusão) |
| Testes automatizados | **87 de 87** passaram (26 anteriores + 61 da rodada 2, reescritos e remedidos após o incidente de 18/09) |
| TypeScript | `npx tsc --noEmit` sem erros |
| ESLint | `eslint .` sem erros (apenas avisos de estilo pré-existentes) |
| APK arm64 de release | **Compilado e assinado** com a mesma chave da versão anterior (atualiza por cima sem desinstalar) |
| Geração de imagem no aparelho | **Pendente** — este ambiente não tem aparelho nem emulador (sem `/dev/kvm`) |
| Bloqueio (tela, biometria, notificação, segundo plano) no aparelho | **Pendente** — mesma limitação |

## O que entrou nesta rodada

### 1. Geração de imagem

- Botão **“Gerar imagem”** na conversa (barra de botões e menu do clipe) → tela
  de geração com: descrição editável, sugestões de exemplo, **proporção**
  (retrato 2:3, vertical 4:5, quadrado 1:1, paisagem 3:2, cinema 16:9) e **8
  estilos** — gótico, sombrio, fantasia, anime, fotografia, ilustração, moda e
  romântico.
- **Perfil visual da Lunaria editável** (aparência adulta, cabelo, olhos, roupas,
  acessórios, extras), salvo no aparelho, usado quando o pedido é sobre ela, com
  aviso explícito do limite real de consistência (o modelo não memoriza rosto
  entre gerações; semente fixa + mesma descrição ≈ parecido).
- **Prévia da descrição final** antes de enviar: o texto exato em inglês que sai
  do aparelho, o prompt negativo e a decisão sobre o perfil.
- **Estados reais**: preparando → enfileirado (posição na fila e espera estimada
  na AI Horde) → gerando → concluído/erro/cancelado, com tempo decorrido, modelo
  usado, **cancelar**, **editar** e **tentar novamente**.
- A imagem aparece **na conversa** (como mensagem do usuário com a descrição) e
  abre no visualizador com **zoom por pinça e toque duplo**, **salvar**,
  **compartilhar** e **apagar**.
- Política de conteúdo rodando **antes de qualquer chamada de rede**: permite
  personagem adulta, sensualidade não explícita, moda alternativa e romance;
  recusa nudez sexual explícita, atos sexuais, menores de idade, coerção e
  conteúdo proibido em qualquer hipótese.

### 2. Provedores (gratuitos, documentados, reais)

| Provedor | Cadastro | Limite conhecido | Verificado |
| --- | --- | --- | --- |
| **AI Horde (imagem)** — padrão | Não (chave anônima `0000000000`); chave pessoal gratuita aumenta prioridade | Rede comunitária: fila depende de quem estiver online; 512×768 levou ~25 s no teste | `POST /generate/async` → id, fila, `generations[0].img` em base64 (WebP), `censored:false` |
| **Pollinations** | Não (nível anônimo) | Nível anônimo: 1 pedido a cada 15 s; pode marcar d'água | JPEG 512×768 em ~2,0 s, sem chave |

Provedores **pagos ficam desativados por padrão** — a tela só oferece os dois
gratuitos acima. A chave pessoal da Horde, se o usuário colar, fica só no
aparelho, nunca em log nem no código.

### 3. Bloqueio por senha

- Senha ou PIN com **mínimo de 6 dígitos/caracteres**; **biometria opcional**
  (com a senha sempre como alternativa segura).
- Pede autenticação **ao abrir** e **na volta do segundo plano**, conforme
  intervalo configurável (imediatamente, 1, 5, 15 min ou 1 h) e botão
  **“Bloquear agora”**.
- Enquanto bloqueado, **nenhuma outra tela é montada**: a tela de bloqueio
  substitui toda a navegação, então não existe um quadro de conversa ou imagem
  antes do desbloqueio. Notificação com “abrir conversa” fica **pendente** e só
  executa depois do desbloqueio.
- **Espera progressiva** nas tentativas erradas (1 s na 3ª, dobrando até 5 min).
  **Nada é apagado automaticamente** — nunca.
- Esconder conteúdo nas notificações e na prévia de aplicativos recentes;
  opção de **impedir captura de tela** (aplicada automaticamente enquanto
  bloqueado).
- Ao bloquear: leitura em voz alta é interrompida, o microfone é abortado, a
  chave sai da memória e as cópias decifradas temporárias são apagadas.
- Ativar, alterar e desativar exigem autenticação. “Esqueci a senha” explica a
  consequência e **só apaga o cofre com confirmação** (conversas, personagem e
  ajustes permanecem).

### 4. Proteção de dados

- Imagens geradas: **AES-256-GCM** (`@noble/ciphers`), chave de 32 bytes aleatória
  que **nunca** é gravada em claro — embrulhada pela senha (PBKDF2-HMAC-SHA256,
  150.000 iterações) e guardada no `expo-secure-store` (Android Keystore). Sem
  senha configurada, a chave fica só no Keystore, para que as imagens continuem
  cifradas em repouso.
- Arquivos cifrados em `documentos/private/`, nome aleatório, extensão
  `.lunaenc`; a senha em si nunca é armazenada, nem em log.
- Cópia de segurança do Android **desativada** para os dados do aplicativo
  (`allowBackup=false` + `data_extraction_rules.xml`):
  conversas, imagens e chave não saem do aparelho em backup automático.
- Exportar para a galeria ou compartilhar avisa, **antes**, que a cópia de fora
  perde a proteção da Lunaria.
- Migração: imagens antigas guardadas em claro em `Attachments/` entram no cofre
  cifrado na primeira abertura, com verificação de leitura do arquivo cifrado
  **antes** de apagar o original. É idempotente e retomável.

## Robustez de execução (decisões de raiz)

- **Nada de globais que talvez não existam**: o Hermes não garante `btoa`,
  `atob`, `TextEncoder` nem `TextDecoder`. O codec de base64 e a conversão UTF-8
  são próprios (`lib/utils/Binary.ts`), testados com acentos, emoji e tamanhos
  que não são múltiplos de 3.
- **Aleatoriedade nunca improvisada**: usa `crypto.getRandomValues` quando
  existe e, senão, o gerador do `expo-crypto` (sistema); se nenhum existir, o
  aplicativo **falha com mensagem clara** em vez de usar `Math.random`.
- **Sem cópias em claro desnecessárias**: imagem gerada não é duplicada em
  `Attachments/`; a conversa guarda `private://nome` e o arquivo segue cifrado.
- **Cópia de segurança desligada** no manifesto, com regras explícitas de
  exclusão para nuvem e transferência.

## Evidências do build (1.1.0)

```
BUILD SUCCESSFUL in 1m 20s
929 actionable tasks: 77 executed, 852 up-to-date
app-release.apk — 60.463.298 bytes
pacote br.aurora.luna.lunaria.next · versão 1.1.0 (versionCode 2)
minSdk 24 · targetSdk 36 · ABI arm64-v8a · 48 bibliotecas nativas
assinatura: CN=Lunaria, digest SHA-256 c0271509…5719a
  → MESMO certificado da 1.0.0: atualiza por cima sem desinstalar
manifesto: READ_MEDIA_IMAGES presente · allowBackup=false ·
  fullBackupContent=false · dataExtractionRules aplicado
assets: index.android.bundle (Hermes, 6.442.212 bytes) · res/RT.gguf
módulos novos confirmados no dex: ScreenCapture, SecureStore,
  MediaLibrary, Sharing, LocalAuthentication
SHA-256 do APK: 6bcbede3ae8a2bf40aebc5f3549062a2ebe5dfd749ce3cf96a2559e2d1236608
```

O build precisou de três tentativas nesta máquina de 2 núcleos e 1,9 GB de RAM:
a primeira morreu com o daemon do Gradle derrubado por falta de memória
(compilando `llama.cpp`), a segunda estourou **Metaspace** no
`lintVitalAnalyzeRelease` de um módulo de biblioteca, e a terceira passou com
`CMAKE_BUILD_PARALLEL_LEVEL=2`, espaço de metadados de 512 MB e o lint de
bibliotecas desativado (`android/build.gradle`, com o motivo comentado no
arquivo — não afeta o APK, é análise estática). As tarefas nativas já compiladas
foram reaproveitadas. Detalhe completo em `BUGS_FOUND.md` e `BUILDING.md`.

## Verificação real feita aqui

```
node --import tsx --test tests/*.test.mjs
# tests 87 · pass 87 · fail 0
#   crypto 9 · imagepolicy 8 · imageprompt 10 · imageprovider 12 · lock 9
#   + 26 anteriores (persona, pesquisa, streaming, persona-guard)
npx tsc --noEmit          → sem erros
npx eslint .              → 0 erros (38 avisos de estilo)
```

Chamadas reais aos provedores (fora do aplicativo, com os mesmos parâmetros):
AI Horde devolveu imagem WebP 512×768 em ~25 s (fila incluída) com a chave
anônima; Pollinations devolveu JPEG 512×768 em ~2,0 s sem chave.

## O que **não** foi verificado (fica registrado como pendente)

- Instalar e usar no Galaxy A05s: gerar imagem de verdade pelo aplicativo,
  cancelar no meio, salvar na galeria, apagar, e a tela de bloqueio na prática
  (senha errada, reinício, volta do segundo plano, abrir por notificação,
  biometria, troca de senha, migração de dados antigos).
- Custo real do PBKDF2 (150.000 iterações) no A05s: no desktop ficou em ~360 ms;
  num aparelho modesto espera-se algo entre 0,5 s e 1,5 s. Se ficar pesado, o
  valor está isolado em `lib/security/Crypto.ts` (`PBKDF2_ITERATIONS`).
- Impressão da tela preta com `preventScreenCaptureAsync` depende do aparelho.

## Limitação deste ambiente (a mesma da rodada anterior)

Sem aparelho Android, sem emulador e sem `/dev/kvm`; o APK é arm64 e o host é
x86_64. O aplicativo **não roda** aqui. Por isso todo o comportamento de tela
descrito acima está implementado e testado na parte pura, mas marcado como
pendente de confirmação no aparelho.

## Resultado do build e da entrega (18/09/2026)

O APK 1.1.0 existe e está assinado. A cadeia inteira está registrada em
`BUGS_FOUND.md`, seções D–K, porque o caminho até aqui teve sete tentativas:

- **nº 4** — o kernel matou o daemon do Gradle (`OOM killer`) porque o daemon do
  Kotlin herdava `-Xmx2560m`; corrigido com `kotlin.daemon.jvmargs=-Xmx1024m`.
- **nº 5** — falhou em 43 s porque eu havia apagado o NDK 27.0.12077973 por
  engano (o projeto precisa dos dois NDKs); reinstalado.
- **nº 6** — disco cheio (`No space left on device`); liberado espaço e
  devolvido o swap extra, que era desnecessário depois do teto do Kotlin.
- **nº 7** — sucesso.

```
> Task :app:minifyReleaseWithR8
BUILD SUCCESSFUL in 3m 17s
929 actionable tasks: 120 executed, 809 up-to-date
--- exit=0 Fri Sep 18 13:49:28 UTC 2026 ---
```

APK arm64-v8a de **60.463.298 bytes**, SHA-256
`6bcbede3ae8a2bf40aebc5f3549062a2ebe5dfd749ce3cf96a2559e2d1236608`, assinado com
o mesmo certificado da 1.0.0 (`c0271509…5719a`).

Verificações feitas no APK final: badging 1.1.0/versionCode 2, minSdk 24 /
targetSdk 36, `READ_MEDIA_IMAGES`, `allowBackup=false`, `fullBackupContent=false`,
`dataExtractionRules` presentes; 48 bibliotecas `.so` arm64; `res/RT.gguf`
(7.818.140 bytes) e `assets/index.android.bundle` (6.424.936 bytes) embutidos — os
mesmos tamanhos do APK perdido, o que confirma que o código recompilado é o mesmo —
com as telas de imagem/bloqueio, o cofre `private://`/`.lunaenc`, a política de
conteúdo e a âncora de idade adulta dentro do bundle; `ScreenCapture`,
`SecureStore`, `MediaLibrary` e `LocalAuthentication` presentes no dex.

Duas mudanças ficaram em `android/gradle.properties` por causa do ambiente, e
nenhuma delas altera o comportamento do aplicativo:
`android.enableR8.fullMode=false` (R8 em modo de compatibilidade) e
`kotlin.daemon.jvmargs` com teto de 1 GB.

Entrega em `/home/user/entrega/`: APK, ZIP do código (sem keystore, sem senha —
conferido com busca pela senha real), relatório de testes, instruções,
`SHA256.txt` e o documento de projeto. O ZIP é também a fonte de recuperação:
foi dele que a árvore foi restaurada depois da segunda reversão do workspace.

O que continua pendente está listado acima: tudo o que depende do aparelho.
