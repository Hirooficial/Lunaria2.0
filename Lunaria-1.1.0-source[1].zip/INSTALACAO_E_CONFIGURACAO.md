# Lunaria 1.0.0 — como instalar e configurar

Arquivos desta entrega:

| Arquivo | O que é |
| --- | --- |
| `Lunaria-1.0.0-arm64-release.apk` | Aplicativo para instalar no Galaxy A05s (arm64) |
| `Lunaria-1.0.0-source.zip` | Código-fonte atualizado (sem chaves e sem senhas) |
| `RELATORIO_DE_TESTES.md` | O que foi testado, onde e o que falta testar |
| `INSTALACAO_E_CONFIGURACAO.md` | Este arquivo |

A chave de assinatura (`lunaria-release.jks`) e a senha ficam **fora** do ZIP,
na pasta `lunaria-assinatura/` do espaço de trabalho. Guarde as duas: sem elas
não é possível atualizar o aplicativo depois de instalado.

## 1. Instalar no celular

1. Copie `Lunaria-1.0.0-arm64-release.apk` para o celular (cabo, Google Drive,
   Telegram, o que for mais fácil).
2. Toque no arquivo. O Android vai pedir para permitir instalação de fontes
   desconhecidas para o app que está abrindo o arquivo — permita só para essa
   ação.
3. Se aparecer “Aplicativo não instalado”, veja a seção **Problemas** no fim.
4. O aplicativo instala **separado** de versões antigas da Lunaria
   (pacote `br.aurora.luna.lunaria.next`). Conversas e modelos da versão velha
   não são migrados automaticamente.

Confira o arquivo antes de instalar, se quiser:

```
SHA-256 do APK: 6b8d707854a83c9e763064d3e94bf3c7a4fe07d298660bae12ce8bb02c4fc97d
```

## 2. Primeira abertura

- O banco de dados é criado no primeiro uso; leva alguns segundos.
- A tela inicial é a lista de personagens, já com a **Lunaria** e o usuário
  **Hamura** criados (Hamura tratado no masculino, conforme a ficha).
- Toque em Lunaria → **Nova conversa** para começar.

## 3. Escolher o modo de IA

Há duas opções, alternáveis pelo seletor no topo da gaveta de configurações
(ou em Configurações → modo da IA):

### Modo online (grátis, AI Horde)

- Não precisa de nada instalado nem de chave: a conexão “Lunaria Online — grátis”
  já vem pronta com a chave anônima `0000000000`.
- **Limites reais**: é uma rede comunitária de voluntários. Pode haver **fila de
  espera**, a velocidade varia, às vezes não há nó disponível e a resposta chega
  **de uma vez**, sem aparecer palavra por palavra (a API é de fila, não de
  streaming). O aplicativo mostra posição na fila, espera, erro e permite
  cancelar — o pedido é cancelado no servidor também.
- **Privacidade**: suas mensagens, o contexto do chat e trechos de pesquisa vão
  para a rede e podem ser processados por voluntários. O aplicativo avisa na
  primeira vez e só continua com a sua confirmação. Não mande senhas nem
  documentos pessoais.
- Para mudar o modelo remoto: Configurações → APIs → conexão → escolher modelos.

### Modo local (GGUF no aparelho)

- Funciona sem internet e sem enviar nada para fora.
- Você precisa importar um modelo de conversa no formato **GGUF**
  (Configurações → Modelos → Importar). O tokenizador já vem dentro do
  aplicativo.
- **Recomendação para o A05s (6 GB de RAM)**: modelos de **1 B a 3 B** com
  quantização **Q4_K_M** (arquivos de ~0,7 GB a ~2 GB). Modelos de 7 B são
  possíveis mas lentos e com risco de o Android fechar o aplicativo.
- Ajustes que já vêm prontos (Configurações → Modelo):
  - Contexto **4096** → se o aplicativo fechar sozinho ao conversar, baixe para
    **2048**.
  - Lote **(batch) 256** → menor consumo de memória.
  - Threads **4** → os quatro núcleos rápidos do Snapdragon 680.
  - Camadas na GPU **0** → o A05s usa CPU; não há ganho em GPU aqui.
  - “Salvar cache KV” desligado economiza armazenamento; ligado acelera a
    continuação da conversa.

## 4. Voz (ditado e leitura)

- **Ditado**: no campo de mensagem, toque no microfone. O Android vai pedir
  permissão de microfone; o idioma padrão é **pt-BR**. O microfone é encerrado
  ao sair da conversa.
- **Leitura em voz alta**: Configurações → Voz. Escolha a voz do sistema
  (recomendado instalar uma voz **pt-BR** no Google TTS, se o aparelho não
  tiver), a velocidade e se deve falar automaticamente após a resposta.
- Se não houver voz instalada, o Android usa a padrão do sistema.

## 5. Pesquisa / Fatos

1. Toque em **Fatos** (na barra do campo de mensagem) ou abra a tela de pesquisa.
2. Digite a pergunta. O aplicativo tenta buscar sozinho; **se a busca
   automática for bloqueada**, ele avisa e você pode colar **dois ou mais links
   HTTPS** de páginas confiáveis no campo indicado.
3. Ele lê as páginas de verdade, guarda trechos e links, e mostra a comparação.
   Trechos iguais de sites diferentes são contados **como um único indício**,
   não como duas confirmações — o contexto enviado ao modelo diz isso
   explicitamente e pede a separação entre fatos, divergências, opiniões e
   evidências insuficientes.
4. **Salvar memória é opcional**: nada entra na memória sem você tocar em
   salvar. Em “Memória de pesquisa” você consulta e apaga o que quiser.
5. Quando a memória é usada numa conversa, o próprio texto avisa ao modelo que
   a informação pode estar desatualizada.

## 6. Problemas comuns

| Situação | O que fazer |
| --- | --- |
| “Aplicativo não instalado” | Confira se o APK foi copiado inteiro (tamanho ~57 MB) e permita instalação de fontes desconhecidas. Se já existir uma Lunaria instalada de outro pacote, isso não é conflito: são aplicativos separados. |
| Instalou, mas fecha ao abrir | Anote a tela de erro que aparece (o aplicativo mostra a falha em português). Vá em Configurações → Registros e copie o trecho final. |
| Resposta não chega no modo online | É fila da rede gratuita. Espere ou cancele e tente de novo, ou mude de modelo. A API é de fila, pode demorar. |
| Aplicativo fecha ao conversar no modo local | Reduza o contexto para 2048 e o lote para 128; use um modelo menor (Q4_K_M de 1–3 B). |
| Texto estranho repetido na resposta | Use “Regenerar” (seta) na mensagem. Se repetir sempre, abaixe a temperatura ou aumente a penalidade de repetição em Amostragem. |
| Ditado não funciona | Verifique permissão de microfone nas configurações do Android e se há serviço de reconhecimento de voz instalado (Google ou Samsung). |
| Pesquisa falha | Use a opção de colar links HTTPS. Páginas com login, bloqueio de robôs ou muito grandes não são lidas. |

## 7. Atualizar para uma versão futura

Mantenha `lunaria-release.jks` e a senha. Ao gerar um APK novo, assine com a
**mesma chave** (o plugin do projeto lê `android/keystore.properties`) e instale
por cima: os dados (conversas, memória, modelos importados) são preservados no
upgrade normal.
