#!/usr/bin/env bash
# Empacota o ZIP de código-fonte público da Lunaria de forma repetível.
#
# Regra de ouro: NENHUM keystore entra no ZIP público — nem o de depuração.
# O keystore de liberação (android/keystore.properties + .jks) vive apenas na
# máquina de quem assina e nunca é copiado para cá.
#
# Uso:  bash tools/empacotar_entrega.sh [diretorio_de_saida]
set -euo pipefail

SAIDA="${1:-/home/user/entrega}"
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
cd "$RAIZ"

# --- o que fica de fora do pacote público ---
#   node_modules/.git/builds: artefatos, não código-fonte
#   keystore.properties/ .jks / .keystore: material de chave (mesmo o público)
#   CHECKSUMS.sha256 NÃO é excluído: ele vai dentro do ZIP para conferência
EXCLUIR=(
  'node_modules/*' '.git/*' 'android/build/*' 'android/app/build/*'
  'android/.gradle/*' 'android/app/.cxx/*' '.expo/*' '*__pycache__*'
  'android/keystore.properties' '*.jks' '*.keystore' 'android/app/debug.keystore'
)

echo "== conferindo que não há material de chave na árvore =="
achados=$(find . -not -path './node_modules/*' \( -name '*.jks' -o -name '*.keystore' \) -print || true)
if [ -n "$achados" ]; then
  echo "encontrados (serão excluídos do ZIP, mas confira se algum é de liberação):"
  echo "$achados" | sed 's/^/  /'
fi

echo "== sincronizando documentos entre a arvore e a pasta de entrega =="
# Os mesmos documentos existem nos dois lugares: na arvore (vao no ZIP) e em
# entrega/ (para ler sem descompactar). A arvore e a fonte da verdade.
for doc in BUGS_FOUND.md CORRECOES.md STATUS.md MATRIZ_DE_CRITERIOS.md \
           RELATORIO_DE_TESTES.md LEIA-ME.md CHECKLIST_APARELHO.md TEST_REPORT.md \
           GERACAO_DE_IMAGEM_E_BLOQUEIO.md INSTALACAO_E_CONFIGURACAO.md; do
  if [ -f "$doc" ]; then
    cp -f "$doc" "$SAIDA/$doc"
  else
    echo "   aviso: $doc nao existe na arvore (pulando)"
  fi
done
echo "   documentos copiados para $SAIDA"

echo "== reconstruindo CHECKSUMS.sha256 (sem keystores) =="
find . -type f -not -path './node_modules/*' -not -path './.git/*' \
  -not -path './android/build/*' -not -path './android/app/build/*' \
  -not -path './android/.gradle/*' -not -path './android/app/.cxx/*' \
  -not -path './.expo/*' -not -path '*__pycache__*' \
  -not -name 'CHECKSUMS.sha256' \
  -not -path './android/keystore.properties' \
  -not -name '*.jks' -not -name '*.keystore' \
  -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > CHECKSUMS.sha256
sha256sum -c CHECKSUMS.sha256 --quiet
echo "   $(wc -l < CHECKSUMS.sha256) arquivos conferem"

echo "== montando o ZIP =="
# O nome do pacote vem do package.json — decisao unica. Ja saiu com o numero
# errado no nome (1.1.2 em vez de 1.1.3) depois do salto de versao.
VERSAO=$(python3 -c "import json;print(json.load(open('package.json'))['version'])")
DESTINO="$SAIDA/Lunaria-$VERSAO-source.zip"
echo "   versao do pacote (do package.json): $VERSAO"
rm -f "$DESTINO"
args=(-r -q -X "$DESTINO" .)
for p in "${EXCLUIR[@]}"; do args+=(-x "$p"); done
zip "${args[@]}"

echo "== conferindo o resultado =="
python3 - "$DESTINO" <<'PY'
import sys, zipfile
z = zipfile.ZipFile(sys.argv[1])
n = z.namelist()
sensiveis = [x for x in n if 'keystore' in x.lower() or x.endswith(('.jks', '.apk', '.p12', '.pem'))]
print(f'   entradas: {len(n)}  ({len([x for x in n if not x.endswith("/")])} arquivos)')
print(f'   material de chave no ZIP: {sensiveis if sensiveis else "nenhum"}')
print(f'   CHECKSUMS interno: {"sim" if "CHECKSUMS.sha256" in n else "NÃO"}')
PY
echo "   tamanho: $(stat -c%s "$DESTINO") bytes"
echo "== pronto: $DESTINO =="
