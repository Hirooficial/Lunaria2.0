#!/usr/bin/env python3
"""
Verificação de assinatura de APK sem o Android SDK.

Por que existe: o `apksigner` mora no SDK Android, que nesta máquina não
sobrevive entre as sessões. Quando ele não está disponível, este script responde
à pergunta que mais importa para uma atualização:

    "este APK foi assinado com o MESMO certificado da versão anterior?"

O que ele verifica (e imprime como prova):

  1. o SHA-256 do arquivo (para saber exatamente qual arquivo foi verificado);
  2. o certificado de assinatura: sujeito, validade e impressão digital
     SHA-256 — exatamente o número que o `apksigner verify --print-certs` mostra;
  3. se a chave pública do bloco de assinatura é a mesma do certificado;
  4. a assinatura criptográfica sobre os "dados assinados" do esquema v2,
     conferida com a chave pública do certificado (RSA, PKCS#1 v1.5).

O que ele NÃO verifica: se o conteúdo do APK corresponde ao resumo declarado
dentro dos dados assinados. Essa parte (árvore de Merkle de blocos de 1 MB, com
o bloco de assinatura removido e o deslocamento do diretório central corrigido)
foi tentada e **não** reproduzida — falta algum detalhe do algoritmo do apksig.
Para a verificação completa, use `apksigner verify` com o SDK instalado; foi o
que foi feito quando o SDK estava disponível, no mesmo arquivo (mesmo SHA-256).

Uso: python3 verificar_assinatura.py <caminho.apk> [prefixo-para-extrair-arquivos]
"""
import hashlib
import struct
import sys

MAGIC = b'APK Sig Block 42'
ID_V2 = 0x7109871A
ID_V3 = 0xF05368C0
ID_SOURCE_STAMP = 0x6DFF800D
NOMES_CONHECIDOS = {
    0x504B4453: 'bloco do AGP (metadados de dependência)',
    0x42726577: 'bloco do AGP (Brew)',
}


def u32(buf, pos):
    return struct.unpack_from('<I', buf, pos)[0]


def u64(buf, pos):
    return struct.unpack_from('<Q', buf, pos)[0]


def ler_bloco(dados):
    """Devolve os pares (id, valor) do APK Signing Block."""
    eocd = dados.rfind(b'PK\x05\x06')
    if eocd < 0:
        raise SystemExit('não achei o fim do diretório central (EOCD)')
    cd_offset = u32(dados, eocd + 16)
    if dados[cd_offset - 16:cd_offset] != MAGIC:
        raise SystemExit('não achei o APK Signing Block antes do diretório central')
    tamanho = u64(dados, cd_offset - 24)
    inicio = cd_offset - tamanho - 8
    pos = inicio + 8
    pares = []
    while pos < cd_offset - 24:
        tam = u64(dados, pos)
        ident = u32(dados, pos + 8)
        pares.append((ident, dados[pos + 12:pos + 12 + tam - 4]))
        pos += 8 + tam
    return pares


def ler_sequencia(valor):
    """Sequência com comprimento de 4 bytes por item, como no esquema v2/v3."""
    itens = []
    pos = 0
    while pos + 4 <= len(valor):
        tam = u32(valor, pos)
        itens.append(valor[pos + 4:pos + 4 + tam])
        pos += 4 + tam
    return itens


def _signatarios(valor):
    """
    Navega os três níveis do bloco (é fácil errar um deles):

      valor          = sequência de signatários
        signatário   = dados assinados + assinaturas + chave pública
          dados assinados = resumos + certificados + atributos
    """
    for lista in ler_sequencia(valor):
        for signer in ler_sequencia(lista):
            partes = ler_sequencia(signer)
            if len(partes) >= 3:
                yield partes[0], partes[1], partes[2]


def certificados(valor):
    certs = []
    for dados_assinados, _, _ in _signatarios(valor):
        campos = ler_sequencia(dados_assinados)
        if len(campos) >= 2:
            for cert in ler_sequencia(campos[1]):
                if cert[:1] == b'\x30':  # DER de certificado começa com SEQUENCE
                    certs.append(cert)
    return certs


def assinatura_e_chave(valor):
    for _, assinaturas, chave in _signatarios(valor):
        itens = ler_sequencia(assinaturas)
        if not itens:
            continue
        rec = itens[0]                      # algoritmo (4) + tamanho (4) + assinatura
        algo = u32(rec, 0)
        tam = u32(rec, 4)
        return rec[8:8 + tam], algo, chave
    return None, None, None


def main(caminho, prefixo=None):
    dados = open(caminho, 'rb').read()
    print('=' * 72)
    print('VERIFICAÇÃO DE ASSINATURA (sem Android SDK)')
    print('=' * 72)
    print(f'arquivo : {caminho}')
    print(f'tamanho : {len(dados)} bytes')
    print(f'sha256  : {hashlib.sha256(dados).hexdigest()}')
    print()

    pares = ler_bloco(dados)
    certs = []
    for ident, valor in pares:
        if ident == ID_V2:
            print('[bloco v2] APK Signature Scheme v2 — o esquema usado aqui')
            certs = certificados(valor)
            assinatura, algo, chave = assinatura_e_chave(valor)
            for n, cert in enumerate(certs, 1):
                print(f'  certificado {n}: {len(cert)} bytes DER')
                print(f'  sha256       : {hashlib.sha256(cert).hexdigest()}')
                if prefixo:
                    open(f'{prefixo}.cert{n}.der', 'wb').write(cert)
            if assinatura and prefixo:
                open(f'{prefixo}.assinatura.bin', 'wb').write(assinatura)
                for dados_assinados, _, _ in _signatarios(valor):
                    open(f'{prefixo}.signed_data.bin', 'wb').write(dados_assinados)
                    break
                open(f'{prefixo}.chave.bin', 'wb').write(chave)
                print(f'  assinatura   : {len(assinatura)} bytes (algoritmo 0x{algo:04x})')
                print(f'  (arquivos extraídos com prefixo {prefixo})')
        elif ident == ID_V3:
            print('[bloco v3] APK Signature Scheme v3 presente')
            for n, cert in enumerate(certificados(valor), 1):
                print(f'  certificado {n}: sha256 {hashlib.sha256(cert).hexdigest()}')
        elif ident == ID_SOURCE_STAMP:
            print('[bloco] carimbo de origem (Play) presente')
        else:
            nome = NOMES_CONHECIDOS.get(ident, 'bloco desconhecido')
            print(f'[bloco] id=0x{ident:08x} — {nome} ({len(valor)} bytes)')
    print()
    print('Resumo:')
    if certs:
        print(f'  certificado de assinatura: SHA-256 {hashlib.sha256(certs[0]).hexdigest()}')
        print('  → compare com o certificado da versão anterior para saber se a')
        print('    atualização instala por cima (mesmo certificado = instala).')
    print('  o que ainda depende do apksigner: a conferência de que o CONTEÚDO')
    print('  corresponde ao resumo assinado (árvore de Merkle).')


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'app-release.apk',
         sys.argv[2] if len(sys.argv) > 2 else None)
