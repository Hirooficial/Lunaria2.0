#!/usr/bin/env node
/*
 * Geração de imagem de VERDADE, pela linha de comando, usando o MESMO código do
 * aplicativo (lib/imagegen/ImageProviders.ts — a função que o botão "Gerar
 * imagem" chama). Serve como prova do caminho real: pedido, fila, consultas,
 * download e validação dos bytes recebidos.
 *
 * Uso:
 *   node --import tsx tools/gerar_imagem_real.mjs <horde|pollinations> "<descrição>" [largura] [altura] [arquivo de saída] [espera máxima em segundos]
 *
 * Exemplo:
 *   node --import tsx tools/gerar_imagem_real.mjs horde "retrato gótico de uma jovem adulta" 512 768 /tmp/exemplo.webp 300
 *
 * Nada é enviado além da descrição: sem conversa, sem memória, sem dados do
 * aparelho.
 */

import { createHash } from 'node:crypto'
import { writeFileSync } from 'node:fs'
import { basename } from 'node:path'

import { generateImage } from '../lib/imagegen/ImageProviders.ts'

const [provider = 'pollinations', prompt, larguraArg, alturaArg, saidaArg, esperaArg] =
    process.argv.slice(2)

if (!prompt) {
    console.error('Falta a descrição. Veja o cabeçalho deste arquivo para o uso.')
    process.exit(2)
}

const width = Number(larguraArg) || 512
const height = Number(alturaArg) || 768
const saida = saidaArg || `/tmp/lunaria-${provider}.bin`
const esperaSegundos = Number(esperaArg) || 300

const inicio = Date.now()
const segundos = () => ((Date.now() - inicio) / 1000).toFixed(1)
const log = (...partes) => console.log(`[${segundos()}s]`, ...partes)

let ultimaFase = ''
let consultas = 0

console.log(`Provedor: ${provider}`)
console.log(`Descrição: ${prompt}`)
console.log(`Tamanho: ${width}x${height}`)
console.log('')

try {
    const imagem = await generateImage({
        provider,
        prompt,
        width,
        height,
        maxWaitMs: esperaSegundos * 1000,
        pollIntervalMs: 5000,
        onProgress: (progresso) => {
            consultas += 1
            if (progresso.phase !== ultimaFase || progresso.message) {
                ultimaFase = progresso.phase
                log(
                    `fase=${progresso.phase}`,
                    progresso.queuePosition !== undefined ? `fila=${progresso.queuePosition}` : '',
                    progresso.elapsedSeconds !== undefined
                        ? `decorrido=${progresso.elapsedSeconds}s`
                        : '',
                    `"${progresso.message}"`
                )
            }
        },
    })

    const bytes = Buffer.from(imagem.bytes)
    writeFileSync(saida, bytes)
    const dimensoes = medir(bytes)

    log(`PRONTO em ${imagem.elapsedSeconds}s`)
    console.log('')
    console.log(`arquivo......: ${saida} (${basename(saida)})`)
    console.log(`bytes........: ${bytes.length}`)
    console.log(`sha256.......: ${createHash('sha256').update(bytes).digest('hex')}`)
    console.log(
        `formato......: ${imagem.mime} (extensão ${imagem.extension}) — detectado: ${dimensoes.formato}`
    )
    console.log(`dimensões....: ${dimensoes.largura}x${dimensoes.altura}`)
    console.log(`modelo.......: ${imagem.model ?? '(não informado)'}`)
    console.log(`provedor.....: ${imagem.provider}`)
    console.log(`eventos de progresso recebidos: ${consultas}`)

    if (!dimensoes.ok) {
        console.error('\nATENÇÃO: os bytes baixados não parecem uma imagem válida.')
        process.exit(1)
    }
    if (dimensoes.largura !== width || dimensoes.altura !== height) {
        console.log(
            `\nObs.: o provedor devolveu ${dimensoes.largura}x${dimensoes.altura} em vez de ${width}x${height}.`
        )
    }
} catch (erro) {
    log(`FALHOU: ${erro?.kind ?? erro?.name ?? 'erro'} — ${erro?.message ?? erro}`)
    if (erro?.hint) console.log(`dica: ${erro.hint}`)
    process.exit(1)
}

/* --- leitura das dimensões, para provar que os bytes são mesmo uma imagem --- */

function medir(buffer) {
    if (
        buffer.length > 24 &&
        buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
    ) {
        return {
            ok: true,
            formato: 'PNG',
            largura: buffer.readUInt32BE(16),
            altura: buffer.readUInt32BE(20),
        }
    }
    if (buffer.length > 4 && buffer[0] === 0xff && buffer[1] === 0xd8) {
        let posicao = 2
        while (posicao + 9 < buffer.length) {
            if (buffer[posicao] !== 0xff) {
                posicao += 1
                continue
            }
            const marcador = buffer[posicao + 1]
            const tamanho = buffer.readUInt16BE(posicao + 2)
            if (
                marcador >= 0xc0 &&
                marcador <= 0xcf &&
                marcador !== 0xc4 &&
                marcador !== 0xc8 &&
                marcador !== 0xcc
            ) {
                return {
                    ok: true,
                    formato: 'JPEG',
                    altura: buffer.readUInt16BE(posicao + 5),
                    largura: buffer.readUInt16BE(posicao + 7),
                }
            }
            posicao += 2 + tamanho
        }
        return { ok: false, formato: 'JPEG sem cabeçalho de quadro', largura: 0, altura: 0 }
    }
    if (
        buffer.length > 30 &&
        buffer.subarray(0, 4).toString() === 'RIFF' &&
        buffer.subarray(8, 12).toString() === 'WEBP'
    ) {
        const tipo = buffer.subarray(12, 16).toString()
        if (tipo === 'VP8X') {
            const largura = 1 + (buffer[24] | (buffer[25] << 8) | (buffer[26] << 16))
            const altura = 1 + (buffer[27] | (buffer[28] << 8) | (buffer[29] << 16))
            return { ok: true, formato: 'WebP (VP8X)', largura, altura }
        }
        if (tipo === 'VP8L') {
            const bits = buffer.readUInt32LE(21)
            return {
                ok: true,
                formato: 'WebP (VP8L)',
                largura: 1 + (bits & 0x3fff),
                altura: 1 + ((bits >> 14) & 0x3fff),
            }
        }
        if (tipo === 'VP8 ') {
            return {
                ok: true,
                formato: 'WebP (VP8)',
                largura: buffer.readUInt16LE(26) & 0x3fff,
                altura: buffer.readUInt16LE(28) & 0x3fff,
            }
        }
        return { ok: false, formato: `WebP (${tipo})`, largura: 0, altura: 0 }
    }
    return { ok: false, formato: 'desconhecido', largura: 0, altura: 0 }
}
