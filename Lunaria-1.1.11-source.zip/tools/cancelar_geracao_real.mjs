#!/usr/bin/env node
/*
 * Prova, contra o serviço real, que CANCELAR avisa o provedor.
 *
 * Por que existe: o defeito corrigido na 1.1.2 era exatamente este — o botão
 * "Cancelar" parava a espera no aplicativo, mas o trabalho continuava na fila e
 * era gerado por um worker voluntário (imagem perdida e prioridade/kudos gasta
 * à toa). Um teste com rede simulada prova que o `DELETE` é enviado; este aqui
 * prova que **o provedor realmente cancela**.
 *
 * Como funciona:
 *   1. cria um pedido de verdade na AI Horde;
 *   2. espera entrar na fila e então cancela pelo mesmo caminho do aplicativo
 *      (`AbortController` passado para `generateWithHorde`);
 *   3. pergunta ao provedor, por fora, o que sobrou do trabalho.
 *
 * Veredito:
 *   CANCELADO OK  → o trabalho ficou com 0 imagens (não foi gerado);
 *   FALHOU        → o trabalho terminou com imagem, ou seja, cancelou só no app.
 *
 * Uso:  node --import tsx tools/cancelar_geracao_real.mjs [segundos antes de cancelar]
 */

import {
    CLIENT_AGENT,
    HORDE_ANONYMOUS_KEY,
    HORDE_API,
    generateWithHorde,
} from '../lib/imagegen/ImageProviders.ts'

const segundosAteCancelar = Number(process.argv[2]) || 10
const t0 = Date.now()
const log = (...p) => console.log(`[${((Date.now() - t0) / 1000).toFixed(1)}s]`, ...p)

// Cria o trabalho por fora, para poder consultar o estado depois do cancelamento.
const resposta = await fetch(`${HORDE_API}/generate/async`, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        apikey: HORDE_ANONYMOUS_KEY,
        'Client-Agent': CLIENT_AGENT,
    },
    body: JSON.stringify({
        prompt: 'teste de cancelamento pela linha de comando',
        params: { width: 512, height: 512, steps: 20, cfg_scale: 7, n: 1 },
        nsfw: false,
        censor_nsfw: true,
        slow_workers: true,
    }),
})
if (!resposta.ok) {
    console.error('não consegui criar o trabalho:', resposta.status, await resposta.text())
    process.exit(2)
}
const { id } = await resposta.json()
log(`trabalho criado: ${id}`)

const controller = new AbortController()
const timer = setTimeout(() => {
    log(`cancelando (AbortController) depois de ${segundosAteCancelar}s`)
    controller.abort()
}, segundosAteCancelar * 1000)

let erroEsperado = false
try {
    await generateWithHorde({
        prompt: 'teste de cancelamento pela linha de comando',
        width: 512,
        height: 512,
        signal: controller.signal,
        pollIntervalMs: 3000,
        maxWaitMs: 240_000,
        onProgress: (p) =>
            log(
                `fase=${p.phase}`,
                p.queuePosition !== undefined ? `fila=${p.queuePosition}` : '',
                `"${p.message}"`
            ),
        // reaproveita o trabalho já criado acima
        fetchImpl: async (url, options = {}) => {
            const alvo = String(url)
            if ((options.method ?? 'GET') === 'POST' || alvo.endsWith('/generate/async')) {
                return { ok: true, status: 202, json: async () => ({ id }) }
            }
            return fetch(url, options)
        },
    })
} catch (erro) {
    erroEsperado = erro?.kind === 'cancelado'
    log(`erro devolvido pelo aplicativo: kind=${erro?.kind} — "${erro?.message}"`)
} finally {
    clearTimeout(timer)
}

if (!erroEsperado) {
    console.error(
        'ATENÇÃO: o aplicativo não devolveu erro de cancelamento — o teste não mediu o que devia.'
    )
}

// Pergunta ao provedor o que sobrou. Dá alguns segundos, porque o DELETE é
// processado do lado de lá.
log('conferindo no provedor o que sobrou do trabalho…')
let ultimo = null
for (let i = 0; i < 10; i++) {
    await new Promise((r) => setTimeout(r, 3000))
    const s = await fetch(`${HORDE_API}/generate/status/${id}`, {
        headers: { 'Client-Agent': CLIENT_AGENT },
    })
    if (!s.ok) {
        log(`consulta ${i + 1}: HTTP ${s.status}`)
        continue
    }
    const d = await s.json()
    ultimo = d
    log(
        `consulta ${i + 1}: done=${d.done} fila=${d.queue_position} gerando=${d.processing} ` +
            `esperando=${d.waiting} pronto=${d.finished} imagens=${d.generations?.length ?? 0}`
    )
    if (d.done || (d.waiting === 0 && d.processing === 0 && d.queue_position === 0)) break
}

const imagens = ultimo?.generations?.length ?? 0
console.log('')
if (imagens === 0) {
    console.log(
        'VEREDITO: CANCELADO OK — o provedor não gerou imagem nenhuma; o trabalho saiu da fila.'
    )
    console.log(
        '(para comparar: um trabalho abandonado, sem cancelamento, GERA a imagem — medido em 18/09.)'
    )
} else {
    console.log(
        `VEREDITO: FALHOU — o provedor gerou ${imagens} imagem(ns); o cancelamento não chegou lá.`
    )
    process.exit(1)
}
