#!/usr/bin/env python3
"""
Preservação verificada DENTRO do APK entregue (sem aparelho).

Por que existe: o critério do encargo inclui preservar tudo o que já funcionava
(conversa, personalidade em pt-BR, tratamento masculino ao Hamura, GGUF local, API
remota, ditado, leitura em voz alta, Pesquisa/Fatos e memória). Testes de lógica e
de renderização cobrem o comportamento; este script cobre outra coisa: que os
recursos estejam **de fato dentro do pacote enviado** — no JavaScript compilado
(Hermes) e nas bibliotecas nativas.

Uso:  python3 tools/verificar_preservacao.py <caminho.apk>
"""

import sys
import zipfile
from pathlib import Path

# Marcador: (recurso, [textos procurados no bundle], [arquivos esperados no pacote])
RECURSOS = [
    (
        'Conversa e histórico',
        ['message', 'chats', 'expo-sqlite'],
        [],
    ),
    (
        'Personalidade editável em pt-BR (gótica/afetuosa)',
        ['góti', 'estética'],
        [],
    ),
    (
        'Tratamento masculino ao Hamura',
        ['Hamura'],
        [],
    ),
    (
        'Pesquisa/Fatos',
        ['Pesquisar e comparar fontes', 'Pesquisas ficam apenas neste aparelho'],
        [],
    ),
    (
        'Memória opcional',
        ['memória local'],
        [],
    ),
    (
        'Ditado (voz para texto)',
        ['expo-speech-recognition'],
        [],
    ),
    (
        'Leitura em voz alta',
        ['expo-speech', 'voz alta'],
        [],
    ),
    (
        'API remota (chat/completions)',
        ['chat/completions'],
        [],
    ),
    (
        # Os nomes reais no pacote: a ligação nativa do llama.cpp é `librnllama*`
        # e as bibliotecas do ggml vêm como `libggml-htp-*` (Hexagon) — conferi
        # listando o APK, em vez de supor os nomes "clássicos".
        'GGUF local (bibliotecas nativas)',
        ['GGUF'],
        ['librnllama', 'libggml-'],
    ),
    (
        # comparado pelo nome do arquivo: res/RT.gguf dentro do APK
        'Modelo local embutido',
        [],
        ['RT.gguf'],
    ),
    (
        'Geração de imagem',
        ['Gerar imagem', 'aihorde.net', 'pollinations'],
        [],
    ),
    (
        'Bloqueio por senha/PIN e cofre',
        ['Bloquear agora', 'SecureStore', 'lunaria-dek'],
        [],
    ),
]


def checar(apk: Path) -> int:
    z = zipfile.ZipFile(apk)
    nomes = z.namelist()

    bundle_nome = next((n for n in nomes if n.endswith('index.android.bundle')), None)
    if bundle_nome is None:
        print('ERRO: não achei o bundle JavaScript dentro do APK.')
        return 2
    bruto = z.read(bundle_nome)
    # O Hermes guarda texto em UTF-16LE para o que tem acento e em ASCII puro para
    # o resto; procura-se nas duas formas.
    def contem(texto: str) -> bool:
        return texto.encode('utf-16-le') in bruto or texto.encode('utf-8') in bruto

    print(f'APK    : {apk}')
    print(f'bundle : {bundle_nome} ({len(bruto)} bytes)')
    print(f'arquivos no pacote: {len(nomes)}')
    print()
    print(f'{"recurso":<46} {"no código":<10} {"no pacote":<10} obs')
    print('-' * 96)

    faltando = []
    for recurso, textos, arquivos in RECURSOS:
        achados_texto = [t for t in textos if contem(t)]
        achados_arq = []
        for prefixo in arquivos:
            candidatos = [n for n in nomes if Path(n).name.startswith(prefixo)]
            if candidatos:
                achados_arq.append(prefixo)
            else:
                achados_arq.append(None)
        faltando_arq = [a for a in achados_arq if a is None]
        achados_arq = [a for a in achados_arq if a]
        if textos:
            ok_texto = len(achados_texto) > 0
        else:
            ok_texto = None
        if arquivos:
            ok_arq = len(faltando_arq) == 0
        else:
            ok_arq = None  # sem arquivos exigidos

        col_texto = 'OK' if ok_texto else ('-' if ok_texto is None else 'FALTA')
        col_arq = 'OK' if ok_arq else ('-' if ok_arq is None else 'FALTA')

        obs = []
        if achados_texto:
            obs.append('código: ' + ', '.join(f'"{t}"' for t in achados_texto[:2]))
        if achados_arq:
            obs.append('pacote: ' + ', '.join(achados_arq[:3]))
        if (ok_texto is False) or (ok_arq is False):
            faltando.append(recurso)

        print(f'{recurso:<46} {col_texto:<10} {col_arq:<10} {" | ".join(obs)}')

    print()
    print('--- bibliotecas nativas do llama.cpp/ggml presentes ---')
    for n in sorted(n for n in nomes if n.endswith('.so')):
        if any(p in n for p in ('llama', 'ggml')):
            print('  ', n)

    print()
    if faltando:
        print(f'VEREDITO: FALTANDO — {len(faltando)} recurso(s): {", ".join(faltando)}')
        return 1
    print('VEREDITO: tudo o que já funcionava continua dentro do pacote entregue.')
    print('Obs.: isto prova que os recursos estão no pacote; o comportamento real')
    print('      continua dependendo das verificações no aparelho.')
    return 0


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(checar(Path(sys.argv[1])))
