#!/usr/bin/env node
/*
 * Sonda: mostra o que a AI Horde devolve no campo `generations[].img` — formato,
 * tamanho, caracteres estranhos e pontas da string. Serve para diagnosticar o
 * erro "base64 inválido: tamanho não múltiplo de 4" com dados reais, sem chute.
 */

import { CLIENT_AGENT, HORDE_ANONYMOUS_KEY, HORDE_API } from '../lib/imagegen/ImageProviders.ts'

const pedido = {
    prompt: 'gothic portrait of a young adult woman, long black hair, candle light, digital painting',
    params: { width: 512, height: 768, steps: 20, cfg_scale: 7, n: 1 },
    nsfw: false,
    censor_nsfw: true,
    slow_workers: true,
}

const resposta = await fetch(`${HORDE_API}/generate/async`, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        apikey: HORDE_ANONYMOUS_KEY,
        'Client-Agent': CLIENT_AGENT,
    },
    body: JSON.stringify(pedido),
})
console.log('POST', resposta.status, JSON.stringify(await resposta.json()))

const job = (
    await (
        await fetch(`${HORDE_API}/generate/async`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                apikey: HORDE_ANONYMOUS_KEY,
                'Client-Agent': CLIENT_AGENT,
            },
            body: JSON.stringify(pedido),
        })
    ).json()
).id

console.log('job', job)

const ALFABETO = /^[A-Za-z0-9+/=]+$/
let rodadas = 0
for (;;) {
    await new Promise((r) => setTimeout(r, 6000))
    rodadas += 1
    const status = await fetch(`${HORDE_API}/generate/status/${job}`, {
        headers: { 'Client-Agent': CLIENT_AGENT },
    })
    if (!status.ok) {
        console.log(`consulta ${rodadas}: HTTP ${status.status}`)
        continue
    }
    const corpo = await status.json()
    console.log(
        `consulta ${rodadas}: done=${corpo.done} fila=${corpo.queue_position} espera=${corpo.wait_time}s ` +
            `gerações=${corpo.generations?.length ?? 0}`
    )
    if (!corpo.done) {
        if (rodadas > 60) break
        continue
    }
    const img = corpo.generations?.[0]?.img ?? ''
    const semEspaco = img.replace(/[\r\n\s]/g, '')
    const proibidos = [
        ...new Set(
            semEspaco
                .split('')
                .filter(
                    (c) =>
                        !'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='.includes(
                            c
                        )
                )
        ),
    ]
    console.log('\n=== ANÁLISE DO CAMPO img ===')
    console.log('tipo:', typeof img)
    console.log('tamanho bruto:', img.length, '| só pela API:', corpo.generations[0].img.length)
    console.log(
        'tamanho sem espaços:',
        semEspaco.length,
        '| resto da divisão por 4:',
        semEspaco.length % 4
    )
    console.log('só caracteres do alfabeto base64:', ALFABETO.test(semEspaco))
    console.log(
        'caracteres fora do alfabeto:',
        proibidos.length === 0 ? '(nenhum)' : JSON.stringify(proibidos)
    )
    console.log('começa com:', JSON.stringify(semEspaco.slice(0, 24)))
    console.log('termina com:', JSON.stringify(semEspaco.slice(-24)))
    console.log('tem "=" de preenchimento:', semEspaco.endsWith('='))
    console.log(
        'cabeçalho de imagem (primeiros bytes decodificados):',
        Buffer.from(semEspaco.slice(0, 16), 'base64').toString('hex')
    )
    console.log(
        'modelo:',
        corpo.generations[0].model,
        '| censurado:',
        corpo.generations[0].censored
    )
    break
}
