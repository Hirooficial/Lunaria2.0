import assert from 'node:assert/strict'
import { Buffer } from 'node:buffer'
import test from 'node:test'

import {
    base64ToBytes,
    bytesToBase64,
    bytesToText,
    constantTimeEqual,
    textToBytes,
} from '../lib/utils/Binary.ts'
import {
    decryptFromBase64,
    deriveKeyFromSecret,
    encryptToBase64,
    generateKey,
    keyOpensVault,
    PBKDF2_ITERATIONS,
    randomSalt,
    verifierFor,
    verifierMatches,
} from '../lib/security/Crypto.ts'

const SECRET = 'senha-da-lunaria-1'

test('texto com acento e emoji sobrevive à ida e volta em bytes', () => {
    const original = 'Coração 🌙 ação ção ãõ'
    assert.equal(bytesToText(textToBytes(original)), original)
})

test('base64 do projeto bate com o do Node (Buffer) para 1 a 256 bytes', () => {
    for (let length = 1; length <= 256; length++) {
        const bytes = new Uint8Array(length).map((_, index) => (index * 7 + length) % 256)
        const mine = bytesToBase64(bytes)
        const reference = Buffer.from(bytes).toString('base64')
        assert.equal(mine, reference, `diferença em length=${length}`)
        assert.deepEqual(Array.from(base64ToBytes(mine)), Array.from(bytes))
    }
})

test('base64 inválido lança erro em vez de devolver lixo', () => {
    assert.throws(() => base64ToBytes('abc')) // tamanho não múltiplo de 4
    assert.throws(() => base64ToBytes('ab*d')) // caractere fora do alfabeto
})

test('derivação de chave é estável com o mesmo sal e muda com sal diferente', () => {
    const salt = randomSalt()
    const first = deriveKeyFromSecret(SECRET, salt, 1000)
    const second = deriveKeyFromSecret(SECRET, salt, 1000)
    const otherSalt = randomSalt()
    assert.deepEqual(Array.from(first), Array.from(second))
    assert.notDeepEqual(Array.from(first), Array.from(deriveKeyFromSecret(SECRET, otherSalt, 1000)))
    assert.equal(first.length, 32)
})

test('o custo do PBKDF2 não caiu sem querer', () => {
    // O valor faz parte da proteção: 150 mil iterações foi medido como ~150 ms.
    assert.equal(PBKDF2_ITERATIONS, 150_000)
})

test('cifrar e decifrar devolve exatamente o conteúdo original', () => {
    const key = generateKey()
    const envelope = encryptToBase64(key, textToBytes('imagem secreta'))
    assert.equal(bytesToText(decryptFromBase64(key, envelope)), 'imagem secreta')
})

test('envelope adulterado é recusado (GCM valida a tag)', () => {
    const key = generateKey()
    const envelope = encryptToBase64(key, textToBytes('conteúdo'))
    const tampered = base64ToBytes(envelope)
    tampered[tampered.length - 1] ^= 0xff
    assert.throws(() => decryptFromBase64(key, bytesToBase64(tampered)))
})

test('a senha errada não abre o cofre', () => {
    const salt = randomSalt()
    const right = deriveKeyFromSecret('senha-certa', salt, 1000)
    const wrong = deriveKeyFromSecret('senha-errada', salt, 1000)
    const wrapped = encryptToBase64(right, generateKey())
    assert.equal(keyOpensVault(right, wrapped), true)
    assert.equal(keyOpensVault(wrong, wrapped), false)
})

test('verificador confere a chave e não guarda a senha', () => {
    const salt = randomSalt()
    const key = deriveKeyFromSecret(SECRET, salt, 1000)
    const verifier = verifierFor(key)
    assert.equal(verifierMatches(key, verifier), true)
    assert.equal(verifierMatches(deriveKeyFromSecret('outra', salt, 1000), verifier), false)
    assert.equal(verifier.includes(SECRET), false)
    assert.equal(verifier.length, 24) // 16 bytes em base64
})

test('comparação em tempo constante distingue conteúdos diferentes', () => {
    assert.equal(constantTimeEqual(new Uint8Array([1, 2, 3]), new Uint8Array([1, 2, 3])), true)
    assert.equal(constantTimeEqual(new Uint8Array([1, 2, 3]), new Uint8Array([1, 2, 4])), false)
    assert.equal(constantTimeEqual(new Uint8Array([1, 2]), new Uint8Array([1, 2, 3])), false)
})
