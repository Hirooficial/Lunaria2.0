import assert from 'node:assert/strict'
import test from 'node:test'

import { ADULT_ANCHOR, buildImagePrompt, stableSeed } from '../lib/imagegen/ImagePrompt.ts'
import {
    ASPECT_RATIOS,
    DEFAULT_LUNARIA_PROFILE,
    DEFAULT_NEGATIVE_PROMPT,
    IMAGE_STYLES,
} from '../lib/imagegen/ImageStyles.ts'

const base = { description: 'Lunaria em um jardim noturno com flores escuras' }

test('todo prompt carrega a âncora de idade adulta', () => {
    const built = buildImagePrompt(base)
    assert.equal(ADULT_ANCHOR, 'adult woman, clearly over 25 years old')
    assert.match(built.prompt, /adult woman, clearly over 25 years old/)
})

test('a descrição do usuário entra antes do estilo', () => {
    const built = buildImagePrompt({ ...base, styleId: 'anime' })
    assert.ok(
        built.prompt.indexOf(base.description) < built.prompt.indexOf(IMAGE_STYLES.anime.prompt)
    )
})

test('o estilo escolhido muda o prompt e o padrão é gótico', () => {
    const gothic = buildImagePrompt(base)
    const anime = buildImagePrompt({ ...base, styleId: 'anime' })
    assert.equal(gothic.styleId, 'gotico')
    assert.match(gothic.prompt, /gothic dark fantasy art/)
    assert.match(anime.prompt, /anime illustration/)
    assert.match(anime.prompt, /cel shading/)
})

test('proporção define as dimensões de verdade', () => {
    const portrait = buildImagePrompt({ ...base, aspectRatioId: 'retrato' })
    const cinema = buildImagePrompt({ ...base, aspectRatioId: 'cinema' })
    assert.equal(portrait.width, ASPECT_RATIOS.retrato.width)
    assert.equal(portrait.height, ASPECT_RATIOS.retrato.height)
    assert.equal(cinema.width, 768)
    assert.equal(cinema.height, 432)
})

test('negativos barram conteúdo proibido mesmo sem o usuário pedir', () => {
    const built = buildImagePrompt(base)
    assert.equal(built.negativePrompt, DEFAULT_NEGATIVE_PROMPT)
    for (const term of ['child', 'minor', 'explicit nudity', 'sexual act']) {
        assert.ok(built.negativePrompt.includes(term), `negativo ausente: ${term}`)
    }
})

test('perfil da Lunaria só entra quando pedido', () => {
    const without = buildImagePrompt(base)
    const withCharacter = buildImagePrompt({
        ...base,
        includeCharacter: true,
        profile: DEFAULT_LUNARIA_PROFILE,
    })
    assert.equal(without.includeCharacter, false)
    assert.equal(without.prompt.includes('silver-white hair'), false)
    assert.equal(withCharacter.includeCharacter, true)
    assert.match(withCharacter.prompt, /silver-white hair/)
    assert.match(withCharacter.prompt, /silver crescent moon pendant/)
})

test('prévia mostra exatamente o texto que será enviado', () => {
    const built = buildImagePrompt({
        ...base,
        includeCharacter: true,
        profile: DEFAULT_LUNARIA_PROFILE,
    })
    assert.ok(built.preview.includes(built.prompt))
    assert.match(built.preview, /Descrição final/)
    assert.match(built.preview, /Semente:/)
    assert.match(built.preview, /Aparência da Lunaria incluída/)
})

test('semente é estável para a mesma descrição e muda entre descrições', () => {
    const first = buildImagePrompt(base)
    const forced = buildImagePrompt({ ...base, seed: first.seed })
    assert.equal(forced.seed, first.seed)
    assert.notEqual(stableSeed('a'), stableSeed('b'))
    assert.equal(stableSeed('mesma descrição'), stableSeed('mesma descrição'))
})

test('o parecer da política vem junto do prompt', () => {
    const allowed = buildImagePrompt({ description: 'retrato gótico adulto, moda alternativa' })
    const refused = buildImagePrompt({ description: 'nudez explícita' })
    assert.equal(allowed.verdict.allowed, true)
    assert.equal(refused.verdict.allowed, false)
    assert.equal(refused.verdict.category, 'explicito')
})

test('descrição vazia ainda gera prompt utilizável (âncora + estilo)', () => {
    const built = buildImagePrompt({ description: '   ' })
    assert.match(built.prompt, /adult woman, clearly over 25 years old/)
    assert.match(built.prompt, /gothic dark fantasy art/)
    assert.equal(built.preview.length > 0, true)
})
