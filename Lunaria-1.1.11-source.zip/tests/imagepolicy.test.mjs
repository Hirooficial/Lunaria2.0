import assert from 'node:assert/strict'
import test from 'node:test'

import { assessImagePrompt, foldText } from '../lib/imagegen/ContentPolicy.ts'

test('permite personagem adulta com sensualidade sem nudez', () => {
    const verdict = assessImagePrompt(
        'Lunaria em pose sensual, vestido gótico de renda, luz de vela, clima íntimo'
    )
    assert.equal(verdict.allowed, true)
})

test('não confunde negação com pedido proibido ("sem nudez")', () => {
    // Este era o falso positivo do primeiro teste: a palavra "nudez" aparecia
    // numa negação e o pedido era legítimo.
    const verdict = assessImagePrompt('pose romântica, sensualidade sem nudez, sem cena explícita')
    assert.equal(verdict.allowed, true)
})

test('recusa nudez explícita com motivo e termo identificado', () => {
    const verdict = assessImagePrompt('nudez explícita em quarto escuro')
    assert.equal(verdict.allowed, false)
    assert.equal(verdict.category, 'explicito')
    assert.equal(verdict.match, 'nudez explicita')
    assert.match(verdict.reason, /não gera nudez sexual explícita/)
})

test('recusa ato sexual mesmo escrito em inglês', () => {
    const verdict = assessImagePrompt('a sexual act in a dark room, gothic style')
    assert.equal(verdict.allowed, false)
    assert.equal(verdict.category, 'explicito')
})

test('recusa menor de idade em contexto sensual e a negação NÃO protege', () => {
    const verdict = assessImagePrompt('adolescente de uniforme escolar, sem nudez')
    assert.equal(verdict.allowed, false)
    assert.equal(verdict.category, 'menor')
})

test('recusa coerção sexual', () => {
    const verdict = assessImagePrompt('cena de estupro em fantasia sombria')
    assert.equal(verdict.allowed, false)
    assert.equal(verdict.category, 'coercao')
})

test('recusa conteúdo fora das regras do provedor (bestialidade)', () => {
    const verdict = assessImagePrompt('bestiality scene with gothic atmosphere')
    assert.equal(verdict.allowed, false)
    assert.equal(verdict.category, 'proibido')
})

test('normaliza acentos e maiúsculas antes de comparar', () => {
    assert.equal(foldText('Nudez Explícita ção'), 'nudez explicita cao')
    const verdict = assessImagePrompt('Nudez Explícita')
    assert.equal(verdict.allowed, false)
})

test('permite moda alternativa e cena romântica adulta', () => {
    const fashion = assessImagePrompt(
        'editorial de moda gótica alternativa, couro, renda, coturno, adulta'
    )
    const romantic = assessImagePrompt('jantar romântico à luz de velas, olhar afetuoso')
    assert.equal(fashion.allowed, true)
    assert.equal(romantic.allowed, true)
})
