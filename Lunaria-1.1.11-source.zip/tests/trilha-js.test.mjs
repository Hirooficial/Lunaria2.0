/**
 * Trilha de abertura — lado JavaScript.
 *
 * O que estes testes travam: as etapas que o JavaScript marca na abertura vão
 * para a **trilha nativa** (a única evidência que sobrevive a um fechamento
 * silencioso e sai do aparelho pela pasta Downloads) e, ao mesmo tempo, para as
 * migalhas do relatório na tela — sem que gravar trilha possa, ele próprio,
 * derrubar a abertura.
 *
 * Três coisas são afirmadas aqui:
 *  1. comportamento: prefixo, corte de tamanho, `true`/`false` de retorno;
 *  2. **falha contida**: sem a ponte, ou com a ponte lançando, nada se propaga;
 *  3. guarda de fonte: as oito etapas estão nos pontos certos, **na ordem certa**,
 *     com o porteiro antes das rotas.
 */

import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import path from 'node:path'
import test, { beforeEach } from 'node:test'

import {
    esquecerEscritorDaTrilha,
    marcarEtapaJs,
    PREFIXO_JS,
    setEscritorDaTrilha,
    setEscritorDeMigalha,
} from '../lib/utils/TrilhaJs.ts'

const raiz = path.resolve(import.meta.dirname, '..')
const ler = (rel) => readFileSync(path.join(raiz, rel), 'utf8')

/** Posição de um trecho no arquivo — usada para afirmar ORDEM, não presença. */
const posicao = (texto, trecho) => {
    const i = texto.indexOf(trecho)
    assert.notEqual(i, -1, `trecho não encontrado no arquivo: ${trecho}`)
    return i
}

let capturado = []
let migalhas = []

beforeEach(() => {
    capturado = []
    migalhas = []
    esquecerEscritorDaTrilha()
    // O canal das migalhas é desviado para uma lista local. Não é manha de
    // teste: o carregador do Node (`tsx`) cria **duas instâncias** do mesmo
    // arquivo quando o mesmo módulo é pedido com e sem extensão (`./Diagnostics`
    // lá dentro, `../lib/utils/Diagnostics.ts` aqui) — foi o que fez a primeira
    // versão deste teste falhar. Sob o Metro há um grafo único, e é isso que o
    // teste de renderização em Jest exercita, este sim, com o diagnóstico real.
    setEscritorDeMigalha((texto) => migalhas.push(texto))
})

test('grava a etapa no escritor da trilha, com o prefixo do JavaScript', () => {
    setEscritorDaTrilha((texto) => capturado.push(texto))
    const gravou = marcarEtapaJs('3/8 tela inicial montou')
    assert.equal(gravou, true)
    assert.deepEqual(capturado, [`${PREFIXO_JS}3/8 tela inicial montou`])
})

test('sem a ponte nativa não grava, mas também não lança', () => {
    // Nenhum escritor injetado e, em Node puro, não existe `NativeModules`:
    // é o mesmo caso do aparelho em que a ponte não está registrada.
    const gravou = marcarEtapaJs('4/8 bloqueio pronto')
    assert.equal(gravou, false)
})

test('escritor que lança não derruba a abertura — e a migalha ainda é gravada', () => {
    setEscritorDaTrilha(() => {
        throw new Error('ponte indisponível na hora de gravar')
    })
    const gravou = marcarEtapaJs('5/8 imagens prontas')
    assert.equal(gravou, false)
    // Os dois canais são independentes: se o arquivo falha, o relatório na tela
    // ainda conta a história.
    assert.deepEqual(migalhas, [`${PREFIXO_JS}5/8 imagens prontas`])
})

test('mesmo sem a ponte, a etapa entra nas migalhas do relatório', () => {
    marcarEtapaJs('6/8 banco migrado')
    // Sem escritor nenhum, o arquivo não recebe nada...
    assert.deepEqual(capturado, [])
    // ...e mesmo assim a etapa aparece para quem abrir o relatório na tela.
    assert.deepEqual(migalhas, [`${PREFIXO_JS}6/8 banco migrado`])
})

test('migalha que lança também não derruba a abertura', () => {
    setEscritorDeMigalha(() => {
        throw new Error('diagnóstico indisponível')
    })
    setEscritorDaTrilha((texto) => capturado.push(texto))
    assert.equal(marcarEtapaJs('8/8 lista de conversas na tela'), true)
    assert.equal(capturado.length, 1)
})

test('etapa longa é cortada em 200 caracteres', () => {
    setEscritorDaTrilha((texto) => capturado.push(texto))
    marcarEtapaJs('x'.repeat(5000))
    assert.equal(capturado.length, 1)
    assert.equal(capturado[0].length, 200)
})

test('sem escritor injetado, o módulo volta a procurar a ponte (memoriza o fracasso)', () => {
    setEscritorDaTrilha((texto) => capturado.push(texto))
    assert.equal(marcarEtapaJs('1/8 porteiro instalado'), true)
    esquecerEscritorDaTrilha()
    assert.equal(marcarEtapaJs('2/8 rotas carregadas'), false)
    assert.equal(capturado.length, 1, 'o escritor antigo não pode continuar valendo')
})

// ---------------------------------------------------------------------------
// Guarda de fonte: as etapas estão onde precisam estar, e na ordem certa.
// ---------------------------------------------------------------------------

test('o index.js marca 1/8 antes de carregar as rotas', () => {
    const fonte = ler('index.js')
    const marca = posicao(fonte, '1/8 porteiro instalado')
    const rotas = posicao(fonte, "require('expo-router/entry')")
    assert.ok(marca < rotas, 'a marca do porteiro deve vir antes do carregamento das rotas')
    assert.ok(
        fonte.includes('catch'),
        'a marcação tem de estar cercada: trilha não pode virar falha de abertura'
    )
})

test('o porteiro marca 2/8 ao terminar de carregar as rotas', () => {
    const fonte = ler('lib/utils/EntradaSegura.js')
    const marca = posicao(fonte, '2/8 rotas carregadas')
    const funcao = posicao(fonte, 'export const marcarRotasCarregadas')
    assert.ok(marca > funcao, 'a marca 2/8 pertence a `marcarRotasCarregadas`')
    // A regra do arquivo continua valendo: nada de import no topo.
    assert.ok(!/^\s*import\s/m.test(fonte), 'o porteiro não pode ganhar import no topo')
})

test('o porteiro grava na trilha quando as rotas falham', () => {
    const fonte = ler('lib/utils/EntradaSegura.js')
    const falha = posicao(fonte, 'export const mostrarFalha')
    const marca = posicao(fonte, '! rotas nao carregaram:')
    assert.ok(marca > falha, 'a marca de falha pertence a `mostrarFalha`')
})

test('a tela inicial marca 3/8, 4/8 e 5/8, nesta ordem', () => {
    const fonte = ler('app/_layout.tsx')
    const tres = posicao(fonte, '3/8 tela inicial montou')
    const quatro = posicao(fonte, '4/8 bloqueio pronto')
    const cinco = posicao(fonte, '5/8 imagens prontas')
    assert.ok(tres < quatro && quatro < cinco, 'a ordem das etapas tem de ser 3 → 4 → 5')
    assert.ok(
        fonte.includes('5/8 imagens puladas (modo seguro)'),
        'no modo seguro a etapa 5 precisa dizer que as imagens foram puladas'
    )
    assert.ok(
        fonte.includes('! falha ao preparar o bloqueio:'),
        'falha do bloqueio precisa deixar rastro na trilha'
    )
})

test('a abertura marca 6/8, 7/8 e 8/8, cada uma no lugar certo', () => {
    // Atenção: aqui a ordem do TEXTO não é a ordem de execução. `startLunaria`
    // (que marca 7/8) é declarada **antes** do efeito que marca 6/8, e mesmo
    // assim roda depois. Então cada marca é presa ao trecho que a executa.
    const fonte = ler('app/index.tsx')

    const seis = posicao(fonte, '6/8 banco migrado')
    const chamaInicio = posicao(fonte, 'void startLunaria()')
    assert.ok(seis < chamaInicio, '6/8 é a etapa imediatamente antes de iniciar a Lunaria')

    const sete = posicao(fonte, '7/8 Lunaria iniciada')
    const esperaInicio = posicao(fonte, 'await startupApp()')
    assert.ok(esperaInicio < sete, '7/8 vem depois de `startupApp()` resolver')

    const oito = posicao(fonte, '8/8 lista de conversas na tela')
    assert.ok(sete < oito, '8/8 é a última etapa')
    assert.ok(
        fonte.includes('! falha ao iniciar a Lunaria:'),
        'falha ao iniciar precisa deixar rastro na trilha'
    )
})

test('a trilha do JavaScript não importa react-native no topo', () => {
    const fonte = ler('lib/utils/TrilhaJs.ts')
    // Só a **coluna 0** conta como topo: o `require` de dentro da função é
    // indentado, justamente por ser tardio.
    const noTopo = fonte.split('\n').filter((linha) => /^(import|const .*require\()/.test(linha))
    assert.deepEqual(
        noTopo.filter((linha) => linha.includes('react-native')),
        [],
        'o require de react-native é tardio, dentro de try/catch'
    )
    assert.ok(
        fonte.includes("require('react-native')"),
        'a busca da ponte precisa existir (tardia) em algum ponto do módulo'
    )
})
