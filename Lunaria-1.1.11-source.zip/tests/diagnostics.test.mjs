import assert from 'node:assert/strict'
import test from 'node:test'

import {
    breadcrumb,
    buildReport,
    checkStartup,
    clearDiagnostics,
    describeError,
    FAILS_FOR_SAFE_MODE,
    isSafeMode,
    markStartupBegin,
    markStartupOk,
    MAX_ERROR_CHARS,
    MAX_STEPS,
    readFailures,
    readLastError,
    readSteps,
    recordError,
    resetDiagStorage,
    setDiagStorage,
    setSafeMode,
} from '../lib/utils/Diagnostics.ts'

const comecarLimpo = () => {
    resetDiagStorage()
}

test('migalhas são gravadas em ordem e o anel não cresce sem limite', () => {
    comecarLimpo()
    for (let i = 0; i < MAX_STEPS + 7; i++) breadcrumb(`passo ${i}`)
    const passos = readSteps()
    assert.equal(passos.length, MAX_STEPS)
    // Ficam os mais recentes: o primeiro passo guardado é o oitavo escrito.
    assert.equal(passos[0].label, 'passo 7')
    assert.equal(passos.at(-1).label, `passo ${MAX_STEPS + 6}`)
    assert.ok(Date.parse(passos[0].at) > 0, 'cada passo tem horário válido')
})

test('erro guarda mensagem, pilha e o lugar onde aconteceu', () => {
    comecarLimpo()
    const erro = new Error('cofre indisponível no Keystore')
    recordError('cofre', erro)

    const guardado = readLastError()
    assert.ok(guardado)
    assert.equal(guardado.kind, 'cofre')
    assert.match(guardado.text, /cofre indisponível no Keystore/)
    assert.match(guardado.text, /Error/)
    // E o erro também deixa rastro no percurso.
    assert.match(readSteps().at(-1).label, /erro em cofre/)
})

test('erro sem ser Error também é descrito, sem quebrar', () => {
    comecarLimpo()
    assert.match(describeError('falha seca'), /falha seca/)
    assert.match(describeError({ code: 429, motivo: 'fila' }), /429/)
    assert.equal(describeError(undefined).length > 0, true)
    const enorme = 'x'.repeat(MAX_ERROR_CHARS * 3)
    assert.equal(describeError(enorme).length, MAX_ERROR_CHARS)
})

test('abertura que não termina conta como falha; duas seguidas ligam o modo seguro', () => {
    comecarLimpo()

    assert.equal(isSafeMode(), false)
    let estado = checkStartup()
    assert.equal(estado.failedLastTime, false)
    assert.equal(estado.failures, 0)

    // Primeira abertura morre no meio (marcou o começo e não marcou o fim).
    markStartupBegin()
    estado = checkStartup()
    assert.equal(estado.failedLastTime, true)
    assert.equal(estado.failures, 1)
    assert.equal(estado.safeMode, false, 'uma falha ainda não basta')

    // Segunda abertura morre igual: agora o modo seguro entra.
    markStartupBegin()
    estado = checkStartup()
    assert.equal(estado.failures, 2)
    assert.equal(estado.safeMode, true)
    assert.equal(isSafeMode(), true)
    assert.equal(FAILS_FOR_SAFE_MODE, 2)
})

test('abertura que termina zera o contador de falhas', () => {
    comecarLimpo()
    markStartupBegin()
    checkStartup()
    assert.equal(readFailures(), 1)

    markStartupBegin()
    markStartupOk()
    const estado = checkStartup()
    assert.equal(estado.failedLastTime, false)
    assert.equal(estado.failures, 0)
})

test('modo seguro pode ser desligado e sobrevive a aberturas normais', () => {
    comecarLimpo()
    setSafeMode(true)
    assert.equal(isSafeMode(), true)
    markStartupOk()
    assert.equal(isSafeMode(), true, 'abrir bem não desliga o modo seguro sozinho')
    setSafeMode(false)
    assert.equal(isSafeMode(), false)
})

test('relatório mostra versões, falhas, erro e passos — e nada de conteúdo pessoal', () => {
    comecarLimpo()
    markStartupBegin()
    recordError('imagens', new Error('sem permissão de mídia'))
    const texto = buildReport({
        appVersion: '1.1.3',
        build: '5',
        model: 'SM-A055F',
        system: 'Android 14',
        memory: '5.6 GB',
    })

    assert.match(texto, /Lunaria — relatório de diagnóstico/)
    assert.match(texto, /1\.1\.3 \(build 5\)/)
    assert.match(texto, /SM-A055F/)
    assert.match(texto, /sem permissão de mídia/)
    assert.match(texto, /onde: imagens/)
    assert.match(texto, /passos \(\d+ últimos\)/)
    assert.match(texto, /Nenhuma conversa, senha ou imagem é registrada aqui/)
})

test('relatório sem erro ainda é montado (nada de tela em branco)', () => {
    comecarLimpo()
    const texto = buildReport({})
    assert.match(texto, /último erro registrado:\s*\n\s*\(nenhum\)/)
    assert.match(texto, /passos \(0 últimos\)/)
})

test('limpar o diagnóstico não deixa o modo seguro ligado por engano', () => {
    comecarLimpo()
    breadcrumb('titulo: conversa privada')
    recordError('javascript', new Error('falha'))
    clearDiagnostics()
    assert.equal(readSteps().length, 0)
    assert.equal(readLastError(), undefined)
    assert.equal(isSafeMode(), false, 'o modo seguro tem o próprio interruptor')
})

test('armazenamento que falha não derruba o diagnóstico', () => {
    resetDiagStorage()
    setDiagStorage({
        getString: () => {
            throw new Error('mmkv fora do ar')
        },
        set: () => {
            throw new Error('mmkv fora do ar')
        },
        remove: () => {
            throw new Error('mmkv fora do ar')
        },
    })

    // Nenhuma destas chamadas pode lançar: é justamente no erro que elas rodam.
    breadcrumb('passo com armazenamento quebrado')
    recordError('teste', new Error('x'))
    assert.deepEqual(readSteps(), [])
    assert.equal(readLastError(), undefined)
    assert.equal(typeof buildReport({}), 'string')
    resetDiagStorage()
})

test('texto do relatório não cresce com o uso: anel fixo', () => {
    comecarLimpo()
    for (let i = 0; i < 500; i++) breadcrumb(`volta ${i}`)
    const linhas = buildReport({}).split('\n').length
    assert.ok(linhas < MAX_STEPS + 20, `relatório com ${linhas} linhas`)
})
