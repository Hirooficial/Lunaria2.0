/**
 * O terceiro caminho para o relatório sair do aparelho.
 *
 * Já existiam dois: copiar para a área de transferência (pode estar indisponível
 * justamente quando o aplicativo está quebrado) e a captura nativa em Downloads
 * (só cobre falhas antes do JavaScript). Este cobre as falhas dentro do JavaScript:
 * grava o mesmo texto em `lunaria-diagnostico.txt`, na pasta Downloads.
 *
 * O que estes testes protegem, além do caminho feliz: que uma falha ao salvar
 * **nunca** derrube a tela de emergência. Ali dentro, o usuário já está sem
 * aplicativo; perder o relatório seria perder tudo.
 */
import { salvarDiagnosticoNoAparelho, NOME_ARQUIVO_DIAGNOSTICO } from '@lib/utils/SalvarDiagnostico'

const mockSalvar = jest.fn(async (_d: string, _n: string, _e: string) => undefined)
jest.mock('@lib/utils/File', () => {
    const real = jest.requireActual('@lib/utils/File')
    return {
        ...real,
        saveStringToDownload: (d: string, n: string, e: string) => mockSalvar(d, n, e),
    }
})

describe('salvar o diagnóstico em Downloads', () => {
    beforeEach(() => {
        mockSalvar.mockClear()
        mockSalvar.mockImplementation(async () => undefined)
    })

    it('usa o utilitário do próprio aplicativo, com nome e codificação definidos', async () => {
        const deu = await salvarDiagnosticoNoAparelho('relatório de teste')

        expect(deu).toBe(true)
        expect(mockSalvar).toHaveBeenCalledWith(
            'relatório de teste',
            NOME_ARQUIVO_DIAGNOSTICO,
            'utf8'
        )
    })

    it('o nome do arquivo é estável (o usuário procura por ele em Downloads)', () => {
        expect(NOME_ARQUIVO_DIAGNOSTICO).toBe('lunaria-diagnostico.txt')
    })

    it('falha ao salvar devolve false e NÃO lança (a tela de emergência não pode cair)', async () => {
        mockSalvar.mockImplementation(async () => {
            throw new Error('disco cheio')
        })

        await expect(salvarDiagnosticoNoAparelho('relatório')).resolves.toBe(false)
    })

    it('o texto salvo é exatamente o que o usuário viu na tela', async () => {
        const texto = 'linha 1\nlinha 2 com acento: diagnóstico'
        await salvarDiagnosticoNoAparelho(texto)
        expect(mockSalvar.mock.calls[0][0]).toBe(texto)
    })
})
