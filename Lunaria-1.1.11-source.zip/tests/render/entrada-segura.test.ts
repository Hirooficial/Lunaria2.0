/**
 * Testes do porteiro de entrada (`lib/utils/EntradaSegura.js`) e do `index.js`.
 *
 * O que está sendo provado, e por que importa: o aplicativo fechava ao abrir
 * quando a avaliação de um módulo falhava (código nativo executado no instante do
 * carregamento — `BUGS_FOUND.md` §AN, §AQ, §AS). Nenhum `try/catch` de tela
 * alcança esse instante. Agora existe um porteiro que roda **antes** de tudo, não
 * depende de nada, e transforma o fechamento silencioso em uma tela com o motivo.
 *
 * Sem estes testes, a garantia seria só uma promessa.
 */

const caminhoDoPorteiro = '@lib/utils/EntradaSegura'

type FalsoErrorUtils = {
    setGlobalHandler: jest.Mock
    getGlobalHandler: jest.Mock
}

const prepararAmbiente = () => {
    const falso: FalsoErrorUtils = {
        setGlobalHandler: jest.fn(),
        getGlobalHandler: jest.fn(() => undefined),
    }
    ;(globalThis as unknown as { ErrorUtils: FalsoErrorUtils }).ErrorUtils = falso
    ;(globalThis as unknown as { __lunariaRotasCarregadas?: boolean }).__lunariaRotasCarregadas =
        undefined
    return falso
}

describe('porteiro de entrada', () => {
    let falso: FalsoErrorUtils

    let mock: jest.Mock

    beforeEach(() => {
        jest.resetModules()
        falso = prepararAmbiente()
        // O porteiro troca `ErrorUtils.setGlobalHandler` por uma versão que
        // encadeia quem chegar depois. Por isso o mock é guardado AQUI, antes:
        // depois da troca, `falso.setGlobalHandler` já não é o mock.
        mock = falso.setGlobalHandler
    })

    it('instala o registro de erro fatal antes de qualquer módulo do aplicativo', () => {
        const porteiro = require(caminhoDoPorteiro)
        porteiro.instalarTratador()

        expect(mock).toHaveBeenCalledTimes(1)
        expect(typeof mock.mock.calls[0][0]).toBe('function')
    })

    it('erro fatal antes das rotas carregarem: registra a tela de aviso', () => {
        const RN = require('react-native')
        const registrar = jest.spyOn(RN.AppRegistry, 'registerComponent')

        const porteiro = require(caminhoDoPorteiro)
        porteiro.instalarTratador()
        const tratador = mock.mock.calls[0][0] as (e: unknown, f: boolean) => void

        tratador(new Error('falha simulada na abertura'), true)

        expect(registrar).toHaveBeenCalledWith('main', expect.any(Function))
        registrar.mockRestore()
    })

    it('depois que as rotas carregaram, não sequestra a interface do usuário', () => {
        const RN = require('react-native')
        const registrar = jest.spyOn(RN.AppRegistry, 'registerComponent')

        const porteiro = require(caminhoDoPorteiro)
        porteiro.instalarTratador()
        porteiro.marcarRotasCarregadas()

        const tratador = mock.mock.calls[0][0] as (e: unknown, f: boolean) => void
        tratador(new Error('erro em sessão já aberta'), true)

        expect(registrar).not.toHaveBeenCalled()
        registrar.mockRestore()
    })

    it('erro NÃO fatal não impõe a tela de aviso', () => {
        const RN = require('react-native')
        const registrar = jest.spyOn(RN.AppRegistry, 'registerComponent')

        const porteiro = require(caminhoDoPorteiro)
        porteiro.instalarTratador()
        const tratador = mock.mock.calls[0][0] as (e: unknown, f: boolean) => void

        tratador(new Error('aviso qualquer'), false)

        expect(registrar).not.toHaveBeenCalled()
        registrar.mockRestore()
    })

    it('quem instala um tratador depois continua recebendo os erros (cadeia)', () => {
        const porteiro = require(caminhoDoPorteiro)
        porteiro.instalarTratador()

        // É o que o aplicativo faz em `app/_layout.tsx` (installGlobalErrorCapture).
        const doAplicativo = jest.fn()
        ;(globalThis as unknown as { ErrorUtils: FalsoErrorUtils }).ErrorUtils.setGlobalHandler(
            doAplicativo
        )

        // O tratador em vigor é o último que chegou ao React Native.
        const emVigor = mock.mock.calls.at(-1)?.[0] as (e: unknown, f: boolean) => void
        emVigor(new Error('erro com dois interessados'), true)

        expect(doAplicativo).toHaveBeenCalledTimes(1)
        expect(porteiro.falhaDeEntrada()).toBeInstanceOf(Error)
    })

    it('descreve a falha sem quebrar, mesmo com um objeto hostil', () => {
        const porteiro = require(caminhoDoPorteiro)
        const hostil = {
            get message() {
                throw new Error('mensagem que explode')
            },
            toString() {
                throw new Error('texto que explode')
            },
        }

        expect(() => porteiro.mostrarFalha(hostil)).not.toThrow()
        const texto = porteiro.textoDaFalha()
        expect(typeof texto).toBe('string')
        expect(texto).toContain('não conseguiu abrir')
        expect(texto).toContain('nada foi apagado')
        expect(texto).toContain('Copiar diagnóstico')
    })

    it('o relatório mostra o erro capturado e a versão do aplicativo', () => {
        const porteiro = require(caminhoDoPorteiro)
        porteiro.mostrarFalha(new Error('módulo nativo indisponível: ExpoSQLite'))

        const texto = porteiro.textoDaFalha()
        expect(texto).toContain('módulo nativo indisponível: ExpoSQLite')
        expect(texto).toMatch(/Versão: \d+\.\d+\.\d+/)
    })

    it('carrega o porteiro e depois as rotas, nessa ordem, num arquivo só', () => {
        const fs = require('fs')
        const path = require('path')
        const raiz = path.join(__dirname, '..', '..')
        const entrada = fs.readFileSync(path.join(raiz, 'index.js'), 'utf8')

        const posicaoPorteiro = entrada.indexOf("require('./lib/utils/EntradaSegura')")
        const posicaoRotas = entrada.indexOf("require('expo-router/entry')")

        expect(posicaoPorteiro).toBeGreaterThan(-1)
        expect(posicaoRotas).toBeGreaterThan(-1)
        expect(posicaoPorteiro).toBeLessThan(posicaoRotas)

        // E o carregamento das rotas tem de estar protegido.
        const trechoRotas = entrada.slice(posicaoRotas)
        expect(trechoRotas).toContain('try')
        expect(trechoRotas).toContain('mostrarFalha')
    })

    it('o main do package.json aponta para o index.js', () => {
        const pacote = require('../../package.json')
        expect(pacote.main).toBe('index.js')
    })
})
