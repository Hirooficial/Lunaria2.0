/**
 * A ponte da trilha, do lado de dentro do React Native.
 *
 * Os testes de lógica (`tests/trilha-js.test.mjs`) cobrem o comportamento com um
 * escritor injetado. Aqui o que é exercitado é o outro lado: o **descobrimento da
 * ponte nativa** em `NativeModules`, que é onde mora o risco de verdade.
 *
 * Por que este arquivo existe: no aparelho, `NativeModules.TrilhaJs` pode não
 * estar lá (registro indisponível, versão do React Native, interrupção no
 * arranque). Se esse caso não fosse contido, a trilha — que existe para
 * diagnosticar falhas — viraria uma falha. A regra é: **sem ponte, o aplicativo
 * abre exatamente igual**; a única perda é a evidência extra.
 */
import { NativeModules } from 'react-native'

import { readSteps, resetDiagStorage, setDiagStorage } from '@lib/utils/Diagnostics'
import { esquecerEscritorDaTrilha, marcarEtapaJs, PREFIXO_JS } from '@lib/utils/TrilhaJs'

type Ponte = { marcarEtapa?: (texto: string) => void }

const comPonte = (ponte: Ponte | undefined) => {
    ;(NativeModules as unknown as { TrilhaJs?: Ponte }).TrilhaJs = ponte
    esquecerEscritorDaTrilha()
}

afterEach(() => {
    comPonte(undefined)
    resetDiagStorage()
})

describe('ponte da trilha em NativeModules', () => {
    it('usa a ponte do aparelho quando ela existe', () => {
        const marcarEtapa = jest.fn()
        comPonte({ marcarEtapa })
        expect(marcarEtapaJs('3/8 tela inicial montou')).toBe(true)
        expect(marcarEtapa).toHaveBeenCalledTimes(1)
        expect(marcarEtapa).toHaveBeenCalledWith(`${PREFIXO_JS}3/8 tela inicial montou`)
    })

    it('sem a ponte: devolve false e não quebra nada', () => {
        comPonte(undefined)
        expect(() => marcarEtapaJs('4/8 bloqueio pronto')).not.toThrow()
        expect(marcarEtapaJs('4/8 bloqueio pronto')).toBe(false)
    })

    it('ponte sem o método esperado é tratada como ponte ausente', () => {
        comPonte({})
        expect(marcarEtapaJs('5/8 imagens prontas')).toBe(false)
    })

    it('ponte que lança não propaga a exceção para a abertura', () => {
        comPonte({
            marcarEtapa: () => {
                throw new Error('ponte quebrada no aparelho')
            },
        })
        expect(() => marcarEtapaJs('6/8 banco migrado')).not.toThrow()
        expect(marcarEtapaJs('6/8 banco migrado')).toBe(false)
    })

    it('a etapa entra nas migalhas do relatório — diagnóstico real, não simulado', () => {
        // Aqui o canal 2 é exercitado de verdade: o `breadcrumb` do próprio
        // `Diagnostics`, com o armazenamento injetado. Este é o teste que não dá
        // para fazer em Node (`tests/trilha-js.test.mjs`): lá o carregador cria
        // duas instâncias do mesmo arquivo e o teste conversaria com a errada.
        const memoria = new Map<string, string>()
        setDiagStorage({
            getString: (chave: string) => memoria.get(chave),
            set: (chave: string, valor: string) => void memoria.set(chave, valor),
            remove: (chave: string) => void memoria.delete(chave),
        })
        comPonte(undefined)

        marcarEtapaJs('2/8 rotas carregadas')

        expect(readSteps().map((passo) => passo.label)).toContain(
            `${PREFIXO_JS}2/8 rotas carregadas`
        )
    })

    it('a ponte é procurada uma vez; registrar depois exige esquecer', () => {
        comPonte(undefined)
        expect(marcarEtapaJs('7/8 Lunaria iniciada')).toBe(false)

        // Simula o registro que só aparece depois (ou o teste que chega atrasado).
        const marcarEtapa = jest.fn()
        ;(NativeModules as unknown as { TrilhaJs?: Ponte }).TrilhaJs = { marcarEtapa }
        expect(marcarEtapaJs('7/8 Lunaria iniciada')).toBe(false)
        expect(marcarEtapa).not.toHaveBeenCalled()

        esquecerEscritorDaTrilha()
        expect(marcarEtapaJs('7/8 Lunaria iniciada')).toBe(true)
        expect(marcarEtapa).toHaveBeenCalledWith(`${PREFIXO_JS}7/8 Lunaria iniciada`)
    })
})
