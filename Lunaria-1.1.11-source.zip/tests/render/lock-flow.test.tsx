/**
 * Ciclo completo do bloqueio, com os módulos de verdade.
 *
 * Até aqui a criptografia e o estado do bloqueio foram testados separadamente,
 * como funções puras. Aqui os dois rodam juntos, integrados, do jeito que o
 * aplicativo usa: ativar a proteção cria o cofre, bloquear fecha, senha errada
 * soma tentativa, senha certa abre, e a troca de senha precisa reabrir o cofre
 * com os mesmos dados dentro.
 *
 * Só o armazenamento nativo é simulado (keychain e MMKV em memória, em
 * jest.setup.js). O resto — AES-256-GCM, PBKDF2, o verificador, o estado — é o
 * código que vai no APK.
 *
 * Continua NÃO sendo teste de aparelho: biometria, keychain real e o
 * comportamento da tela continuam pendentes.
 */
import * as SecureStore from 'expo-secure-store'

import { useAppLock } from '@lib/state/AppLock'
import { mmkv } from '@lib/storage/MMKV'

const segredoCorreto = '123456'
const outroSegredo = 'senha-nova-987'

const limparTudo = async () => {
    // estado do aplicativo
    useAppLock.setState({
        ready: false,
        locked: false,
        configured: false,
        failures: 0,
        lockoutSeconds: 0,
        lastReason: undefined,
        settings: {
            enabled: false,
            biometric: false,
            autoLockMinutes: 5,
            blockScreenshots: false,
            hideInNotifications: true,
        },
    })
    // armazenamento simulado
    ;(SecureStore as unknown as { __slots: Map<string, string> }).__slots.clear()
    mmkv.clearAll()
    await useAppLock.getState().init()
}

describe('ciclo de vida da proteção por senha', () => {
    beforeEach(limparTudo)

    it('ativar a proteção cria o cofre e deixa o aplicativo desbloqueado', async () => {
        const resultado = await useAppLock.getState().enableLock(segredoCorreto)
        expect(resultado.ok).toBe(true)
        expect(useAppLock.getState().settings.enabled).toBe(true)
        expect(useAppLock.getState().configured).toBe(true)
        expect(useAppLock.getState().locked).toBe(false)
    })

    it('senha curta é recusada com motivo', async () => {
        const resultado = await useAppLock.getState().enableLock('123')
        expect(resultado.ok).toBe(false)
        expect(resultado.error).toBeTruthy()
        expect(useAppLock.getState().settings.enabled).toBe(false)
    })

    it('bloquear fecha o cofre e exige senha', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        useAppLock.getState().lockNow('manual')
        expect(useAppLock.getState().locked).toBe(true)
        expect(useAppLock.getState().lastReason).toBe('manual')
    })

    it('senha errada não abre e conta a tentativa', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        useAppLock.getState().lockNow('manual')

        const abriu = await useAppLock.getState().unlock('000000')
        expect(abriu).toBe(false)
        expect(useAppLock.getState().locked).toBe(true)
        expect(useAppLock.getState().failures).toBe(1)
    })

    it('senha certa abre o cofre', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        useAppLock.getState().lockNow('manual')

        const abriu = await useAppLock.getState().unlock(segredoCorreto)
        expect(abriu).toBe(true)
        expect(useAppLock.getState().locked).toBe(false)
        expect(useAppLock.getState().failures).toBe(0)
    })

    it('depois de 3 erros passa a exigir espera, e a espera é contada', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        useAppLock.getState().lockNow('manual')

        for (let i = 0; i < 3; i++) await useAppLock.getState().unlock('000000')

        expect(useAppLock.getState().failures).toBe(3)
        expect(useAppLock.getState().lockoutSeconds).toBeGreaterThan(0)
        // durante a espera, nem a senha certa abre
        const abriuNaEspera = await useAppLock.getState().unlock(segredoCorreto)
        expect(abriuNaEspera).toBe(false)
    })

    it('a espera conta para trás e depois libera a tentativa', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        useAppLock.getState().lockNow('manual')
        for (let i = 0; i < 3; i++) await useAppLock.getState().unlock('000000')

        const inicio = useAppLock.getState().lockoutSeconds
        useAppLock.getState().tickLockout()
        expect(useAppLock.getState().lockoutSeconds).toBe(inicio - 1)
    })

    it('trocar a senha mantém o cofre: abre com a nova e recusa a antiga', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        const trocou = await useAppLock.getState().changeSecret(segredoCorreto, outroSegredo)
        expect(trocou.ok).toBe(true)

        useAppLock.getState().lockNow('manual')
        expect(await useAppLock.getState().unlock(segredoCorreto)).toBe(false)
        expect(await useAppLock.getState().unlock(outroSegredo)).toBe(true)
    })

    it('não dá para trocar a senha sem saber a atual', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        const trocou = await useAppLock.getState().changeSecret('000000', outroSegredo)
        expect(trocou.ok).toBe(false)
        expect(trocou.error).toBeTruthy()
    })

    it('desligar a proteção exige a senha atual', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)

        const comSenhaErrada = await useAppLock.getState().disableLock('000000')
        expect(comSenhaErrada.ok).toBe(false)
        expect(useAppLock.getState().settings.enabled).toBe(true)

        const comSenhaCerta = await useAppLock.getState().disableLock(segredoCorreto)
        expect(comSenhaCerta.ok).toBe(true)
        expect(useAppLock.getState().settings.enabled).toBe(false)
    })
})

describe('nenhuma senha em claro no armazenamento (verificado depois do uso real)', () => {
    beforeEach(limparTudo)

    it('o keychain não guarda a senha, só material derivado', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        const slots = (SecureStore as unknown as { __slots: Map<string, string> }).__slots
        expect(slots.size).toBeGreaterThan(0)
        for (const [, valor] of slots) {
            expect(String(valor)).not.toContain(segredoCorreto)
        }
    })

    it('o armazenamento do aplicativo também não guarda a senha', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        useAppLock.getState().lockNow('manual')
        await useAppLock.getState().unlock(segredoCorreto)

        for (const chave of mmkv.getAllKeys()) {
            const valor = mmkv.getString(chave)
            expect(String(valor)).not.toContain(segredoCorreto)
        }
    })

    it('depois de trocar a senha, nem a antiga nem a nova aparecem em claro', async () => {
        await useAppLock.getState().enableLock(segredoCorreto)
        await useAppLock.getState().changeSecret(segredoCorreto, outroSegredo)

        const slots = (SecureStore as unknown as { __slots: Map<string, string> }).__slots
        for (const [, valor] of slots) {
            expect(String(valor)).not.toContain(segredoCorreto)
            expect(String(valor)).not.toContain(outroSegredo)
        }
        for (const chave of mmkv.getAllKeys()) {
            expect(String(mmkv.getString(chave))).not.toContain(outroSegredo)
        }
    })
})
