/**
 * Primeiro teste de renderização do projeto.
 *
 * Os 87 testes em tests/*.test.mjs cobrem lógica pura (criptografia, política de
 * conteúdo, montagem de prompt, cliente HTTP...). Nenhum deles **executa** um
 * componente React — ou seja, um import quebrado, um hook fora de ordem ou um
 * símbolo inexistente numa tela só apareceria no aparelho. Estes testes fecham
 * essa lacuna: renderizam telas de verdade, no ambiente jsdom/react-native do
 * jest-expo, com os módulos nativos simulados.
 */
import { render, screen } from '@testing-library/react-native'
import { Text } from 'react-native'

describe('ambiente de renderização', () => {
    it('renderiza um componente React Native', () => {
        render(<Text>Lunaria</Text>)
        expect(screen.getByText('Lunaria')).toBeTruthy()
    })
})
