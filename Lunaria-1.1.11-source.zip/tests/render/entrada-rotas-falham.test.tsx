/**
 * O caminho de emergência **de ponta a ponta**: o `index.js` de verdade, com as
 * rotas falhando de verdade.
 *
 * Os testes do porteiro provam pedaços (o tratador é instalado, a tela é
 * registrada quando alguém chama o tratador). Este aqui prova o **encadeamento
 * inteiro**, que é o que o Hamura vai viver se o aplicativo não carregar:
 *
 *   `index.js` → carrega o porteiro → tenta carregar as rotas → **falha** →
 *   porteiro registra a tela de aviso → o aplicativo abre e mostra o motivo.
 *
 * A diferença importa: um teste de pedaço pode passar com o encadeamento quebrado
 * (por exemplo, se o `index.js` deixasse de chamar `mostrarFalha`).
 *
 * Duas armadilhas encontradas ao escrever este arquivo, registradas para não
 * voltarem:
 *
 *  1. **`jest.resetModules()` com a biblioteca de testes requerida dentro do
 *     teste** registra hooks aninhados e o próprio Jest aborta ("Hooks cannot be
 *     defined inside tests"). Aqui tudo é carregado uma vez, no topo do arquivo.
 *  2. **Passar a fábrica da tela direto ao React** faz o React tratá-la como
 *     componente funcional e receber de volta uma classe — que não é filho válido,
 *     e a tela sai vazia. A fábrica **precisa ser chamada** (é ela que lê
 *     `react` e `react-native` na hora do uso, de propósito).
 */
import { render } from '@testing-library/react-native'
import React from 'react'
import { AppRegistry } from 'react-native'

// As rotas estouram no momento em que são carregadas — como aconteceria se um
// módulo do caminho de abertura falhasse ao procurar o módulo nativo.
jest.mock('expo-router/entry', () => {
    throw new Error('módulo nativo indisponível: falha simulada ao avaliar as rotas')
})

// O gravador do relatório em Downloads, controlado por teste. O prefixo `mock` no
// nome não é estilo: é exigência do Jest para variáveis usadas dentro de fábricas
// de mock (hoisting) — sem ele, a suíte nem carrega.
const mockSalvar = jest.fn(async (_texto: string) => true)
jest.mock('@lib/utils/SalvarDiagnostico', () => ({
    salvarDiagnosticoNoAparelho: (texto: string) => mockSalvar(texto),
    NOME_ARQUIVO_DIAGNOSTICO: 'lunaria-diagnostico.txt',
}))

// O encadeamento real, sem atalho: é este arquivo que o Metro usa como ponto de
// entrada do aplicativo. Carregado uma única vez, com o espião já no lugar.
const registrar = jest.spyOn(AppRegistry, 'registerComponent')
const erroDeConsole = jest.spyOn(console, 'error').mockImplementation(() => undefined)
// eslint-disable-next-line @typescript-eslint/no-require-imports
require('../../index.js')
erroDeConsole.mockRestore()

type Fabrica = () => unknown

const fabricaDaTela = () =>
    registrar.mock.calls.find((chamada: unknown[]) => chamada[0] === 'main')?.[1] as Fabrica

describe('index.js quando as rotas não carregam', () => {
    it('o aplicativo não explode: a tela de aviso é registrada', () => {
        expect(registrar).toHaveBeenCalledWith('main', expect.any(Function))
        expect(typeof fabricaDaTela()).toBe('function')
    })

    it('a tela registrada é a de aviso, e ela renderiza o motivo', () => {
        // A fábrica precisa ser chamada: ela monta o componente lendo `react` e
        // `react-native` na hora do uso (nada é importado no topo dela).
        const componente = fabricaDaTela()()
        const tela = render(React.createElement(componente as never))

        // Duas menções de propósito: o título da tela e a primeira linha do relatório.
        expect(tela.getAllByText(/A Lunaria não conseguiu abrir/).length).toBeGreaterThan(0)
        // O relatório precisa citar a falha real, não um texto genérico.
        expect(tela.getByText(/módulo nativo indisponível/)).toBeTruthy()
        // E precisa oferecer as duas saídas para o texto sair do aparelho.
        expect(tela.getByText('Copiar diagnóstico')).toBeTruthy()
        expect(tela.getByText('Salvar em Downloads')).toBeTruthy()
    })

    it('o botão "Salvar em Downloads" grava o relatório e dá retorno ao usuário', async () => {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const { fireEvent } = require('@testing-library/react-native')
        mockSalvar.mockClear()

        const componente = fabricaDaTela()()
        const tela = render(React.createElement(componente as never))
        fireEvent.press(tela.getByText('Salvar em Downloads'))

        await tela.findByText(/Salvo na pasta Downloads do aparelho/)
        expect(mockSalvar).toHaveBeenCalledTimes(1)
        // O que foi salvo é o relatório completo que está na tela, não um resumo.
        expect(String(mockSalvar.mock.calls[0][0])).toContain('módulo nativo indisponível')
    })

    it('o relatório da tela de aviso nomeia as saídas para o usuário', () => {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const porteiro = require('@lib/utils/EntradaSegura')
        const texto = porteiro.textoDaFalha() as string

        expect(texto).toContain('Suas conversas e imagens continuam no aparelho')
        expect(texto).toContain('lunaria-ultimo-erro.txt')
        expect(texto).toContain('lunaria-diagnostico.txt')
        expect(texto).toContain('Salvar em Downloads')
    })
})
