/**
 * O cofre de arquivos privados, ponta a ponta.
 *
 * Verifica o que o encargo pede em "privacidade": as imagens ficam na área
 * privada do aplicativo, cifradas, e o texto em claro não existe no arquivo
 * gravado. Aqui o arquivo é de mentira (memória), o que permite inspecionar os
 * bytes que seriam escritos no disco — e é justamente isso que prova a
 * cifragem: o conteúdo gravado é comparado com o conteúdo original.
 */
import * as SecureStore from 'expo-secure-store'

import { toPrivateUri, isPrivateUri, storedImageExtension } from '@lib/security/PrivateNames'
import { privateVault } from '@lib/security/PrivateStorage'
import { createVault, destroyVault, secretIsCorrect, unlockVault } from '@lib/security/SecureVault'
import { mmkv } from '@lib/storage/MMKV'

const SENHA = '123456'
const arquivos = () =>
    (require('expo-file-system') as unknown as { __arquivos: Map<string, Uint8Array> }).__arquivos

const limpar = async () => {
    ;(SecureStore as unknown as { __slots: Map<string, string> }).__slots.clear()
    mmkv.clearAll()
    arquivos().clear()
    await destroyVault()
}

describe('cofre de arquivos privados (criptografia real, disco simulado)', () => {
    beforeEach(limpar)

    it('grava cifrado: os bytes no arquivo não contêm o conteúdo original', async () => {
        const dek = await createVault(SENHA)
        privateVault.unlock(dek)

        const conteudo = new TextEncoder().encode(
            'conteúdo secreto da lunaria que não pode aparecer'
        )
        const salvo = privateVault.writeFile(conteudo, 'teste')

        expect(salvo.uri.startsWith('private://')).toBe(true)
        expect(salvo.fileName.endsWith('.lunaenc')).toBe(true)

        // inspeciona o que foi realmente gravado
        const gravados = [...arquivos().entries()]
        expect(gravados.length).toBe(1)
        const bytes = gravados[0][1]
        const comoTexto = new TextDecoder().decode(bytes)
        expect(comoTexto).not.toContain('conteúdo secreto')
        expect(comoTexto).not.toContain('lunaria')
        // e não é igual ao original
        expect(Buffer.from(bytes).equals(Buffer.from(conteudo))).toBe(false)
    })

    it('lê de volta exatamente o que foi gravado', async () => {
        const dek = await createVault(SENHA)
        privateVault.unlock(dek)

        const conteudo = new Uint8Array([0, 1, 2, 3, 250, 251, 252, 253])
        const { fileName } = privateVault.writeFile(conteudo, 'binario')
        const lido = privateVault.readFile(fileName)

        expect(Array.from(lido)).toEqual(Array.from(conteudo))
    })

    it('o mesmo conteúdo gravado duas vezes gera arquivos diferentes (IV novo a cada vez)', async () => {
        const dek = await createVault(SENHA)
        privateVault.unlock(dek)
        const conteudo = new TextEncoder().encode('mesmo conteúdo')

        privateVault.writeFile(conteudo, 'a')
        privateVault.writeFile(conteudo, 'b')

        const [primeiro, segundo] = [...arquivos().values()]
        expect(Buffer.from(primeiro).equals(Buffer.from(segundo))).toBe(false)
    })

    it('apagar remove o arquivo do armazenamento', async () => {
        const dek = await createVault(SENHA)
        privateVault.unlock(dek)
        const { fileName } = privateVault.writeFile(new TextEncoder().encode('x'), 'apagar')

        expect(arquivos().size).toBe(1)
        privateVault.deleteFile(fileName)
        expect(arquivos().size).toBe(0)
    })

    it('com o cofre fechado, não dá para ler o arquivo', async () => {
        const dek = await createVault(SENHA)
        privateVault.unlock(dek)
        const { fileName } = privateVault.writeFile(new TextEncoder().encode('segredo'), 'fechado')

        privateVault.lock()
        // sem a chave em memória, a leitura falha na hora (não devolve lixo)
        expect(() => privateVault.readFile(fileName)).toThrow()
    })

    it('senha errada não abre o cofre e o arquivo continua ilegível', async () => {
        const dek = await createVault(SENHA)
        privateVault.unlock(dek)
        privateVault.writeFile(new TextEncoder().encode('segredo'), 'cofre')
        privateVault.lock()

        expect(await secretIsCorrect('000000')).toBe(false)
        await expect(unlockVault('000000')).rejects.toBeTruthy()
    })

    it('a senha certa reabre o cofre e o arquivo antigo volta a ser legível', async () => {
        const dek = await createVault(SENHA)
        privateVault.unlock(dek)
        const { fileName } = privateVault.writeFile(new TextEncoder().encode('volta'), 'antigo')

        privateVault.lock()
        const dek2 = await unlockVault(SENHA)
        privateVault.unlock(dek2)

        expect(privateVault.readFile(fileName)).toEqual(new TextEncoder().encode('volta'))
    })
})

describe('nomes e uri privadas', () => {
    it('a uri privada é reconhecida e convertida', () => {
        const uri = toPrivateUri('1.webp')
        expect(isPrivateUri(uri)).toBe(true)
        expect(isPrivateUri('file:///dcim/foto.webp')).toBe(false)
    })

    it('a extensão de uma imagem do cofre é lida do nome interno, não do envelope', () => {
        // regressão: o sufixo .lunaenc já foi confundido com a extensão
        expect(storedImageExtension('1.webp.lunaenc')).toBe('webp')
        expect(storedImageExtension('2.png.lunaenc')).toBe('png')
        expect(storedImageExtension('3')).toBe('bin')
    })
})
