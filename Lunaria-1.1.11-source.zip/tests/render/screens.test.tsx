/**
 * Executa as telas novas (geração de imagem e bloqueio) e o visualizador.
 *
 * Os testes de lógica pura provam que a criptografia, a política de conteúdo e o
 * cliente dos provedores funcionam. Eles **não** provam que as telas abrem: um
 * import errado, um símbolo que não existe, um hook fora de ordem ou um estado
 * vazio que quebra na renderização só apareceriam no aparelho.
 *
 * Aqui cada tela é renderizada de verdade, com os módulos nativos simulados.
 * Não é o mesmo que usar no aparelho — é o passo anterior, que precisa passar
 * antes de qualquer teste de uso.
 */
import { render, screen } from '@testing-library/react-native'
import React from 'react'

// Estado real das telas, mas com o MMKV/SecureStore em memória (jest.setup.js)
// o sistema de arquivos em memória fica no jest.setup.js (vale para todas as suítes)
jest.mock('expo-media-library', () => ({
    requestPermissionsAsync: jest.fn(async () => ({ granted: true })),
    saveToLibraryAsync: jest.fn(async () => undefined),
    createAssetAsync: jest.fn(async () => ({})),
    getAlbumAsync: jest.fn(async () => null),
    createAlbumAsync: jest.fn(async () => ({})),
}))

jest.mock('expo-sharing', () => ({ shareAsync: jest.fn(async () => undefined) }))
jest.mock('expo-clipboard', () => ({
    setStringAsync: jest.fn(async () => true),
    getStringAsync: jest.fn(async () => ''),
}))
jest.mock('expo-speech', () => ({
    speak: jest.fn(),
    stop: jest.fn(async () => undefined),
    isSpeakingAsync: jest.fn(async () => false),
}))
jest.mock('expo-speech-recognition', () => ({
    ExpoSpeechRecognitionModule: {
        start: jest.fn(),
        stop: jest.fn(),
        abort: jest.fn(),
        requestPermissionsAsync: jest.fn(async () => ({ granted: true })),
        addListener: jest.fn(() => ({ remove: jest.fn() })),
    },
    useSpeechRecognitionEvent: jest.fn(),
}))

// Os imports das telas ficam DEPOIS do bloco de jest.mock de propósito: aqui os
// mocks precisam existir antes de o módulo ser carregado (a suíte de telas
// quebrou em 18/09 quando a formatação automática subiu estes imports).
import ImageGenerationScreen from '../../app/screens/ImageGenerationScreen'
import ImageSettingsScreen from '../../app/screens/ImageSettingsScreen'
import LockSettingsScreen from '../../app/screens/LockSettingsScreen'
import PrivateImage from '../../app/components/views/PrivateImage'
import ImageViewer from '../../app/components/views/ImageViewer'

describe('telas novas da 1.1.0 — abrem sem quebrar', () => {
    it('tela de geração de imagem renderiza', () => {
        render(<ImageGenerationScreen />)
        // a tela existe e pediu ao menos um controle
        expect(screen.toJSON()).toBeTruthy()
    })

    it('tela de ajustes de imagem renderiza', () => {
        render(<ImageSettingsScreen />)
        expect(screen.toJSON()).toBeTruthy()
    })

    it('tela de ajustes de bloqueio renderiza', () => {
        render(<LockSettingsScreen />)
        expect(screen.toJSON()).toBeTruthy()
    })

    it('ajustes de imagem avisam o limite de idioma da Pollinations (medido na API real)', () => {
        render(<ImageSettingsScreen />)
        const texto = JSON.stringify(screen.toJSON())
        expect(texto).toMatch(/entende melhor descrições em inglês/i)
        expect(texto).toMatch(/provedor AI Horde se saiu melhor/i)
    })

    it('visualizador de imagem renderiza (fechado, sem imagem)', () => {
        render(<ImageViewer />)
        // sem imagem selecionada, o visualizador não mostra nada — e não quebra
        expect(screen.toJSON()).toBeFalsy()
    })

    it('imagem privada aceita uma uri do cofre sem quebrar', () => {
        render(<PrivateImage uri="private://1.webp" style={{ width: 100, height: 100 }} />)
        expect(screen.toJSON()).toBeTruthy()
    })

    it('imagem privada com uri comum também renderiza', () => {
        render(<PrivateImage uri="file:///cache/view-1.webp" style={{ width: 50, height: 50 }} />)
        expect(screen.toJSON()).toBeTruthy()
    })
})

describe('segurança das telas novas', () => {
    it('a tela de geração não expõe nenhuma chave fixa no texto', () => {
        render(<ImageGenerationScreen />)
        const arvore = JSON.stringify(screen.toJSON())
        // nem a chave anônima da Horde nem qualquer token longo aparecem na tela
        expect(arvore).not.toMatch(/0000000000/)
        expect(arvore).not.toMatch(/Bearer\s+[A-Za-z0-9]{20,}/)
    })

    it('a tela de bloqueio (ajustes) não mostra a senha em lugar nenhum', () => {
        render(<LockSettingsScreen />)
        const arvore = JSON.stringify(screen.toJSON())
        expect(arvore).not.toMatch(/senha\s*[:=]\s*\S/i)
    })
})
