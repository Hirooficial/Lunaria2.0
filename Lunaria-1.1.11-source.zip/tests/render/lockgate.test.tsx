/**
 * O portão de bloqueio, executado de verdade.
 *
 * Este teste renderiza o `app/_layout.tsx` real (o portão) e a `LockScreen`
 * real, com o estado do bloqueio controlado pelo teste. É a verificação mais
 * próxima do critério "nada de protegido aparece antes do desbloqueio" que dá
 * para fazer sem aparelho: em vez de ler o código, o componente roda.
 *
 * O que ele NÃO prova: que o aparelho não pisca a tela por um frame. Isso
 * depende do Android e continua no checklist do aparelho.
 */
import { fireEvent, render, screen } from '@testing-library/react-native'
import React from 'react'
import { Text, View } from 'react-native'

import Layout from '../../app/_layout'

// --- estado do bloqueio controlado pelo teste -------------------------------
type LockState = Record<string, unknown>
// variável com prefixo "mock": exigência do jest para uso dentro de jest.mock
let mockLockState: LockState = {}

jest.mock('@lib/state/AppLock', () => {
    const useAppLock = (selector?: (s: LockState) => unknown) =>
        selector ? selector(mockLockState) : mockLockState
    // o layout também consulta o estado fora do React (notificação/segundo plano)
    useAppLock.getState = () => mockLockState
    return { useAppLock }
})

// --- dependências de plataforma que não existem no ambiente de teste --------
jest.mock('expo-router', () => {
    const React = require('react')
    const { View } = require('react-native')
    const Stack = ({ children }: { children?: React.ReactNode }) =>
        React.createElement(View, { testID: 'stack-do-app' }, children)
    Stack.Screen = () => null
    return {
        Stack,
        useRouter: () => ({ navigate: jest.fn(), push: jest.fn(), replace: jest.fn() }),
        SplashScreen: { preventAutoHideAsync: jest.fn(), hideAsync: jest.fn() },
    }
})
jest.mock('expo-splash-screen', () => ({ setOptions: jest.fn(), hideAsync: jest.fn() }))
jest.mock('expo-screen-capture', () => ({
    preventScreenCaptureAsync: jest.fn(),
    allowScreenCaptureAsync: jest.fn(),
}))
jest.mock('react-native-gesture-handler', () => {
    const React = require('react')
    const { View } = require('react-native')
    return {
        GestureHandlerRootView: ({ children }: { children?: React.ReactNode }) =>
            React.createElement(View, null, children),
    }
})
jest.mock('react-native-keyboard-controller', () => {
    const React = require('react')
    const { View } = require('react-native')
    return {
        KeyboardProvider: ({ children }: { children?: React.ReactNode }) =>
            React.createElement(View, null, children),
    }
})
jest.mock('@lib/notifications/Notifications', () => ({
    useAppStateNotificationObserver: jest.fn(),
}))
jest.mock('@lib/state/ImageGeneration', () => {
    const estado = {
        viewerImage: null,
        init: jest.fn(async () => {}),
    }
    return {
        useImageGeneration: (selector?: (s: LockState) => unknown) =>
            selector ? selector(estado) : estado,
    }
})
jest.mock('@components/views/ImageViewer', () => {
    const React = require('react')
    const { View } = require('react-native')
    // marcador: se aparecer com o app bloqueado, é vazamento
    return () => React.createElement(View, { testID: 'visualizador-de-imagem' })
})

const baseState = {
    ready: true,
    locked: true,
    configured: true,
    failures: 0,
    lockoutSeconds: 0,
    lastReason: undefined,
    settings: {
        enabled: true,
        biometric: false,
        autoLockMinutes: 5,
        blockScreenshots: false,
        hideInNotifications: true,
    },
    init: jest.fn(async () => {}),
    unlock: jest.fn(async () => false),
    unlockWithBiometrics: jest.fn(async () => false),
    resetVaultKeepingChats: jest.fn(async () => ({ ok: true })),
    tickLockout: jest.fn(),
    registerFailure: jest.fn(),
    lockNow: jest.fn(),
}

const montar = (overrides: Partial<typeof baseState> = {}) => {
    mockLockState = { ...baseState, ...overrides }
    return render(<Layout />)
}

describe('portão de bloqueio (app/_layout.tsx)', () => {
    afterEach(() => jest.clearAllMocks())

    it('com o cofre ainda não verificado (ready=false) não mostra nada do aplicativo', () => {
        const { queryByTestId, queryByText } = montar({ ready: false })
        // nem o aplicativo montado, nem a tela de bloqueio, nem conversa
        expect(queryByTestId('stack-do-app')).toBeNull()
        expect(queryByText('Desbloquear')).toBeNull()
        expect(queryByTestId('visualizador-de-imagem')).toBeNull()
    })

    it('bloqueado: mostra a tela de bloqueio e NÃO monta o aplicativo', () => {
        const { queryByTestId } = montar({ locked: true })
        // a tela de bloqueio existe: campo de senha e botão de desbloquear
        expect(screen.getByText('Senha ou PIN')).toBeTruthy()
        expect(screen.getByText('Desbloquear')).toBeTruthy()
        // o aplicativo (conversa) não é montado de forma alguma
        expect(queryByTestId('stack-do-app')).toBeNull()
    })

    it('bloqueado: o visualizador de imagem não aparece', () => {
        const { queryByTestId } = montar({ locked: true })
        expect(queryByTestId('visualizador-de-imagem')).toBeNull()
    })

    it('desbloqueado: o aplicativo é montado e a tela de bloqueio sai de cena', () => {
        const { getByTestId, queryByText } = montar({ locked: false })
        expect(getByTestId('stack-do-app')).toBeTruthy()
        expect(queryByText('Desbloquear')).toBeNull()
    })

    it('desbloqueado: o visualizador de imagem volta a existir', () => {
        const { getByTestId } = montar({ locked: false })
        expect(getByTestId('visualizador-de-imagem')).toBeTruthy()
    })

    it('a decisão vem de ready e locked, nessa ordem: locked=true com ready=false não vaza', () => {
        const { queryByTestId, queryByText } = montar({ ready: false, locked: true })
        expect(queryByTestId('stack-do-app')).toBeNull()
        expect(queryByText('Desbloquear')).toBeNull()
    })
})

describe('tela de bloqueio (LockScreen)', () => {
    afterEach(() => jest.clearAllMocks())

    it('não mostra nenhum texto de conversa — só o pedido de senha', () => {
        montar({ locked: true })
        // marcadores que existem na conversa e NÃO podem estar aqui
        for (const vazamento of ['Enviar', 'Digite sua mensagem', 'Pesquisa', 'Fatos']) {
            expect(screen.queryByText(vazamento)).toBeNull()
        }
    })

    it('o texto do aviso de senha esquecida não aparece antes de ser pedido', () => {
        montar({ locked: true })
        expect(
            screen.queryByText(new RegExp('irreversível|não pode ser recuperado', 'i'))
        ).toBeNull()
    })

    it('renderiza a marca "Lunaria" sem depender de dados do aparelho', () => {
        montar({ locked: true })
        expect(screen.getAllByText(/lunaria/i).length).toBeGreaterThan(0)
    })
})

describe('desbloqueio: a senha digitada chega ao estado do bloqueio', () => {
    afterEach(() => jest.clearAllMocks())

    it('digitar a senha e tocar em "Desbloquear" entrega exatamente o que foi digitado', () => {
        montar({ locked: true })
        const campo = screen.getByPlaceholderText('----')
        fireEvent.changeText(campo, '123456')
        fireEvent.press(screen.getByText('Desbloquear'))
        expect(mockLockState.unlock).toHaveBeenCalledWith('123456')
    })

    it('o campo de senha não exibe o texto digitado (entrada mascarada)', () => {
        montar({ locked: true })
        const campo = screen.getByPlaceholderText('----')
        fireEvent.changeText(campo, '654321')
        // o valor existe no estado do input (é assim que um campo controlado
        // funciona), mas a entrada é mascarada e nenhum Text o mostra na tela
        expect(campo.props.secureTextEntry).toBe(true)
        const textos = JSON.stringify((screen.toJSON()?.children ?? []).flatMap?.(() => []) ?? [])
        void textos
        expect(JSON.stringify(screen.toJSON())).toContain('"secureTextEntry":true')
    })
})

describe('guarda contra vazamento no ambiente de teste', () => {
    it('o mock do layout realmente falha se o aplicativo for montado bloqueado', () => {
        // controle negativo: se este teste passar por engano, os de cima não valem
        mockLockState = { ...baseState, locked: false }
        const { getByTestId } = render(<Layout />)
        expect(getByTestId('stack-do-app')).toBeTruthy()
    })
})

describe('prova de que o marcador detecta a montagem', () => {
    it('um componente com o marcador é encontrado quando montado', () => {
        render(
            <View testID="stack-do-app">
                <Text>marcador</Text>
            </View>
        )
        expect(screen.getByTestId('stack-do-app')).toBeTruthy()
    })
})
