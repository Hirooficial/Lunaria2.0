/**
 * Testes de comportamento que precisam do transform do React Native (por isso
 * vivem aqui e não em `tests/*.test.mjs`, que roda no Node puro).
 *
 * O que se prova, e por que importa: `openDatabaseSync` rodava no escopo de
 * `db/db.ts` (importado pela primeira tela) e o `expo-sqlite` era importado no
 * topo — os dois no instante de avaliação do pacote, antes de qualquer tela e de
 * qualquer `try/catch`. Uma falha ali fechava o aplicativo sem mensagem.
 */
import { novoId, uuidDeReserva } from '@lib/utils/RandomId'

const mockOpenDatabaseSync = jest.fn()
let mockBanco: Record<string, unknown> = {}

jest.mock('expo-sqlite', () => ({
    openDatabaseSync: (...args: unknown[]) => mockOpenDatabaseSync(...args),
    bundledExtensions: {},
}))

jest.mock('drizzle-orm/expo-sqlite', () => ({
    drizzle: (banco: unknown, opcoes: unknown) => ({ banco, opcoes, query: { execute: () => undefined } }),
}))

describe('banco de dados sob demanda', () => {
    beforeEach(() => {
        jest.resetModules()
        mockOpenDatabaseSync.mockClear()
        mockBanco = {
            loadExtensionAsync: jest.fn(() => Promise.resolve()),
            execAsync: jest.fn(() => Promise.resolve()),
        }
        mockOpenDatabaseSync.mockReturnValue(mockBanco)
    })

    it('não abre o banco ao ser importado (era aqui que o app morria)', () => {
        require('@db')
        expect(mockOpenDatabaseSync).not.toHaveBeenCalled()
    })

    it('abre o banco no primeiro uso, e só uma vez', () => {
        const { db } = require('@db')
        void db.query
        void db.query
        void db.query
        expect(mockOpenDatabaseSync).toHaveBeenCalledTimes(1)
        expect(mockOpenDatabaseSync).toHaveBeenCalledWith('db.db', { enableChangeListener: true })
    })

    it('liga as chaves estrangeiras no primeiro uso', () => {
        const { sqliteDB } = require('@db')
        void sqliteDB.loadExtensionAsync
        const chamadas = (mockBanco.execAsync as jest.Mock).mock.calls.map((c) => String(c[0]))
        expect(chamadas.join(' ')).toContain('foreign_keys = ON')
    })
})

describe('identificadores', () => {
    const formato = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[0-9a-f]{4}-[0-9a-f]{12}$/

    it('funciona mesmo se a fonte aleatória do sistema falhar', () => {
        expect(novoId()).toMatch(formato)
        expect(uuidDeReserva()).toMatch(formato)
    })

    it('não repete identificadores', () => {
        const ids = new Set(Array.from({ length: 500 }, () => novoId()))
        expect(ids.size).toBe(500)
    })
})
