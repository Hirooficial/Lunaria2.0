/** `mime/lite` em ESM não passa pelo transformador do jest; aqui só o que o app usa. */
module.exports = {
    __esModule: true,
    default: {
        getType: (nome) => {
            const ext = String(nome).split('.').pop()?.toLowerCase()
            return (
                {
                    jpg: 'image/jpeg',
                    jpeg: 'image/jpeg',
                    png: 'image/png',
                    webp: 'image/webp',
                    gif: 'image/gif',
                    gguf: 'application/octet-stream',
                }[ext] ?? 'application/octet-stream'
            )
        },
        getExtension: (tipo) => (tipo === 'image/jpeg' ? 'jpg' : 'bin'),
    },
}
