/**
 * Shim do Reanimated para o ambiente de teste.
 *
 * O Reanimated 4 depende do runtime nativo (JSI) e, sem aparelho, qualquer
 * import dele derruba a suíte. Este arquivo substitui o módulo por uma versão
 * puramente JavaScript, com as duas partes que importam para um teste de
 * renderização:
 *
 *  1. os componentes (`Animated.View`, `Image`, `ScrollView`, `FlatList`)
 *     viram os equivalentes do React Native — a árvore renderizada é a mesma,
 *     então dá para afirmar o que apareceu e o que não apareceu;
 *  2. os hooks (`useSharedValue`, `useAnimatedStyle`) funcionam com valores
 *     comuns, sem thread de UI.
 *
 * Um Proxy cobre o resto: qualquer símbolo que eu não tenha previsto devolve um
 * stub encadeável, em vez de quebrar o teste. Isso é de propósito — o objetivo
 * aqui é renderizar telas, não simular o Reanimated.
 */
const React = require('react')
const RN = require('react-native')

const chain = () =>
    new Proxy(function () {}, {
        get: (target, prop) => {
            if (prop === 'valueOf' || prop === 'toString' || prop === Symbol.toPrimitive)
                return () => 0
            if (prop === Symbol.iterator) return undefined
            return chain()
        },
        apply: () => chain(),
    })

const component = (name) => {
    const Base = RN[name] ?? RN.View
    const C = React.forwardRef((props, ref) =>
        React.createElement(Base, { ...props, ref }, props?.children)
    )
    C.displayName = `AnimatedShim.${name}`
    return C
}

const lastValue = (input) => {
    // withTiming/withSpring recebem o valor de destino no primeiro argumento
    if (input && typeof input === 'object' && 'value' in input) return input.value
    return input
}

const Animated = {
    View: component('View'),
    Text: component('Text'),
    Image: component('Image'),
    ScrollView: component('ScrollView'),
    FlatList: component('FlatList'),
    createAnimatedComponent: (C) => C,
    timing: (value, config, callback) => ({
        start: (cb) => {
            callback?.(true)
            cb?.(true)
        },
        stop: () => {},
        _value: value,
        _config: config,
    }),
    spring: (_value, config, callback) => ({
        start: (cb) => {
            callback?.(true)
            cb?.(true)
        },
        stop: () => {},
    }),
    parallel: () => ({ start: (cb) => cb?.(true), stop: () => {} }),
    sequence: () => ({ start: (cb) => cb?.(true), stop: () => {} }),
    delay: () => ({ start: (cb) => cb?.(true), stop: () => {} }),
}

const Easing = new Proxy(
    {
        linear: (t) => t,
        ease: (t) => t,
        quad: (t) => t,
        cubic: (t) => t,
        bezier: () => (t) => t,
        in: (f) => f,
        out: (f) => f,
        inOut: (f) => f,
    },
    {
        get: (target, prop) => (prop in target ? target[prop] : (t) => t),
    }
)

const module_ = {
    __esModule: true,
    default: Animated,
    ...Animated,
    Easing,

    // Hooks: valores comuns, sem thread de UI
    useSharedValue: (initial) => React.useRef({ value: initial }).current,
    useAnimatedStyle: (fn) => {
        try {
            return fn() ?? {}
        } catch {
            return {}
        }
    },
    useDerivedValue: (fn) => ({
        value: (() => {
            try {
                return fn()
            } catch {
                return undefined
            }
        })(),
    }),
    useAnimatedRef: () => React.useRef(null),
    useAnimatedScrollHandler: () => () => {},
    useAnimatedGestureHandler: () => () => {},
    useAnimatedReaction: () => {},

    // Funções utilitárias
    withTiming: (value, config, callback) => {
        callback?.(true)
        return lastValue(value)
    },
    withSpring: (value, config, callback) => {
        callback?.(true)
        return lastValue(value)
    },
    withDelay: (_delay, animation) => animation,
    withSequence: (...animations) => animations[animations.length - 1],
    withRepeat: (animation) => animation,
    cancelAnimation: () => {},
    runOnJS: (fn) => fn,
    runOnUI: (fn) => fn,
    interpolate: (value, input, output) => output?.[0] ?? value,
    interpolateColor: (_v, _i, output) => output?.[0],
    clamp: (value, min, max) => Math.min(Math.max(value, min), max),
    measure: () => null,
    scrollTo: () => {},
    isSharedValue: (v) => Boolean(v && typeof v === 'object' && 'value' in v),
    setUpTests: () => {},
    getAnimatedStyle: () => ({}),
    advanceAnimationByTime: () => {},
    advanceAnimationByFrame: () => {},
    ColorSpace: { RGB: 'rgb', HSV: 'hsv' },
    Extrapolation: { CLAMP: 'clamp', EXTEND: 'extend', IDENTITY: 'identity' },
    ReduceMotion: { System: 'system', Always: 'always', Never: 'never' },
    InterfaceOrientation: {},
    KeyboardState: {},
    SensorType: {},
    IOSReferenceFrame: {},
    reanimatedVersion: '4.2.1-shim',
}

// Presets de entrada/saída e transições: aceitam .duration()/.delay() etc.
const preset = () => chain()
module_.FadeIn = preset()
module_.FadeOut = preset()
module_.FadeInDown = preset()
module_.FadeInUp = preset()
module_.FadeOutDown = preset()
module_.ZoomIn = preset()
module_.ZoomOut = preset()
module_.SlideInLeft = preset()
module_.SlideInRight = preset()
module_.SlideInUp = preset()
module_.SlideInDown = preset()
module_.SlideOutRight = preset()
module_.LinearTransition = preset()
module_.CurvedTransition = preset()
module_.FadeInEasy = preset()

module.exports = new Proxy(module_, {
    get: (target, prop) => (prop in target ? target[prop] : chain()),
})
