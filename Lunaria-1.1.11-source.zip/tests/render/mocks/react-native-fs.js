/**
 * `@vali98/react-native-fs` é um módulo nativo distribuído em ESM (sem
 * transpilação), o que o jest não consegue carregar no node. Aqui ficam só as
 * funções que o aplicativo usa, com respostas neutras: nenhum teste depende de
 * copiar arquivo de verdade — isso é do aparelho.
 */
module.exports = {
    __esModule: true,
    getContentFd: jest.fn(async () => 0),
    closeFd: jest.fn(async () => undefined),
    copyFileSAF: jest.fn(async () => 'file:///cache/modelo.gguf'),
    persistContentPermission: jest.fn(async () => 'content://autorizacao'),
    localDownload: jest.fn(async () => 'file:///cache/baixado'),
}
