/**
 * Shim do react-native-worklets: sem runtime nativo, tudo roda na thread de JS.
 * O Reanimated importa este pacote na inicialização, então ele precisa existir
 * no ambiente de teste.
 */
const runOnJS = (fn) => fn
const runOnUI = (fn) => fn

module.exports = {
    __esModule: true,
    runOnJS,
    runOnUI,
    createWorkletRuntime: () => ({ run: (fn) => fn?.() }),
    runOnRuntime: (runtime, fn) => fn,
    isWorkletFunction: () => false,
    makeShareableCloneRecursive: (v) => v,
    makeShareableCloneOnUIRecursive: (v) => v,
    shouldBeUseWeb: () => true,
    getWorkletsModule: () => ({}),
    WorkletsModule: {},
    NativeWorklets: function () {},
    WorkletsError: class WorkletsError extends Error {},
}
