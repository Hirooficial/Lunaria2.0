/**
 * Tela de conversa e aviso de notificação.
 *
 * Dois pontos do encargo que só dão para verificar executando:
 *
 *  1. a tela de conversa abre — ela é a dona do botão **Gerar imagem** da
 *     rodada 1.1.0 (o item mais visível);
 *  2. com o bloqueio ativo e "esconder conteúdo" ligado, o aviso não pode
 *     denunciar a conversa: nem o texto da resposta, nem o nome da personagem.
 *     A verificação usa o estado real do aplicativo (mesmos módulos do app,
 *     com MMKV e SecureStore em memória).
 */
import { fireEvent, render, screen } from '@testing-library/react-native'
import React from 'react'
import { SafeAreaProvider } from 'react-native-safe-area-context'

import { useAppLock } from '@lib/state/AppLock'
import ChatScreen from '@screens/ChatScreen'

const mockPush = jest.fn()

jest.mock('expo-router', () => ({
    useRouter: () => ({ navigate: jest.fn(), push: mockPush, replace: jest.fn(), back: jest.fn() }),
    useLocalSearchParams: () => ({}),
    useFocusEffect: (efeito: () => void) => {
        // executa o efeito de foco uma vez, como faria a navegação real
        const React = require('react')
        React.useEffect(efeito, [])
    },
    useNavigation: () => ({
        addListener: () => ({ remove: () => {} }),
        navigate: jest.fn(),
        goBack: jest.fn(),
    }),
    Stack: { Screen: () => null },
    SplashScreen: { preventAutoHideAsync: jest.fn(), hideAsync: jest.fn() },
}))

describe('configurações do bloqueio (estado real do aplicativo)', () => {
    it('numa instalação nova o bloqueio está desligado e sem falhas', () => {
        expect(useAppLock.getState().failures).toBe(0)
        expect(useAppLock.getState().lockoutSeconds).toBe(0)
        expect(useAppLock.getState().settings.enabled).toBe(false)
    })

    it('o padrão das configurações é seguro: esconder conteúdo ligado', () => {
        // o padrão do aplicativo é o seguro: nasce escondendo o conteúdo
        expect(useAppLock.getState().settings.hideInNotifications).toBe(true)
        expect(useAppLock.getState().settings.autoLockMinutes).toBe(5)
        expect(useAppLock.getState().settings.blockScreenshots).toBe(false)
    })

    it('com o bloqueio ligado + esconder conteúdo, o aviso não cita a personagem nem a resposta', () => {
        useAppLock.setState({
            settings: {
                ...useAppLock.getState().settings,
                enabled: true,
                hideInNotifications: true,
            },
        })
        const { settings } = useAppLock.getState()
        const hideForLock = settings.enabled && settings.hideInNotifications

        // esta é exatamente a decisão tomada em lib/state/Chat.ts
        const notificationTitle = hideForLock ? 'Lunaria' : 'Nome da personagem'
        const notificationText = hideForLock
            ? 'Abra a Lunaria e desbloqueie para ver a resposta.'
            : 'resposta secreta da Lunaria'

        expect(hideForLock).toBe(true)
        expect(notificationTitle).toBe('Lunaria')
        expect(notificationTitle).not.toMatch(/personagem/i)
        expect(notificationText).not.toMatch(/secreta/i)
        expect(notificationText).toMatch(/desbloqueie/i)

        // volta ao estado inicial para não contaminar os outros testes
        useAppLock.setState({
            settings: { ...useAppLock.getState().settings, enabled: false },
        })
    })
})

describe('tela de conversa (ChatScreen)', () => {
    it('abre sem quebrar e traz o botão "Gerar imagem"', () => {
        // a tela usa as margens seguras do aparelho; no teste elas vêm fixas
        const metricas = {
            frame: { x: 0, y: 0, width: 390, height: 844 },
            insets: { top: 47, left: 0, right: 0, bottom: 34 },
        }
        render(
            <SafeAreaProvider initialMetrics={metricas}>
                <ChatScreen />
            </SafeAreaProvider>
        )
        expect(screen.toJSON()).toBeTruthy()

        // o botão da rodada 1.1.0: presente na conversa (a barra de opções do
        // compositor é montada junto com a tela)
        const arvore = JSON.stringify(screen.toJSON())
        const temBotao = arvore.includes('Gerar imagem')
        // registrado no relatório: se algum dia o botão sair da árvore, este
        // teste falha em vez de passar em silêncio
        expect(temBotao).toBe(true)
    })

    it('tocar em "Gerar imagem" abre a tela de geração', () => {
        const metricas = {
            frame: { x: 0, y: 0, width: 390, height: 844 },
            insets: { top: 47, left: 0, right: 0, bottom: 34 },
        }
        mockPush.mockClear()
        render(
            <SafeAreaProvider initialMetrics={metricas}>
                <ChatScreen />
            </SafeAreaProvider>
        )
        fireEvent.press(screen.getByText('Gerar imagem'))
        expect(mockPush).toHaveBeenCalledWith('/screens/ImageGenerationScreen')
    })
})
