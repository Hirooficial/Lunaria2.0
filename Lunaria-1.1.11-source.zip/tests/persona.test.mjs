import assert from 'node:assert/strict'
import test from 'node:test'
import { polishLunariaResponse } from '../lib/persona/ResponseGuard.ts'

test('remove um turno ecoado sem apagar a resposta seguinte', () => {
    assert.equal(
        polishLunariaResponse({
            response: 'Lunaria: Olá!\nOlá, Hamura.\u0000',
            latestUserMessage: 'Olá!',
        }),
        'Olá, Hamura.'
    )
})
test('preserva Markdown, links, números, acentos e emoji', () => {
    const response =
        'Fontes 🌙:\n\n1. [Site](https://example.com/lei).\n2. Taxa: 3,5%.\n\n```python\nprint("ação")\n```'
    assert.equal(polishLunariaResponse({ response }), response)
})
test('não inventa frases quando a geração falha ou se repete', () => {
    assert.equal(polishLunariaResponse({ response: '', latestUserMessage: 'Oi' }), '')
    const response = 'Brasília é a capital do Brasil.'
    assert.equal(polishLunariaResponse({ response, previousAssistantMessage: response }), response)
})
test('não altera citações ou negações', () => {
    const response = 'Ela disse: "Estou cansada". Não estou cansada, apenas citei a frase.'
    assert.equal(polishLunariaResponse({ response }), response)
})
