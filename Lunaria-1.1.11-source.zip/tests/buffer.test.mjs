import assert from 'node:assert/strict'
import test from 'node:test'
import { appendStreamChunk, bufferBelongsToSwipe } from '../lib/engine/StreamBuffer.ts'

test('acrescenta pedaços do mesmo swipe sem perder o início', () => {
    let buffer = { data: '', swipeId: 7 }
    buffer = appendStreamChunk(buffer, 'Oi, ', 7)
    buffer = appendStreamChunk(buffer, 'Hamura.', 7)
    assert.deepEqual(buffer, { data: 'Oi, Hamura.', swipeId: 7 })
})

test('descarta sobra de outra conversa antes de começar uma resposta nova', () => {
    const leftovers = { data: 'resposta antiga de outro chat', swipeId: 12 }
    const merged = appendStreamChunk(leftovers, 'Nova resposta', 99)
    assert.deepEqual(merged, { data: 'Nova resposta', swipeId: 99 })
    assert.equal(bufferBelongsToSwipe(merged, 99), true)
    assert.equal(bufferBelongsToSwipe(merged, 12), false)
})

test('mantém o texto quando o swipe ainda não foi identificado', () => {
    const merged = appendStreamChunk({ data: 'prefixo ' }, 'continuação', 4)
    assert.deepEqual(merged, { data: 'prefixo continuação', swipeId: 4 })
    assert.equal(bufferBelongsToSwipe({ data: 'prefixo ' }, 4), true)
})

test('pedaço vazio não apaga nem altera o buffer', () => {
    const buffer = { data: 'texto', swipeId: 3 }
    assert.equal(appendStreamChunk(buffer, '', 3), buffer)
    assert.equal(appendStreamChunk(buffer, '', 8).data, 'texto')
})

test('acentos e emoji sobrevivem à concatenação entre pedaços', () => {
    let buffer = { data: '', swipeId: 1 }
    ;['Olá, ', 'ação ', 'çã', 'o 🌙'].forEach((chunk) => {
        buffer = appendStreamChunk(buffer, chunk, 1)
    })
    assert.equal(buffer.data, 'Olá, ação ção 🌙')
})
