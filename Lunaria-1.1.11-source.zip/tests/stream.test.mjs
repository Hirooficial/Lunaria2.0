import assert from 'node:assert/strict'
import test from 'node:test'
import { StreamDecoder } from '../lib/engine/StreamDecoder.ts'

test('preserva Unicode em cada corte possível dos bytes SSE', () => {
    const event = JSON.stringify({ text: 'Olá, Hamura! Ação e memória 🌙.' })
    const bytes = new TextEncoder().encode(`data: ${event}\r\n\r\ndata: [DONE]\r\n\r\n`)
    for (let i = 0; i <= bytes.length; i++) {
        const decoder = new StreamDecoder()
        assert.deepEqual(
            [
                ...decoder.push(bytes.slice(0, i)),
                ...decoder.push(bytes.slice(i)),
                ...decoder.finish(),
            ],
            [event],
            `corte ${i}`
        )
        assert.equal(decoder.done, true)
    }
})
test('recebe um byte por vez, comentários e múltiplas linhas', () => {
    const decoder = new StreamDecoder()
    const bytes = new TextEncoder().encode(
        ': keepalive\nevent: token\ndata: um\ndata: dois\n\ndata: três\n\n'
    )
    const output = Array.from(bytes).flatMap((byte) => decoder.push(Uint8Array.of(byte)))
    assert.deepEqual([...output, ...decoder.finish()], ['um\ndois', 'três'])
})
test('preserva NDJSON dividido e a última linha sem newline', () => {
    const decoder = new StreamDecoder()
    const bytes = new TextEncoder().encode('{"text":"ação"}\n{"text":"fim"}')
    const output = Array.from(bytes).flatMap((byte) => decoder.push(Uint8Array.of(byte)))
    assert.deepEqual([...output, ...decoder.finish()], ['{"text":"ação"}', '{"text":"fim"}'])
})
test('não apresenta evento truncado como completo', () => {
    const decoder = new StreamDecoder()
    assert.deepEqual(decoder.push(new TextEncoder().encode('data: {"text":"parcial"}\n')), [])
    assert.deepEqual(decoder.finish(), [])
    assert.equal(decoder.incomplete, true)
})
test('recusa UTF-8 inválido', () => {
    assert.throws(() => new StreamDecoder().push(Uint8Array.of(0xff)))
})
