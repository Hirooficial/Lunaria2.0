/**
 * Proteção da abertura contra módulo nativo indisponível.
 *
 * O defeito que estes testes travam: um `import` no topo do arquivo é resolvido
 * quando o pacote JavaScript é avaliado — antes de qualquer tela, antes do
 * relatório de diagnóstico e antes de qualquer `try/catch`. Módulo nativo
 * ausente ou quebrado nesse ponto = aplicativo fechando sozinho, sem mensagem.
 *
 * Dois blocos:
 *  1. comportamento de `carregarModuloNativo` (devolve, falha, memoriza);
 *  2. guarda de fonte: o caminho de abertura **não pode** importar direto os
 *     módulos nativos novos — só `import type` e carga sob demanda.
 */

import assert from 'node:assert/strict'
import { readFileSync, readdirSync, statSync } from 'node:fs'
import path from 'node:path'
import test from 'node:test'

import { carregarModuloNativo, esquecerModulosNativos } from '../lib/utils/NativeModules.ts'

const RAIZ = path.resolve(import.meta.dirname, '..')

test('carrega o módulo quando ele existe', () => {
    esquecerModulosNativos()
    const falso = { marcar: () => 'ok' }
    const carregado = carregarModuloNativo('teste-ok', () => falso)
    assert.equal(carregado, falso)
    assert.equal(carregado.marcar(), 'ok')
})

test('devolve null (sem lançar) quando o carregador lança', () => {
    esquecerModulosNativos()
    let erro = null
    const resultado = carregarModuloNativo('teste-falha', () => {
        erro = new Error('módulo nativo não registrado')
        throw erro
    })
    assert.equal(resultado, null)
    assert.ok(erro, 'o carregador precisa ter sido chamado')
})

test('devolve null quando o módulo vem vazio', () => {
    esquecerModulosNativos()
    assert.equal(
        carregarModuloNativo('teste-vazio', () => undefined),
        null
    )
    assert.equal(
        carregarModuloNativo('teste-vazio2', () => null),
        null
    )
})

test('memoriza: uma tentativa por módulo, mesmo depois de falhar', () => {
    esquecerModulosNativos()
    let tentativas = 0
    const carregador = () => {
        tentativas += 1
        throw new Error('quebrado')
    }
    carregarModuloNativo('teste-memo-falha', carregador)
    carregarModuloNativo('teste-memo-falha', carregador)
    carregarModuloNativo('teste-memo-falha', carregador)
    assert.equal(tentativas, 1, 'não deve tentar carregar de novo a cada uso')
})

test('memoriza o sucesso: devolve a mesma instância', () => {
    esquecerModulosNativos()
    let tentativas = 0
    const carregar = () => {
        tentativas += 1
        return { id: tentativas }
    }
    const primeiro = carregarModuloNativo('teste-memo-ok', carregar)
    const segundo = carregarModuloNativo('teste-memo-ok', carregar)
    assert.equal(primeiro.id, 1)
    assert.equal(segundo.id, 1)
    assert.equal(tentativas, 1)
})

/**
 * Guarda de fonte.
 *
 * Escopo medido, não achismo: no pacote instalado, `createMMKV` só cria os
 * objetos nativos **dentro da função** e `getDefaultMMKVInstance()` é chamado
 * dentro do corpo dos hooks (na renderização). Ou seja, no aplicativo inteiro a
 * única chamada nativa no momento do *import* era `createMMKV()` no topo de
 * `lib/storage/MMKV.ts` — corrigida abaixo. Por isso a guarda de import direto
 * cobre os módulos convertidos (`expo-secure-store`, `expo-media-library`,
 * `expo-sharing`), e a guarda de escopo de módulo cobre o MMKV.
 */
const MODULOS_DE_CARGA_SOB_DEMANDA = ['expo-secure-store', 'expo-media-library', 'expo-sharing']

const arquivosDe = (dir) => {
    const saida = []
    for (const item of readdirSync(dir)) {
        const completo = path.join(dir, item)
        if (statSync(completo).isDirectory()) {
            saida.push(...arquivosDe(completo))
            continue
        }
        if (item.endsWith('.ts') || item.endsWith('.tsx')) saida.push(completo)
    }
    return saida
}

test('nenhum arquivo importa no topo os módulos de carga sob demanda', () => {
    const arquivos = [...arquivosDe(path.join(RAIZ, 'lib')), ...arquivosDe(path.join(RAIZ, 'app'))]
    assert.ok(arquivos.length > 100, `esperava muitos arquivos, veio ${arquivos.length}`)

    const infratores = []
    for (const arquivo of arquivos) {
        const linhas = readFileSync(arquivo, 'utf8').split('\n')
        for (const [indice, linha] of linhas.entries()) {
            for (const modulo of MODULOS_DE_CARGA_SOB_DEMANDA) {
                // `import type` é apagado na compilação: não conta como import real.
                const importaDireto =
                    new RegExp(`^\\s*import\\s+(?!type\\b).*from\\s+['"]${modulo}['"]`).test(
                        linha
                    ) || new RegExp(`^\\s*import\\s+['"]${modulo}['"]`).test(linha)
                if (!importaDireto) continue
                // O catálogo de telas (image provider) é carregado sob demanda e
                // só registra chaves de estilo — fica de fora da regra.
                infratores.push(`${path.relative(RAIZ, arquivo)}:${indice + 1} → ${modulo}`)
            }
        }
    }

    assert.deepEqual(
        infratores,
        [],
        'módulo nativo crítico importado no topo (derruba a abertura se faltar):\n' +
            infratores.join('\n')
    )
})

test('o MMKV não é criado no escopo do módulo (a chamada nativa da abertura)', () => {
    const mmkv = readFileSync(path.join(RAIZ, 'lib/storage/MMKV.ts'), 'utf8')
    const criacoesNoEscopo = mmkv
        .split('\n')
        .filter((linha) => /^(export\s+)?(const|let|var)\s+\w+\s*=\s*createMMKV\(/.test(linha))
    assert.deepEqual(
        criacoesNoEscopo,
        [],
        'createMMKV() no escopo do módulo derruba a abertura se o nativo não responder'
    )
    assert.match(
        mmkv,
        /carregarModuloNativo<Preferencias>\(/,
        'MMKV deve passar pela carga protegida'
    )
    assert.match(mmkv, /mmkvEmMemoria/, 'deve existir reserva em memória declarada')
})

test('os módulos convertidos são realmente carregados sob demanda', () => {
    const mmkv = readFileSync(path.join(RAIZ, 'lib/storage/MMKV.ts'), 'utf8')
    assert.match(
        mmkv,
        /carregarModuloNativo<Preferencias>\(/,
        'MMKV deve passar pela carga protegida'
    )

    const cofre = readFileSync(path.join(RAIZ, 'lib/security/SecureVault.ts'), 'utf8')
    assert.match(cofre, /carregarSecureStore/, 'SecureStore deve ter carga própria')
    assert.match(cofre, /carregarCrypto/, 'expo-crypto deve ter carga própria')

    const imagens = readFileSync(path.join(RAIZ, 'lib/state/ImageGeneration.ts'), 'utf8')
    assert.match(imagens, /carregarMediaLibrary/, 'galeria deve ser carregada no uso')
    assert.match(imagens, /carregarSharing/, 'compartilhamento deve ser carregado no uso')

    const trava = readFileSync(path.join(RAIZ, 'lib/state/AppLock.ts'), 'utf8')
    assert.match(trava, /carregarLocalAuthentication/, 'biometria deve ser carregada no uso')
})

/**
 * O banco de dados: era o outro ponto que executava código nativo no instante do
 * import (`openDatabaseSync` no escopo de `db/db.ts`, além do próprio
 * `expo-sqlite`, que busca o módulo nativo ao ser importado —
 * `node_modules/expo-sqlite/build/ExpoSQLite.js`). Como `db/db.ts` é importado
 * pela primeira tela, uma falha ali fechava o aplicativo sem mensagem.
 */
test('o banco não é aberto no escopo do módulo', () => {
    const fonte = readFileSync(path.join(RAIZ, 'db/db.ts'), 'utf8')
    const noEscopo = fonte
        .split('\n')
        .filter((linha) =>
            /^(export\s+)?(const|let|var)\s+\w+\s*=\s*openDatabaseSync\(/.test(linha)
        )
    assert.deepEqual(noEscopo, [], 'openDatabaseSync no escopo do módulo derruba a abertura')
    assert.match(
        fonte,
        /carregarModuloNativo<typeof SQLiteModule>/,
        'expo-sqlite deve ser carregado sob demanda'
    )
})

test('nenhum arquivo importa expo-sqlite no topo', () => {
    const arquivos = [
        ...arquivosDe(path.join(RAIZ, 'lib')),
        ...arquivosDe(path.join(RAIZ, 'app')),
        path.join(RAIZ, 'db/db.ts'),
    ]
    const infratores = []
    for (const arquivo of arquivos) {
        const linhas = readFileSync(arquivo, 'utf8').split('\n')
        for (const [indice, linha] of linhas.entries()) {
            if (/^\s*import\s+(?!type\b).*from\s+['"]expo-sqlite['"]/.test(linha)) {
                infratores.push(`${path.relative(RAIZ, arquivo)}:${indice + 1}`)
            }
        }
    }
    assert.deepEqual(
        infratores,
        [],
        'expo-sqlite busca o módulo nativo no import: precisa ser sob demanda'
    )
})

/**
 * Identificadores: `expo-crypto` também busca o módulo nativo no import
 * (`build/Crypto.js` → `build/ExpoCrypto.js`: `requireNativeModule('ExpoCrypto')`)
 * e era importado no topo do estado do chat, que está no caminho da abertura.
 */
test('nenhum arquivo importa expo-crypto no topo', () => {
    const arquivos = [...arquivosDe(path.join(RAIZ, 'lib')), ...arquivosDe(path.join(RAIZ, 'app'))]
    const infratores = []
    for (const arquivo of arquivos) {
        const linhas = readFileSync(arquivo, 'utf8').split('\n')
        for (const [indice, linha] of linhas.entries()) {
            if (/^\s*import\s+(?!type\b).*from\s+['"]expo-crypto['"]/.test(linha)) {
                infratores.push(`${path.relative(RAIZ, arquivo)}:${indice + 1}`)
            }
        }
    }
    assert.deepEqual(
        infratores,
        [],
        'expo-crypto busca o módulo nativo no import: precisa ser sob demanda'
    )
})

/**
 * O porteiro de entrada (`lib/utils/EntradaSegura.js`).
 *
 * Ele existe para o caso em que NADA mais pode socorrer: a falha na avaliação de
 * um pacote. Para isso, a regra que não pode ser quebrada é que ele **não importe
 * nada** — nem React Native, nem nossos módulos. Se um dia alguém acrescentar um
 * `import` no topo dele, ele passa a morrer da mesma doença que existe para
 * diagnosticar, e o aplicativo volta a fechar em silêncio.
 */
test('o porteiro de entrada não importa nada no topo', () => {
    const fonte = readFileSync(path.join(RAIZ, 'lib/utils/EntradaSegura.js'), 'utf8')
    const linhas = fonte.split('\n')
    const importsNoTopo = []
    for (const [indice, linha] of linhas.entries()) {
        // Só conta o que está no TOPO (coluna 0): `require` dentro de uma função,
        // na hora do uso, é exatamente o desenho correto deste arquivo.
        if (
            /^(import\s|import\{|const\s+\w+\s*=\s*require\(|let\s+\w+\s*=\s*require\()/.test(linha)
        ) {
            importsNoTopo.push(`${indice + 1}: ${linha.trim()}`)
        }
    }
    assert.deepEqual(
        importsNoTopo,
        [],
        'o porteiro precisa continuar sem depender de nada: a carga tem de ser dentro de try/catch, na hora do uso'
    )
})

test('o main do aplicativo passa pelo porteiro antes das rotas', () => {
    const pacote = JSON.parse(readFileSync(path.join(RAIZ, 'package.json'), 'utf8'))
    assert.equal(
        pacote.main,
        'index.js',
        'o main precisa ser o index.js: é ele que carrega o porteiro antes das rotas'
    )

    const entrada = readFileSync(path.join(RAIZ, 'index.js'), 'utf8')
    const porteiro = entrada.indexOf("require('./lib/utils/EntradaSegura')")
    const rotas = entrada.indexOf("require('expo-router/entry')")
    assert.ok(porteiro > -1, 'o index.js precisa carregar o porteiro')
    assert.ok(rotas > -1, 'o index.js precisa carregar as rotas')
    assert.ok(porteiro < rotas, 'o porteiro precisa ser carregado ANTES das rotas')

    const protegido =
        /try\s*\{[\s\S]*require\('expo-router\/entry'\)[\s\S]*\}\s*catch\s*\([^)]*\)\s*\{[\s\S]*mostrarFalha/
    assert.ok(
        protegido.test(entrada),
        'o carregamento das rotas precisa estar protegido, com o porteiro avisando na falha'
    )
})
