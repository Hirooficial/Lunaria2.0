/**
 * Captura de falha no lado **nativo** (Kotlin), antes do JavaScript existir.
 *
 * O defeito que estes testes travam — e que é um defeito do **diagnóstico**, não do
 * aplicativo: a captura existia desde a rodada anterior, mas gravava o registro
 * apenas na pasta privada do aplicativo. Se o aplicativo não abre, essa pasta é
 * inalcançável para o Hamura (sem computador, sem `adb`, sem root). Ou seja: a
 * prova do defeito existia e não havia como tirá-la de dentro do aparelho.
 *
 * Agora o registro sai também na pasta **Downloads**, e a morte que não gera
 * exceção Java (falha nativa, travamento, memória) é lida do histórico do próprio
 * Android na abertura seguinte.
 *
 * Estes testes leem o código Kotlin (não o executam — não há Android aqui), então
 * eles protegem **estrutura**, não comportamento. O comportamento só o aparelho
 * responde, e está no `CHECKLIST_APARELHO.md`.
 */

import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import path from 'node:path'
import test from 'node:test'

const RAIZ = path.resolve(import.meta.dirname, '..')
const KOTLIN = path.join(
    RAIZ,
    'android/app/src/main/java/br/aurora/luna/lunaria/next/CapturaDeFalha.kt'
)
const MAIN = path.join(
    RAIZ,
    'android/app/src/main/java/br/aurora/luna/lunaria/next/MainApplication.kt'
)
const RELATORIO = path.join(RAIZ, 'app/components/views/DiagnosticReport.tsx')

const lerKotlin = () => readFileSync(KOTLIN, 'utf8')

test('a captura nativa grava o registro em dois lugares', () => {
    const fonte = lerKotlin()
    assert.match(
        fonte,
        /ARQUIVO_PRIVADO\s*=\s*"diagnostico-nativo\.txt"/,
        'o arquivo privado é o que o relatório em JavaScript lê'
    )
    assert.match(
        fonte,
        /ARQUIVO_PUBLICO\s*=\s*"lunaria-ultimo-erro\.txt"/,
        'o arquivo público é o que o Hamura consegue me enviar pelo celular'
    )
})

test('o nome do arquivo privado é o mesmo dos dois lados (Kotlin e JavaScript)', () => {
    const kotlin = lerKotlin().match(/ARQUIVO_PRIVADO\s*=\s*"([^"]+)"/)?.[1]
    const relatorio = readFileSync(RELATORIO, 'utf8')
    assert.ok(kotlin, 'o Kotlin precisa declarar o nome do arquivo privado')
    assert.ok(
        relatorio.includes(`diagnostico-nativo.txt`) || relatorio.includes('diagnostico-nativo'),
        `o relatório precisa continuar lendo "${kotlin}": se um lado mudar o nome e o outro não, o relatório fica vazio em silêncio`
    )
})

test('a gravação em Downloads usa o caminho permitido no Android atual', () => {
    const fonte = lerKotlin()
    assert.match(
        fonte,
        /MediaStore\.Downloads\.EXTERNAL_CONTENT_URI/,
        'no Android 10+ a gravação em Downloads passa pela MediaStore (sem permissão especial)'
    )
    assert.match(
        fonte,
        /Build\.VERSION\.SDK_INT\s*>=\s*Build\.VERSION_CODES\.Q/,
        'a escolha do caminho tem de ser decidida pela versão do Android em execução'
    )
    assert.match(
        fonte,
        /Environment\.getExternalStoragePublicDirectory/,
        'versões antigas tentam o caminho direto (com falha tolerada)'
    )
})

test('registrar nunca substitui o comportamento do Android (a falha continua sendo falha)', () => {
    const fonte = lerKotlin()
    assert.match(
        fonte,
        /getDefaultUncaughtExceptionHandler/,
        'o tratador anterior precisa ser guardado'
    )
    assert.match(
        fonte,
        /anterior\?\.uncaughtException\(linha,\s*falha\)/,
        'o tratador anterior precisa ser chamado no fim: registrar não é engolir'
    )
    assert.match(
        fonte,
        /catch\s*\(_\s*:\s*Throwable\)/,
        'falha ao gravar não pode gerar um segundo problema'
    )
})

test('morte sem exceção Java é lida do histórico do Android', () => {
    const fonte = lerKotlin()
    assert.match(
        fonte,
        /getHistoricalProcessExitReasons\(app\.packageName, 0, 10\)/,
        'falha nativa, travamento e memória não geram exceção: só o histórico do Android sabe'
    )
    assert.match(fonte, /REASON_CRASH_NATIVE/, 'falha nativa precisa ser reconhecida como anormal')
    assert.match(fonte, /REASON_ANR/, 'travamento (ANR) precisa ser reconhecido como anormal')
    assert.match(fonte, /traceInputStream/, 'o rastro da falha nativa precisa ser lido')
    assert.match(
        fonte,
        /Build\.VERSION\.SDK_INT\s*<\s*Build\.VERSION_CODES\.R/,
        'o histórico só existe do Android 11 em diante: a checagem tem de estar lá'
    )
    assert.match(
        fonte,
        /jaRegistrado|marcarRegistrado/,
        'a mesma morte não pode ser reportada em toda abertura para sempre'
    )
})

test('o registro identifica versão e aparelho', () => {
    const fonte = lerKotlin()
    assert.match(
        fonte,
        /BuildConfig\.VERSION_NAME/,
        'sem versão, o registro não serve para corrigir'
    )
    assert.match(fonte, /Build\.MODEL/, 'sem aparelho, o registro não serve para corrigir')
    assert.match(fonte, /Date\(\)/, 'sem horário, não se sabe se é a falha de agora')
})

test('a captura é instalada ANTES de o React Native carregar', () => {
    const fonte = readFileSync(MAIN, 'utf8')
    const posicaoCaptura = fonte.indexOf('CapturaDeFalha.instalar(this)')
    const posicaoCarga = fonte.indexOf('loadReactNative(this)')
    assert.ok(posicaoCaptura > -1, 'o MainApplication precisa instalar a captura')
    assert.ok(posicaoCarga > -1, 'o MainApplication precisa carregar o React Native')
    assert.ok(
        posicaoCaptura < posicaoCarga,
        'a captura precisa vir antes: depois de loadReactNative já pode ser tarde demais'
    )
    // A consulta às mortes anteriores NÃO acontece mais aqui: ela foi para dentro
    // de `instalar()`, que roda no `attachBaseContext` — antes deste arquivo. É a
    // correção do §BD: os dois coletores (trilha e histórico) escreviam o mesmo
    // arquivo em threads separadas, e um apagava o outro.
    assert.ok(
        !fonte.includes('registrarSaidasAnteriores'),
        'o segundo coletor não pode voltar ao MainApplication'
    )
    const kotlin = lerKotlin()
    const instalar = kotlin.slice(
        kotlin.indexOf('fun instalar('),
        kotlin.indexOf('fun instalar(') + 1600
    )
    assert.match(
        instalar,
        /colherAberturaAnterior\(app\)/,
        'a colheita (motivo + trilha) precisa ser disparada na instalação'
    )
})

test('o relatório em JavaScript diz onde o arquivo está e como enviá-lo', () => {
    const relatorio = readFileSync(RELATORIO, 'utf8')
    assert.match(
        relatorio,
        /lunaria-ultimo-erro\.txt/,
        'o relatório precisa dizer o nome do arquivo que está em Downloads'
    )
    assert.match(relatorio, /Downloads/, 'e precisa dizer a pasta, senão o usuário não encontra')
})

/**
 * Trilha de abertura: responde "até onde ele chegou?" quando não há exceção nenhuma.
 *
 * Falha nativa (violação de memória em biblioteca), morte por sinal e falta de
 * memória **não** geram exceção Java — o tratador de erros nunca roda e não há o
 * que registrar. A trilha resolve isso por outro caminho: cada etapa do arranque
 * deixa uma linha com horário, e a última linha escrita diz onde parou.
 */
test('a trilha é instalada no ponto mais cedo possível (attachBaseContext)', () => {
    const fonte = readFileSync(MAIN, 'utf8')
    const iAttach = fonte.indexOf('override fun attachBaseContext')
    const iInstalar = fonte.indexOf('CapturaDeFalha.instalar(this)')
    const iOnCreate = fonte.indexOf('override fun onCreate')

    assert.ok(iAttach > -1, 'o MainApplication precisa ter attachBaseContext')
    assert.ok(iInstalar > -1, 'a captura precisa ser instalada')
    assert.ok(
        iAttach < iInstalar && iInstalar < iOnCreate,
        'instalar precisa estar DENTRO de attachBaseContext: em onCreate já pode ser tarde demais'
    )
    assert.equal(
        fonte.split('CapturaDeFalha.instalar(this)').length - 1,
        1,
        'instalar é idempotente, mas chamar duas vezes confunde quem lê: uma vez só'
    )
})

test('as cinco etapas do arranque são marcadas', () => {
    const main = readFileSync(MAIN, 'utf8')
    const activity = readFileSync(
        path.join(RAIZ, 'android/app/src/main/java/br/aurora/luna/lunaria/next/MainActivity.kt'),
        'utf8'
    )
    const captura = lerKotlin()

    // 1/5 nasce dentro da própria captura, ao instalar
    assert.match(captura, /marcarEtapa\(app, "1\/5 captura de falha instalada"\)/)
    // 2/5 e 3/5 no Application
    assert.match(main, /"2\/5 aplicativo criado"/)
    assert.match(main, /"3\/5 React Native carregado"/)
    // 4/5 e 5/5 na tela
    assert.match(activity, /"4\/5 tela principal criada"/)
    assert.match(activity, /concluirAbertura\(application\)/)
    assert.match(captura, /"5\/5 \$MARCA_FINAL"/)
})

test('a marca final é gravada quando a tela chega à frente (onResume)', () => {
    const activity = readFileSync(
        path.join(RAIZ, 'android/app/src/main/java/br/aurora/luna/lunaria/next/MainActivity.kt'),
        'utf8'
    )
    const iResume = activity.indexOf('override fun onResume()')
    assert.ok(iResume > -1, 'a marca final precisa vir do ciclo de vida da tela')
    const trecho = activity.slice(iResume, iResume + 220)
    assert.match(
        trecho,
        /super\.onResume\(\)/,
        'onResume precisa chamar a implementação do sistema'
    )
    assert.match(trecho, /concluirAbertura\(application\)/)
})

test('concluir a abertura acontece uma vez por processo', () => {
    const fonte = lerKotlin()
    const trecho = fonte.slice(
        fonte.indexOf('fun concluirAbertura'),
        fonte.indexOf('fun concluirAbertura') + 400
    )
    assert.match(
        trecho,
        /if \(concluida\) return/,
        'sem isso, toda volta ao primeiro plano reescreveria a trilha'
    )
    assert.match(fonte, /private var concluida = false/)
})

test('a abertura que não termina é promovida com o ponto onde parou', () => {
    const fonte = lerKotlin()
    assert.match(
        fonte,
        /A ABERTURA ANTERIOR NÃO CHEGOU AO FIM/,
        'é o texto que o Hamura vai ler no arquivo de Downloads'
    )
    assert.match(fonte, /onde parou: \$ultima/, 'precisa dizer a última etapa registrada')
    assert.match(
        fonte,
        /endsWith\(MARCA_FINAL\)\) return null/,
        'abertura que terminou normalmente NÃO pode virar alarme — seria alarme falso todo dia'
    )
})

test('a trilha é colhida e limpa numa passagem só (senão apaga a abertura atual)', () => {
    const fonte = lerKotlin()
    const trecho = fonte.slice(
        fonte.indexOf('fun colherTrilhaAnterior'),
        fonte.indexOf('fun colherTrilhaAnterior') + 1200
    )
    assert.match(trecho, /arquivo\.readLines\(\)/, 'precisa ler')
    assert.match(trecho, /arquivo\.writeText\(""\)/, 'precisa limpar para a abertura atual')
    const iLeitura = trecho.indexOf('readLines()')
    const iLimpeza = trecho.indexOf('writeText("")')
    assert.ok(
        iLeitura < iLimpeza,
        'ler ANTES de limpar: se limpar primeiro, a prova da abertura anterior some'
    )
})

test('a trilha tem teto de linhas', () => {
    const fonte = lerKotlin()
    assert.match(fonte, /LIMITE_TRILHA = \d+/, 'trilha sem teto é vazamento de memória do usuário')
    assert.match(fonte, /takeLast\(LIMITE_TRILHA\)/, 'o teto precisa ser aplicado ao gravar')
})

test('cada linha da trilha tem horário', () => {
    const fonte = lerKotlin()
    assert.match(fonte, /SimpleDateFormat\(/, 'sem horário a trilha não diz quando')
    assert.match(fonte, /\$\{agora\(\)\}/, 'a marca da etapa precisa usar o horário')
})

test('o relatório da abertura anterior sai do aparelho', () => {
    const fonte = lerKotlin()
    const inicio = fonte.indexOf('fun colherAberturaAnterior')
    assert.notEqual(inicio, -1, 'a colheita da abertura anterior precisa existir')
    const trecho = fonte.slice(inicio, inicio + 1200)
    assert.match(
        trecho,
        /publicar\(app, conteudo\)/,
        'o relatório tem de ser publicado (privado + público) por um caminho único'
    )
})

/**
 * O defeito que estes testes travam (§BD): duas threads — a colheita da abertura
 * anterior e o tratador de exceção não tratada — gravavam o MESMO arquivo em
 * Downloads. Como a gravação trunca o arquivo, quem escrevia por último apagava o
 * outro: o Hamura podia receber o motivo sem a trilha, ou a trilha sem o motivo,
 * justamente no caso em que a evidência importa.
 */
test('só existe UM caminho que grava o relatório público', () => {
    const fonte = lerKotlin()
    const ocorrencias = fonte.match(/gravarPublico\(app, ARQUIVO_PUBLICO/g) ?? []
    assert.equal(
        ocorrencias.length,
        1,
        'cada chamada extra de gravarPublico é um escritor a mais apagando o arquivo'
    )
    const trecho = fonte.slice(
        fonte.indexOf('private fun publicar'),
        fonte.indexOf('private fun publicar') + 700
    )
    assert.match(
        trecho,
        /gravarPublico\(app, ARQUIVO_PUBLICO, conteudo\)/,
        'a gravação única pertence a `publicar`'
    )
})

test('publicar junta as seções em vez de sobrescrever', () => {
    const fonte = lerKotlin()
    assert.match(
        fonte,
        /private val secoes = mutableListOf<String>\(\)/,
        'sem registro de seções não há junção'
    )
    const trecho = fonte.slice(
        fonte.indexOf('private fun publicar'),
        fonte.indexOf('private fun publicar') + 700
    )
    assert.match(trecho, /secoes\.add\(secao\)/, 'a seção precisa ser guardada')
    assert.match(
        trecho,
        /secoes\.joinToString/,
        'o arquivo tem de ser reescrito com TODAS as seções publicadas'
    )
    // A trava fica ANTES da função, então a busca é no arquivo todo.
    assert.match(
        fonte,
        /@Synchronized\s+private fun publicar/,
        'duas threads publicando ao mesmo tempo precisam de trava'
    )
})

test('os dois produtores de evidência passam por publicar', () => {
    const fonte = lerKotlin()
    // 1) tratador de exceção não tratada
    const erro = fonte.slice(
        fonte.indexOf('setDefaultUncaughtExceptionHandler'),
        fonte.indexOf('setDefaultUncaughtExceptionHandler') + 900
    )
    assert.match(erro, /publicar\(app, conteudo\)/, 'a exceção precisa publicar, não gravar direto')
    // 2) colheita da abertura anterior
    const colheita = fonte.slice(fonte.indexOf('fun colherAberturaAnterior'))
    assert.match(
        colheita.slice(0, 1200),
        /publicar\(app, conteudo\)/,
        'a colheita precisa publicar'
    )
})

test('a colheita da abertura anterior acontece uma vez, e não duas', () => {
    const fonte = lerKotlin()
    assert.match(fonte, /colherAberturaAnterior\(app\)/, 'a colheita precisa ser disparada')
    const aplicacao = readFileSync(MAIN, 'utf8')
    assert.ok(
        !aplicacao.includes('registrarSaidasAnteriores'),
        'o antigo segundo coletor não pode voltar: era ele que criava a corrida'
    )
    assert.equal(
        (fonte.match(/Thread\s*\{/g) ?? []).length <= 4,
        true,
        'threads demais neste arquivo é sinal de gravação concorrente'
    )
})

test('a colheita recusa saída já registrada e não repete relatório', () => {
    const fonte = lerKotlin()
    assert.match(fonte, /if \(jaRegistrado\(app, anormal\.timestamp\)\) return null/)
    assert.match(fonte, /marcarRegistrado\(app, anormal\.timestamp\)/)
})
