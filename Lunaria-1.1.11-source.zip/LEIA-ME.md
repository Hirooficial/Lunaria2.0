# Entrega — Lunaria 1.1.11 (19/09/2026)

> **Rodada atual (1.1.11) — um defeito meu, achado antes de você testar.**
> Duas partes do relatório de falha — o **motivo** (do histórico do Android) e a
> **trilha** (até onde o arranque chegou) — eram gravadas por processos separados no
> **mesmo** arquivo, cada um apagando o que o outro tinha escrito. Você podia me
> mandar metade da evidência sem saber.
>
> Agora é **uma gravação só**: o arquivo chega com o motivo e, em seguida, a trilha
> etapa por etapa, sob o cabeçalho `RELATÓRIO DA ABERTURA ANTERIOR`.
>
> Seis testes prendem esse arranjo (um deles exige que exista **exatamente um**
> ponto de gravação no código nativo). Um teste antigo falhou ao aplicar a mudança —
> e está registrado como resultado: ele prendia a fiação velha, e foi reescrito.
>
> **Ressalva honesta**: continua **não provado** que o aplicativo abre no seu aparelho
> — isso depende do teste no A05s (itens 18 a 25 do `CHECKLIST_APARELHO.md`).
>
> **E uma correção de escopo, sem maquiagem**: as **imagens** são cifradas
> (cofre `.lunaenc`), mas o **texto das conversas e a memória de pesquisa ficam em
> claro** no disco — protegidos pelo cofre de arquivos do Android, pela pasta privada
> e pela porta de bloqueio, mas **não** pela Lunaria. A documentação dizia "criptografia
> real de conversas, memória e imagens"; estava a mais, e foi corrigida (`BUGS_FOUND.md`
> §BE, e o escopo completo em `GERACAO_DE_IMAGEM_E_BLOQUEIO.md`, seção 5).
>
> Cifrar esse texto é a **próxima etapa**, e ela tem um motivo conhecido para esperar:
> a busca de mensagens é feita em SQL sobre o próprio texto, e cifrar a coluna sem
> refazer a busca quebraria a busca **em silêncio**. Além disso, a mudança não é
> verificável neste ambiente, e uma camada nova de dados no meio do diagnóstico do
> fechamento tornaria impossível saber qual das duas coisas falhou. A pendência está
> registrada **no próprio conjunto de testes** (aparece como `skipped` em toda
> execução): `tests/privatefiles.test.mjs`.

Versão nova: **geração de imagem** e **bloqueio por senha/PIN**, mantendo tudo o
que já funcionava na 1.0.0 (conversa, personalidade editável em pt-BR, tratamento
masculino ao Hamura, GGUF local, API remota, ditado, leitura em voz alta,
Pesquisa/Fatos e memória opcional).

| Arquivo | O que é |
| --- | --- |
| `Lunaria-1.1.11-arm64-release.apk` | **É este que você instala.** Versão 1.1.11 (código 13), arm64, assinado com a mesma chave de sempre — atualiza por cima da 1.0.0/1.1.x sem desinstalar. Sai com o R8 desligado de propósito (fica maior, e é o que permite o relatório de diagnóstico vir à tela em vez de silêncio) |
| `Lunaria-1.1.11-source.zip` | Código-fonte desta versão (sem **nenhum** keystore, sem senha, sem chave) |
| `Lunaria-1.0.0-source.zip` | Fonte da 1.0.0, guardada para recompilar a base se for preciso |
| `CORRECOES.md` | O que mudou em cada rodada, com a prova de cada correção |
| `exemplo_horde.webp` / `exemplo_pollinations.jpg` / `exemplo_horde_429_recuperado.webp` | Três imagens geradas de verdade hoje (exemplos de teste, não fazem parte do app). A terceira foi gerada **durante** um bloqueio de consultas do provedor — e terminou bem |
| `TEST_REPORT.md` | **Relatório de testes**, separando o que foi executado aqui (lógica e renderização), o que não pôde ser (emulador, com o motivo técnico) e o que depende do seu aparelho |
| `BUGS_FOUND.md` | Todos os defeitos, um por um, com a prova — inclusive a hipótese que eu perseguia e que se provou **errada** (§AM) |
| `STATUS.md` | Estado da entrega por rodada; a rodada atual está no fim do arquivo, com um atalho no topo |
| `RELATORIO_DE_TESTES.md` | Relatório das rodadas anteriores (histórico) |
| `INSTALACAO_E_CONFIGURACAO.md` | Passo a passo de instalação, provedor de imagem e ajustes |
| `GERACAO_DE_IMAGEM_E_BLOQUEIO.md` | Como as duas funções novas funcionam, por dentro |
| `CHECKLIST_APARELHO.md` | **Comece por aqui depois de instalar**: as 24 verificações que só o aparelho responde, na ordem. Se tiver pouco tempo, os itens **18, 19, 23 e 24** são os do defeito relatado |
| `MATRIZ_DE_CRITERIOS.md` | Cada pedido do encargo → onde está no código → o que já foi testado → o que falta |
| `SHA256.txt` | Conferência de integridade dos dois arquivos principais |

Se você quiser compilar em modo de **depuração** a partir do ZIP, o Android exige
um keystore de depuração. Ele não vai no pacote (nenhum keystore vai), e recriar é
uma linha:

```bash
keytool -genkeypair -v -keystore android/app/debug.keystore -storepass android \
  -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=Android Debug,O=Android,C=US"
```

Fora desta pasta: `lunaria-assinatura/` com o keystore e a senha (**nunca
publicar**) e `lunaria-src/lunaria-next/` com o projeto completo.

O APK da 1.0.0 **saiu desta pasta** de propósito: o workspace desta máquina tem
limite de ~128 MB e estava com 152 MB — foi isso que fez os arquivos grandes
sumirem duas vezes (relatado em `BUGS_FOUND.md`, seção L). A fonte da 1.0.0
continua aqui (`Lunaria-1.0.0-source.zip`), então ela pode ser recompilada a
qualquer momento com o mesmo keystore, e a atualização para a 1.1.2 continua
funcionando por cima do que já está instalado no aparelho.

## Leia isto antes de instalar

**Este APK é uma recompilação.** O workspace desta máquina foi revertido **duas
vezes** no limite dos turnos. Na primeira, perdi o código da rodada 2 e refiz
tudo. Na segunda, perdi o APK que já estava pronto — mas o ZIP do código
sobreviveu, e foi dele que restaurei a árvore (388 arquivos, todos conferidos
contra o `CHECKSUMS` do próprio pacote). O registro completo, sem maquiagem, está
em `BUGS_FOUND.md` (seções C e G–K).

O que continua igual, e é o que importa para atualizar: o **keystore** e,
portanto, a assinatura — `CN=Lunaria`, digest SHA-256
`c0271509…5719a`, o mesmo da 1.0.0. A instalação por cima funciona sem
desinstalar nem apagar dados.

Todos os números abaixo foram medidos **nesta** compilação. Não reaproveitei
nenhuma medição antiga.

## Estado real, sem enfeite

**Medido nesta máquina (x86_64, 2 núcleos, 1,9 GB de RAM, 25 GB de disco):**

- **Compila**: `:app:assembleRelease` para arm64-v8a terminou com
  **BUILD SUCCESSFUL in 3m 17s** (929 tarefas: 120 executadas, 809
  reaproveitadas). Foram **sete** tentativas até aqui — memória (o daemon do
  Kotlin herdava 2,5 GB e o kernel matou o build), um NDK que eu apaguei por
  engano e o disco enchendo. Cada falha está descrita em `BUGS_FOUND.md`.
- **Assinado**: `apksigner verify` OK, mesmo certificado da 1.0.0. O APK **não**
foi recompilado depois (as mudanças seguintes são só testes e ferramentas de
desenvolvimento); o arquivo é byte a byte o mesmo que foi verificado —
SHA-256 `da020f60…acc3`, conforme `SHA256.txt`.
- **Tamanho**: 60.466.266 bytes (57,7 MiB). SHA-256 em `SHA256.txt`.
- **Testes de lógica**: **87 de 87** (`npm run test:unit`), `tsc --noEmit` sem
  erros, ESLint com 0 erros.
- **Testes de renderização** (adicionados depois do APK): **49 de 49**
  (`npm run test:render`) — executam de verdade o portão de bloqueio, a tela de
  desbloqueio, o ciclo completo de senha com o código real (Crypto, SecureVault
  e AppLock), o cofre de arquivos, a tela de conversa com o botão **Gerar
  imagem** e as telas novas. É o que permite afirmar, por execução e não por
  leitura de código, que nada do aplicativo é montado enquanto está bloqueado.
- **APK conferido por dentro**: `READ_MEDIA_IMAGES`, `allowBackup=false`,
  `fullBackupContent=false` e `dataExtractionRules` no manifesto; 48 bibliotecas
  `.so` arm64; `res/RT.gguf` (7,8 MB) e o bundle Hermes com as telas de geração
  de imagem e de bloqueio, o cofre `private://`/`.lunaenc`, a política de
  conteúdo e a âncora de idade adulta; `ScreenCapture`, `SecureStore`,
  `MediaLibrary` e `LocalAuthentication` presentes no dex.
- **Provedor de imagem**: chamadas reais à AI Horde (WebP em ~25 s, com fila) e à
  Pollinations (~2 s, sem chave) durante o desenvolvimento. Os limites reais e os
  ajustes estão em `INSTALACAO_E_CONFIGURACAO.md` e escritos dentro do próprio
  aplicativo, na tela de ajustes de imagem.

**Duas mudanças em `android/gradle.properties`** ficaram por causa do ambiente de
compilação — nenhuma altera o comportamento do aplicativo:
`android.enableR8.fullMode=false` (R8 em modo de compatibilidade, com shrinking e
ofuscação mantidos) e `kotlin.daemon.jvmargs` com teto de 1 GB (só compilação).
As duas estão comentadas no arquivo, com o motivo.

**Sobre as ferramentas deste ambiente**: `/opt` (JDK e SDK Android) não sobrevive
entre as sessões. Se for preciso recompilar, `bash lunaria-build/setup-toolchain.sh`
reinstala tudo e `lunaria-build/build-apk-2.sh` já traz no cabeçalho os quatro
requisitos aprendidos (memória, disco, os dois NDKs e o R8 em modo de
compatibilidade). O keystore e a senha estão em `lunaria-assinatura/`.

**Não testado no aparelho** — este ambiente não tem aparelho, nem emulador, nem
`/dev/kvm`, e o APK é arm64. Ficam pendentes e **não** são apresentados como
validados: instalação real, geração de imagem no aparelho, cancelamento, queda de
rede, cota esgotada, salvar/compartilhar/apagar imagem, senha errada, reinício,
volta do segundo plano, abertura por notificação, biometria, troca de senha,
migração dos dados existentes e a conferência de que nada protegido aparece antes
do desbloqueio. A lista item por item está em `RELATORIO_DE_TESTES.md`.

O que dá para afirmar com segurança: o APK instala em Android 7 ou superior
(arm64), atualiza por cima da 1.0.0 e as funções novas estão dentro dele.
O que só o seu aparelho pode responder: se o comportamento é o esperado na
prática.
