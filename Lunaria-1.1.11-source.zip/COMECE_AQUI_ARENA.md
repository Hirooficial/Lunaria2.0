# Continuar a Lunaria

Pacote de continuidade preparado em 15/09/2026, a pedido do usuário. Contém o
código atual e as pendências para outro ambiente continuar o desenvolvimento.
**Não contém APK novo nem uma versão validada no celular.**

## Pedido para colar no Arena

```text
Continue a Lunaria a partir deste projeto. Primeiro leia COMECE_AQUI_ARENA.md,
STATUS.md, BUGS_FOUND.md, TEST_REPORT.md e BUILDING.md. Preserve a base ChatterUI,
a identidade Lunaria, a personalidade editável, Pesquisa/Fatos com fontes,
a memória de pesquisa, o ditado e a leitura em voz alta em português, e as
opções de IA remota e GGUF local. Use o código existente como ponto de partida.

Conclua a compilação Android arm64, corrija os erros que conseguir reproduzir
e teste instalação, conversa, cancelamento, acentos/emoji, voz e pesquisa.
Informe exatamente quais testes passaram e quais dependem do meu celular.
Não use um APK antigo como se fosse o resultado deste código. Ao finalizar,
entregue APK assinado, ZIP atualizado do código e relatório de validação.
Se seu ambiente não puder compilar ou executar Android, explique o bloqueio
e entregue as alterações com comandos reproduzíveis, sem alegar que testou.
Não publique chaves, senhas ou conversas privadas.
```

Anexe o ZIP junto com esse pedido. Se o ambiente não aceitar ZIP, extraia a
pasta `lunaria-next` e envie os arquivos que ele conseguir ler, começando por
este documento. Os comandos de compilação exigem um ambiente de desenvolvimento
Android; um chat sem terminal não consegue executá-los apenas lendo o código.

## O que há no pacote

- Projeto Expo/React Native com código, recursos, configurações e lockfile.
- Correções de transmissão de texto, cancelamento e processamento de respostas.
- Pesquisa/Fatos com links, comparação de trechos e memória opcional.
- Reconhecimento de voz em pt-BR e leitura pelo mecanismo do Android.
- IA remota via AI Horde e suporte a GGUF local.
- Testes automatizados, documentação e workflow manual de build Android.

Não há modelo de conversação incluído. O arquivo GGUF em `assets/models` é
um recurso do tokenizador; não serve como modelo de chat. Dependências, SDK,
caches, chaves privadas e APKs antigos não fazem parte deste ZIP.

## Ordem de trabalho

1. Instalar as dependências com `npm ci` e repetir as verificações abaixo.
2. Gerar o projeto Android e concluir `assembleRelease`.
3. Conferir pacote, arquitetura, bibliotecas nativas e assinatura do APK.
4. Executar a lista de testes Android de `TEST_REPORT.md` e registrar resultados.
5. Atualizar a documentação e entregar os artefatos com suas limitações reais.

### Verificações do código

Na pasta `lunaria-next`, com Node.js 22, npm e Java 17:

```bash
npm ci
npm run test:unit
npx tsc --noEmit
npx eslint app db lib --ignore-pattern db/migrations --max-warnings=0
```

### Compilação Android

Preparar Android SDK 36, build-tools 36.0.0, NDK 27.1.12297006 e CMake 3.22.1.
O Gradle também solicitou NDK 27.0.12077973 para uma dependência Expo na última
tentativa; permitir sua instalação se necessário. Configurar `JAVA_HOME` para
Java 17 e o caminho do SDK no ambiente local.

```bash
CI=1 NODE_ENV=production npx expo prebuild --platform android --no-install
cd android
chmod +x gradlew
NODE_ENV=production ./gradlew :app:assembleRelease -PreactNativeArchitectures=arm64-v8a --no-daemon --max-workers=2
```

Saída esperada, apenas se o build terminar com sucesso:
`android/app/build/outputs/apk/release/`.

Se reaparecer o erro de cache Kotlin/Gradle descrito em `BUGS_FOUND.md`, tentar:

```bash
NODE_ENV=production ./gradlew :app:assembleRelease -PreactNativeArchitectures=arm64-v8a -Pkotlin.incremental=false --no-parallel --no-build-cache --no-daemon --max-workers=1 --stacktrace
```

A tentativa com esses parâmetros avançou além do erro anterior, mas não chegou
ao fim. Não é uma comprovação de que o build completo funciona.

O template Expo usa assinatura de depuração por padrão. Antes da distribuição,
configurar uma chave persistente do usuário e verificar a assinatura final.
Uma chave privada foi criada separadamente durante o trabalho anterior, mas
não foi usada para assinar um APK concluído e não está neste pacote. Nunca
enviar essa chave para repositórios públicos. Ver `BUILDING.md`.

## Identidade e instalação

- Nome do app: **Lunaria**; versão do projeto: **1.0.0**.
- Pacote Android: `br.aurora.luna.lunaria.next`.
- Base: ChatterUI, licença AGPL-3.0; preservar créditos e licença.
- Este pacote instala separadamente das versões antigas. Não há migração
  automática de conversas nem dos modelos importados.
- Não orientar a apagar dados ou desinstalar a versão antiga como primeira
  tentativa de solução; registrar o erro real de instalação.

O workflow `.github/workflows/build.yml` está incluído no código, mas sua
execução no GitHub não foi validada. Ele precisa estar na raiz de um repositório
com o restante do projeto para funcionar; enviar apenas o ZIP ao GitHub não
executa esse workflow.
