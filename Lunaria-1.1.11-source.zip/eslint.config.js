const { defineConfig } = require('eslint/config')
const expoConfig = require('eslint-config-expo/flat')
const internalPlugin = require('eslint-plugin-internal')
const eslintPluginPrettierRecommended = require('eslint-plugin-prettier/recommended')
const reactCompilerPlugin = require('eslint-plugin-react-compiler')

module.exports = defineConfig([
    expoConfig,
    eslintPluginPrettierRecommended,
    {
        ignores: ['dist/*'],
    },

    {
        files: ['**/*.{js,jsx,ts,tsx,d.ts}'],
        languageOptions: {
            parserOptions: {
                project: './tsconfig.json',
            },
        },
        plugins: {
            'react-compiler': reactCompilerPlugin,
            internal: internalPlugin,
        },
        rules: {
            'react-compiler/react-compiler': 'error',
            'prettier/prettier': [
                'warn',
                {
                    usePrettierrc: true,
                },
            ],
            radix: 'off',
            '@typescript-eslint/no-require-imports': 'off',
            'object-shorthand': ['warn', 'consistent'],
            'import/order': [
                'warn',
                {
                    alphabetize: { order: 'asc', caseInsensitive: true },
                    groups: [['builtin', 'external'], ['internal'], ['parent', 'sibling', 'index']],
                    'newlines-between': 'always',
                },
            ],
        },
    },
    // Arquivos de teste: rodam no jest (node), não no aplicativo. Por isso os
    // globais do jest e do node entram aqui, e as regras de JSX/React não fazem
    // sentido nos shims de módulos nativos (tests/render/mocks/*).
    {
        files: ['tests/**/*.{js,jsx,ts,tsx}', 'tools/**/*.mjs', 'jest.setup.js'],
        languageOptions: {
            globals: {
                jest: 'readonly',
                describe: 'readonly',
                it: 'readonly',
                test: 'readonly',
                expect: 'readonly',
                beforeEach: 'readonly',
                afterEach: 'readonly',
                beforeAll: 'readonly',
                afterAll: 'readonly',
                Buffer: 'readonly',
                require: 'readonly',
                module: 'writable',
                __dirname: 'readonly',
                global: 'readonly',
            },
        },
        rules: {
            // import/first desligado: nos testes, os jest.mock precisam vir ANTES
            // dos imports que eles substituem. Em 18/09 a formatação automática
            // subiu os imports, a suíte de telas passou a carregar os módulos de
            // verdade e quebrou (useInference.subscribe indefinido).
            'import/first': 'off',
            // import/order também fica desligado aqui: em 18/09 a ordenação
            // alfabética pôs ImageViewer antes das telas, a cadeia de imports
            // carregou lib/state/TTS antes do mock de useInference e a suíte
            // quebrou com "Cannot read properties of undefined (reading 'subscribe')".
            'import/order': 'off',
            'react/display-name': 'off',
            'react-compiler/react-compiler': 'off',
            'no-undef': 'off',
        },
    },
])
