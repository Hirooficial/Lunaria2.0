# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in /usr/local/Cellar/android-sdk/24.3.3/tools/proguard/proguard-android.txt
# You can edit the include path and order by changing the proguardFiles
# directive in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# react-native-reanimated
-keep class com.swmansion.reanimated.** { *; }
-keep class com.facebook.react.turbomodule.** { *; }

# Add any project specific keep options here:

# @generated begin expo-build-properties - expo prebuild (DO NOT MODIFY)
-keep class com.rnllama.** { *; }
# @generated end expo-build-properties

# ---------------------------------------------------------------------------
# Classes que as bibliotecas NATIVAS procuram por nome (JNI / registro de
# módulos). Evidência: `strings` dentro das `.so` do próprio aplicativo mostra
# os nomes, por exemplo `libmmkv.so` → com/tencent/mmkv/MMKV,
# `libNitroModules.so` → com/margelo/nitro/NitroModules e
# `libNitroMmkv.so` → com/margelo/nitro/mmkv/HybridMMKVPlatformContext.
#
# Honestidade sobre o que isto é: a auditoria do APK 1.1.2 (o que fechava)
# mostrou que **estas classes sobreviveram ao R8 na prática** — a hipótese de
# renomeação foi testada e refutada (classe, métodos e manifesto idênticos).
# Estas regras são, portanto, **proteção para builds futuros**, não a correção
# do defeito relatado. Nenhum destes pacotes publica regras próprias de consumo.
# ---------------------------------------------------------------------------
-keep class com.tencent.mmkv.** { *; }
-keep class com.margelo.nitro.** { *; }
-keep class com.swmansion.worklets.** { *; }
-keep class com.swmansion.rnscreens.** { *; }
-keep class com.github.penfeizhou.** { *; }
-keep class org.aomedia.avif.** { *; }
-keep class expo.modules.kotlin.** { *; }
-keep class expo.modules.sqlite.** { *; }
-keep class expo.modules.adapters.** { *; }