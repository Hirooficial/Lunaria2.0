package br.aurora.luna.lunaria.next

import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

/**
 * Ponte mínima: deixa o **JavaScript** gravar na mesma trilha de abertura que o
 * lado nativo já escreve.
 *
 * ## Por que isto existe
 *
 * A trilha nativa responde "até onde o arranque chegou" para o que acontece
 * **antes** do JavaScript: captura instalada (1/5), aplicativo criado (2/5), React
 * Native carregado (3/5), tela criada (4/5), abertura concluída (5/5). O que ela
 * **não** respondia era a parte mais provável de um fechamento silencioso: o meio
 * do caminho, entre "React Native carregado" e "abertura concluída" — banco,
 * cofre, bloqueio, primeira tela. Ali o processo pode morrer sem exceção e a
 * trilha para em 4/5, sem dizer o quê.
 *
 * O JavaScript **já** registra migalhas (`lib/utils/Diagnostics.ts`), mas elas
 * vivem no `react-native-mmkv`, que só pode ser lido por JavaScript — ou seja:
 * para lê-las é preciso que o aplicativo **abra**, que é exatamente o que não
 * acontece quando ele fecha. Ficava um buraco: o arquivo que o Hamura consegue
 * enviar (em Downloads) contava só a metade nativa da história.
 *
 * Com esta ponte, o JavaScript grava na **mesma** trilha (`trilha-abertura.txt`,
 * na pasta privada). Como a colheita da trilha anterior é do lado nativo
 * (`CapturaDeFalha.colherTrilhaAnterior`), a próxima abertura leva **tudo** —
 * etapas nativas e etapas do JavaScript — para `lunaria-ultimo-erro.txt` na pasta
 * Downloads, mesmo que o aplicativo morra de novo.
 *
 * ## Regras que valem para este arquivo
 *
 * 1. **Nunca lança para o JavaScript.** Um `@ReactMethod` que estoura vira erro
 *    no lado JS; este método só chama código que já engole tudo.
 * 2. **Não decide nada.** Ele não filtra etapa, não interpreta texto e não guarda
 *    estado: escreve uma linha e volta.
 * 3. **A falha dele não muda o aplicativo.** Se a ponte não existir no aparelho
 *    (interoperabilidade indisponível), o lado JavaScript simplesmente não grava
 *    — o aplicativo abre do mesmo jeito. Está provado por teste.
 */
class TrilhaJsModule(private val contexto: ReactApplicationContext) :
    ReactContextBaseJavaModule(contexto) {

    /** Nome visto pelo JavaScript: `NativeModules.TrilhaJs`. */
    override fun getName(): String = NOME

    /**
     * Grava uma etapa vinda do JavaScript. O texto chega pronto (o lado JS
     * prefixa com `js `), e passar dos limites de tamanho faz o método ignorar a
     * linha em silêncio — trilha é uma linha curta, não um despejo de texto.
     */
    @ReactMethod
    fun marcarEtapa(etapa: String) {
        CapturaDeFalha.marcarEtapaDeJs(contexto.applicationContext, etapa)
    }

    companion object {
        const val NOME = "TrilhaJs"
    }
}
