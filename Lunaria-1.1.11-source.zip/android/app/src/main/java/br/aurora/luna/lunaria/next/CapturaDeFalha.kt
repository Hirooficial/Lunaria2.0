package br.aurora.luna.lunaria.next

import android.app.ActivityManager
import android.app.Application
import android.app.ApplicationExitInfo
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Captura de falha **antes do JavaScript existir**, e a trilha de abertura.
 *
 * ## Por que isto existe
 *
 * O aplicativo fecha ao abrir no aparelho do Hamura. Cada abertura que termina mal
 * não deixava rastro. O relatório em JavaScript (`lib/utils/Diagnostics.ts`) e o
 * porteiro de entrada (`lib/utils/EntradaSegura.js`) só funcionam **depois** que o
 * motor JavaScript começou. Se a falha acontece antes — biblioteca nativa que não
 * carrega, `.so` incompatível, exceção em `onCreate` — nenhum dos dois existe.
 *
 * Duas defesas ficam aqui:
 *
 *  1. **Registro de falha**: qualquer exceção não tratada vira arquivo antes de o
 *     processo morrer (a pasta privada para o relatório na tela, e a pasta
 *     **Downloads** para o Hamura conseguir enviar sem computador).
 *  2. **Trilha de abertura**: cada etapa do arranque grava uma linha com horário.
 *     Isso responde à pergunta que nenhuma exceção responde: **até onde ele
 *     chegou?** Se o processo morre sem exceção alguma — violação de memória,
 *     morte por sinal, biblioteca incompatível — a última linha da trilha diz
 *     exatamente onde parou.
 *
 * ## Onde o arquivo é gravado (e por que em dois lugares)
 *
 * | arquivo | onde | para quê |
 * | --- | --- | --- |
 * | `diagnostico-nativo.txt` | pasta privada (`filesDir`) | o relatório em JavaScript lê daqui e mostra na tela |
 * | `lunaria-ultimo-erro.txt` | pasta **Downloads** do aparelho | o Hamura abre pelo celular e me envia — **sem computador, sem `adb`** |
 *
 * O registro sair do aparelho é o ponto: antes desta rodada ele ficava só na pasta
 * privada, inalcançável para quem tem apenas o celular (`BUGS_FOUND.md` §AU).
 *
 * ## As mortes que **não** passam por tratador de exceção
 *
 * Falha nativa de verdade (violação de memória em biblioteca), travamento e morte
 * por memória **não** geram exceção Java: o sistema mata o processo e o tratador
 * nunca roda. Para esses casos há duas fontes: o histórico de saídas do Android
 * (`ApplicationExitInfo`, Android 11+) e a **trilha de abertura**, que mostra até
 * onde aquele arranque chegou.
 */
object CapturaDeFalha {

    private const val ARQUIVO_PRIVADO = "diagnostico-nativo.txt"
    private const val ARQUIVO_PUBLICO = "lunaria-ultimo-erro.txt"
    private const val TRILHA = "trilha-abertura.txt"

    /** Última linha da trilha quando a abertura chega ao fim. */
    private const val MARCA_FINAL = "ABERTURA CONCLUÍDA"

    /** Teto de linhas da trilha: memória do aparelho não é lugar de log infinito. */
    private const val LIMITE_TRILHA = 120

    /** Teto do tamanho de uma etapa vinda do JavaScript. */
    private const val LIMITE_ETAPA_JS = 200

    @Volatile
    private var instalado = false

    @Volatile
    private var concluida = false

    /**
     * Seções já publicadas **nesta abertura**.
     *
     * Por que existe: dois momentos diferentes escrevem no mesmo arquivo em
     * Downloads — a colheita da abertura anterior (no `attachBaseContext`) e o
     * tratador de exceção não tratada (quando o processo está morrendo). Cada
     * gravação abre o arquivo em modo "escrever do começo", então a última apaga
     * a anterior. Guardando as seções aqui, a última gravação **contém todas** —
     * e a ordem de chegada deixa de importar. Ver `BUGS_FOUND.md` §BD.
     */
    private val secoes = mutableListOf<String>()

    /**
     * Instala o tratador e começa a trilha. **Idempotente**: pode ser chamada de
     * `attachBaseContext` (o ponto mais cedo que existe em Java) e de `onCreate`
     * sem envolver o tratador duas vezes.
     */
    fun instalar(app: Application) {
        if (instalado) return
        synchronized(this) {
            if (instalado) return
            instalado = true

            val anterior = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { linha, falha ->
                try {
                    val rastro = StringWriter()
                    falha.printStackTrace(PrintWriter(rastro))
                    // Sem `cabecalho` aqui: quem publica já põe o cabeçalho, e a
                    // seção entra no arquivo junto com as outras.
                    val conteudo =
                        "tipo: exceção não tratada (Java/Kotlin)\n" +
                            "linha: ${linha?.name}\n" +
                            "trilha antes da falha: ${ultimaEtapa(app) ?: "?"}\n\n" +
                            rastro.toString()
                    publicar(app, conteudo)
                } catch (_: Throwable) {
                    // Se nem gravar funcionar, o comportamento é o de antes: fecha.
                }
                // O tratador anterior é preservado: registrar não é engolir.
                anterior?.uncaughtException(linha, falha)
            }
        }

        // A abertura ANTERIOR é colhida aqui, numa passagem só — motivo e trilha
        // no MESMO relatório. Ver `colherAberturaAnterior` para o defeito que isso
        // corrige (dois escritores disputando o mesmo arquivo em Downloads).
        colherAberturaAnterior(app)

        marcarEtapa(app, "1/5 captura de falha instalada")
    }

    /**
     * Grava uma linha na trilha de abertura. Chamada em cada etapa do arranque.
     * Nunca lança: diagnóstico não pode ser motivo de problema.
     */
    @Synchronized
    fun marcarEtapa(app: Application, etapa: String) {
        try {
            val arquivo = File(app.filesDir, TRILHA)
            val linhas = if (arquivo.exists()) arquivo.readLines().toMutableList() else mutableListOf()
            linhas.add("${agora()}  $etapa")
            // Mantém o fim da trilha: se a abertura ficar repetindo etapas, não cresce sem fim.
            val recortadas = if (linhas.size > LIMITE_TRILHA) linhas.takeLast(LIMITE_TRILHA) else linhas
            arquivo.writeText(recortadas.joinToString("\n") + "\n")
        } catch (_: Throwable) {
        }
    }

    /**
     * Marca uma etapa vinda do **JavaScript** ([TrilhaJsModule]). Grava na mesma
     * trilha das etapas nativas, de propósito: assim a colheita da abertura
     * anterior (`colherTrilhaAnterior`, que é do lado nativo) leva as duas metades
     * para a pasta Downloads — inclusive quando o aplicativo morre de novo e o
     * Hamura nunca chega a ver tela nenhuma.
     *
     * Cercado por todos os lados: contexto ausente, texto vazio e texto gigante são
     * descartados em silêncio; qualquer falha é engolida. Diagnóstico nunca pode
     * ser a causa de um problema novo.
     */
    fun marcarEtapaDeJs(contexto: Context?, etapa: String?) {
        try {
            if (etapa.isNullOrBlank() || etapa.length > LIMITE_ETAPA_JS) return
            val app = contexto?.applicationContext as? Application ?: return
            marcarEtapa(app, etapa)
        } catch (_: Throwable) {
        }
    }

    /**
     * Marca a abertura como concluída. Chamada quando a tela principal chega à
     * frente (`onResume`) — é o sinal de que o aplicativo **abriu**, não apenas
     * carregou. Uma vez por processo: um aplicativo em uso não fica reescrevendo.
     */
    @Synchronized
    fun concluirAbertura(app: Application) {
        if (concluida) return
        concluida = true
        marcarEtapa(app, "5/5 $MARCA_FINAL")
    }

    /** Última etapa registrada na trilha (para o registro de falha). */
    private fun ultimaEtapa(app: Application): String? =
        try {
            File(app.filesDir, TRILHA).takeIf { it.exists() }?.readLines()?.lastOrNull { it.isNotBlank() }
        } catch (_: Throwable) {
            null
        }

    /**
     * Lê a trilha da abertura anterior e **esvazia o arquivo** para a atual.
     *
     * Devolve o texto a promover quando aquela abertura **não** chegou ao fim (ou
     * seja: o aplicativo morreu em algum ponto do arranque) e `null` quando ela
     * terminou normalmente.
     *
     * A leitura e a limpeza são feitas na mesma passagem, de propósito: se ficassem
     * em passos separados, a linha da abertura atual poderia ser apagada por uma
     * limpeza atrasada — e o diagnóstico sumiria justamente quando é preciso.
     */
    @Synchronized
    private fun colherTrilhaAnterior(app: Application): String? {
        return try {
            val arquivo = File(app.filesDir, TRILHA)
            if (!arquivo.exists()) return null
            val linhas = arquivo.readLines().filter { it.isNotBlank() }
            arquivo.writeText("")
            if (linhas.isEmpty()) return null

            val ultima = linhas.last()
            if (ultima.endsWith(MARCA_FINAL)) return null

            "tipo: A ABERTURA ANTERIOR NÃO CHEGOU AO FIM\n" +
                "onde parou: $ultima\n" +
                "isto costuma significar que o processo foi encerrado no meio do arranque\n" +
                "(falha nativa, memória, ou o sistema matando o aplicativo)\n\n" +
                "--- trilha da abertura anterior, etapa por etapa ---\n" +
                linhas.joinToString("\n") +
                "\n"
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Colhe a evidência da abertura anterior e grava **um** relatório só.
     *
     * ## O defeito que isto corrige (1.1.11)
     *
     * Antes, duas fontes de evidência eram colhidas em **threads separadas** e
     * gravadas no **mesmo arquivo** da pasta Downloads: a trilha da abertura
     * anterior (aqui) e a saída anormal do histórico do Android (em
     * `onCreate`). Como a gravação abre o arquivo em modo "escrever do começo"
     * (truncar), **quem escrevia por último apagava o outro**. Numa abertura
     * depois de uma falha — exatamente o caso em que a evidência importa — o
     * arquivo podia chegar ao Hamura com só metade da história: o motivo, sem a
     * trilha; ou a trilha, sem o motivo.
     *
     * Agora há **um** leitor e **uma** gravação: lê o histórico do Android, colhe a
     * trilha e escreve as duas coisas juntas, na ordem em que se leem — primeiro o
     * motivo (curto, direto), depois a trilha etapa por etapa (o detalhe).
     *
     * Roda em segundo plano porque consultar o histórico é chamada ao sistema e
     * não pode atrasar a abertura.
     */
    fun colherAberturaAnterior(app: Application) {
        Thread {
            try {
                val motivo = lerSaidaAnormal(app)
                val trilha = colherTrilhaAnterior(app)
                if (motivo == null && trilha == null) return@Thread

                val conteudo =
                    "RELATÓRIO DA ABERTURA ANTERIOR\n" +
                        "(as duas metades juntas: o motivo da morte e a trilha de onde ela parou)\n\n" +
                        listOfNotNull(motivo, trilha).joinToString("\n\n")

                // Uma publicação: privado (para a tela de diagnóstico) e público
                // (para o Hamura mandar sem computador) — e contendo também o que
                // já tiver sido publicado nesta abertura.
                publicar(app, conteudo)
            } catch (_: Throwable) {
                // Diagnóstico nunca pode ser motivo de novo problema.
            }
        }.start()
    }

    /**
     * Lê no histórico do Android a última saída **anormal** deste aplicativo.
     * É o único caminho de evidência para morte por falha nativa, que não passa
     * por exceção Java.
     *
     * Devolve o texto do relatório, ou `null` quando não há nada a registrar
     * (aparelho antigo, sem saída anormal, ou a mesma saída já registrada antes).
     * **Não grava nada** — quem grava é [colherAberturaAnterior], uma única vez.
     */
    private fun lerSaidaAnormal(app: Application): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return try {
            val gerente =
                app.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return null
            val saidas = gerente.getHistoricalProcessExitReasons(app.packageName, 0, 10).orEmpty()
            val anormal = saidas.firstOrNull { ehAnormal(it.reason) } ?: return null
            if (jaRegistrado(app, anormal.timestamp)) return null

            val motivo = nomeDoMotivo(anormal.reason)
            val rastro = try {
                anormal.traceInputStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            } catch (_: Throwable) {
                ""
            }
            val texto =
                "tipo: a execução ANTERIOR terminou de forma anormal\n" +
                    "motivo: $motivo (código ${anormal.reason})\n" +
                    "quando: ${Date(anormal.timestamp)}\n" +
                    "descrição: ${anormal.description ?: "-"}\n" +
                    "memória no fim: ${anormal.rss / 1024} MB\n" +
                    "trilha daquela abertura: ${ultimaEtapa(app) ?: "?"}\n\n" +
                    if (rastro.isNotBlank()) rastro else "sem rastro disponível\n"

            marcarRegistrado(app, anormal.timestamp)
            texto
        } catch (_: Throwable) {
            null
        }
    }

    /** Só interessa o que é falha; saída normal (usuário fechou, sistema liberou) não é. */
    private fun ehAnormal(motivo: Int): Boolean = when (motivo) {
        ApplicationExitInfo.REASON_CRASH,
        ApplicationExitInfo.REASON_CRASH_NATIVE,
        ApplicationExitInfo.REASON_ANR,
        ApplicationExitInfo.REASON_INITIALIZATION_FAILURE,
        ApplicationExitInfo.REASON_LOW_MEMORY,
        -> true
        else -> false
    }

    private fun nomeDoMotivo(motivo: Int): String = when (motivo) {
        ApplicationExitInfo.REASON_CRASH -> "exceção (Java/Kotlin)"
        ApplicationExitInfo.REASON_CRASH_NATIVE -> "falha NATIVA (biblioteca)"
        ApplicationExitInfo.REASON_ANR -> "aplicativo não respondeu"
        ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "falha ao inicializar"
        ApplicationExitInfo.REASON_LOW_MEMORY -> "memória insuficiente"
        ApplicationExitInfo.REASON_SIGNALED -> "morto por sinal"
        else -> "motivo $motivo"
    }

    /**
     * Evita repetir o mesmo registro a cada abertura (o histórico do Android guarda
     * os últimos processos, e a mesma morte seria reportada de novo indefinidamente).
     */
    private fun jaRegistrado(app: Application, quando: Long): Boolean =
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(ULTIMO, 0L) == quando

    private fun marcarRegistrado(app: Application, quando: Long) {
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(ULTIMO, quando).apply()
    }

    private fun agora(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())

    private fun cabecalho(app: Application): String =
        "Lunaria — registro de falha (gravado pelo próprio Android, antes do JavaScript)\n" +
            "versão: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\n" +
            "aparelho: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "quando: ${Date()}\n\n"

    /**
     * Publica uma seção do relatório: guarda na memória e regrava o arquivo
     * **completo** (privado e público). Chamar de qualquer thread é seguro.
     *
     * Regra de ouro desta classe: a última gravação sempre contém tudo o que foi
     * publicado antes. Assim, uma corrida entre a colheita da abertura anterior e
     * o tratador de exceção deixa de poder apagar evidência — o pior caso passa a
     * ser "escreveu duas vezes a mesma coisa".
     */
    @Synchronized
    private fun publicar(app: Application, secao: String) {
        try {
            if (!secoes.contains(secao)) secoes.add(secao)
            val conteudo = cabecalho(app) + secoes.joinToString("\n\n")
            gravarPrivado(app, conteudo)
            gravarPublico(app, ARQUIVO_PUBLICO, conteudo)
        } catch (_: Throwable) {
            // Diagnóstico nunca pode ser motivo de novo problema.
        }
    }

    private fun gravarPrivado(app: Application, conteudo: String) {
        try {
            File(app.filesDir, ARQUIVO_PRIVADO).writeText(conteudo)
        } catch (_: Throwable) {
        }
    }

    /**
     * Grava na pasta Downloads. Android 10+ usa `MediaStore` (caminho permitido sem
     * permissão); versões antigas tentam o caminho direto e, se falharem, não mudam
     * nada — o registro privado continua existindo.
     */
    private fun gravarPublico(app: Application, nome: String, conteudo: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val colecao = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val resolvido = app.contentResolver
                val filtro = "${MediaStore.Downloads.DISPLAY_NAME} = ?"
                val existente =
                    resolvido.query(colecao, arrayOf(MediaStore.Downloads._ID), filtro, arrayOf(nome), null)
                val uri = if (existente != null && existente.moveToFirst()) {
                    val id = existente.getLong(0)
                    existente.close()
                    ContentUris.withAppendedId(colecao, id)
                } else {
                    existente?.close()
                    val valores = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, nome)
                        put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    resolvido.insert(colecao, valores)
                } ?: return

                resolvido.openOutputStream(uri, "wt")?.use { it.write(conteudo.toByteArray()) }
                val pronto = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                resolvido.update(uri, pronto, null, null)
            } else {
                @Suppress("DEPRECATION")
                val pasta = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!pasta.exists()) pasta.mkdirs()
                File(pasta, nome).writeText(conteudo)
            }
        } catch (_: Throwable) {
        }
    }

    private const val PREFS = "lunaria.diagnostico"
    private const val ULTIMO = "ultimaSaidaRegistrada"
}
