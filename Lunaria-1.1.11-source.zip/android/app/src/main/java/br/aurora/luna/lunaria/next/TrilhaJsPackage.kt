package br.aurora.luna.lunaria.next

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

/**
 * Pacote que registra a [TrilhaJsModule] no aplicativo.
 *
 * Um pacote é a forma padrão do React Native de expor um módulo nativo para o
 * JavaScript. Ele é adicionado à lista de pacotes em `MainApplication`, dentro de
 * `try/catch`: se por qualquer motivo o registro falhar, o aplicativo continua
 * abrindo — o diagnóstico é acessório, o aplicativo não é.
 *
 * Registro de views: nenhum. Este módulo não desenha nada; ele existe só para
 * receber uma linha de texto e gravar.
 */
class TrilhaJsPackage : ReactPackage {

    override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> =
        listOf(TrilhaJsModule(reactContext))

    override fun createViewManagers(reactContext: ReactApplicationContext): List<ViewManager<*, *>> =
        emptyList()
}
