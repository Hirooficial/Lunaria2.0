package br.aurora.luna.lunaria.next

import android.app.Application
import android.content.res.Configuration

import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactNativeApplicationEntryPoint.loadReactNative
import com.facebook.react.ReactPackage
import com.facebook.react.ReactHost
import com.facebook.react.common.ReleaseLevel
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint

import expo.modules.ApplicationLifecycleDispatcher
import expo.modules.ExpoReactHostFactory

class MainApplication : Application(), ReactApplication {

  override val reactHost: ReactHost by lazy {
    ExpoReactHostFactory.getDefaultReactHost(
      context = applicationContext,
      packageList =
        PackageList(this).packages.apply {
          // Packages that cannot be autolinked yet can be added manually here, for example:
          // add(MyReactNativePackage())

          // Trilha do JavaScript: ponte para o JS marcar as etapas do arranque no
          // MESMO arquivo da trilha nativa (TrilhaJsModule.kt). Assim, se o
          // aplicativo morrer no meio da abertura — depois do React Native e antes
          // de qualquer tela —, a próxima abertura leva a história inteira para a
          // pasta Downloads, e não só a metade nativa.
          //
          // Em `try/catch` de propósito: se o registro falhar, a trilha some, mas o
          // aplicativo abre. Diagnóstico é acessório; abrir não é.
          try {
            add(TrilhaJsPackage())
          } catch (_: Throwable) {
          }
        }
    )
  }

  /**
   * Ponto mais cedo que existe em Java: `attachBaseContext` roda **antes** de
   * `onCreate`. É aqui que a captura de falha e a trilha de abertura começam — se
   * o arranque morrer em `onCreate` ou no carregamento das bibliotecas, já existe
   * registro de até onde foi.
   */
  override fun attachBaseContext(base: android.content.Context) {
    super.attachBaseContext(base)
    // Instalar AQUI, e não em onCreate: este é o ponto mais cedo que existe em
    // Java. Se o arranque morrer no próprio onCreate ou no carregamento das
    // bibliotecas nativas, a captura e a trilha já estão no lugar.
    CapturaDeFalha.instalar(this)
  }

  override fun onCreate() {
    super.onCreate()
    CapturaDeFalha.marcarEtapa(this, "2/5 aplicativo criado")
    // A colheita da abertura anterior (motivo no histórico do Android + trilha)
    // NÃO é disparada daqui: ela acontece uma única vez, em `instalar()`, no
    // `attachBaseContext` — e grava as duas coisas juntas. Antes eram duas
    // threads escrevendo o mesmo arquivo em Downloads, e uma apagava a outra
    // (BUGS_FOUND.md §BD).
    DefaultNewArchitectureEntryPoint.releaseLevel = try {
      ReleaseLevel.valueOf(BuildConfig.REACT_NATIVE_RELEASE_LEVEL.uppercase())
    } catch (e: IllegalArgumentException) {
      ReleaseLevel.STABLE
    }
    loadReactNative(this)
    CapturaDeFalha.marcarEtapa(this, "3/5 React Native carregado")
    ApplicationLifecycleDispatcher.onApplicationCreate(this)
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    ApplicationLifecycleDispatcher.onConfigurationChanged(this, newConfig)
  }

}
