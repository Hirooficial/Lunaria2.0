# Geração de imagem local no Galaxy A05s — avaliação de viabilidade

Pergunta feita na rodada: *“preferir geração remota para poupar o aparelho;
considerar local só depois de avaliar a viabilidade”*. Esta é a avaliação, com
números públicos e com o que já roda no aparelho.

## Hardware do alvo

Samsung Galaxy A05s: Snapdragon 680 (4× Cortex-A73 2,4 GHz + 4× Cortex-A53),
Adreno 610, **6 GB de RAM**, sem NPU aproveitável para difusão (aceleração QNN
existe a partir de Snapdragon 8 Gen 1, segundo a Qualcomm e os guias de execução
local). A A05s não está nessa faixa.

## Números de referência (Stable Diffusion 512×512, 20 passos)

| Backend | Chip | Tempo por imagem |
| --- | --- | --- |
| NPU QNN | Snapdragon 8 Gen 3 | ~5–10 s |
| NPU QNN | Snapdragon 8 Gen 1 | ~10–15 s |
| CPU (MNN) | Snapdragon 8 Gen 3 | ~15 s |
| CPU (MNN) | intermediário | ~25–40 s |
| CPU (MNN), sem NPU | aparelho de entrada (caso da A05s) | **acima de 40 s por imagem**, com aquecimento e throttling |

Fontes consultadas (18/09/2026): guias de execução local em Android
(getoffgridai.co/guides/stable-diffusion-android, dev.to/alichherawalla) e a
demonstração da Qualcomm de Stable Diffusion em Snapdragon 8 Gen 2 (TechSpot,
2023-02-27). Nenhuma dessas fontes reporta medição em Snapdragon 680.

## O que isso significa para a Lunaria

1. **Memória**: um modelo de difusão quantizado ocupa de 1 a 4 GB de armazenamento
   e perto de 1,5–2,5 GB de RAM no pico. O aparelho tem 6 GB e o aplicativo já
   reserva memória para o modelo de conversa (GGUF), o banco, o TTS e o próprio
   Android. Rodar os dois no mesmo aparelho, na mesma sessão, é o cenário que
   mais arrisca o encerramento do aplicativo pelo sistema.
2. **Tempo**: acima de 40 s por imagem, com o aparelho esquentando e reduzindo
   frequência depois de duas ou três imagens — e a conversa local, se estiver
   carregada, já deixa o aparelho aquecido.
3. **Bateria/armazenamento**: modelo no cartão ou na memória interna (1–4 GB) mais
   o consumo contínuo de CPU em todos os núcleos.
4. **Qualidade**: os modelos que caibam em CPU nessa faixa são versões
   quantizadas de SD 1.5 — piores justamente em rostos, mãos e consistência de
   personagem, que é o que a Lunaria quer acertar.

## Decisão desta versão

Geração **remota** (AI Horde ou Pollinations), com o aparelho fazendo apenas o
que ele faz bem: montar o texto, receber a imagem e cifrá-la. As resoluções
oferecidas (512×768, 512×640, 640×640, 768×512, 768×432) foram escolhidas para
caber bem na tela, trafegar rápido e não pesar no cofre cifrado.

## Como revisitar isso

O caminho para geração local passa por um binário de difusão compatível com
arm64 (por exemplo `stable-diffusion.cpp`/MNN) empacotado como módulo nativo,
escolha de modelo LCM/Turbo de 512 px quantizado, teste medido de memória de pico
e tempo por imagem **neste aparelho**, e só então uma opção “gerar no aparelho”
desativada por padrão. Sem a medição no aparelho, incluir isso seria promessa sem
base — por isso ficou fora, com o motivo registrado aqui.
