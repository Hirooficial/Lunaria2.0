# Verificação da Lunaria 1.0.0 — 15/09/2026 (Arena)

Cada linha diz **onde** foi verificado: `código` (análise e testes executados
neste ambiente), `serviço` (chamada real a serviço externo) ou `aparelho`
(exige o Galaxy A05s — não executado aqui).

| Verificação | Onde | Resultado |
| --- | --- | --- |
| `npm ci` | código | 1018 pacotes instalados, `patch-package` aplicado |
| `npm run test:unit` | código | **26 de 26** passaram (19 anteriores + 7 novos) |
| `npx tsc --noEmit` | código | sem erros |
| `npx eslint app db lib --max-warnings=0` | código | sem erros e sem avisos |
| `npx expo prebuild --platform android` | código | concluído; plugin de assinatura aplicado |
| `:app:assembleRelease` arm64 | código | **BUILD SUCCESSFUL** em 14m32s, 951 tarefas |
| Assinatura do APK | código | `apksigner verify` com a chave de release da Lunaria |
| Manifesto e versão | código | `br.aurora.luna.lunaria.next`, v1.0.0, minSdk 24, targetSdk 36 |
| Bibliotecas nativas | código | 53 `.so` arm64, 14 delas `librnllama*`; sem símbolos OpenMP indefinidos |
| Tokenizador no APK | código | presente (`res/RT.gguf`, 7.818.140 bytes) |
| IA remota AI Horde | serviço | resposta correta em 7,8 s, fila 0, sem falha |
| Pesquisa por links reais | serviço | (checkpoint anterior) NASA e ESA, ~8,4 s |
| Busca automática DuckDuckGo | serviço | bloqueada no ambiente de desenvolvimento; alternativa por links funciona |
| Instalação no aparelho | aparelho | **pendente** |
| Conversa e segunda mensagem | aparelho | **pendente** |
| Cancelar e reenviar | aparelho | **pendente** |
| Acentos e emoji na resposta local | aparelho | **pendente** |
| Ditado em pt-BR e leitura em voz alta | aparelho | **pendente** |
| Pesquisa, salvar e apagar memória | aparelho | **pendente** |
| Importar GGUF e medir desempenho | aparelho | **pendente** |
| Segundo plano e notificação | aparelho | **pendente** |

## Por que o aparelho não foi usado

Este ambiente é x86_64, sem `/dev/kvm` e sem emulador Android instalado, e o
APK é arm64-v8a (o A05s tem Snapdragon 680). Não há como executar o aplicativo
aqui — nem por USB, nem por emulador. Os itens marcados como `aparelho`
continuam abertos.

## Evidência dos testes automatizados

```
# tests 26
# pass 26
# fail 0
```

Os 7 testes novos cobrem:

1. `lib/engine/StreamBuffer.ts` — acúmulo normal, descarte de sobra de outra
   conversa, texto ainda sem dono, pedaço vazio e acentos/emoji na concatenação.
2. `lib/research/WebResearch.ts` — dois sites repetindo o mesmo texto-base
   contam como um indício; o contexto enviado ao modelo informa o número de
   textos-base distintos e separa fatos, divergências, opiniões e evidências
   insuficientes.

## Análise do APK (independente do código-fonte)

```
package: br.aurora.luna.lunaria.next  versionName='1.0.0'  versionCode='1'
sdkVersion:'24'  targetSdkVersion:'36'  compileSdkVersion='36'
lib/arm64-v8a/*.so — 53 arquivos
librnllama.so — DT_NEEDED apenas liblog, libandroid, libm, libdl, libc
res/RT.gguf — 7.818.140 bytes (tokenizador)
```

## O que ainda não foi medido

Tempo até o primeiro token, duração de resposta e consumo de memória **no
aparelho**. A única medida feita aqui é de serviço externo (7,8 s até a resposta
completa da AI Horde) e, no histórico do projeto, ~8,4 s para ler duas páginas
na pesquisa. Nenhuma dessas medidas descreve o A05s.

Observação importante para o modo remoto: a API pública da AI Horde é de fila e
devolve o texto completo, sem streaming. Nesse modo não existe “primeiro token”
parcial; o aplicativo mostra posição na fila e tempo de espera.
