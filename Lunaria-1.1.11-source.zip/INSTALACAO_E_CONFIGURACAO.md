# Lunaria 1.1.11 — como instalar e configurar

> **Versão desta rodada:** 1.1.11 (código 13). O que mudou desde a 1.1.1 está no fim
> deste arquivo (§11) e, em detalhe, em `STATUS.md`, `BUGS_FOUND.md` e
> `TEST_REPORT.md`. Se o aplicativo **fechar ao abrir** no seu aparelho, leia o §11
> antes de qualquer coisa: há uma forma de me mandar o motivo exato do fechamento.

Arquivos desta entrega:

| Arquivo | O que é |
| --- | --- |
| `Lunaria-1.1.11-arm64-release.apk` | Aplicativo para instalar no Galaxy A05s (arm64) |
| `Lunaria-1.1.11-source.zip` | Código-fonte atualizado (sem chaves e sem senhas) |
| `CHECKLIST_APARELHO.md` | O que conferir no aparelho; os itens 18 a 25 são os que faltam |
| `GERACAO_DE_IMAGEM_E_BLOQUEIO.md` | Guia das duas novidades desta versão |
| `RELATORIO_DE_TESTES.md` | O que foi testado, onde e o que falta testar |
| `INSTALACAO_E_CONFIGURACAO.md` | Este arquivo |

A chave de assinatura (`lunaria-release.jks`) e a senha ficam **fora** do ZIP,
na pasta `lunaria-assinatura/` do espaço de trabalho. Guarde as duas: sem elas
não é possível atualizar o aplicativo depois de instalado.

## 1. Instalar no celular

1. Copie `Lunaria-1.1.11-arm64-release.apk` para o celular (cabo, Google Drive,
   Telegram, o que for mais fácil).
2. Toque no arquivo. O Android vai pedir para permitir instalação de fontes
   desconhecidas para o app que está abrindo o arquivo — permita só para essa
   ação.
3. Se aparecer “Aplicativo não instalado”, veja a seção **Problemas** no fim.
4. **Se você já tem a Lunaria 1.0.0 instalada, instale por cima**: é o mesmo
   pacote (`br.aurora.luna.lunaria.next`) e a mesma assinatura, então o Android
   aceita atualizar sem desinstalar e **sem perder conversas, personagem,
   ajustes, memória nem imagens**. Não desinstale antes.
5. Vindo de um aplicativo antigo **com outro pacote** (o ChatterUI, por
   exemplo), aí sim ele instala separado e nada é migrado automaticamente.

Confira o arquivo antes de instalar, se quiser:

```
SHA-256 do APK desta versão: ver o arquivo `SHA256.txt` que acompanha a entrega
```

O sha do ZIP de fonte **não** vai aqui de propósito: ele mudaria este arquivo, que
muda o ZIP — um ciclo. Os dois (e os de todas as versões anteriores) estão em
`SHA256.txt`, que acompanha a entrega e se confere com `sha256sum -c SHA256.txt`.

## 2. Primeira abertura

- O banco de dados é criado no primeiro uso; leva alguns segundos.
- A tela inicial é a lista de personagens, já com a **Lunaria** e o usuário
  **Hamura** criados (Hamura tratado no masculino, conforme a ficha).
- Toque em Lunaria → **Nova conversa** para começar.

## 3. Escolher o modo de IA

Há duas opções, alternáveis pelo seletor no topo da gaveta de configurações
(ou em Configurações → modo da IA):

### Modo online (grátis, AI Horde)

- Não precisa de nada instalado nem de chave: a conexão “Lunaria Online — grátis”
  já vem pronta com a chave anônima `0000000000`.
- **Limites reais**: é uma rede comunitária de voluntários. Pode haver **fila de
  espera**, a velocidade varia, às vezes não há nó disponível e a resposta chega
  **de uma vez**, sem aparecer palavra por palavra (a API é de fila, não de
  streaming). O aplicativo mostra posição na fila, espera, erro e permite
  cancelar — o pedido é cancelado no servidor também.
- **Privacidade**: suas mensagens, o contexto do chat e trechos de pesquisa vão
  para a rede e podem ser processados por voluntários. O aplicativo avisa na
  primeira vez e só continua com a sua confirmação. Não mande senhas nem
  documentos pessoais.
- Para mudar o modelo remoto: Configurações → APIs → conexão → escolher modelos.

### Modo local (GGUF no aparelho)

- Funciona sem internet e sem enviar nada para fora.
- Você precisa importar um modelo de conversa no formato **GGUF**
  (Configurações → Modelos → Importar). O tokenizador já vem dentro do
  aplicativo.
- **Recomendação para o A05s (6 GB de RAM)**: modelos de **1 B a 3 B** com
  quantização **Q4_K_M** (arquivos de ~0,7 GB a ~2 GB). Modelos de 7 B são
  possíveis mas lentos e com risco de o Android fechar o aplicativo.
- Ajustes que já vêm prontos (Configurações → Modelo):
  - Contexto **4096** → se o aplicativo fechar sozinho ao conversar, baixe para
    **2048**.
  - Lote **(batch) 256** → menor consumo de memória.
  - Threads **4** → os quatro núcleos rápidos do Snapdragon 680.
  - Camadas na GPU **0** → o A05s usa CPU; não há ganho em GPU aqui.
  - “Salvar cache KV” desligado economiza armazenamento; ligado acelera a
    continuação da conversa.

## 4. Voz (ditado e leitura)

- **Ditado**: no campo de mensagem, toque no microfone. O Android vai pedir
  permissão de microfone; o idioma padrão é **pt-BR**. O microfone é encerrado
  ao sair da conversa.
- **Leitura em voz alta**: Configurações → Voz. Escolha a voz do sistema
  (recomendado instalar uma voz **pt-BR** no Google TTS, se o aparelho não
  tiver), a velocidade e se deve falar automaticamente após a resposta.
- Se não houver voz instalada, o Android usa a padrão do sistema.

## 5. Pesquisa / Fatos

1. Toque em **Fatos** (na barra do campo de mensagem) ou abra a tela de pesquisa.
2. Digite a pergunta. O aplicativo tenta buscar sozinho; **se a busca
   automática for bloqueada**, ele avisa e você pode colar **dois ou mais links
   HTTPS** de páginas confiáveis no campo indicado.
3. Ele lê as páginas de verdade, guarda trechos e links, e mostra a comparação.
   Trechos iguais de sites diferentes são contados **como um único indício**,
   não como duas confirmações — o contexto enviado ao modelo diz isso
   explicitamente e pede a separação entre fatos, divergências, opiniões e
   evidências insuficientes.
4. **Salvar memória é opcional**: nada entra na memória sem você tocar em
   salvar. Em “Memória de pesquisa” você consulta e apaga o que quiser.
5. Quando a memória é usada numa conversa, o próprio texto avisa ao modelo que
   a informação pode estar desatualizada.

## 6. Gerar imagens (novidade da 1.1.0; correções na 1.1.1)

Na conversa, toque em **Imagem**. A tela tem descrição editável, proporção,
estilo (gótico, anime, fotografia, ilustração, fantasia, moda, romântico,
sombrio), o perfil visual da Lunaria e a **prévia do texto exato** que será
enviado. Dois provedores gratuitos, com limites reais documentados:

| Provedor | Cadastro | Limite real |
| --- | --- | --- |
| AI Horde (padrão) | não; chave anônima `0000000000` | fila comunitária; 512×768 em ~25 s no teste |
| Pollinations | não no nível anônimo | 1 pedido a cada 15 s; pode marcar d'água |

**Provedores pagos ficam desativados por padrão.** Detalhes, incluindo o que
pode e o que não pode ser gerado, estão em `GERACAO_DE_IMAGEM_E_BLOQUEIO.md`.

## 7. Bloquear a Lunaria com senha (novidade da 1.1.0)

**Configurações → Proteção por senha**: crie uma senha ou PIN (mínimo 6 dígitos),
ative biometria se quiser e escolha o intervalo para pedir senha ao voltar do
segundo plano. Há botão **Bloquear agora**, opção de **impedir capturas de tela**
e de **esconder o conteúdo das notificações**.

Guarde a senha: ela **não** é armazenada em lugar nenhum (nem em backup). Se
esquecer, a única saída é apagar o cofre de imagens com confirmação — conversas,
personagem e ajustes continuam.

## 8. Atualizar para a 1.1.1 (o que acontece com seus dados)

- Conversas, personagem, ajustes, memória de pesquisa e modelos GGUF: **iguais**,
  nada é reescrito.
- Imagens que você anexou nas conversas na 1.0.0 (que ficavam em claro na pasta
  `Attachments/`): na primeira abertura da versão com cofre elas entram no cofre cifrado
  automaticamente. A Lunaria só apaga o arquivo antigo **depois** de confirmar
  que a cópia cifrada abre corretamente; se algo falhar, o original fica e a
  migração continua na próxima abertura.
- A proteção por senha **não** vem ligada: você escolhe ativar.

## 9. Problemas comuns

| Situação | O que fazer |
| --- | --- |
| “Aplicativo não instalado” | Confira se o APK foi copiado inteiro (tamanho ~57 MB) e permita instalação de fontes desconhecidas. Se já existir uma Lunaria instalada de outro pacote, isso não é conflito: são aplicativos separados. |
| Instalou, mas fecha ao abrir | Anote a tela de erro que aparece (o aplicativo mostra a falha em português). Vá em Configurações → Registros e copie o trecho final. |
| Resposta não chega no modo online | É fila da rede gratuita. Espere ou cancele e tente de novo, ou mude de modelo. A API é de fila, pode demorar. |
| Aplicativo fecha ao conversar no modo local | Reduza o contexto para 2048 e o lote para 128; use um modelo menor (Q4_K_M de 1–3 B). |
| Texto estranho repetido na resposta | Use “Regenerar” (seta) na mensagem. Se repetir sempre, abaixe a temperatura ou aumente a penalidade de repetição em Amostragem. |
| Ditado não funciona | Verifique permissão de microfone nas configurações do Android e se há serviço de reconhecimento de voz instalado (Google ou Samsung). |
| Pesquisa falha | Use a opção de colar links HTTPS. Páginas com login, bloqueio de robôs ou muito grandes não são lidas. |

### Bloqueio por senha

- **“Não consigo desbloquear / esqueci a senha”**: a Lunaria não pode recuperar a
  senha. Em “Esqueci a senha” a janela explica e só apaga o cofre (as imagens
  geradas dentro do app) com a sua confirmação; conversas e ajustes continuam.
- **“A espera aumentou depois de errar”**: é a proteção progressiva (1 s na 3ª
  tentativa, dobrando até 5 minutos). Nada é apagado por errar.
- **“A tela fica preta nas capturas de tela”**: é a opção “impedir capturas”
  ligada (fica ligada automaticamente enquanto o app está bloqueado).

### Geração de imagem

- **“Sem conexão com o provedor”**: confira a internet; a geração é remota.
- **“Aguarde alguns segundos”**: limite do nível anônimo do Pollinations (1 a
  cada 15 s) ou fila cheia na Horde.
- **“Descrição bloqueada”**: a cena tem nudez explícita, ato sexual ou referência
  a menor de idade. A janela diz qual termo disparou — reescreva sem ele.
- **Fila parada na Horde**: é rede comunitária; tentar de novo sorteia outro
  voluntário. O Pollinations responde rápido quando há pressa.

## 10. Atualizar para uma versão futura

Mantenha `lunaria-release.jks` e a senha. Ao gerar um APK novo, assine com a
**mesma chave** (o plugin do projeto lê `android/keystore.properties`) e instale
por cima: os dados (conversas, memória, modelos importados) são preservados no
upgrade normal.

## 11. O que mudou até aqui, e o que fazer se fechar ao abrir

Esta versão sai da 1.1.1. De lá para cá, o trabalho foi em cima de **um problema só**:
o aplicativo **fecha ao abrir** no seu Galaxy A05s, sem mensagem nenhuma.

O que já foi descartado, com prova: módulo nativo faltando, desalinhamento de
configuração, corte/renomeação do R8, erro no manifesto ou nos recursos, e a
possibilidade de o próprio aplicativo se encerrar de propósito (não existe nada no
código que faça isso — nem no JavaScript, nem no Kotlin). O que **não** se descobriu
ainda é a causa. Como o fechamento é silencioso, o caminho passou a ser instrumentar:

- **A trilha de abertura.** Cada etapa do arranque grava uma linha com horário
  (1/5 captura instalada → 2/5 aplicativo criado → 3/5 React Native carregado →
  4/5 tela criada → 5/5 abertura concluída). Se uma abertura não chegar ao fim, a
  próxima diz **em que etapa ela parou** e grava isso na pasta Downloads, no arquivo
  `lunaria-ultimo-erro.txt`. É a única forma de enxergar morte **sem** exceção
  (falha nativa de biblioteca, memória, sinal do sistema).
- **O porteiro de abertura.** Se o JavaScript não carregar, em vez de fechar, o
  aplicativo abre numa tela que mostra o motivo.
- **Terceira saída para o relatório** (novidade da 1.1.9): aquela tela de aviso agora
  tem **dois** botões — "Copiar diagnóstico" e **"Salvar em Downloads"**. O segundo
  grava o relatório em `lunaria-diagnostico.txt`, na pasta Downloads, sem depender de
  colar texto.
- **A trilha atravessa o meio do caminho** (novidade da 1.1.10): antes, a trilha sabia
  o que aconteceu **antes** do JavaScript; no meio (banco, senha, tema, primeira tela)
  ela parava em "4/5 tela criada" sem dizer o quê. Agora o próprio aplicativo escreve
  as etapas dele na mesma trilha, de `js 1/8` (porteiro instalado) até `js 8/8` (lista
  de conversas na tela), e falhas gravam linha com `!` no lugar do número. Detalhes de
  como ler no item **25** do `CHECKLIST_APARELHO.md`.
- **O relatório chega inteiro** (correção da 1.1.11): o motivo da morte e a trilha eram
  gravados por processos separados no mesmo arquivo, e um podia apagar o outro. Agora
  é uma gravação só — o arquivo começa com `RELATÓRIO DA ABERTURA ANTERIOR` e traz o
  motivo e a trilha juntos.

**Se o aplicativo fechar ao abrir, faça isto (nesta ordem):**

1. Abra o aplicativo **de novo**, uma vez. Se agora ele abrir, me diga isso: o
   arquivo `lunaria-ultimo-erro.txt` em Downloads vai dizer em que etapa a tentativa
   anterior parou.
2. Se aparecer a tela "A Lunaria não conseguiu abrir", toque em **"Salvar em
   Downloads"** (ou em "Copiar diagnóstico" e cole a mensagem para mim).
3. Se fechar direto, sem tela nenhuma: abra os **Downloads** do aparelho e me mande o
   arquivo `lunaria-ultimo-erro.txt` — ele foi gravado pela captura nativa na
   abertura anterior.

Os detalhes de cada caminho estão nos itens **18 a 24** do `CHECKLIST_APARELHO.md`.
