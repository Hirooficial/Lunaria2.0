# Lunaria

Para continuar este pacote no Arena, leia [COMECE_AQUI_ARENA.md](COMECE_AQUI_ARENA.md).
O estado atual e as pendências estão em [STATUS.md](STATUS.md) e
[BUGS_FOUND.md](BUGS_FOUND.md).

Lunaria é uma companheira virtual para Android, em português, baseada no
[ChatterUI](https://github.com/Vali-98/ChatterUI). O projeto mantém a opção de
inferência local com GGUF e oferece, por padrão, um modo remoto gratuito via
[AI Horde](https://github.com/Haidra-Org/AI-Horde). A conexão anônima do AI
Horde pode entrar em fila e a qualidade/velocidade depende dos modelos e
workers disponíveis no momento.

## O que foi personalizado

- identidade, nome, ícone e cartão de personagem Lunaria;
- persona em pt-BR com tom gótico, afetuoso e adulto consensual;
- resposta masculina ao usuário configurado como Hamura;
- correção de caracteres recebidos em partes e remoção de eco exato, sem substituir respostas por frases prontas;
- modo local com modelos `.gguf` compatíveis;
- modo online gratuito com consentimento de privacidade na primeira utilização;
- Pesquisa/Fatos: busca em várias fontes, comparação de excertos e memória de
  pesquisa;
- ditado em português e leitura em voz alta pelo mecanismo do Android;
- memória local e controles de privacidade no próprio aparelho.

Conteúdo adulto só deve envolver personagens adultos, consentimento e ficção.
O aplicativo não é um filtro de segurança do provedor: modelos remotos podem
recusar ou variar respostas, e nunca se deve enviar informação sensível a uma
API pública/anônima.

## Usar sem chave de API

1. Abra **Modelo** e mantenha o modo remoto selecionado.
2. Na primeira mensagem, leia e aceite o aviso de privacidade do AI Horde.
3. Aguarde a fila; se o serviço estiver congestionado, tente mais tarde ou
   escolha um modelo local.

As consultas de **Pesquisa/Fatos** são enviadas ao DuckDuckGo para obter
resultados públicos. O texto encontrado é mostrado com links e só é salvo na
memória quando o usuário toca em **Salvar pesquisa**.
Se o buscador bloquear a consulta, também é possível informar links HTTPS de
pelo menos dois domínios. Somente páginas efetivamente lidas entram na comparação.
Domínios diferentes não garantem independência editorial; confira sempre o texto
original. A memória inclui a data e as fontes e pode ser apagada pelo usuário.

A edição atual ainda está em validação. Consulte o relatório antes de instalar.
O pacote Android novo é `br.aurora.luna.lunaria.next`: ele instala separadamente
das versões antigas e não migra automaticamente conversas e modelos.

## Modo local

Importe um modelo GGUF que caiba na memória do telefone em **Modelo → Importar
modelo**. Quantizações menores (por exemplo, Q4) costumam ser mais adequadas a
celulares de entrada. O modelo local é executado no aparelho e não exige
internet, mas o tempo de resposta depende do tamanho do modelo e da RAM.

## Desenvolvimento e build

Veja [BUILDING.md](BUILDING.md) para Node.js, Java 17, Android SDK, prebuild,
testes e geração do APK. O build deve ser feito em ambiente limpo; não inclua
chaves privadas, `android/local.properties` ou `node_modules` no backup público.

## Testes

Os testes unitários de persona e pesquisa ficam em `tests/`. O relatório da
última validação está em [TEST_REPORT.md](TEST_REPORT.md).

## Créditos e licença

O código-base é derivado do ChatterUI e permanece sob AGPL-3.0, conforme
[LICENSE](LICENSE). Consulte [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)
para as bibliotecas de terceiros.
