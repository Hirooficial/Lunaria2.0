# Privacidade

O modo local mantém o processamento no aparelho. O modo remoto AI Horde envia
as mensagens necessárias ao serviço público para gerar uma resposta; a
conexão anônima usa uma fila compartilhada e não é apropriada para segredos,
senhas, dados de saúde ou informações pessoais identificáveis.

O recurso Pesquisa/Fatos consulta DuckDuckGo e abre páginas públicas. Trechos,
links e o resumo comparativo só são armazenados no banco local quando o usuário
escolhe salvá-los. A memória pode ser apagada pelo menu do aplicativo.

O reconhecimento de voz exige a permissão de microfone do Android e o texto
reconhecido é usado para preencher a mensagem. A leitura em voz alta usa o
serviço TTS configurado no Android.
