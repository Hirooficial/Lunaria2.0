import type * as DrizzleExpoModule from 'drizzle-orm/expo-sqlite'
import type * as SQLiteModule from 'expo-sqlite'

import { breadcrumb, recordError } from '@lib/utils/Diagnostics'
import { carregarModuloNativo } from '@lib/utils/NativeModules'

import * as schema from './schema'

/**
 * O banco de dados (conversas, personagens, memória) — aberto **sob demanda**.
 *
 * O que havia de errado, medido:
 *
 *  1. `openDatabaseSync` rodava no escopo do módulo — no instante em que o pacote
 *     JavaScript era avaliado, antes de qualquer tela, de qualquer proteção e de
 *     qualquer `try/catch`. Este arquivo é importado pela primeira tela
 *     (`app/index.tsx`), então uma falha de abertura (arquivo de banco corrompido
 *     por uma instalação anterior, disco cheio) fechava o aplicativo **sem
 *     mensagem**. Mesmo defeito do armazenamento de preferências (`BUGS_FOUND.md`
 *     §AN), no recurso mais crítico.
 *  2. `expo-sqlite` procura o módulo nativo **no import**
 *     (`node_modules/expo-sqlite/build/ExpoSQLite.js`:
 *     `export default requireNativeModule('ExpoSQLite')`) — e não só ele:
 *     `drizzle-orm/expo-sqlite/query.js` também faz `import ... from "expo-sqlite"`.
 *     Ou seja, manter `import { drizzle } from 'drizzle-orm/expo-sqlite'` no topo
 *     reabria o mesmo buraco por outro caminho. Os dois passaram a ser carregados
 *     sob demanda.
 *
 * Agora a abertura acontece **no primeiro uso**, dentro do `try/catch` de quem
 * chamou. Se falhar, o erro aparece onde já era tratado: a tela de abertura mostra
 * o relatório de diagnóstico em vez de o aplicativo sumir.
 */
export const MENSAGEM_BANCO_INDISPONIVEL =
    'Não foi possível abrir o banco de dados da Lunaria. As conversas continuam ' +
    'no aparelho, intactas — o motivo exato está no relatório de diagnóstico.'

const carregarSQLite = () =>
    carregarModuloNativo<typeof SQLiteModule>('expo-sqlite', () =>
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        require('expo-sqlite')
    )

const carregarDrizzle = () =>
    carregarModuloNativo<typeof DrizzleExpoModule>('drizzle-orm/expo-sqlite', () =>
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        require('drizzle-orm/expo-sqlite')
    )

const abrir = () => {
    const sqlite = carregarSQLite()
    if (!sqlite) throw new Error(MENSAGEM_BANCO_INDISPONIVEL)

    const banco = sqlite.openDatabaseSync('db.db', { enableChangeListener: true })

    // As duas chamadas abaixo são assíncronas e não têm espera: sem o `catch`,
    // uma falha delas virava promessa rejeitada sem dono.
    const extensao = sqlite.bundledExtensions['sqlite-vec']
    if (extensao) {
        banco.loadExtensionAsync(extensao.libPath, extensao.entryPoint).catch((erro) => {
            recordError('banco:extensao', erro)
        })
    }
    banco.execAsync('PRAGMA foreign_keys = ON;').catch((erro) => {
        recordError('banco:pragma', erro)
    })

    breadcrumb('banco: aberto')
    return banco
}

const criarDrizzle = () => {
    const modulo = carregarDrizzle()
    if (!modulo) throw new Error(MENSAGEM_BANCO_INDISPONIVEL)
    return modulo.drizzle(abrir(), { schema })
}

type BancoSqlite = ReturnType<typeof abrir>
type BancoDrizzle = ReturnType<typeof criarDrizzle>

let sqliteAberto: BancoSqlite | undefined
let drizzleCriado: BancoDrizzle | undefined

/**
 * Acesso que abre o banco na primeira leitura de propriedade.
 *
 * O tipo devolvido é o mesmo de antes, então nada mais no aplicativo precisa
 * mudar. `then`/`catch`/`finally` ficam de fora de propósito: `await banco` (ou
 * devolver o banco de dentro de uma função assíncrona) não pode disparar a
 * abertura — só o uso de verdade dispara.
 */
const sobDemanda = <T extends object>(obter: () => T): T =>
    new Proxy({} as T, {
        get: (_alvo, prop) => {
            if (prop === 'then' || prop === 'catch' || prop === 'finally') return undefined
            return Reflect.get(obter(), prop)
        },
    })

export const sqliteDB = sobDemanda<BancoSqlite>(() => (sqliteAberto ??= abrir()))
export const db = sobDemanda<BancoDrizzle>(() => (drizzleCriado ??= criarDrizzle()))
