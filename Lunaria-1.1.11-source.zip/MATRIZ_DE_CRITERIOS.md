# Matriz de critérios — Lunaria 1.1.2

> **Documento de rodada antiga**, mantido como histórico. A leitura atual do mesmo
> assunto está em `BUGS_FOUND.md` (seções AR a BA) e em `STATUS.md`.

Cada pedido do seu encargo, onde ele está no código, o que foi **testado de
verdade** nesta máquina e o que só o aparelho pode confirmar.

Novidade desta rodada: uma segunda camada de testes (renderização, 49 testes)
passou a **executar** as telas e o ciclo da senha com o código real. Itens que
eram só leitura de código agora estão marcados como [auto-render]. O APK
entregue **não** mudou: são testes e ferramentas de desenvolvimento.

Legenda de status:
- **[auto]** — verificado por teste automatizado ou comando executado aqui, com resultado real.
- **[estático]** — verificado lendo o código e o APK entregue (não é execução do app).
- **[auto-render]** — verificado executando a tela ou o fluxo de verdade, com os módulos nativos simulados (`npm run test:render`).
- **[aparelho]** — depende exclusivamente do Galaxy A05s; **não testado ainda**.

---

## 1. Geração de imagem

| Critério | Onde está | Status |
| --- | --- | --- |
| Botão "Gerar imagem" na conversa | `app/screens/ChatScreen/ChatInput/index.tsx` | [auto-render] a tela de conversa renderiza, o botão está na árvore e tocá-lo abre a rota da tela de geração |
| Descrição editável antes de enviar | `app/screens/ImageGenerationScreen.tsx` | [estático] |
| Prévia da descrição final antes do envio | `lib/imagegen/ImagePrompt.ts` (`preview`) | [auto] `imageprompt` 10/10 |
| Escolha de proporção | `lib/imagegen/ImageStyles.ts` — retrato 512×768, paisagem 768×512, quadrado 640×640, clássico 512×640, cinema 768×432 | [auto] `imageprompt` |
| Estilos gótico, anime, fotografia, ilustração, fantasia (+ sombrio, moda, romântico) | `ImageStyles.ts` (`IMAGE_STYLE_LIST`) | [auto] `imageprompt` |
| Permite adulta, sensualidade sem nudez, moda alternativa, romance | `lib/imagegen/ContentPolicy.ts` | [auto] `imagepolicy` 9/9 |
| Recusa nudez explícita e ato sexual | `ContentPolicy.ts` + prompt negativo terminando em `child, minor, explicit nudity, sexual act` | [auto] `imagepolicy` |
| Recusa **antes** de chamar a rede | `lib/state/ImageGeneration.ts` (política antes do provedor) | [auto] `imagepolicy` + `imageprovider` |
| Perfil visual editável da Lunaria (aparência adulta, cabelo, olhos, roupas, acessórios) | `ImageStyles.ts` (`DEFAULT_LUNARIA_PROFILE`, `LUNARIA_PROFILE_FIELDS`) | [auto] `imageprompt` |
| Aviso honesto sobre limites de consistência visual | `CONSISTENCY_NOTE` em `ImageStyles.ts` | [auto] `imageprompt` |
| Âncora adulta no prompt | `ADULT_ANCHOR = 'adult woman, clearly over 25 years old'` | [auto] `imageprompt` |
| Estados de conexão/fila/geração/conclusão/erro, com cancelar, editar e repetir | `lib/state/ImageGeneration.ts` (fases `preparando/enfileirado/gerando/concluido/cancelado/erro`) | [auto] `imageprovider` 30/30 — inclui espera após 429/5xx com teto, `Retry-After`, cancelamento durante a espera e as fases observadas numa **fila real** (262 → 0) |
| Imagem na conversa com ampliar, apagar, salvar e compartilhar | `app/components/views/{PrivateImage,ImageViewer}.tsx`, `lib/state/components/ImageViewer.ts` | [estático] |
| Não travar enquanto a imagem carrega | carregamento assíncrono + estado de fila; nenhuma espera de rede na renderização | [estático] |
| Geração real pelo aplicativo | — | **[aparelho]** itens 1–7 do checklist |

## 2. Provedor

| Critério | Onde está | Status |
| --- | --- | --- |
| Integração documentada | `entrega/INSTALACAO_E_CONFIGURACAO.md` + `PROVIDER_INFO` no código | [auto] |
| Opção gratuita priorizada | AI Horde padrão (chave anônima `0000000000`), Pollinations como alternativa sem chave | [auto] chamadas reais feitas |
| Cotas e limites reais conferidos | Horde: fila, kudos 6,0 (512²) e 9,0 (adulto, `dry_run`); Pollinations: 1 req/15 s anônimo, marca d'água em modelo básico | [auto] chamadas reais |
| Licença/registro verificados | Horde é software livre, sem cadastro obrigatório; Pollinations sem chave | [auto] |
| Provedores pagos desligados por padrão | nenhum provedor pago embutido | [estático] |
| Provedor configurável | `app/screens/ImageSettingsScreen.tsx` | [estático] |
| Credenciais protegidas | chave em `SecureStore`; a chave anônima não é segredo por definição | [estático] |
| Mensagens claras: sem internet, cota esgotada, indisponível, recusa | `lib/imagegen/ImageProviders.ts` — tipos `rede/cota/autenticacao/recusa/timeout/cancelado/formato/desconhecido` | [auto] `imageprovider` |
| Geração remota preferida em vez de local | decisão registrada em `IMAGEM_LOCAL_VIABILIDADE.md` (A05s não tem NPU; >40 s e 1,5–2,5 GB de pico por imagem) | [auto] |
| Resultado lido tanto em base64 quanto em **endereço https** (caso real da Horde/R2) | `readHordeResult` em `ImageProviders.ts` | [auto] 5 testes + geração real baixada (WebP 91.666 bytes) |
| Cancelar avisa o provedor e tira o trabalho da fila | `cancelHordeJob` chamado no `catch` de `generateWithHorde` | [auto] 3 testes (cancela e avisa; sucesso não avisa; 401 não avisa) + `DELETE` conferido na API real |
| Cancelamento **pelo botão no aparelho** | — | **[aparelho]** item 17 do checklist |
| Limite de consultas do provedor (429) não cancela a geração | espera crescente com teto de 30 s em `generateWithHorde` | [auto] 6 testes + 429 observado na fila real |
| Pollinations sempre com semente própria (evita imagem de cache) | `usedSeed` em `generateWithPollinations` | [auto] 2 testes + medido: 37.167 bytes idênticos antes |
| Limitação de idioma do provedor informada ao usuário | `PROVIDER_INFO.pollinations.languageNote` + aviso na tela | [auto] `imageprovider` + [auto-render] o aviso aparece na tela de ajustes |
| Só a descrição e as referências autorizadas são enviadas | `buildImagePrompt` monta o corpo a partir da descrição, do estilo e do perfil; nada de conversa/histórico | [auto] `imageprompt` |

## 3. Bloqueio

| Critério | Onde está | Status |
| --- | --- | --- |
| Senha ou PIN com no mínimo 6 dígitos | `lib/security/LockPolicy.ts` (`MIN 6`, PIN `/^\d{6,}$/`) | [auto] `lock` 9/9 + [auto-render] senha de 3 dígitos recusada no fluxo real |
| Biometria quando disponível, com alternativa segura | `SecureVault.ts` (slot `lunaria-dek-biometric`) + `AppLock` | [estático] |
| Pedir desbloqueio ao abrir e ao voltar depois de um intervalo configurável | `app/_layout.tsx` (AppState) + `AUTO_LOCK_OPTIONS` 0/1/5/15/60 (padrão 5 min) | [auto] + [estático] |
| "Bloquear agora" | `lib/state/AppLock.ts` (`lockNow`) | [auto-render] bloquear fecha o cofre e passa a exigir senha |
| Protege todas as telas e entradas, inclusive notificação e link | `_layout.tsx`: `!ready` → tela em branco; `locked` → **só** `LockScreen`, sem a `Stack` da conversa e sem o visualizador de imagem | [auto-render] 6 testes: bloqueado não monta o app; `ready` falso não mostra nada |
| Notificação não abre conversa bloqueada | `lib/notifications/Notifications.ts` → guarda `pendingChat` e retorna | [estático] |
| Conversas e imagens escondidas até autenticar | `_layout.tsx` (acima) + cofre fechado (`privateVault.lock()`) | [estático] |
| Conteúdo sensível escondido na notificação | `lib/state/Chat.ts`: com bloqueio ativo, título "Lunaria" e texto "Abra a Lunaria e desbloqueie para ver a resposta." | [auto-render] com o estado real do app: nem nome de personagem nem texto da resposta |
| Esconder na prévia de recentes | `setRecentsHidden`/flag de bloqueio; captura de tela também pode ser impedida | [estático] |
| Opção de impedir capturas | `_layout.tsx` chama `ScreenCapture.preventScreenCaptureAsync('lunaria')` quando ligado | [estático] Módulo `ScreenCapture` presente no dex do APK |
| Parar leitura em voz alta e microfone ao bloquear | `AppLock.lockNow`: `stopAudioAndMic()` → `privateVault.lock()` → limpar temporários | [estático] |
| Autenticação obrigatória para trocar ou desligar proteção | `AppLock.changeSecret`/`disableLock` exigem a senha atual; `DISABLE_WARNING` | [auto] `lock` + [auto-render] trocar/desligar sem a senha atual é recusado |
| Espera progressiva após erros | `LockPolicy.ts`: `2^(n−3)` s, teto de 300 s | [auto] `lock` + [auto-render] 3 erros acumulam e nem a senha certa abre durante a espera |
| Nunca apagar dados automaticamente | não existe caminho de wipe automático; `resetVaultKeepingChats` só roda com confirmação explícita | [estático] |
| Explicar senha esquecida e consequências antes de redefinir | `FORGOT_SECRET_EXPLANATION` + confirmação "Nada foi apagado..." | [auto] `lock` |
| Desbloqueio (senha errada, espera, troca, desligar) | `AppLock` | [auto-render] coberto sem aparelho |
| Desbloqueio na prática (reinício, segundo plano, notificação, biometria) | — | **[aparelho]** itens 7–12 do checklist |

## 4. Privacidade e dados

| Critério | Onde está | Status |
| --- | --- | --- |
| Criptografia real das **imagens privadas** | AES-256-GCM + PBKDF2-SHA256 (150.000 iterações), envelope `iv‖ct+tag`, AAD `lunaria-v1` | [auto] `crypto` 10/10 + [auto-render] os bytes gravados não contêm o conteúdo; dois arquivos iguais geram bytes diferentes |
| Criptografia real do **texto das conversas e da memória** | **NÃO implementada.** O que existe hoje: as conversas vivem no banco SQLite da pasta privada do aplicativo (protegidas pelo cofre de arquivos do Android e pela porta de bloqueio), e a memória de pesquisa vive no MMKV — **ambas em claro no disco** | [verificado no código] `db/schema.ts` (coluna `swipe`, sem transformação), `lib/state/Chat.ts:709` (gravação direta), `lib/state/ResearchMemory.ts` (MMKV) |
| Chave gerenciada no padrão da plataforma | DEK envolvida pela senha e guardada no `SecureStore` (chaveiro do sistema) | [auto] + [estático] |
| Nenhuma senha em claro | nenhuma gravação de senha em mmkv/arquivo; só verificador derivado | [auto-render] depois de ativar, bloquear, errar, acertar e trocar: a senha não aparece no keychain nem no armazenamento |
| Nenhuma credencial em log | **zero** chamadas de `console.log/warn/error` em `lib/security/`, `lib/imagegen/`, `AppLock.ts` e `ImageGeneration.ts` | [auto] verificado por busca |
| Nada em backup público | `allowBackup=false`, `fullBackupContent=false`, `dataExtractionRules` com domínios fechados | [estático] conferido no APK entregue |
| Imagem fica na área privada por padrão | `document/private/*.lunaenc`; o arquivo em claro só existe em `cache/view-*` | [auto] `privatefiles` 10/10 + [auto-render] cofre fechado recusa leitura |
| Aviso ao exportar para a galeria ou compartilhar | `externalCopyWarning('galeria' \| 'compartilhar')` — "fora da Lunaria ela fica sem a proteção do aplicativo" | [estático] |
| Usuário controla armazenamento e exclusão | biblioteca com teto de 500 itens, exclusão individual, limpeza de cache | [estático] |
| Migração segura dos dados existentes | `Migration.ts` verifica a releitura do arquivo cifrado **antes** de apagar o original | [auto] `lock` (plano idempotente) + `privatefiles` |
| Dados antigos continuam acessíveis após a atualização | — | **[aparelho]** itens 15–16 do checklist |

## 5. Preservação do que já funcionava

Duas camadas de prova: **comportamento** (suítes automatizadas) e **presença no
pacote entregue** — esta última feita dentro do APK, sem aparelho, com
`tools/verificar_preservacao.py` (que vai no ZIP). Resultado: **12 de 12 recursos
encontrados no APK 1.1.2**.

| Critério | Comportamento | Dentro do APK entregue |
| --- | --- | --- |
| Conversa e histórico | [auto] `persona` 4/4, `stream` 5/5 | [auto] `message`, `chats`, expo-sqlite no bundle |
| Personalidade editável em pt-BR (gótica, afetuosa) | [auto] `persona` | [auto] textos de estética/persona no bundle |
| Tratamento masculino ao Hamura | [auto] `persona` | [auto] "Hamura" no bundle |
| Pesquisa/Fatos | [auto] `research` 12/12 | [auto] "Pesquisar e comparar fontes", "Pesquisas ficam apenas neste aparelho" |
| Memória opcional | [auto] suíte sem regressão | [auto] "memória local" no bundle |
| Ditado (fala → texto) | [auto] módulos cobertos nos testes de render | [auto] `expo-speech-recognition` no bundle |
| Leitura em voz alta | [auto] parada ao bloquear (render) | [auto] `expo-speech` no bundle |
| API remota | [auto] `stream` 5/5 | [auto] `chat/completions` no bundle |
| GGUF local | [auto] `stream` (local) | [auto] `librnllama*.so` (17 arquivos) + `libggml-htp-*.so` no pacote |
| Modelo local embutido | — | [auto] `res/RT.gguf`, 7.818.140 bytes |
| Nada substituído por resposta pronta | testes exercitam o caminho real (streaming/pesquisa) | [auto] sem texto de resposta embutido: o bundle só monta pedidos, não guarda respostas |
| Geração de imagem e bloqueio (novos) | [auto] 104 + 50 testes | [auto] "Gerar imagem", "aihorde.net", "Bloquear agora", cofre `lunaria-dek` |

Limite desta camada, dito com clareza: ela prova que o recurso **está no pacote
enviado** — não que ele funciona no seu aparelho. Isso segue no
`CHECKLIST_APARELHO.md`.

## 6. Entrega

| Critério | Status |
| --- | --- |
| APK assinado atualizado | [auto] 1.1.2/versionCode 4, arm64-v8a — assinatura v2 verificada pelo `apksigner`; SHA-256 `e39b3ae7…319b` e tamanho em `RELATORIO_DE_TESTES.md` §3 |
| Compatível com a assinatura existente | [auto] mesmo certificado `c0271509…5719a` da 1.0.0 |
| ZIP do código-fonte | [auto] 494 arquivos, `CHECKSUMS.sha256` conferido, sem keystore e sem senha (buscado pela senha real dentro do ZIP) |
| Instruções simples | `entrega/LEIA-ME.md` e `INSTALACAO_E_CONFIGURACAO.md` |
| Relatório de validação | `entrega/RELATORIO_DE_TESTES.md`, `entrega/CORRECOES.md` + este documento |
| Chaves privadas fora do backup público | [auto] keystore e senha em `lunaria-assinatura/`, ausentes do ZIP (buscado pela senha real) |
| Só o que foi testado é apresentado como validado | este documento marca cada item |

## 7. Resumo do que falta

Nada aqui depende de código: são 16 verificações no aparelho, listadas em
`CHECKLIST_APARELHO.md`. Este ambiente não tem aparelho, nem emulador, nem
`/dev/kvm`, e o APK é arm64 — o aplicativo **não executa** aqui.

O que a camada de renderização tirou da lista de pendências (sem aparelho):
botão Gerar imagem e sua navegação, portão de bloqueio, ciclo de senha,
espera progressiva, troca e desligamento da proteção, ausência de senha em
claro, cifragem dos arquivos do cofre e abertura das telas novas. O que segue
dependendo do A05s é o que envolve hardware, sistema operacional e rede:
biometria, keychain, captura de tela, notificação, reinício, segundo plano,
migração de dados existentes e a geração de imagem de verdade.

---

## 8. Defeito relatado depois da entrega: "fecha quando aperto em abrir"

Este critério não estava no encargo original: veio depois, do Hamura, no Galaxy
A05s. Está aqui para o documento ficar completo — o acompanhamento rodada a rodada
está no `STATUS.md`, e a análise técnica no `BUGS_FOUND.md`.

| hipótese | estado | como foi decidida |
| --- | --- | --- |
| módulo nativo ausente no APK | **refutada com medida** | classes **e** o registro (`expo.modules.ExpoModulesPackageList`) conferidos **dentro** do APK entregue — os módulos usados estão lá |
| R8 renomeando classes que o nativo procura por nome | **refutada com medida** | comparação do APK 1.1.2 (com R8) × 1.1.3 (sem R8): classes, métodos, manifesto, bibliotecas e assets idênticos (§AM) |
| manifesto/configuração divergente | **refutada** | idem, comparado arquivo a arquivo |
| migração de dados no arranque | **refutada** | a migração só roda depois do desbloqueio, não no arranque |
| **código nativo executado no instante do carregamento** | **defeito real, corrigido** | o armazenamento interno (§AN), o **banco de dados** (§AQ), o `expo-crypto` e a biometria; prova: teste que mostra que importar o banco **não** abre o banco |
| **falha de carregamento não deixava rastro (fechava em silêncio)** | **defeito real, corrigido** | **porteiro de entrada** (§AS): primeiro código a rodar, sem dependências, instala o registro de erros e carrega as rotas protegido; se falhar, abre numa tela com o motivo e o botão "Copiar diagnóstico" |
| causa exata no A05s | **ainda não provada** | depende do aparelho: itens 18 a 22 do `CHECKLIST_APARELHO.md`; se a 1.1.6 ainda fechar, a falha é anterior ao JavaScript e a prova tem de vir do `logcat` do Android |

**O que está provado por teste automatizado**: o banco não é tocado no carregamento;
o porteiro roda antes de tudo, mostra a falha fatal de abertura e não interfere
depois que o aplicativo montou; o identificador de anexo nunca sai vazio.
**O que NÃO está provado**: que o aplicativo abre no A05s. Nenhuma linha deste
documento afirma isso.

### Pendência registrada, sem meias palavras

`expo-file-system` procura o módulo nativo no import e está no topo de nove arquivos
do caminho de abertura. Fechar esse ponto exige refatorar dezenas de telas e **não
foi feito** — decisão explícita, para não trocar um defeito conhecido por uma
regressão em massa às vésperas da entrega. O que se pode dizer: o módulo **está
registrado** no APK (conferido no dex), e o porteiro do §AS agora transforma
qualquer falha desse tipo em mensagem na tela, em vez de silêncio.
