import type * as MMKVModule from 'react-native-mmkv'
import { createJSONStorage, StateStorage } from 'zustand/middleware'

import { setDiagStorage } from '@lib/utils/Diagnostics'
import { carregarModuloNativo } from '@lib/utils/NativeModules'

/**
 * Preferências do aplicativo.
 *
 * O armazenamento nativo (`react-native-mmkv`, ainda em beta na versão 4) é
 * criado **aqui**, no escopo do módulo — ou seja, no instante em que o pacote
 * JavaScript é avaliado, antes de qualquer tela. É o ponto mais frágil da
 * abertura: se a criação falhar, o aplicativo fechava sozinho, sem mensagem e
 * sem diagnóstico.
 *
 * Por isso a carga passa por `carregarModuloNativo` (com `try/catch` e registro
 * no relatório) e existe uma **reserva em memória**. Com ela o aplicativo abre
 * mesmo quando o armazenamento nativo não responde — as preferências não são
 * gravadas em disco durante essa sessão, mas o usuário vê o motivo no relatório
 * de diagnóstico em vez de um fechamento silencioso.
 */
type Preferencias = {
    getString: (key: string) => string | undefined
    getBoolean: (key: string) => boolean | undefined
    getNumber: (key: string) => number | undefined
    set: (key: string, value: string | number | boolean) => void
    remove: (key: string) => void
    getAllKeys: () => string[]
    clearAll: () => void
}

const memoria = (): Preferencias => {
    const dados = new Map<string, string | number | boolean>()
    return {
        getString: (key) => {
            const valor = dados.get(key)
            return typeof valor === 'string' ? valor : undefined
        },
        getBoolean: (key) => {
            const valor = dados.get(key)
            return typeof valor === 'boolean' ? valor : undefined
        },
        getNumber: (key) => {
            const valor = dados.get(key)
            return typeof valor === 'number' ? valor : undefined
        },
        set: (key, value) => {
            dados.set(key, value)
        },
        remove: (key) => {
            dados.delete(key)
        },
        getAllKeys: () => [...dados.keys()],
        clearAll: () => {
            dados.clear()
        },
    }
}

const nativo = carregarModuloNativo<Preferencias>('react-native-mmkv', () =>
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    (require('react-native-mmkv') as typeof MMKVModule).createMMKV()
)

export const mmkvEmMemoria = nativo === null

export const mmkv: Preferencias = nativo ?? memoria()

// O diagnóstico grava no armazenamento do próprio aplicativo. A ligação fica
// aqui, e não no Diagnostics, para aquele arquivo continuar sem dependência
// nativa — é o que permite testá-lo em Node puro.
setDiagStorage({
    getString: (key) => mmkv.getString(key),
    set: (key, value) => {
        mmkv.set(key, value)
    },
    remove: (key) => {
        mmkv.remove(key)
    },
})

export const mmkvStorage: StateStorage = {
    setItem: (name, value) => {
        return mmkv.set(name, value)
    },
    getItem: (name) => {
        const value = mmkv.getString(name)
        return value ?? null
    },
    removeItem: (name) => {
        return mmkv.remove(name)
    },
}

export const createMMKVStorage = () => {
    return createJSONStorage(() => mmkvStorage)
}
