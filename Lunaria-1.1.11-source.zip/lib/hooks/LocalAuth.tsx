import type * as LocalAuthModule from 'expo-local-authentication'
import { useCallback, useEffect, useState } from 'react'
import { useMMKVBoolean } from 'react-native-mmkv'

import { AppSettings } from '@lib/constants/GlobalValues'
import { carregarModuloNativo } from '@lib/utils/NativeModules'

/**
 * `expo-local-authentication` procura o módulo nativo no import, então o pacote
 * não pode ser importado no topo de um arquivo que entra no bundle (ver
 * `lib/utils/NativeModules.ts`).
 */
const carregarAuth = () =>
    carregarModuloNativo<typeof LocalAuthModule>('expo-local-authentication', () =>
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        require('expo-local-authentication')
    )

const useLocalAuth = () => {
    const [success, setSuccess] = useState(false)
    const [retryCount, setRetryCount] = useState(0)
    const [hasAuth, sethasAuth] = useState(true)
    const [enabled] = useMMKVBoolean(AppSettings.LocallyAuthenticateUser)
    const authorized = !enabled || !hasAuth || success

    const retry = useCallback(() => {
        setRetryCount((item) => item + 1)
    }, [])

    useEffect(() => {
        if (!enabled || success) return
        const auth = carregarAuth()
        if (!auth) {
            // Sem o módulo no aparelho, insistir no prompt seria beco sem saída:
            // o usuário ficaria preso. A proteção da própria Lunaria (senha)
            // continua valendo por conta própria — ver `lib/state/AppLock.ts`.
            sethasAuth(false)
            return
        }
        auth
            .authenticateAsync({
                promptMessage: 'Authentication Required',
            })
            .then((result) => {
                setSuccess(result.success)
            })
    }, [retryCount, enabled, success])

    useEffect(() => {
        const auth = carregarAuth()
        if (!auth) {
            sethasAuth(false)
            return
        }
        auth
            .getEnrolledLevelAsync()
            .then((result) => sethasAuth(result !== auth.SecurityLevel.NONE))
            .catch(() => sethasAuth(false))
    }, [])

    return { authorized, retry }
}

export default useLocalAuth
