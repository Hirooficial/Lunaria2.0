export type ResearchSource = {
    title: string
    url: string
    domain: string
    excerpt: string
}

export type ResearchBundle = {
    id: string
    query: string
    createdAt: number
    sources: ResearchSource[]
}

export type ResearchNote = ResearchBundle & {
    summary?: string
}
