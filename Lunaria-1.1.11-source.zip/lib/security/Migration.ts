/**
 * Executa a migração das imagens antigas para o cofre cifrado.
 *
 * Ordem que **não** pode ser trocada, para não perder imagem do usuário:
 *   1. ler o arquivo em claro;
 *   2. gravar cifrado no cofre;
 *   3. **ler de volta e comparar** o conteúdo;
 *   4. só então atualizar a referência no banco e apagar o arquivo em claro.
 *
 * Se qualquer passo falhar, a imagem fica exatamente como estava — nada de
 * conversa com anexo quebrado.
 */

import { eq } from 'drizzle-orm'
import { File } from 'expo-file-system'

import { db as database } from '@db'
import { Logger } from '@lib/state/Logger'
import { mmkv } from '@lib/storage/MMKV'
import { chatAttachments } from 'db/schema'

import {
    AttachmentLike,
    describeMigrationResult,
    MIGRATION_MMKV_KEY,
    MigrationResult,
    planAttachmentMigration,
} from './MigrationPlan'
import { privateVault } from './PrivateStorage'

const sameBytes = (a: Uint8Array, b: Uint8Array): boolean => {
    if (a.length !== b.length) return false
    for (let index = 0; index < a.length; index++) {
        if (a[index] !== b[index]) return false
    }
    return true
}

export type MigrationOutcome = MigrationResult & {
    blocked: boolean
    blockedReason?: string
    message: string
}

export const lastMigrationResult = (): MigrationResult | undefined => {
    const raw = mmkv.getString(MIGRATION_MMKV_KEY)
    if (!raw) return undefined
    try {
        return JSON.parse(raw) as MigrationResult
    } catch {
        return undefined
    }
}

/**
 * Roda a migração das imagens. Seguro chamar mais de uma vez: o que já foi
 * migrado é ignorado (`private://`) e nada é recifrado.
 */
export const migrateExistingImages = async (vaultReady: boolean): Promise<MigrationOutcome> => {
    const rows = await database.query.chatAttachments.findMany()
    const attachments: AttachmentLike[] = rows.map((row) => ({
        id: row.id,
        uri: row.uri,
        type: row.type,
        exists: row.uri.startsWith('private://') ? true : new File(row.uri).exists,
    }))

    const plan = planAttachmentMigration(attachments, vaultReady)

    const result: MigrationResult = {
        moved: 0,
        alreadyPrivate: plan.items.filter((item) => item.action === 'ja-privada').length,
        kept: plan.items.filter((item) => item.action === 'manter').length,
        ignored: plan.items.filter((item) => item.action === 'ignorar').length,
        failed: 0,
        finishedAt: new Date().toISOString(),
    }

    if (plan.blocked) {
        return {
            ...result,
            blocked: true,
            blockedReason: plan.blockedReason,
            message: plan.blockedReason ?? 'Migração pendente.',
        }
    }

    await import('./SecureVault') // garante o registro da fonte aleatória do aparelho

    for (const item of plan.items) {
        if (item.action !== 'mover') continue
        try {
            const source = new File(item.uri)
            const plaintext = source.bytesSync()
            const stored = privateVault.writeFile(plaintext)

            // Verificação: a cópia cifrada precisa devolver exatamente os mesmos bytes.
            const readBack = privateVault.readFile(stored.fileName)
            if (!sameBytes(plaintext, readBack)) {
                privateVault.deleteFile(stored.fileName)
                throw new Error('Conferência falhou: conteúdo devolvido diferente do original')
            }

            await database
                .update(chatAttachments)
                .set({ uri: stored.uri })
                .where(eq(chatAttachments.id, item.id))

            source.delete()
            result.moved += 1
        } catch (error) {
            result.failed += 1
            Logger.error(`Migração da imagem ${item.uri} falhou: ${error}`)
        }
    }

    mmkv.set(MIGRATION_MMKV_KEY, JSON.stringify(result))

    return {
        ...result,
        blocked: false,
        message: describeMigrationResult(result),
    }
}
