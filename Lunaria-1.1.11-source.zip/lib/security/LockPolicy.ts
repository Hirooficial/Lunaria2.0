/**
 * Regras do bloqueio por senha/PIN — puras e testáveis (`tests/lock.test.mjs`).
 *
 * Ficam separadas da tela e do estado global de propósito: errar aqui significa
 * trancar o usuário para fora ou deixar o aplicativo aberto. Nada nesta camada
 * toca em disco, em biometria ou em armazenamento seguro.
 */

/** Tamanho mínimo aceito para senha ou PIN. */
export const MIN_SECRET_LENGTH = 6
/** Espera máxima após erros seguidos, em segundos (5 minutos). */
export const MAX_LOCKOUT_SECONDS = 300
/** A partir de quantos erros seguidos começa a espera progressiva. */
export const FREE_ATTEMPTS = 3
/** Valor de PIN: só dígitos, no mínimo 6 (aceita quantos o usuário quiser). */
export const PIN_PATTERN = /^\d{6,}$/

/**
 * Opções de retorno automático. `0` significa "bloqueia assim que o aplicativo
 * sai da frente", que é o comportamento mais seguro e por isso vem por padrão.
 */
export const AUTO_LOCK_OPTIONS = [0, 1, 5, 15, 60] as const
export const DEFAULT_AUTO_LOCK_MINUTES = 5

export type SecretVerdict = {
    ok: boolean
    reason?: string
    /** Todo em dígitos: muda só a mensagem exibida, não a criptografia. */
    isPin: boolean
}

/** Diz se a senha/PIN pode ser usada, com mensagem pronta em português. */
export const validateSecret = (secret: string): SecretVerdict => {
    const value = secret ?? ''
    const isPin = PIN_PATTERN.test(value)
    if (value.length === 0) {
        return { ok: false, reason: 'Digite uma senha ou um PIN.', isPin: false }
    }
    if (value.length < MIN_SECRET_LENGTH) {
        return {
            ok: false,
            reason: `Use pelo menos ${MIN_SECRET_LENGTH} dígitos ou caracteres.`,
            isPin,
        }
    }
    if (value.trim().length !== value.length) {
        return { ok: false, reason: 'Evite espaços no começo ou no fim.', isPin }
    }
    return { ok: true, isPin }
}

/**
 * Espera após erros seguidos: 1 s, 2 s, 4 s, 8 s… limitada a 5 minutos.
 * Nunca apaga dado nenhum — o pedido foi explícito: nada de limpeza automática.
 */
export const lockoutSecondsFor = (failures: number): number => {
    if (!Number.isFinite(failures) || failures < FREE_ATTEMPTS) return 0
    return Math.min(2 ** (failures - FREE_ATTEMPTS), MAX_LOCKOUT_SECONDS)
}

/** Texto da espera para mostrar na tela de bloqueio. */
export const formatLockout = (seconds: number): string => {
    if (seconds <= 0) return ''
    if (seconds < 60) return `Aguarde ${seconds} s antes de tentar de novo.`
    const minutes = Math.ceil(seconds / 60)
    return `Aguarde ${minutes} min antes de tentar de novo.`
}

/** Texto da opção escolhida em "Bloquear depois de". */
export const describeAutoLock = (minutes: number): string => {
    if (minutes === 0) return 'Assim que sair do aplicativo'
    if (minutes === 1) return '1 minuto fora do aplicativo'
    if (minutes < 60) return `${minutes} minutos fora do aplicativo`
    return `${Math.round(minutes / 60)} hora(s) fora do aplicativo`
}

/** Recomendação de segurança exibida antes de desligar o bloqueio. */
export const DISABLE_WARNING =
    'Sem o bloqueio, qualquer pessoa com o aparelho desbloqueado consegue abrir a Lunaria, ver as conversas e as imagens geradas. As imagens continuam cifradas em repouso, mas o aplicativo abre direto.'

/** Explicação do procedimento de senha esquecida, mostrada ANTES do reinício. */
export const FORGOT_SECRET_EXPLANATION = [
    'Não existe "recuperar senha": a chave que decifra o cofre é derivada da sua senha e não é guardada em lugar nenhum — é justamente isso que protege as imagens.',
    'Se você esquecer a senha, a única saída é apagar o cofre de imagens: as imagens geradas e as conversas que as usam são perdidas, e você define uma senha nova.',
    'As conversas de texto, personagens, memória e ajustes continuam intactos — eles ficam no banco do aplicativo, não no cofre.',
    'Se a biometria estiver ativa, ela abre o aplicativo normalmente, mas não substitui a senha para reiniciar o cofre.',
] as const
