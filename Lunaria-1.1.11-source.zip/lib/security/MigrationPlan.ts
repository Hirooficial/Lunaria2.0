/**
 * Plano de migração das imagens que já existiam antes da 1.1.0.
 *
 * Contexto: até a 1.0.0, as imagens anexadas nas conversas ficavam em claro em
 * `document/attachments/`. Na 1.1.0 elas passam a viver cifradas no cofre. A
 * migração precisa ser segura e verificável:
 *
 *  - só roda depois que o usuário cria a senha (sem chave não há como cifrar);
 *  - nada é apagado antes de a cópia cifrada ser lida de volta com sucesso;
 *  - conversas que não têm imagem não são tocadas;
 *  - a decisão é registrada em `lunaria-migration-images-v2` para não repetir.
 *
 * Este módulo é puro de propósito (testado em `tests/privatefiles.test.mjs`):
 * diz **o que** fazer. Quem faz é `Migration.ts`.
 */

import { isPrivateUri } from './PrivateNames'

/** Chave onde fica o resultado da migração. */
export const MIGRATION_MMKV_KEY = 'lunaria-migration-images-v2'

export type AttachmentLike = {
    id: number
    uri: string
    type: string
    /** O arquivo em claro ainda existe no disco? (conferido por quem chama) */
    exists?: boolean
}

export type MigrationAction = 'mover' | 'ja-privada' | 'manter' | 'ignorar'

export type MigrationPlanItem = {
    id: number
    uri: string
    action: MigrationAction
    reason: string
}

export type MigrationPlan = {
    items: MigrationPlanItem[]
    /** Quantas imagens serão cifradas agora. */
    toMove: number
    /** `true` quando falta pré-requisito (senha/cofre) para migrar. */
    blocked: boolean
    blockedReason?: string
}

/**
 * Monta o plano. `vaultReady` indica que existe senha configurada e o cofre já
 * foi aberto — é o que permite cifrar.
 */
export const planAttachmentMigration = (
    attachments: AttachmentLike[],
    vaultReady: boolean
): MigrationPlan => {
    const items: MigrationPlanItem[] = attachments.map((attachment) => {
        if (isPrivateUri(attachment.uri)) {
            return {
                id: attachment.id,
                uri: attachment.uri,
                action: 'ja-privada' as const,
                reason: 'Já está no cofre.',
            }
        }
        if (attachment.type !== 'image') {
            return {
                id: attachment.id,
                uri: attachment.uri,
                action: 'manter' as const,
                reason: 'Só imagens entram no cofre; áudio e documento continuam onde estão.',
            }
        }
        if (attachment.exists === false) {
            return {
                id: attachment.id,
                uri: attachment.uri,
                action: 'ignorar' as const,
                reason: 'O arquivo não está mais no aparelho.',
            }
        }
        return {
            id: attachment.id,
            uri: attachment.uri,
            action: 'mover' as const,
            reason: 'Imagem em claro que passa a ficar cifrada.',
        }
    })

    const toMove = items.filter((item) => item.action === 'mover').length

    if (toMove > 0 && !vaultReady) {
        return {
            items,
            toMove,
            blocked: true,
            blockedReason:
                'As imagens antigas continuam visíveis, mas ainda em claro. Crie a senha de bloqueio para que a Lunaria possa movê-las para o cofre cifrado.',
        }
    }

    return { items, toMove, blocked: false }
}

export type MigrationResult = {
    moved: number
    alreadyPrivate: number
    kept: number
    ignored: number
    failed: number
    finishedAt: string
}

export const describeMigrationResult = (result: MigrationResult): string => {
    if (result.moved === 0 && result.failed === 0) {
        return 'Nenhuma imagem precisou ser movida: as conversas já estavam protegidas.'
    }
    const parts = [`${result.moved} imagem(ns) movida(s) para o cofre cifrado`]
    if (result.failed > 0) parts.push(`${result.failed} falhou(aram) e continua(m) como estavam`)
    if (result.alreadyPrivate > 0) parts.push(`${result.alreadyPrivate} já estava(m) protegida(s)`)
    if (result.kept > 0) parts.push(`${result.kept} áudio/documento mantido(s)`)
    if (result.ignored > 0) parts.push(`${result.ignored} arquivo(s) ausente(s) no aparelho`)
    return parts.join('; ') + '.'
}
