/**
 * Primitivas de criptografia da Lunaria.
 *
 * Regras que este arquivo segue:
 *  - AES-256-GCM para tudo (confidencialidade + detecção de adulteração).
 *  - PBKDF2-SHA256 para transformar a senha em chave (senha nunca é guardada).
 *  - Nada aqui depende de API de navegador: o Hermes não garante `crypto`,
 *    `btoa` nem `TextEncoder`. Quando `globalThis.crypto` existe, ele é usado;
 *    no aparelho, o app registra uma fonte aleatória do `expo-crypto` via
 *    `setRandomSource` (ver `lib/security/SecureVault.ts`).
 *  - O arquivo é **puro** de propósito: assim os testes rodam no Node sem
 *    carregar módulo nativo nenhum.
 */

import { gcm } from '@noble/ciphers/aes'
import { pbkdf2 } from '@noble/hashes/pbkdf2'
import { sha256 } from '@noble/hashes/sha256'

import {
    concatBytes,
    constantTimeEqual,
    bytesToBase64,
    base64ToBytes,
    textToBytes,
    bytesToText,
} from '@lib/utils/Binary'

/** Custo do PBKDF2. Medido neste projeto: ~150 ms por derivação. */
export const PBKDF2_ITERATIONS = 150_000
export const KEY_LENGTH = 32
export const IV_LENGTH = 12
export const SALT_LENGTH = 16
/** Contexto autenticado (AAD): amarra o conteúdo ao formato da Lunaria. */
export const AAD = textToBytes('lunaria-v1')

type RandomSource = (length: number) => Uint8Array

let injectedRandom: RandomSource | undefined

/** Registra uma fonte de aleatoriedade (usado pelo app com `expo-crypto`). */
export const setRandomSource = (source: RandomSource) => {
    injectedRandom = source
}

/**
 * Bytes aleatórios criptograficamente seguros. Ordem: WebCrypto (Node, testes),
 * fonte registrada pelo app (expo-crypto no aparelho) e, se nada existir,
 * erro explícito — jamais devolve valor previsível.
 */
export const randomBytes = (length: number): Uint8Array => {
    const webCrypto = (globalThis as { crypto?: Crypto }).crypto
    if (webCrypto?.getRandomValues) {
        const output = new Uint8Array(length)
        webCrypto.getRandomValues(output)
        return output
    }
    if (injectedRandom) return injectedRandom(length)
    throw new Error('Fonte de números aleatórios indisponível neste ambiente')
}

export const randomSalt = (length: number = SALT_LENGTH) => randomBytes(length)

/** Senha → chave de 256 bits. O sal é aleatório por cofre e guardado junto. */
export const deriveKeyFromSecret = (
    secret: string,
    salt: Uint8Array,
    iterations: number = PBKDF2_ITERATIONS
): Uint8Array => pbkdf2(sha256, textToBytes(secret), salt, { c: iterations, dkLen: KEY_LENGTH })

/** Chave aleatória (DEK) — é ela que cifra os arquivos, nunca a senha. */
export const generateKey = () => randomBytes(KEY_LENGTH)

/** Deriva uma chave a partir de outra (ex.: verso da chave para biometria). */
export const deriveSubKey = (key: Uint8Array, label: string): Uint8Array =>
    pbkdf2(sha256, key, textToBytes(label), { c: 1_000, dkLen: KEY_LENGTH })

/**
 * Cifra bytes. Formato do envelope: `iv(12) ‖ ciphertext+tag`.
 * O AAD entra na autenticação: conteúdo cifrado com um contexto não abre em outro.
 */
export const encryptBytes = (
    key: Uint8Array,
    plaintext: Uint8Array,
    aad: Uint8Array = AAD
): Uint8Array => {
    const iv = randomBytes(IV_LENGTH)
    const cipher = gcm(key, iv, aad)
    return concatBytes(iv, cipher.encrypt(plaintext))
}

/** Decifra o envelope. Lança erro se a chave estiver errada ou o dado adulterado. */
export const decryptBytes = (
    key: Uint8Array,
    payload: Uint8Array,
    aad: Uint8Array = AAD
): Uint8Array => {
    if (payload.length <= IV_LENGTH) throw new Error('Envelope cifrado inválido')
    const iv = payload.slice(0, IV_LENGTH)
    const body = payload.slice(IV_LENGTH)
    // O GCM valida a tag: adulteração ou chave errada falha aqui, não devolve lixo.
    return gcm(key, iv, aad).decrypt(body)
}

export const encryptToBase64 = (
    key: Uint8Array,
    plaintext: Uint8Array,
    aad: Uint8Array = AAD
): string => bytesToBase64(encryptBytes(key, plaintext, aad))

export const decryptFromBase64 = (
    key: Uint8Array,
    payload: string,
    aad: Uint8Array = AAD
): Uint8Array => decryptBytes(key, base64ToBytes(payload), aad)

export const encryptString = (key: Uint8Array, text: string, aad: Uint8Array = AAD): string =>
    encryptToBase64(key, textToBytes(text), aad)

export const decryptString = (key: Uint8Array, payload: string, aad: Uint8Array = AAD): string =>
    bytesToText(decryptFromBase64(key, payload, aad))

/**
 * Verificador guardado no aparelho: 16 bytes derivados da chave. Serve para
 * saber se a senha digitada está certa **sem** precisar decifrar arquivo algum
 * e sem guardar a senha. Não permite reconstruir a chave.
 */
export const verifierFor = (key: Uint8Array): string => bytesToBase64(key.slice(0, 16))

export const verifierMatches = (key: Uint8Array, verifier: string): boolean => {
    try {
        return constantTimeEqual(key.slice(0, 16), base64ToBytes(verifier))
    } catch {
        return false
    }
}

/** Embaralha a chave para conferir se ela abre o cofre (senha correta). */
export const keyOpensVault = (key: Uint8Array, wrappedDek: string): boolean => {
    try {
        decryptFromBase64(key, wrappedDek)
        return true
    } catch {
        return false
    }
}
