/**
 * Nomes, extensões e tipos de arquivo das imagens privadas.
 *
 * Este módulo é **puro** (não toca em disco, nem em módulo nativo) porque é aqui
 * que mora a lógica que mais erra na prática: descobrir o tipo real de um arquivo
 * e montar o nome certo na hora de exibir, exportar ou apagar. Fica testável em
 * `tests/privatefiles.test.mjs`.
 */

/** Sufixo do envelope cifrado gravado em disco (`1234-abcd.webp.lunaenc`). */
export const ENVELOPE_SUFFIX = '.lunaenc'
/** Prefixo usado nas referências dentro do banco de conversas. */
export const PRIVATE_URI_PREFIX = 'private://'
/** Extensão usada quando o tipo do arquivo não pode ser reconhecido. */
export const UNKNOWN_EXTENSION = 'bin'

const MIME_BY_EXTENSION: Record<string, string> = {
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    webp: 'image/webp',
    heic: 'image/heic',
    heif: 'image/heif',
    gif: 'image/gif',
    bmp: 'image/bmp',
    bin: 'application/octet-stream',
}

const KNOWN_IMAGE_EXTENSIONS = new Set(
    Object.keys(MIME_BY_EXTENSION).filter((item) => item !== 'bin')
)

export const extensionOf = (fileName: string): string => {
    const base = fileName.split('/').pop() ?? fileName
    const parts = base.split('.')
    if (parts.length < 2) return ''
    return (parts.pop() ?? '').toLowerCase()
}

/** `true` quando a referência aponta para o cofre privado e não para o disco comum. */
export const isPrivateUri = (uri: string): boolean =>
    typeof uri === 'string' && uri.startsWith(PRIVATE_URI_PREFIX)

/** Nome do arquivo guardado no cofre, a partir da referência `private://…`. */
export const privateFileNameFromUri = (uri: string): string =>
    isPrivateUri(uri) ? uri.slice(PRIVATE_URI_PREFIX.length) : ''

/** Monta a referência usada no banco de conversas. */
export const toPrivateUri = (fileName: string): string => PRIVATE_URI_PREFIX + fileName

/**
 * Nome do arquivo **em claro** usado na visualização. O arquivo decifrado é
 * temporário e nunca deve manter o nome do envelope: um nome terminando em
 * `.lunaenc` faria o visualizador recusar a imagem.
 */
export const viewFileName = (storedName: string): string => {
    const base = storedName.split('/').pop() ?? storedName
    const withoutEnvelope = base.endsWith(ENVELOPE_SUFFIX)
        ? base.slice(0, -ENVELOPE_SUFFIX.length)
        : base
    return `view-${withoutEnvelope}`
}

/**
 * Extensão de imagem de um arquivo guardado; desconhecida vira `bin`.
 *
 * Cuidado que o teste pegou: no cofre o nome é `1712-ab.webp.lunaenc`, então o
 * sufixo do envelope precisa sair **antes** de procurar a extensão — senão a
 * "extensão" encontrada é `lunaenc` e toda imagem virava `bin`.
 */
export const storedImageExtension = (storedName: string): string => {
    const base = (storedName.split('/').pop() ?? storedName).replace(ENVELOPE_SUFFIX, '')
    const extension = extensionOf(base)
    return KNOWN_IMAGE_EXTENSIONS.has(extension) ? extension : UNKNOWN_EXTENSION
}

export const mimeForExtension = (extension: string): string =>
    MIME_BY_EXTENSION[extension.toLowerCase()] ?? MIME_BY_EXTENSION.bin

export type DetectedImageType = {
    extension: string
    mime: string
    /** Assinatura reconhecida, para registro e diagnóstico. */
    kind: 'png' | 'jpeg' | 'webp' | 'heic' | 'gif' | 'bmp' | 'desconhecido'
}

const startsWith = (bytes: Uint8Array, signature: number[], offset = 0): boolean => {
    if (bytes.length < offset + signature.length) return false
    for (let index = 0; index < signature.length; index++) {
        if (bytes[offset + index] !== signature[index]) return false
    }
    return true
}

const asciiAt = (bytes: Uint8Array, offset: number, text: string): boolean => {
    if (bytes.length < offset + text.length) return false
    for (let index = 0; index < text.length; index++) {
        if (bytes[offset + index] !== text.charCodeAt(index)) return false
    }
    return true
}

/**
 * Descobre o tipo da imagem pelo **conteúdo**, não pela extensão.
 *
 * Isso importa porque o provedor devolve formatos diferentes (a AI Horde manda
 * WebP; a Pollinations manda JPEG) e porque uma extensão errada salva com a
 * extensão errada quebra o visualizador e o compartilhamento depois.
 */
export const detectImageType = (bytes: Uint8Array): DetectedImageType => {
    // PNG: 89 50 4E 47 0D 0A 1A 0A
    if (startsWith(bytes, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) {
        return { extension: 'png', mime: MIME_BY_EXTENSION.png, kind: 'png' }
    }
    // JPEG: FF D8 FF
    if (startsWith(bytes, [0xff, 0xd8, 0xff])) {
        return { extension: 'jpg', mime: MIME_BY_EXTENSION.jpg, kind: 'jpeg' }
    }
    // WebP: "RIFF" nos bytes 0-3, tamanho nos 4-7 e "WEBP" nos bytes 8-11
    if (asciiAt(bytes, 0, 'RIFF') && asciiAt(bytes, 8, 'WEBP')) {
        return { extension: 'webp', mime: MIME_BY_EXTENSION.webp, kind: 'webp' }
    }
    // GIF: "GIF87a" ou "GIF89a"
    if (asciiAt(bytes, 0, 'GIF87a') || asciiAt(bytes, 0, 'GIF89a')) {
        return { extension: 'gif', mime: MIME_BY_EXTENSION.gif, kind: 'gif' }
    }
    // BMP: "BM"
    if (asciiAt(bytes, 0, 'BM')) {
        return { extension: 'bmp', mime: MIME_BY_EXTENSION.bmp, kind: 'bmp' }
    }
    // HEIC/HEIF: tamanho nos bytes 0-3, "ftyp" nos 4-7 e a marca nos 8-11
    if (asciiAt(bytes, 4, 'ftyp')) {
        const brands = ['heic', 'heix', 'hevc', 'hevx', 'mif1', 'msf1', 'heim', 'heis']
        if (brands.some((brand) => asciiAt(bytes, 8, brand))) {
            return { extension: 'heic', mime: MIME_BY_EXTENSION.heic, kind: 'heic' }
        }
    }

    return { extension: UNKNOWN_EXTENSION, mime: MIME_BY_EXTENSION.bin, kind: 'desconhecido' }
}

/** Nome amigável para o arquivo exportado para a galeria ou compartilhado. */
export const exportFileName = (id: number, extension: string): string =>
    `lunaria-${id}.${KNOWN_IMAGE_EXTENSIONS.has(extension) ? extension : UNKNOWN_EXTENSION}`
