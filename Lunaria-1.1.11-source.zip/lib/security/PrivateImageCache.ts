/**
 * Ponte entre o cofre e a interface.
 *
 * A conversa guarda apenas uma referência (`private://nome.lunaenc`). Quando a
 * imagem precisa aparecer na tela, ela é decifrada uma vez para um arquivo
 * temporário e o URI fica memorizado — rolar a conversa não deve decifrar a
 * mesma imagem várias vezes no A05s.
 */

import { File } from 'expo-file-system'

import {
    detectImageType,
    exportFileName,
    ENVELOPE_SUFFIX,
    isPrivateUri,
    mimeForExtension,
    privateFileNameFromUri,
    storedImageExtension,
    toPrivateUri,
    viewFileName,
} from './PrivateNames'
import { privateVault } from './PrivateStorage'

// Reexportado para os componentes que só precisam identificar o cofre.
export {
    detectImageType,
    exportFileName,
    ENVELOPE_SUFFIX,
    isPrivateUri,
    mimeForExtension,
    privateFileNameFromUri,
    storedImageExtension,
    toPrivateUri,
    viewFileName,
}

const viewUriCache = new Map<string, string>()

/** URI local exibível para uma referência do cofre (decifra sob demanda). */
export const resolvePrivateImage = async (privateUri: string): Promise<string | undefined> => {
    const fileName = privateFileNameFromUri(privateUri)
    if (!fileName) return undefined

    const cached = viewUriCache.get(fileName)
    if (cached && new File(cached).exists) return cached

    const exported = privateVault.exportToCache(fileName)
    viewUriCache.set(fileName, exported.uri)
    return exported.uri
}

/** Esquece uma imagem específica (usado ao apagá-la). */
export const forgetPrivateImage = (storedNameOrUri: string): void => {
    const fileName = isPrivateUri(storedNameOrUri)
        ? privateFileNameFromUri(storedNameOrUri)
        : storedNameOrUri
    viewUriCache.delete(fileName)
    privateVault.removeFromCache(fileName)
}

/** Esvazia tudo: chamado em cada bloqueio e ao desligar a proteção. */
export const clearPrivateImageCache = (): void => {
    viewUriCache.clear()
    privateVault.clearCache()
}

export const privateImageCount = (): number => privateVault.listFiles().length
