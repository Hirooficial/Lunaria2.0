/**
 * Política de conteúdo das imagens — roda **antes** de qualquer chamada de rede.
 *
 * O que a Lunaria permite: personagens adultos, sensualidade sem nudez, moda
 * alternativa (gótica, couro, renda, coturno), cenas românticas.
 * O que ela recusa: nudez sexual explícita, atos sexuais, menores de idade em
 * qualquer contexto sensual e coerção/violência sexual.
 *
 * A recusa é feita aqui, localmente, por dois motivos: (1) não faz sentido enviar
 * um pedido que o provedor vai recusar e cobrar da cota do usuário; (2) os termos
 * proibidos nunca chegam a sair do aparelho.
 *
 * Módulo puro (testado em `tests/imagepolicy.test.mjs`) — nada de rede, nada de
 * arquivo, nada de módulo nativo.
 */

export type PolicyCategory = 'explicito' | 'menor' | 'coercao' | 'proibido'

export type PolicyVerdict = {
    allowed: boolean
    category?: PolicyCategory
    reason: string
    /** Termo que disparou a recusa, para o usuário entender o motivo. */
    match?: string
}

type Rule = {
    category: PolicyCategory
    reason: string
    terms: string[]
}

/**
 * Reduz o texto a letras minúsculas sem acento.
 *
 * Feito à mão em vez de usar `String.normalize`: o Hermes não garante
 * normalização Unicode completa, e aqui a lista de caracteres do português é
 * curta e conhecida.
 */
const ACCENT_MAP: Record<string, string> = {
    á: 'a',
    à: 'a',
    ã: 'a',
    â: 'a',
    ä: 'a',
    é: 'e',
    è: 'e',
    ê: 'e',
    ë: 'e',
    í: 'i',
    ì: 'i',
    î: 'i',
    ï: 'i',
    ó: 'o',
    ò: 'o',
    õ: 'o',
    ô: 'o',
    ö: 'o',
    ú: 'u',
    ù: 'u',
    û: 'u',
    ü: 'u',
    ç: 'c',
    ñ: 'n',
}

export const foldText = (text: string): string => {
    let output = ''
    const lower = (text ?? '').toLowerCase()
    for (const char of lower) {
        output += ACCENT_MAP[char] ?? char
    }
    return output
}

const RULES: Rule[] = [
    {
        category: 'menor',
        reason: 'A Lunaria não gera imagens com menores de idade. Personagens devem ser adultos.',
        terms: [
            'menor de idade',
            'menina',
            'menino',
            'crianca',
            'infantil',
            'pre-adolescente',
            'pre adolescente',
            'adolescente',
            'bebe',
            'loli',
            'lolicon',
            'shota',
            'escolar infantil',
            'colegial',
            'underage',
            'under age',
            'child',
            'kid',
            'minor',
            'teen',
            'schoolgirl',
            'little girl',
            'young girl',
            'young boy',
            'young teen',
        ],
    },
    {
        category: 'coercao',
        reason: 'A Lunaria não gera cenas de violência sexual ou de relações sem consentimento.',
        terms: [
            'estupro',
            'estuprada',
            'estuprar',
            'nao consentido',
            'sem consentimento',
            'a forca',
            'a força',
            'forcada',
            'forcado',
            'violentada',
            'violencia sexual',
            'abuso sexual',
            'tortura sexual',
            'rape',
            'non-consent',
            'nonconsent',
            'forced sex',
            'sexual violence',
        ],
    },
    {
        category: 'proibido',
        reason: 'Esse tipo de conteúdo está fora do que a Lunaria gera.',
        terms: [
            'zoofilia',
            'bestialidade',
            'com animal',
            'com animais',
            'necrofilia',
            'com cadaver',
            'incesto',
            'bestiality',
            'animal sex',
            'necrophilia',
            'incest',
        ],
    },
    {
        category: 'explicito',
        reason: 'A Lunaria não gera nudez sexual explícita nem atos sexuais. Sensualidade sem nudez, sim.',
        terms: [
            'nudez explicita',
            'nudez total',
            'pelada',
            'pelado',
            'sem roupa',
            'genitalia',
            'genitais',
            'orgao sexual',
            'orgaos sexuais',
            'seios a mostra',
            'peitos a mostra',
            'mamilo',
            'mamilos',
            'vagina exposta',
            'penis exposto',
            'erecao',
            'sexo explicito',
            'ato sexual',
            'relacao sexual',
            'transando',
            'penetracao',
            'ejaculacao',
            'orgasmo',
            'pornografia',
            'pornografico',
            'xoxota',
            'buceta',
            'pinto',
            'gozada',
            'explicit nudity',
            'full nudity',
            'nude',
            'naked',
            'topless',
            'genital',
            'genitals',
            'nipples',
            'sexual act',
            'sex scene',
            'intercourse',
            'penetration',
            'pornographic',
            'explicit sex',
        ],
    },
]

/** Palavras que anulam um termo explícito quando vêm antes dele (ex.: "sem nudez"). */
const NEGATIONS = [
    'sem',
    'nem',
    'nada de',
    'nenhum',
    'nenhuma',
    'evitar',
    'evite',
    'nao',
    'no ',
    'without',
    'not ',
    'avoid',
]

/**
 * Só é aplicada à categoria `explicito`. Pedidos como "pose sensual, sem nudez"
 * são legítimos e não podem ser recusados — foi exatamente esse falso positivo
 * que apareceu no primeiro teste. A guarda **nunca** vale para menor ou coerção:
 * "adolescente, sem nudez" continua recusado, e com razão.
 */
const isNegated = (haystack: string, index: number): boolean => {
    const window = haystack.slice(Math.max(0, index - 24), index)
    return NEGATIONS.some((negation) => window.includes(negation))
}

/** Parecer sobre o pedido. `allowed: false` interrompe a geração antes da rede. */
export const assessImagePrompt = (prompt: string): PolicyVerdict => {
    const text = foldText(prompt)

    // Menor e coerção primeiro e sem guarda de negação: são sempre recusados.
    for (const rule of RULES) {
        if (rule.category === 'explicito') continue
        for (const term of rule.terms) {
            const index = text.indexOf(term)
            if (index >= 0) {
                return {
                    allowed: false,
                    category: rule.category,
                    reason: rule.reason,
                    match: term,
                }
            }
        }
    }

    const explicitRule = RULES.find((rule) => rule.category === 'explicito')!
    for (const term of explicitRule.terms) {
        let index = text.indexOf(term)
        while (index >= 0) {
            if (!isNegated(text, index)) {
                return {
                    allowed: false,
                    category: 'explicito',
                    reason: explicitRule.reason,
                    match: term,
                }
            }
            index = text.indexOf(term, index + 1)
        }
    }

    return { allowed: true, reason: 'Pedido dentro das regras da Lunaria.' }
}

/** Versão resumida para exibição. */
export const policySummary = (verdict: PolicyVerdict): string =>
    verdict.allowed ? 'Dentro das regras' : `Recusado (${verdict.category})`
