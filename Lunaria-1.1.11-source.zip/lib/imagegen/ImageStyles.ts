/**
 * Estilos, proporções e o perfil visual da Lunaria.
 *
 * Módulo puro (testado em `tests/imageprompt.test.mjs`): é só dado, sem rede e
 * sem módulo nativo, para poder ser conferido pelos testes e reaproveitado pela
 * tela de geração.
 */

export type AspectRatioId = 'retrato' | 'paisagem' | 'quadrado' | 'classico' | 'cinema'
export type ImageStyleId =
    | 'gotico'
    | 'sombrio'
    | 'fantasia'
    | 'anime'
    | 'fotografia'
    | 'ilustracao'
    | 'moda'
    | 'romantico'

export const DEFAULT_STYLE: ImageStyleId = 'gotico'
export const DEFAULT_ASPECT_RATIO: AspectRatioId = 'retrato'

export type AspectRatio = {
    id: AspectRatioId
    label: string
    width: number
    height: number
    hint: string
}

/**
 * Tamanhos escolhidos dentro do que os provedores gratuitos entregam de forma
 * confiável (a AI Horde cobra 6 kudos por 512×512 e o custo cresce com a área).
 * Nada de 1024×1024: no A05s isso significa download maior, memória maior e
 * espera maior sem ganho real numa tela de 6,7 polegadas.
 */
export const ASPECT_RATIOS: Record<AspectRatioId, AspectRatio> = {
    retrato: {
        id: 'retrato',
        label: 'Retrato',
        width: 512,
        height: 768,
        hint: 'Corpo inteiro em pé',
    },
    paisagem: { id: 'paisagem', label: 'Paisagem', width: 768, height: 512, hint: 'Cena larga' },
    quadrado: { id: 'quadrado', label: 'Quadrado', width: 640, height: 640, hint: 'Rosto e busto' },
    classico: { id: 'classico', label: 'Clássico', width: 512, height: 640, hint: 'Meio corpo' },
    cinema: {
        id: 'cinema',
        label: 'Cinema',
        width: 768,
        height: 432,
        hint: 'Cena cinematográfica',
    },
}

export const ASPECT_RATIO_LIST: AspectRatio[] = Object.values(ASPECT_RATIOS)

export type ImageStyle = {
    id: ImageStyleId
    label: string
    /** Trecho em inglês injetado no prompt (os modelos entendem melhor assim). */
    prompt: string
    description: string
}

export const IMAGE_STYLES: Record<ImageStyleId, ImageStyle> = {
    gotico: {
        id: 'gotico',
        label: 'Gótico',
        prompt: 'gothic dark fantasy art, elegant gothic fashion, cathedral background, moonlight, deep purples and blacks, ornate lace, atmospheric fog, painterly detail',
        description: 'O estilo da casa: renda, catedral, luar e roxo profundo.',
    },
    sombrio: {
        id: 'sombrio',
        label: 'Sombrio',
        prompt: 'dark moody atmosphere, chiaroscuro lighting, muted palette, subtle candle light, gothic romance mood, high contrast shadows',
        description: 'Luz baixa, contraste alto, clima de suspense.',
    },
    fantasia: {
        id: 'fantasia',
        label: 'Fantasia',
        prompt: 'epic fantasy illustration, magical runes, ethereal glow, enchanted forest, detailed costume design, dramatic lighting',
        description: 'Runas, brilho etéreo e figurino de fantasia.',
    },
    anime: {
        id: 'anime',
        label: 'Anime',
        prompt: 'anime illustration, clean lineart, cel shading, expressive eyes, detailed hair, soft rim light, high quality key visual',
        description: 'Traço limpo, cel shading, olhos expressivos.',
    },
    fotografia: {
        id: 'fotografia',
        label: 'Fotografia',
        prompt: 'professional photography, 85mm lens, shallow depth of field, natural skin texture, cinematic color grading, soft window light',
        description: 'Retrato fotográfico, lente 85 mm, luz suave.',
    },
    ilustracao: {
        id: 'ilustracao',
        label: 'Ilustração',
        prompt: 'digital painting illustration, visible brush strokes, rich color harmony, stylized proportions, concept art quality',
        description: 'Pintura digital com pincelada visível.',
    },
    moda: {
        id: 'moda',
        label: 'Moda alternativa',
        prompt: 'alternative fashion editorial, gothic lolita or dark streetwear, leather and velvet textures, statement accessories, studio lighting, full outfit visible',
        description: 'Editorial de moda alternativa, figurino em destaque.',
    },
    romantico: {
        id: 'romantico',
        label: 'Romântico',
        prompt: 'romantic soft scene, warm ambient light, intimate but tasteful mood, gentle smile, flowers and candles, film grain',
        description: 'Cena romântica, luz quente, clima íntimo sem excesso.',
    },
}

export const IMAGE_STYLE_LIST: ImageStyle[] = Object.values(IMAGE_STYLES)

/**
 * Negativos padrão. O fim da lista é o que mantém a geração dentro das regras
 * mesmo quando o modelo "tenta" ir para outro lado.
 */
export const DEFAULT_NEGATIVE_PROMPT = [
    'lowres',
    'worst quality',
    'jpeg artifacts',
    'extra limbs',
    'extra fingers',
    'deformed hands',
    'deformed face',
    'watermark',
    'signature',
    'text',
    'blurry',
    'child',
    'minor',
    'underage',
    'explicit nudity',
    'sexual act',
    'pornographic',
].join(', ')

export type LunariaProfile = {
    /** Aparência — sempre adulta, é regra do projeto. */
    appearance: string
    hair: string
    eyes: string
    clothes: string
    accessories: string
}

/**
 * Perfil visual padrão da Lunaria. É **editável** pelo usuário (tela de
 * configurações de imagem) e só é usado quando ele pede para gerar a própria
 * personagem. Está em inglês porque é isso que vai no prompt; a tela mostra a
 * mesma coisa traduzida para conferência.
 */
export const DEFAULT_LUNARIA_PROFILE: LunariaProfile = {
    appearance:
        'adult woman in her late twenties, pale porcelain skin, slender elegant build, soft gothic features',
    hair: 'long straight silver-white hair with violet undertones, side bangs',
    eyes: 'deep violet eyes with a calm affectionate gaze, subtle dark makeup',
    clothes: 'elegant black gothic dress with lace sleeves and corset detail, velvet choker',
    accessories: 'silver crescent moon pendant, delicate rings, occasional dark tiara',
}

export const LUNARIA_PROFILE_FIELDS: { key: keyof LunariaProfile; label: string; hint: string }[] =
    [
        {
            key: 'appearance',
            label: 'Aparência',
            hint: 'Idade aparente, pele, porte físico (sempre adulta)',
        },
        { key: 'hair', label: 'Cabelo', hint: 'Cor, corte e franja' },
        { key: 'eyes', label: 'Olhos', hint: 'Cor e expressão do olhar' },
        { key: 'clothes', label: 'Roupas', hint: 'Vestido, tecidos, detalhes' },
        { key: 'accessories', label: 'Acessórios', hint: 'Colar, anéis, tiara' },
    ]

export const buildProfilePrompt = (profile: LunariaProfile): string =>
    [profile.appearance, profile.hair, profile.eyes, profile.clothes, profile.accessories]
        .map((part) => part.trim())
        .filter((part) => part.length > 0)
        .join(', ')

/**
 * Aviso honesto sobre consistência visual. Vai na tela de geração, não é letra
 * miúda: modelos gratuitos não mantêm o mesmo rosto entre imagens.
 */
export const CONSISTENCY_NOTE =
    'Atenção: os modelos gratuitos não guardam a identidade da personagem entre imagens. Cada geração é independente, então o rosto, o cabelo e o vestido podem mudar de uma imagem para outra, mesmo com o perfil preenchido. O perfil ajuda a manter o estilo geral (cor de cabelo, roupa, clima), mas não garante o mesmo rosto.'

export const POLICY_NOTE =
    'Permitido: personagens adultos, sensualidade sem nudez, moda alternativa e cenas românticas. Recusado: nudez sexual explícita, atos sexuais, menores de idade e coerção. A recusa acontece no aparelho, antes de qualquer envio.'
