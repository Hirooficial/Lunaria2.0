/**
 * Montagem do prompt final de imagem.
 *
 * Fluxo obrigatório do pedido: o usuário escreve a descrição → a política de
 * conteúdo dá o parecer → **a descrição final é mostrada antes do envio** →
 * só então o provedor é chamado. Este módulo cuida do meio: transformar a
 * descrição em um prompt que os modelos entendem, com estilo, proporção e o
 * perfil visual da personagem quando pedido.
 *
 * Puro (testado em `tests/imageprompt.test.mjs`).
 */

import { assessImagePrompt, PolicyVerdict } from './ContentPolicy'
import {
    ASPECT_RATIOS,
    AspectRatioId,
    buildProfilePrompt,
    DEFAULT_ASPECT_RATIO,
    DEFAULT_NEGATIVE_PROMPT,
    DEFAULT_STYLE,
    IMAGE_STYLES,
    ImageStyleId,
    LunariaProfile,
} from './ImageStyles'

/**
 * Âncora de idade. Vai em **todo** prompt, mesmo quando o usuário não menciona
 * idade: é o que reduz a chance de o modelo devolver um rosto infantil por
 * acidente em pedidos de "personagem jovem e delicada".
 */
export const ADULT_ANCHOR = 'adult woman, clearly over 25 years old'

const QUALITY_TAGS = 'highly detailed, sharp focus, best quality, coherent anatomy'

export type BuildPromptParams = {
    description: string
    styleId?: ImageStyleId
    aspectRatioId?: AspectRatioId
    /** Marca a caixa "usar a aparência da Lunaria" na tela. */
    includeCharacter?: boolean
    profile?: LunariaProfile
    /** Fixo para repetir a mesma imagem; aleatório quando o usuário pede outro resultado. */
    seed?: number
}

export type BuiltPrompt = {
    /** Texto exato enviado ao provedor. */
    prompt: string
    negativePrompt: string
    width: number
    height: number
    seed: number
    /** Texto em português mostrado ao usuário antes do envio. */
    preview: string
    verdict: PolicyVerdict
    styleId: ImageStyleId
    aspectRatioId: AspectRatioId
    includeCharacter: boolean
}

/** Semente estável: a mesma descrição tende à mesma imagem (reprodutibilidade). */
export const stableSeed = (text: string): number => {
    let hash = 2166136261
    for (let index = 0; index < text.length; index++) {
        hash ^= text.charCodeAt(index)
        hash = Math.imul(hash, 16777619)
    }
    return Math.abs(hash) % 1000000
}

/** Semente nova a cada geração, quando o usuário quer variar. */
export const randomSeed = (): number => Math.floor(Math.random() * 1000000)

export const buildImagePrompt = ({
    description,
    styleId = DEFAULT_STYLE,
    aspectRatioId = DEFAULT_ASPECT_RATIO,
    includeCharacter = false,
    profile,
    seed,
}: BuildPromptParams): BuiltPrompt => {
    const cleanDescription = (description ?? '').trim()
    const verdict = assessImagePrompt(cleanDescription)
    const style = IMAGE_STYLES[styleId] ?? IMAGE_STYLES[DEFAULT_STYLE]
    const ratio = ASPECT_RATIOS[aspectRatioId] ?? ASPECT_RATIOS[DEFAULT_ASPECT_RATIO]

    const parts: string[] = [ADULT_ANCHOR]

    // Descrição do usuário vem primeiro: ela é o pedido, o estilo é o acabamento.
    if (cleanDescription.length > 0) parts.push(cleanDescription)

    // Perfil da personagem só entra quando o usuário pede a Lunaria.
    if (includeCharacter && profile) {
        const profilePrompt = buildProfilePrompt(profile)
        if (profilePrompt.length > 0) parts.push(profilePrompt)
    }

    parts.push(style.prompt, QUALITY_TAGS)

    const prompt = parts.join(', ')
    const finalSeed = seed ?? randomSeed()

    const preview = [
        `Descrição final (enviada ao provedor):`,
        prompt,
        ``,
        `Estilo: ${style.label} · ${ratio.label} (${ratio.width}×${ratio.height})`,
        includeCharacter
            ? `Aparência da Lunaria incluída (perfil visual editável).`
            : `Sem a aparência da Lunaria — só a sua descrição e o estilo.`,
        `Semente: ${finalSeed}`,
    ].join('\n')

    return {
        prompt,
        negativePrompt: DEFAULT_NEGATIVE_PROMPT,
        width: ratio.width,
        height: ratio.height,
        seed: finalSeed,
        preview,
        verdict,
        styleId: style.id,
        aspectRatioId: ratio.id,
        includeCharacter,
    }
}
