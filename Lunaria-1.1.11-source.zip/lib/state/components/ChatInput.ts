import { create } from 'zustand'

/** Mesmo formato usado pelo compositor da conversa (ver ChatInput/index.tsx). */
export type PendingAttachment = {
    uri: string
    type: 'image' | 'audio' | 'document'
    name: string
}

type ChatInputTextStoreProps = {
    text: string
    setText: (text: string) => void
    /**
     * Anexos que outra tela mandou para o compositor (ex.: imagem recém-gerada).
     * A tela de geração chama `attach()`; o compositor recolhe na volta.
     */
    pendingAttachments: PendingAttachment[]
    attach: (attachment: PendingAttachment) => void
    consumeAttachments: () => PendingAttachment[]
}

export const useChatInputTextStore = create<ChatInputTextStoreProps>()((set, get) => ({
    text: '',
    setText: (text) => set({ text }),
    pendingAttachments: [],
    attach: (attachment) =>
        set((state) => ({
            // Evita duplicar a mesma imagem se o usuário tocar duas vezes.
            pendingAttachments: state.pendingAttachments.some((item) => item.uri === attachment.uri)
                ? state.pendingAttachments
                : [...state.pendingAttachments, attachment],
        })),
    consumeAttachments: () => {
        const items = get().pendingAttachments
        if (items.length > 0) set({ pendingAttachments: [] })
        return items
    },
}))
