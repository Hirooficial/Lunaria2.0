/**
 * Estado do visualizador de imagem (uma instância só, montada no layout raiz).
 *
 * A conversa só manda "abre esta imagem"; quem sabe ampliar, salvar,
 * compartilhar e apagar é o visualizador — inclusive apagando o anexo da
 * mensagem certa, quando a imagem veio do chat.
 */

import { create } from 'zustand'

export type ImageViewerTarget = {
    /** Referência da imagem: `private://nome.lunaenc` (cofre) ou `file://`. */
    uri: string
    /** Nome amigável quando existe (imagens geradas pela Lunaria). */
    title?: string
    /** Preenchido quando a imagem está presa a uma mensagem do chat. */
    attachmentId?: number
    entryIndex?: number
}

type ImageViewerState = {
    visible: boolean
    target?: ImageViewerTarget
    openUri: (uri: string, options?: Omit<ImageViewerTarget, 'uri'>) => void
    close: () => void
}

export const useImageViewer = create<ImageViewerState>()((set) => ({
    visible: false,
    target: undefined,
    openUri: (uri, options) => set({ visible: true, target: { uri, ...options } }),
    close: () => set({ visible: false, target: undefined }),
}))
