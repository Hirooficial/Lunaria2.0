/**
 * Estado da geração de imagem.
 *
 * Regras que valem aqui:
 *  - a política de conteúdo decide **antes** de qualquer rede;
 *  - a descrição final é mostrada ao usuário antes do envio (nada sai sem ele ver);
 *  - só existe **uma** geração por vez, cancelável (um `AbortController`);
 *  - a imagem pronta é gravada cifrada no cofre e indexada em
 *    `lunaria-generated-images-v1` (limite de 500 entradas antigas);
 *  - baixar é uma ação explícita do usuário e sempre avisa que a cópia externa
 *    perde a proteção da Lunaria.
 */

import type * as MediaLibraryModule from 'expo-media-library'
import type * as SharingModule from 'expo-sharing'
import { create } from 'zustand'

import Alert from '@components/views/Alert'
import { assessImagePrompt, PolicyVerdict } from '@lib/imagegen/ContentPolicy'
import { buildImagePrompt, BuiltPrompt, randomSeed } from '@lib/imagegen/ImagePrompt'
import {
    generateImage,
    GenerationProgress,
    ImageGenerationError,
    ImageProviderId,
} from '@lib/imagegen/ImageProviders'
import {
    AspectRatioId,
    DEFAULT_LUNARIA_PROFILE,
    DEFAULT_NEGATIVE_PROMPT,
    ImageStyleId,
    LunariaProfile,
} from '@lib/imagegen/ImageStyles'
import { clearPrivateImageCache, forgetPrivateImage } from '@lib/security/PrivateImageCache'
import { exportFileName, toPrivateUri } from '@lib/security/PrivateNames'
import { privateVault } from '@lib/security/PrivateStorage'
import { Logger } from '@lib/state/Logger'
import { mmkv } from '@lib/storage/MMKV'
import { recordError } from '@lib/utils/Diagnostics'
import { carregarModuloNativo } from '@lib/utils/NativeModules'

// Galeria e compartilhamento entram sob demanda: são módulos novos na 1.1.x e
// um `import` no topo derrubaria o aplicativo na abertura em aparelho onde eles
// não respondam (ver `lib/utils/NativeModules.ts`).
const carregarMediaLibrary = () =>
    carregarModuloNativo<typeof MediaLibraryModule>('expo-media-library', () =>
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        require('expo-media-library')
    )

const carregarSharing = () =>
    carregarModuloNativo<typeof SharingModule>('expo-sharing', () =>
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        require('expo-sharing')
    )

const PREFS_KEY = 'lunaria-image-prefs-v1'
const PROFILE_KEY = 'lunaria-visual-profile-v1'
const LIBRARY_KEY = 'lunaria-generated-images-v1'
const LIBRARY_LIMIT = 500

export type ImagePrefs = {
    provider: ImageProviderId
    styleId: ImageStyleId
    aspectRatioId: AspectRatioId
    /** Chave própria do usuário (opcional). Nunca é gravada em log. */
    apiKey?: string
    model?: string
}

const DEFAULT_PREFS: ImagePrefs = {
    provider: 'horde',
    styleId: 'gotico',
    aspectRatioId: 'retrato',
}

export type GeneratedImageEntry = {
    id: number
    fileName: string
    width: number
    height: number
    styleId: ImageStyleId
    provider: ImageProviderId
    prompt: string
    bytes: number
    createdAt: string
    seconds: number
}

const readPrefs = (): ImagePrefs => {
    const raw = mmkv.getString(PREFS_KEY)
    if (!raw) return { ...DEFAULT_PREFS }
    try {
        return { ...DEFAULT_PREFS, ...(JSON.parse(raw) as Partial<ImagePrefs>) }
    } catch {
        return { ...DEFAULT_PREFS }
    }
}

const writePrefs = (prefs: ImagePrefs) => mmkv.set(PREFS_KEY, JSON.stringify(prefs))

export const readLunariaProfile = (): LunariaProfile => {
    const raw = mmkv.getString(PROFILE_KEY)
    if (!raw) return { ...DEFAULT_LUNARIA_PROFILE }
    try {
        return { ...DEFAULT_LUNARIA_PROFILE, ...(JSON.parse(raw) as Partial<LunariaProfile>) }
    } catch {
        return { ...DEFAULT_LUNARIA_PROFILE }
    }
}

export const writeLunariaProfile = (profile: LunariaProfile) =>
    mmkv.set(PROFILE_KEY, JSON.stringify(profile))

const readLibrary = (): GeneratedImageEntry[] => {
    const raw = mmkv.getString(LIBRARY_KEY)
    if (!raw) return []
    try {
        return JSON.parse(raw) as GeneratedImageEntry[]
    } catch {
        return []
    }
}

const writeLibrary = (entries: GeneratedImageEntry[]) =>
    mmkv.set(LIBRARY_KEY, JSON.stringify(entries.slice(0, LIBRARY_LIMIT)))

type ImageGenerationState = {
    prefs: ImagePrefs
    profile: LunariaProfile
    library: GeneratedImageEntry[]
    /** Prévia mostrada antes de enviar. */
    draft?: BuiltPrompt
    progress?: GenerationProgress
    /** Resultado pronto, aguardando o usuário anexar à conversa. */
    result?: GeneratedImageEntry
    error?: { kind: string; message: string; hint: string }
    busy: boolean
    controller?: AbortController

    init: () => void
    setProvider: (provider: ImageProviderId) => void
    setStyle: (styleId: ImageStyleId) => void
    setAspectRatio: (aspectRatioId: AspectRatioId) => void
    setApiKey: (apiKey: string) => void
    setModel: (model: string) => void
    saveProfile: (profile: LunariaProfile) => void
    /** Monta a prévia (não envia nada). */
    preview: (params: {
        description: string
        includeCharacter: boolean
        styleId?: ImageStyleId
        aspectRatioId?: AspectRatioId
    }) => BuiltPrompt
    /** Envia de verdade, depois da confirmação do usuário. */
    start: (params: {
        description: string
        includeCharacter: boolean
        styleId?: ImageStyleId
        aspectRatioId?: AspectRatioId
    }) => Promise<GeneratedImageEntry | undefined>
    cancel: () => void
    retry: () => Promise<GeneratedImageEntry | undefined>
    discard: () => void
    saveImageToGallery: (entry: GeneratedImageEntry) => Promise<void>
    shareImage: (entry: GeneratedImageEntry) => Promise<void>
    deleteImage: (entry: GeneratedImageEntry) => Promise<void>
}

/** Aviso padrão quando a cópia sai da proteção da Lunaria. */
const externalCopyWarning = (action: 'galeria' | 'compartilhar') =>
    action === 'galeria'
        ? 'A imagem vai para a galeria do aparelho. Fora da Lunaria ela fica **sem** a proteção do aplicativo: qualquer app com acesso à galeria poderá vê-la.'
        : 'Ao compartilhar, a imagem é enviada para fora da Lunaria e perde a proteção do aplicativo no destino.'

export const useImageGeneration = create<ImageGenerationState>()((set, get) => ({
    prefs: DEFAULT_PREFS,
    profile: { ...DEFAULT_LUNARIA_PROFILE },
    library: [],
    busy: false,

    init: () => {
        // Preferências de imagem não podem impedir a abertura do aplicativo.
        try {
            set({ prefs: readPrefs(), profile: readLunariaProfile(), library: readLibrary() })
        } catch (error) {
            recordError('imagens (ajustes)', error)
        }
    },

    setProvider: (provider) => {
        const prefs = { ...get().prefs, provider }
        writePrefs(prefs)
        set({ prefs })
    },
    setStyle: (styleId) => {
        const prefs = { ...get().prefs, styleId }
        writePrefs(prefs)
        set({ prefs })
    },
    setAspectRatio: (aspectRatioId) => {
        const prefs = { ...get().prefs, aspectRatioId }
        writePrefs(prefs)
        set({ prefs })
    },
    setApiKey: (apiKey) => {
        const prefs = { ...get().prefs, apiKey }
        writePrefs(prefs)
        set({ prefs })
    },
    setModel: (model) => {
        const prefs = { ...get().prefs, model }
        writePrefs(prefs)
        set({ prefs })
    },
    saveProfile: (profile) => {
        writeLunariaProfile(profile)
        set({ profile })
    },

    preview: ({ description, includeCharacter, styleId, aspectRatioId }) => {
        const { prefs, profile } = get()
        const draft = buildImagePrompt({
            description,
            styleId: styleId ?? prefs.styleId,
            aspectRatioId: aspectRatioId ?? prefs.aspectRatioId,
            includeCharacter,
            profile,
        })
        set({ draft, error: undefined })
        return draft
    },

    start: async ({ description, includeCharacter, styleId, aspectRatioId }) => {
        const { prefs, profile, busy } = get()
        if (busy) return undefined

        const draft = buildImagePrompt({
            description,
            styleId: styleId ?? prefs.styleId,
            aspectRatioId: aspectRatioId ?? prefs.aspectRatioId,
            includeCharacter,
            profile,
        })

        // Portão de conteúdo: recusa local, sem gastar rede nem cota.
        const verdict: PolicyVerdict = assessImagePrompt(draft.prompt)
        if (!verdict.allowed) {
            set({
                draft,
                error: {
                    kind: verdict.category ?? 'recusa',
                    message: verdict.reason,
                    hint: 'Ajuste a descrição e tente de novo.',
                },
            })
            return undefined
        }

        const controller = new AbortController()
        set({
            busy: true,
            draft,
            controller,
            error: undefined,
            progress: { phase: 'preparando', message: 'Preparando o pedido…' },
        })

        try {
            const generated = await generateImage({
                provider: prefs.provider,
                prompt: draft.prompt,
                negativePrompt: draft.negativePrompt || DEFAULT_NEGATIVE_PROMPT,
                width: draft.width,
                height: draft.height,
                seed: draft.seed,
                apiKey: prefs.apiKey,
                model: prefs.model,
                signal: controller.signal,
                onProgress: (progress) => set({ progress }),
            })

            // Grava cifrado no cofre e indexa.
            const stored = privateVault.writeFile(generated.bytes)
            const entry: GeneratedImageEntry = {
                id: Date.now(),
                fileName: stored.fileName,
                width: draft.width,
                height: draft.height,
                styleId: draft.styleId,
                provider: generated.provider,
                prompt: draft.prompt,
                bytes: generated.bytes.length,
                createdAt: new Date().toISOString(),
                seconds: generated.elapsedSeconds,
            }
            const library = [entry, ...get().library].slice(0, LIBRARY_LIMIT)
            writeLibrary(library)
            set({
                library,
                result: entry,
                busy: false,
                controller: undefined,
                progress: {
                    phase: 'concluido',
                    message: 'Imagem pronta.',
                    elapsedSeconds: entry.seconds,
                },
            })
            return entry
        } catch (error) {
            const failure =
                error instanceof ImageGenerationError
                    ? error
                    : new ImageGenerationError(
                          'desconhecido',
                          'Não foi possível gerar a imagem.',
                          String((error as Error)?.message ?? error)
                      )
            Logger.error(`Geração de imagem falhou (${failure.kind}): ${failure.message}`)
            set({
                busy: false,
                controller: undefined,
                error: { kind: failure.kind, message: failure.message, hint: failure.hint },
                progress:
                    failure.kind === 'cancelado'
                        ? { phase: 'cancelado', message: 'Geração cancelada.' }
                        : { phase: 'erro', message: failure.message },
            })
            return undefined
        }
    },

    cancel: () => {
        const controller = get().controller
        controller?.abort()
        set({
            busy: false,
            controller: undefined,
            progress: { phase: 'cancelado', message: 'Geração cancelada.' },
        })
    },

    retry: async () => {
        const draft = get().draft
        if (!draft) return undefined
        return get().start({
            description: draft.prompt,
            includeCharacter: draft.includeCharacter,
            styleId: draft.styleId,
            aspectRatioId: draft.aspectRatioId,
        })
    },

    discard: () =>
        set({ draft: undefined, result: undefined, error: undefined, progress: undefined }),

    saveImageToGallery: async (entry) => {
        Alert.alert({
            title: 'Salvar na galeria',
            description: externalCopyWarning('galeria'),
            buttons: [
                { label: 'Cancelar', type: 'default' },
                {
                    label: 'Salvar',
                    type: 'warning',
                    onPress: async () => {
                        try {
                            const { uri } = privateVault.exportToCache(entry.fileName)
                            const MediaLibrary = carregarMediaLibrary()
                            if (!MediaLibrary) {
                                Alert.alert({
                                    title: 'Galeria indisponível',
                                    description:
                                        'O módulo de galeria não respondeu neste aparelho. A imagem continua no cofre da Lunaria — use Compartilhar, escolhendo "Salvar em Fotos". O motivo está no relatório de diagnóstico.',
                                    buttons: [{ label: 'Entendi' }],
                                })
                                return
                            }
                            // No Android 10+ salvar na galeria não exige permissão;
                            // em versões antigas, o pedido pode ser negado.
                            const permission = await MediaLibrary.requestPermissionsAsync(false)
                            if (!permission.granted && permission.canAskAgain === false) {
                                Alert.alert({
                                    title: 'Permissão necessária',
                                    description:
                                        'Sem permissão de acesso às fotos, a Lunaria não consegue salvar na galeria. Você pode abrir o compartilhamento e escolher outro destino.',
                                    buttons: [{ label: 'Entendi' }],
                                })
                                return
                            }
                            await MediaLibrary.saveToLibraryAsync(uri)
                            Alert.alert({
                                title: 'Imagem salva',
                                description:
                                    'A cópia foi para a galeria do aparelho, fora da proteção da Lunaria.',
                                buttons: [{ label: 'Entendi' }],
                            })
                        } catch (error) {
                            Logger.error('Falha ao salvar na galeria: ' + error)
                            Alert.alert({
                                title: 'Não deu para salvar',
                                description:
                                    'A imagem continua no cofre da Lunaria. Tente pelo botão Compartilhar, escolhendo "Salvar em Fotos".',
                                buttons: [{ label: 'Entendi' }],
                            })
                        }
                    },
                },
            ],
        })
    },

    shareImage: async (entry) => {
        Alert.alert({
            title: 'Compartilhar',
            description: externalCopyWarning('compartilhar'),
            buttons: [
                { label: 'Cancelar', type: 'default' },
                {
                    label: 'Compartilhar',
                    type: 'warning',
                    onPress: async () => {
                        try {
                            const { uri } = privateVault.exportToCache(entry.fileName)
                            const Sharing = carregarSharing()
                            if (!Sharing) {
                                Alert.alert({
                                    title: 'Compartilhamento indisponível',
                                    description:
                                        'O módulo de compartilhamento não respondeu neste aparelho. A imagem continua no cofre da Lunaria. O motivo está no relatório de diagnóstico.',
                                    buttons: [{ label: 'Entendi' }],
                                })
                                return
                            }
                            if (!(await Sharing.isAvailableAsync())) {
                                Alert.alert({
                                    title: 'Compartilhamento indisponível',
                                    description:
                                        'Este aparelho não oferece o menu de compartilhar.',
                                    buttons: [{ label: 'Entendi' }],
                                })
                                return
                            }
                            await Sharing.shareAsync(uri, {
                                mimeType: 'image/*',
                                dialogTitle: 'Compartilhar imagem da Lunaria',
                            })
                        } catch (error) {
                            Logger.error('Falha ao compartilhar: ' + error)
                            Alert.alert({
                                title: 'Não deu para compartilhar',
                                description: 'Tente novamente em alguns instantes.',
                                buttons: [{ label: 'Entendi' }],
                            })
                        }
                    },
                },
            ],
        })
    },

    deleteImage: async (entry) => {
        Alert.alert({
            title: 'Apagar imagem',
            description:
                'A imagem sai do cofre da Lunaria e não pode ser recuperada. Se você já salvou uma cópia na galeria, essa cópia continua lá — a Lunaria não controla arquivos fora dela.',
            buttons: [
                { label: 'Cancelar', type: 'default' },
                {
                    label: 'Apagar',
                    type: 'warning',
                    onPress: async () => {
                        privateVault.deleteFile(entry.fileName)
                        forgetPrivateImage(entry.fileName)
                        const library = get().library.filter((item) => item.id !== entry.id)
                        writeLibrary(library)
                        set({
                            library,
                            result: get().result?.id === entry.id ? undefined : get().result,
                        })
                    },
                },
            ],
        })
    },
}))

/** Chamado ao bloquear: nenhum temporário decifrado pode sobreviver ao bloqueio. */
export const clearDecryptedImages = () => clearPrivateImageCache()
