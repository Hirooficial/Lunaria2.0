import { fetch } from 'expo/fetch'

import { Logger } from '@lib/state/Logger'

import { StreamDecoder } from './StreamDecoder'

type SSEValues = {
    endpoint: string
    method: 'POST' | 'GET'
    body: string
    headers: any
}

export class SSEFetch {
    private abortController: AbortController = new AbortController()
    private onEvent = (data: string) => {}
    private onError = () => {}
    private onClose = () => {}
    private closeStream = () => {}
    private cancelled = false
    public abort() {
        this.cancelled = true
        this.abortController.abort()
        this.closeStream()
    }

    public async start(values: SSEValues) {
        this.abortController = new AbortController()
        const body = values.method === 'POST' ? { body: values.body } : {}
        this.cancelled = false
        const decoder = new StreamDecoder()
        try {
            const res = await fetch(values.endpoint, {
                signal: this.abortController.signal,
                method: values.method,
                headers: values.headers,
                ...body,
            })
            if (res.status !== 200 || !res.body) {
                Logger.error('Status ' + res.status)
                Logger.error(await res.text())
                return this.onError()
            }
            const reader = res.body.getReader()
            this.closeStream = () => {
                this.cancelled = true
                void reader.cancel().catch(() => {})
            }
            while (true) {
                const { value, done } = await reader.read()
                if (this.cancelled) break
                if (done) {
                    decoder.finish().forEach((item) => this.onEvent(item))
                    if (decoder.incomplete) this.onError()
                    break
                }
                decoder.push(value).forEach((item) => this.onEvent(item))
                if (decoder.done) {
                    await reader.cancel()
                    break
                }
            }
        } catch (e) {
            if (this.cancelled || this.abortController.signal.aborted) {
                Logger.debug('Abort caught')
            } else {
                Logger.error('Request Failed: ' + e)
                this.onError()
            }
        } finally {
            this.closeStream = () => {}
            this.onClose()
        }
    }

    public setOnEvent(callback: (data: string) => void) {
        this.onEvent = callback
    }

    public setOnError(callback: () => void) {
        this.onError = callback
    }

    public setOnClose(callback: () => void) {
        this.onClose = callback
    }
}
