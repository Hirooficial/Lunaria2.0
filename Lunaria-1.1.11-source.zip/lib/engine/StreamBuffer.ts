/**
 * The generation buffer is a single global string shared by every conversation.
 * Before this guard, a stream that was still running (or a leftover from a
 * previous answer) kept appending into that shared buffer, so a brand new
 * answer could start with text that belonged to another chat, another swipe or
 * an older draft. The saved message inherited the same contamination.
 *
 * The buffer now records which swipe owns its content, and a chunk coming from
 * a different swipe never inherits foreign text.
 */

export type SourcedBuffer = {
    data: string
    swipeId?: number
}

/** True when the buffer content can be shown for this swipe. */
export const bufferBelongsToSwipe = (buffer: SourcedBuffer, swipeId?: number) =>
    buffer.swipeId === undefined || swipeId === undefined || buffer.swipeId === swipeId

/**
 * Appends a streamed chunk. An empty chunk never changes the buffer. A chunk
 * from another swipe replaces foreign content instead of concatenating it.
 */
export const appendStreamChunk = <T extends SourcedBuffer>(
    buffer: T,
    chunk: string,
    swipeId?: number
): T => {
    if (!chunk) return buffer
    const foreign = !bufferBelongsToSwipe(buffer, swipeId)
    return {
        ...buffer,
        swipeId: swipeId ?? buffer.swipeId,
        data: (foreign ? '' : buffer.data) + chunk,
    }
}
