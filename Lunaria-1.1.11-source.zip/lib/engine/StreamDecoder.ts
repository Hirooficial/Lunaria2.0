/** Decode network fragments without assuming they end on a character or event. */
export class StreamDecoder {
    private decoder = new TextDecoder('utf-8', { fatal: true })
    private pending = ''
    private data: string[] = []
    private eventLength = 0
    public done = false
    public incomplete = false

    push(bytes: Uint8Array): string[] {
        return this.consume(this.decoder.decode(bytes, { stream: true }))
    }

    finish(): string[] {
        const output = this.consume(this.decoder.decode())
        if (this.pending.endsWith('\r')) output.push(...this.consume('\n'))
        if (this.pending.trimStart().startsWith('{') && this.data.length === 0) {
            output.push(...this.line(this.pending))
        }
        this.incomplete = !this.done && (this.data.length > 0 || this.pending.startsWith('data:'))
        this.pending = ''
        this.data = []
        return output
    }

    private consume(text: string): string[] {
        this.pending += text
        const output: string[] = []
        let start = 0
        for (let i = 0; i < this.pending.length; i++) {
            const char = this.pending[i]
            if (char !== '\n' && char !== '\r') continue
            if (char === '\r' && i === this.pending.length - 1) break
            output.push(...this.line(this.pending.slice(start, i)))
            if (char === '\r' && this.pending[i + 1] === '\n') i++
            start = i + 1
        }
        this.pending = this.pending.slice(start)
        if (this.pending.length + this.eventLength > 1_048_576) {
            throw new Error('O servidor enviou um evento de texto grande demais.')
        }
        return output
    }

    private line(line: string): string[] {
        if (this.done) return []
        if (line === '') {
            const value = this.data.join('\n')
            this.data = []
            this.eventLength = 0
            if (value.trim() === '[DONE]') {
                this.done = true
                return []
            }
            return value ? [value] : []
        }
        if (line.trimStart().startsWith('{') && this.data.length === 0) {
            JSON.parse(line)
            return [line]
        }
        const colon = line.indexOf(':')
        const field = colon < 0 ? line : line.slice(0, colon)
        if (field !== 'data') return []
        let value = colon < 0 ? '' : line.slice(colon + 1)
        if (value.startsWith(' ')) value = value.slice(1)
        this.data.push(value)
        this.eventLength += value.length + 1
        if (this.eventLength > 1_048_576) throw new Error('Evento grande demais')
        return []
    }
}
