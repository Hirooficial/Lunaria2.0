import { nativeApplicationVersion } from 'expo-application'

import { AppSettings, CLAUDE_VERSION } from '@lib/constants/GlobalValues'
import { SSEFetch } from '@lib/engine/SSEFetch'
import { Logger } from '@lib/state/Logger'
import { mmkv } from '@lib/storage/MMKV'
import { getNestedValue } from '@lib/utils/Parsing'

import { APIConfiguration } from './APIBuilder.types'
import { buildContext, ContextBuilderParams } from './ContextBuilder'
import { buildRequest, RequestBuilderParams } from './RequestBuilder'

export interface APIBuilderParams
    extends ContextBuilderParams,
        Omit<RequestBuilderParams, 'prompt'> {
    onData: (data: string) => void
    onEnd: (data: string) => void
    stopSequence: string[]
    stopGenerating: (error?: string) => void
}

export const buildAndSendRequest = async ({
    apiConfig,
    apiValues,
    onData,
    onEnd,
    instruct,
    samplers,
    character,
    user,
    messages,
    stopSequence,
    stopGenerating,
    chatTokenizer,
    tokenizer,
    messageLoader,
    maxLength,
    cache,
    extraSystemContext,
}: APIBuilderParams) => {
    try {
        let payload: any = undefined
        const bypassContextLength = mmkv.getBoolean(AppSettings.BypassContextLength)
        const prompt = await buildContext({
            apiConfig,
            apiValues,
            instruct,
            character,
            user,
            messages,
            chatTokenizer,
            tokenizer,
            messageLoader,
            maxLength,
            cache,
            bypassContextLength,
            extraSystemContext,
        })
        if (prompt === undefined) {
            Logger.errorToast(`Prompt construction failed`)
            stopGenerating('Não foi possível montar o contexto da conversa.')
            return
        }

        payload = await buildRequest({
            apiConfig,
            apiValues,
            samplers,
            instruct,
            prompt,
            stopSequence,
        })

        if (!payload) {
            Logger.errorToast(`Payload construction failed`)
            stopGenerating('Não foi possível montar o pedido para a IA.')
            return
        }

        if (typeof payload !== 'string') {
            payload = JSON.stringify(payload)
        }

        let header: any = {}
        if (apiConfig.features.useKey) {
            const anthropicVersion =
                apiConfig.name === 'Claude' ? { 'anthropic-version': CLAUDE_VERSION } : {}

            header = {
                ...anthropicVersion,
                [apiConfig.request.authHeader]: apiConfig.request.authPrefix + apiValues.key,
            }
        }

        const response = responses[apiConfig.request.requestType]

        const replaceStrings = constructReplaceStrings(stopSequence)

        const parseOutput = (
            event: any,
            pattern: string | string[],
            prefixThinkTag: boolean = false,
            prefixExitThink: boolean = false
        ) => {
            try {
                const data = getNestedValue(
                    typeof event === 'string' ? JSON.parse(event) : event,
                    pattern
                ) as string | null
                const text = data?.replaceAll(replaceStrings, '') ?? ''
                if (text && prefixExitThink) onData('</think>')
                if (text && prefixThinkTag) onData('<think>')
                if (text) onData(text)
                return !!text?.trim()
            } catch (e) {
                Logger.error(JSON.stringify(e))
            }
            return false
        }
        let inReasoning = false
        const isChatCompletions = apiConfig.request.completionType.type === 'chatCompletions'

        return response({
            endpoint: apiValues.endpoint,
            payload: payload,
            onEvent: (event) => {
                if (
                    parseOutput(event, apiConfig.request.responseParsePattern, false, inReasoning)
                ) {
                    inReasoning = false
                    return
                }
                const reasonPattern = apiConfig.request.reasoningParsePattern
                // do not prefix think tags on text completions
                if (
                    reasonPattern &&
                    isChatCompletions &&
                    parseOutput(event, reasonPattern, !inReasoning)
                ) {
                    inReasoning = true
                }
            },
            onEnd: onEnd,
            header: header,
            stopGenerating: stopGenerating,
        })
    } catch (e) {
        Logger.errorToast('Completion failed: ' + e)
        stopGenerating(String(e))
    }
}

type KeyHeader = {
    [key: string]: string
}

type SenderParams = {
    endpoint: string
    payload: string
    header: KeyHeader
    onEnd: (data: string) => void
    onEvent: (event: any) => void
    stopGenerating: (error?: string) => void
}

const hordeResponse = (senderParams: SenderParams) => {
    const hordeURL = `https://aihorde.net/api/v2/`
    let generation_id = ''
    let aborted = false
    let finished = false
    let activeController: AbortController | undefined
    const startedAt = Date.now()
    const clientAgent = `Lunaria:${nativeApplicationVersion ?? '1.0.0'}:https://github.com/Vali-98/ChatterUI`

    const finish = (callEnd = false, error?: string) => {
        if (finished) return
        finished = true
        if (callEnd) senderParams.onEnd('')
        senderParams.stopGenerating(error)
    }

    const timedFetch = async (url: string, options: RequestInit, timeoutMs = 30_000) => {
        const controller = new AbortController()
        activeController = controller
        const timer = setTimeout(() => controller.abort(), timeoutMs)
        try {
            const response = await fetch(url, { ...options, signal: controller.signal })
            const body = await response.json()
            return { response, body }
        } finally {
            clearTimeout(timer)
            if (activeController === controller) activeController = undefined
        }
    }

    const cancelRemote = () => {
        if (generation_id) {
            const id = generation_id
            generation_id = ''
            const controller = new AbortController()
            const timer = setTimeout(() => controller.abort(), 10_000)
            fetch(`${hordeURL}generate/text/status/${id}`, {
                method: 'DELETE',
                signal: controller.signal,
                headers: {
                    ...senderParams.header,
                    'Client-Agent': clientAgent,
                    accept: 'application/json',
                    'Content-Type': 'application/json',
                },
            })
                .then((response) => response.text())
                .catch(Logger.error)
                .finally(() => clearTimeout(timer))
        }
    }

    const abortFn = () => {
        if (finished) return
        aborted = true
        activeController?.abort()
        cancelRemote()
        finish(false, 'Resposta interrompida.')
    }

    const sendRequest = async () => {
        Logger.info(`Using Horde`)

        try {
            const { response: request, body: requestBody } = await timedFetch(
                `${hordeURL}generate/text/async`,
                {
                    method: 'POST',
                    body: senderParams.payload,
                    headers: {
                        ...senderParams.header,
                        'Client-Agent': clientAgent,
                        accept: 'application/json',
                        'content-type': 'application/json',
                    },
                }
            )

            if (request.status !== 202 || !requestBody?.id) {
                const detail =
                    requestBody?.message ??
                    requestBody?.errors?.join?.(', ') ??
                    `HTTP ${request.status}`
                throw new Error(`Pedido recusado pela AI Horde: ${detail}`)
            }

            generation_id = requestBody.id
            if (aborted) {
                cancelRemote()
                return
            }
            let result: any

            do {
                await new Promise((resolve) => setTimeout(resolve, 3000))
                if (aborted) return
                if (Date.now() - startedAt > 180_000) {
                    throw new Error('A fila gratuita demorou mais de 3 minutos. Tente novamente.')
                }

                const { response, body } = await timedFetch(
                    `${hordeURL}generate/text/status/${generation_id}`,
                    {
                        method: 'GET',
                        headers: {
                            ...senderParams.header,
                            'Client-Agent': clientAgent,
                            accept: 'application/json',
                            'content-type': 'application/json',
                        },
                    }
                )
                result = body
                if (!response.ok) {
                    throw new Error(
                        result?.message ?? `Falha ao consultar a fila: HTTP ${response.status}`
                    )
                }
                if (result?.faulted) throw new Error('O nó voluntário falhou ao gerar a resposta.')
            } while (!result?.done)

            if (aborted) return
            const text = result?.generations?.[0]?.text
            if (!text?.trim()) throw new Error('A AI Horde devolveu uma resposta vazia.')

            senderParams.onEvent(result)
            generation_id = ''
            finish(true)
        } catch (error) {
            cancelRemote()
            if (aborted) return
            const detail = error instanceof Error ? error.message : `${error}`
            Logger.error(`Falha na AI Horde: ${detail}`)
            Logger.errorToast(`IA online: ${detail}`)
            finish(false, detail)
        }
    }
    void sendRequest()

    return abortFn
}

const readableStreamResponse = async (senderParams: SenderParams) => {
    const sse = new SSEFetch()
    let closed = false
    let failed = false

    const closeStream = () => {
        if (closed) return
        closed = true
        Logger.debug('Running Close Stream')
        if (!failed) senderParams.onEnd('')
        senderParams.stopGenerating(failed ? 'A resposta foi interrompida ou falhou.' : undefined)
    }

    sse.setOnEvent((data) => {
        try {
            const a = JSON.parse(data)
            if (a?.error) {
                failed = true
                Logger.errorToast('Error Logged')
                Logger.error(data)
                sse.abort()
                return
            }
        } catch {}
        senderParams.onEvent(data)
    })

    sse.setOnError(() => {
        failed = true
        Logger.errorToast('Generation Failed')
        closeStream()
    })

    sse.setOnClose(() => {
        Logger.info('Stream Closed')
        closeStream()
    })

    sse.start({
        endpoint: senderParams.endpoint,
        body: senderParams.payload,
        method: 'POST',
        headers: {
            accept: 'application/json',
            'Content-Type': 'application/json',
            ...senderParams.header,
        },
    })

    return () => {
        failed = true
        sse.abort()
        closeStream()
    }
}

const constructReplaceStrings = (stopSequence: string[]) => {
    const replace = RegExp(
        stopSequence.map((item) => item.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join(`|`),
        'g'
    )
    return replace
}

const responses: Record<
    APIConfiguration['request']['requestType'],
    (params: SenderParams) => Promise<() => void> | (() => void)
> = {
    horde: hordeResponse,
    stream: readableStreamResponse,
}
