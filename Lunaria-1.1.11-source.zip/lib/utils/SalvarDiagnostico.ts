import { breadcrumb, recordError } from './Diagnostics'

/**
 * Salva o relatório de diagnóstico na pasta **Downloads** do aparelho.
 *
 * Por que isto existe: quando o aplicativo não abre, o relatório **precisa sair do
 * aparelho** — senão não há como corrigir a causa. Havia dois caminhos, e os dois
 * podem falhar:
 *
 *  - o botão "Copiar diagnóstico" usa a área de transferência, que pode estar
 *    indisponível justamente quando o aplicativo está quebrado;
 *  - a captura nativa grava o arquivo em Downloads, mas só cobre falhas que
 *    acontecem **antes** do JavaScript (ver `CapturaDeFalha.kt`).
 *
 * Este é o terceiro caminho, para as falhas **dentro** do JavaScript: escreve o
 * mesmo texto do botão de copiar num arquivo chamado
 * `lunaria-diagnostico.txt`, na pasta Downloads, pelo mesmo utilitário que o
 * aplicativo já usa para exportar arquivos (`lib/utils/File.ts`).
 *
 * ## Carga tardia, de propósito
 *
 * `lib/utils/File.ts` importa `expo-file-system` e `expo-document-picker` no topo —
 * e os dois procuram o módulo nativo **no instante do import**, que é o defeito
 * registrado em `BUGS_FOUND.md` §AN. Como este módulo também é chamado da **tela de
 * emergência** (a que aparece quando o aplicativo não conseguiu carregar), a carga
 * acontece **na hora do uso**, dentro de `try/catch`: se falhar, devolve `false` e a
 * tela continua de pé, com o texto selecionável e o botão de copiar.
 *
 * Nunca lança. Nunca apaga nada: só acrescenta um arquivo.
 */
export const NOME_ARQUIVO_DIAGNOSTICO = 'lunaria-diagnostico.txt'

export const salvarDiagnosticoNoAparelho = async (texto: string): Promise<boolean> => {
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const { saveStringToDownload } = require('./File')
        await saveStringToDownload(texto, NOME_ARQUIVO_DIAGNOSTICO, 'utf8')
        breadcrumb('diagnóstico: relatório salvo em Downloads')
        return true
    } catch (erro) {
        // Não é motivo para assustar o usuário: o texto continua na tela e o botão
        // de copiar continua ali. O motivo entra no relatório, nomeado.
        recordError('diagnóstico: salvar em Downloads', erro)
        return false
    }
}
