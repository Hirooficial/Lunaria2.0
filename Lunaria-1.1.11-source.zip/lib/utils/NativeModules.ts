/**
 * Carregamento protegido de módulos nativos.
 *
 * ## Por que isto existe
 *
 * Um `import` no topo do arquivo é resolvido quando o pacote JavaScript é
 * avaliado — isto é, **antes** de qualquer tela, de qualquer proteção de
 * conteúdo e de qualquer `try/catch`. Vários pacotes do Expo procuram o módulo
 * nativo exatamente nesse instante:
 *
 * ```js
 * // node_modules/expo-sqlite/build/ExpoSQLite.js
 * export default requireNativeModule('ExpoSQLite')
 * ```
 *
 * Se essa procura falhar nesse aparelho, a exceção sobe durante a avaliação do
 * pacote e o aplicativo **fecha sem mensagem** — não há tela, não há relatório,
 * não há nada para o usuário copiar. Esse é o defeito registrado em
 * `BUGS_FOUND.md` §AN.
 *
 * Aqui a carga acontece no momento do uso, dentro de `try/catch`. Se falhar:
 *
 *  - o motivo entra no relatório de diagnóstico (`recordError`), identificado
 *    pelo nome do módulo;
 *  - a função devolve `null` e **quem chamou decide** — em geral degradando só
 *    aquele recurso (exportar para a galeria, por exemplo) em vez de derrubar o
 *    aplicativo inteiro.
 *
 * ## Regra de ouro
 *
 * Módulo **opcional** (recurso que pode faltar): use este carregador e trate o
 * `null` com mensagem clara. Módulo **essencial** (banco, preferências): use o
 * carregador e transforme o `null` em erro descritivo no ponto de uso — nunca
 * deixe a falha acontecer na avaliação do pacote.
 *
 * A carga é memorizada: o `require` do Metro já guarda o módulo, e a memória
 * evita repetir a tentativa e repetir o registro do mesmo erro no relatório.
 */

import { breadcrumb, recordError } from './Diagnostics'

const memorizados = new Map<string, unknown>()

export const carregarModuloNativo = <T>(nome: string, carregador: () => unknown): T | null => {
    if (memorizados.has(nome)) return memorizados.get(nome) as T | null

    try {
        const modulo = carregador()
        if (modulo == null) throw new Error('o módulo respondeu vazio')
        memorizados.set(nome, modulo)
        return modulo as T
    } catch (erro) {
        memorizados.set(nome, null)
        recordError(`ModuloNativo:${nome}`, erro)
        breadcrumb(`módulo nativo indisponível: ${nome}`)
        return null
    }
}

/** Somente para testes: esquece as tentativas já feitas. */
export const esquecerModulosNativos = () => memorizados.clear()

/** Nomes de módulos que falharam, para o relatório de diagnóstico. */
export const modulosIndisponiveis = () =>
    [...memorizados.entries()].filter(([, valor]) => valor === null).map(([nome]) => nome)
