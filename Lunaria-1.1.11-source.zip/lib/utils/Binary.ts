/**
 * Conversões binárias usadas pela criptografia e pelo provedor de imagem.
 *
 * Por que existe: o Hermes (motor JavaScript do React Native) **não garante**
 * `btoa`, `atob`, `TextEncoder` nem `TextDecoder`. Usar essas APIs direto
 * quebra em produção com "TextEncoder is not defined". Aqui a conversão é
 * feita à mão, sem depender de nada do ambiente — funciona no aparelho, no
 * Hermes e no Node (usado pelos testes automatizados).
 */

const BASE64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

const BASE64_LOOKUP: Record<string, number> = {}
for (let index = 0; index < BASE64_ALPHABET.length; index++) {
    BASE64_LOOKUP[BASE64_ALPHABET[index]] = index
}

/** Converte bytes crus em string base64 (sem quebras de linha). */
export const bytesToBase64 = (bytes: Uint8Array): string => {
    let result = ''
    for (let index = 0; index < bytes.length; index += 3) {
        const b0 = bytes[index]
        const b1 = index + 1 < bytes.length ? bytes[index + 1] : undefined
        const b2 = index + 2 < bytes.length ? bytes[index + 2] : undefined

        result += BASE64_ALPHABET[b0 >> 2]
        result += BASE64_ALPHABET[((b0 & 0b11) << 4) | ((b1 ?? 0) >> 4)]
        result += b1 === undefined ? '=' : BASE64_ALPHABET[((b1 & 0b1111) << 2) | ((b2 ?? 0) >> 6)]
        result += b2 === undefined ? '=' : BASE64_ALPHABET[b2 & 0b111111]
    }
    return result
}

/**
 * Converte base64 em bytes. Lança erro em entrada inválida em vez de devolver
 * lixo silencioso — quem chama precisa saber que a imagem chegou corrompida.
 */
export const base64ToBytes = (base64: string): Uint8Array => {
    const clean = base64.replace(/[\r\n\s]/g, '')
    if (clean.length % 4 !== 0) throw new Error('base64 inválido: tamanho não múltiplo de 4')

    const padding = clean.endsWith('==') ? 2 : clean.endsWith('=') ? 1 : 0
    const outputLength = (clean.length / 4) * 3 - padding
    if (outputLength < 0) throw new Error('base64 inválido: conteúdo vazio ou malformado')

    const output = new Uint8Array(outputLength)
    let position = 0

    for (let index = 0; index < clean.length; index += 4) {
        const chunk = clean.slice(index, index + 4)
        const values: number[] = []

        for (let offset = 0; offset < 4; offset++) {
            const char = chunk[offset]
            if (char === '=') {
                values.push(0)
                continue
            }
            const value = BASE64_LOOKUP[char]
            if (value === undefined) throw new Error(`base64 inválido: caractere "${char}"`)
            values.push(value)
        }

        const block = (values[0] << 18) | (values[1] << 12) | (values[2] << 6) | values[3]
        if (position < outputLength) output[position++] = (block >> 16) & 0xff
        if (position < outputLength) output[position++] = (block >> 8) & 0xff
        if (position < outputLength) output[position++] = block & 0xff
    }

    return output
}

/**
 * Texto UTF-8 → bytes, sem `TextEncoder`. Os acentos são codificados
 * manualmente porque as respostas da Lunaria são em português.
 */
export const textToBytes = (text: string): Uint8Array => {
    const output: number[] = []
    for (let index = 0; index < text.length; index++) {
        let code = text.charCodeAt(index)

        // Par substituto (emoji, por exemplo): recombina antes de codificar.
        if (code >= 0xd800 && code <= 0xdbff && index + 1 < text.length) {
            const next = text.charCodeAt(index + 1)
            if (next >= 0xdc00 && next <= 0xdfff) {
                code = ((code - 0xd800) << 10) + (next - 0xdc00) + 0x10000
                index++
            }
        }

        if (code < 0x80) {
            output.push(code)
        } else if (code < 0x800) {
            output.push(0xc0 | (code >> 6), 0x80 | (code & 0x3f))
        } else if (code < 0x10000) {
            output.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f))
        } else {
            output.push(
                0xf0 | (code >> 18),
                0x80 | ((code >> 12) & 0x3f),
                0x80 | ((code >> 6) & 0x3f),
                0x80 | (code & 0x3f)
            )
        }
    }
    return new Uint8Array(output)
}

/** Bytes UTF-8 → texto, sem `TextDecoder`. */
export const bytesToText = (bytes: Uint8Array): string => {
    let result = ''
    let index = 0

    while (index < bytes.length) {
        const byte = bytes[index]
        let code: number

        if (byte < 0x80) {
            code = byte
            index += 1
        } else if ((byte & 0xe0) === 0xc0) {
            code = ((byte & 0x1f) << 6) | (bytes[index + 1] & 0x3f)
            index += 2
        } else if ((byte & 0xf0) === 0xe0) {
            code =
                ((byte & 0x0f) << 12) | ((bytes[index + 1] & 0x3f) << 6) | (bytes[index + 2] & 0x3f)
            index += 3
        } else {
            code =
                ((byte & 0x07) << 18) |
                ((bytes[index + 1] & 0x3f) << 12) |
                ((bytes[index + 2] & 0x3f) << 6) |
                (bytes[index + 3] & 0x3f)
            index += 4
        }

        if (code > 0xffff) {
            code -= 0x10000
            result += String.fromCharCode(0xd800 + (code >> 10), 0xdc00 + (code & 0x3ff))
        } else {
            result += String.fromCharCode(code)
        }
    }

    return result
}

/** Junta vários blocos de bytes em um só (usado ao montar iv‖ciphertext‖tag). */
export const concatBytes = (...chunks: Uint8Array[]): Uint8Array => {
    const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0)
    const output = new Uint8Array(total)
    let offset = 0
    for (const chunk of chunks) {
        output.set(chunk, offset)
        offset += chunk.length
    }
    return output
}

/** Comparação em tempo constante — evita vazar informação por tempo de resposta. */
export const constantTimeEqual = (a: Uint8Array, b: Uint8Array): boolean => {
    if (a.length !== b.length) return false
    let difference = 0
    for (let index = 0; index < a.length; index++) {
        difference |= a[index] ^ b[index]
    }
    return difference === 0
}
