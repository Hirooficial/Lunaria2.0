/**
 * Diagnóstico de abertura.
 *
 * Por que existe: no aparelho, o aplicativo fechou ao abrir **sem dizer nada**. Em
 * versão de produção não existe caixa vermelha — um erro na abertura vira
 * silêncio, e sem texto não há como corrigir a causa.
 *
 * O que ele faz:
 *  - grava "migalhas" de percurso (em que passo o aplicativo está) num anel de
 *    tamanho fixo, no armazenamento local;
 *  - captura erros de JavaScript, promessas não tratadas e o que for escrito em
 *    `console.error`, guardando o último;
 *  - conta aberturas que **não terminaram**: duas seguidas ligam o **modo
 *    seguro**, que abre o aplicativo sem as camadas opcionais (geração de
 *    imagem, bloqueio de captura de tela, observador de notificações) para o
 *    chat continuar acessível;
 *  - monta um relatório que pode ser lido e copiado na tela.
 *
 * Regra de privacidade, sem exceção: aqui entram **passos, mensagens de erro e
 * versões do sistema**. Nunca conversa, nunca senha, nunca chave, nunca conteúdo
 * de imagem. O relatório é feito para ser mostrado ao Hamura e enviado a quem
 * conserta — então não pode conter nada que ele não queira mostrar.
 *
 * O armazenamento é injetável (`setDiagStorage`) porque o módulo real
 * (`react-native-mmkv`) é nativo: assim este arquivo pode ser testado em Node
 * puro, como o resto da lógica do projeto.
 */

export type DiagStep = {
    /** Momento do passo, em ISO 8601. */
    at: string
    /** O que o aplicativo estava fazendo. Texto curto e sem dado pessoal. */
    label: string
}

export type DiagError = {
    at: string
    /** Onde aconteceu (`bloqueio`, `imagens`, `tela`, `javascript`…). */
    kind: string
    /** Texto do erro (mensagem + começo da pilha). */
    text: string
}

export type DiagStorage = {
    getString: (key: string) => string | undefined
    set: (key: string, value: string) => void
    remove: (key: string) => void
}

export type DiagReportMeta = {
    appVersion?: string
    build?: string
    /** Ex.: `SM-A055F`. */
    model?: string
    /** Ex.: `Android 14 (SDK 34)`. */
    system?: string
    /** Memória total do aparelho, já formatada. */
    memory?: string
}

const RING = 'lunaria-diag-steps-v1'
const LAST_ERROR = 'lunaria-diag-erro-v1'
const IN_PROGRESS = 'lunaria-diag-em-curso-v1'
const FAILS = 'lunaria-diag-falhas-v1'
const SAFE_MODE = 'lunaria-diag-modo-seguro-v1'

/** Quantos passos ficam guardados (os mais recentes). */
export const MAX_STEPS = 40
/** Corte do texto de erro guardado, para o relatório não virar um romance. */
export const MAX_ERROR_CHARS = 4000
/** Duas aberturas seguidas sem terminar já justificam o modo seguro. */
export const FAILS_FOR_SAFE_MODE = 2

const memory = new Map<string, string>()

const memoryStorage: DiagStorage = {
    getString: (key) => memory.get(key),
    set: (key, value) => {
        memory.set(key, value)
    },
    remove: (key) => {
        memory.delete(key)
    },
}

let storage: DiagStorage = memoryStorage

/** Liga o diagnóstico ao armazenamento real. Feito no `MMKV.ts`, sem ciclo. */
export const setDiagStorage = (novo: DiagStorage) => {
    storage = novo
}

/** Volta ao armazenamento de memória (usado nos testes). */
export const resetDiagStorage = () => {
    memory.clear()
    storage = memoryStorage
}

/** Um erro no próprio diagnóstico não pode derrubar o aplicativo. */
const safe = <T>(acao: () => T): T | undefined => {
    try {
        return acao()
    } catch {
        return undefined
    }
}

const now = () => new Date().toISOString()

export const describeError = (error: unknown): string => {
    if (error instanceof Error) {
        const partes = [`${error.name}: ${error.message}`]
        if (error.stack) {
            // A primeira linha da pilha repete a mensagem; a partir da segunda
            // está o caminho real do defeito.
            const linhas = error.stack.split('\n')
            if (linhas.length > 1) partes.push(linhas.slice(1, 12).join('\n'))
        }
        return partes.join('\n').slice(0, MAX_ERROR_CHARS)
    }
    if (typeof error === 'string') return error.slice(0, MAX_ERROR_CHARS)
    const comoTexto = safe(() => JSON.stringify(error))
    return (typeof comoTexto === 'string' ? comoTexto : String(error)).slice(0, MAX_ERROR_CHARS)
}

export const readSteps = (): DiagStep[] => {
    const bruto = safe(() => storage.getString(RING))
    if (!bruto) return []
    try {
        const dados = JSON.parse(bruto)
        if (!Array.isArray(dados)) return []
        return dados.filter(
            (item): item is DiagStep =>
                !!item && typeof item.at === 'string' && typeof item.label === 'string'
        )
    } catch {
        return []
    }
}

export const breadcrumb = (label: string) => {
    const passos = readSteps()
    passos.push({ at: now(), label })
    while (passos.length > MAX_STEPS) passos.shift()
    safe(() => storage.set(RING, JSON.stringify(passos)))
}

export const recordError = (kind: string, error: unknown) => {
    const texto = describeError(error)
    const registro: DiagError = { at: now(), kind, text: texto }
    safe(() => storage.set(LAST_ERROR, JSON.stringify(registro)))
    // A primeira linha basta para o percurso; o texto inteiro fica no registro.
    breadcrumb(`erro em ${kind}: ${texto.split('\n')[0].slice(0, 120)}`)
}

export const readLastError = (): DiagError | undefined => {
    const bruto = safe(() => storage.getString(LAST_ERROR))
    if (!bruto) return undefined
    try {
        const dados = JSON.parse(bruto) as DiagError
        if (!dados || typeof dados.text !== 'string') return undefined
        return dados
    } catch {
        return undefined
    }
}

export const clearDiagnostics = () => {
    safe(() => storage.remove(RING))
    safe(() => storage.remove(LAST_ERROR))
}

export const markStartupBegin = () => {
    safe(() => storage.set(IN_PROGRESS, now()))
}

export const markStartupOk = () => {
    safe(() => storage.remove(IN_PROGRESS))
    safe(() => storage.set(FAILS, '0'))
}

export const isSafeMode = () => safe(() => storage.getString(SAFE_MODE)) === '1'

export const setSafeMode = (ligado: boolean) => {
    if (ligado) safe(() => storage.set(SAFE_MODE, '1'))
    else safe(() => storage.remove(SAFE_MODE))
}

export const readFailures = (): number => {
    const bruto = safe(() => storage.getString(FAILS))
    const numero = Number(bruto ?? 0)
    return Number.isFinite(numero) && numero > 0 ? numero : 0
}

export type StartupCheck = {
    /** A abertura anterior não chegou ao fim. */
    failedLastTime: boolean
    /** Quantas aberturas seguidas não terminaram. */
    failures: number
    /** Modo seguro ligado (agora, por causa destas falhas ou antes). */
    safeMode: boolean
}

/**
 * Chamado **uma vez**, no começo da abertura. Se a vez anterior ficou marcada
 * como "em curso", ela morreu no meio — conta a falha e, ao chegar no limite,
 * liga o modo seguro para a próxima tela poder aparecer.
 */
export const checkStartup = (): StartupCheck => {
    const emCurso = safe(() => storage.getString(IN_PROGRESS))
    let falhas = readFailures()

    if (emCurso) {
        falhas += 1
        safe(() => storage.set(FAILS, String(falhas)))
        safe(() => storage.remove(IN_PROGRESS))
    } else {
        falhas = 0
        safe(() => storage.set(FAILS, '0'))
    }

    let safeMode = isSafeMode()
    if (!safeMode && falhas >= FAILS_FOR_SAFE_MODE) {
        setSafeMode(true)
        safeMode = true
    }

    return { failedLastTime: !!emCurso, failures: falhas, safeMode }
}

const formatarMomento = (iso: string) => {
    const data = new Date(iso)
    if (Number.isNaN(data.getTime())) return iso
    return data.toLocaleString('pt-BR', { hour12: false })
}

/** Relatório em texto puro — é o que aparece na tela e o que se copia. */
export const buildReport = (meta: DiagReportMeta = {}): string => {
    const linhas: string[] = ['Lunaria — relatório de diagnóstico', '']
    linhas.push(`aplicativo: ${meta.appVersion ?? '?'} (build ${meta.build ?? '?'})`)
    linhas.push(`aparelho: ${meta.model ?? '?'} · ${meta.system ?? '?'} · ${meta.memory ?? '?'}`)
    linhas.push(`modo seguro: ${isSafeMode() ? 'ligado' : 'desligado'}`)
    linhas.push(`aberturas seguidas sem terminar: ${readFailures()}`)

    const erro = readLastError()
    linhas.push('', 'último erro registrado:')
    if (erro) {
        linhas.push(`  quando: ${formatarMomento(erro.at)}`)
        linhas.push(`  onde: ${erro.kind}`)
        for (const linha of erro.text.split('\n')) linhas.push(`  ${linha}`)
    } else {
        linhas.push('  (nenhum)')
    }

    const passos = readSteps()
    linhas.push('', `passos (${passos.length} últimos):`)
    if (passos.length === 0) linhas.push('  (nenhum)')
    for (const passo of passos) linhas.push(`  ${formatarMomento(passo.at)}  ${passo.label}`)

    linhas.push('', 'Observação: este relatório tem só passos e mensagens de erro.')
    linhas.push('Nenhuma conversa, senha ou imagem é registrada aqui.')
    return linhas.join('\n')
}

type GlobalComErros = {
    ErrorUtils?: {
        getGlobalHandler?: () => (error: unknown, isFatal?: boolean) => void
        setGlobalHandler?: (handler: (error: unknown, isFatal?: boolean) => void) => void
    }
}

let captureInstalled = false

/**
 * Instala a captura global. Precisa rodar **antes** de qualquer tela: um erro
 * durante a montagem do React não passa por `try/catch` de componente.
 *
 * O tratamento anterior é preservado — o objetivo é registrar, não engolir.
 */
export const installGlobalErrorCapture = () => {
    if (captureInstalled) return
    captureInstalled = true

    const global = globalThis as unknown as GlobalComErros
    const erros = global.ErrorUtils
    if (erros?.setGlobalHandler && erros.getGlobalHandler) {
        const antes = erros.getGlobalHandler()
        erros.setGlobalHandler((error, isFatal) => {
            recordError(isFatal ? 'javascript (fatal)' : 'javascript', error)
            if (typeof antes === 'function') antes(error, isFatal)
        })
    }

    const consoleOriginal = console.error
    console.error = (...args: unknown[]) => {
        // O aviso de promessa não tratada do React Native chega por aqui, então
        // isto cobre rejeições que de outro modo ficariam invisíveis.
        recordError('console.error', args.map(describeError).join(' '))
        consoleOriginal(...args)
    }
}
