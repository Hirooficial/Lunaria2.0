import type * as CryptoModule from 'expo-crypto'

import { recordError } from './Diagnostics'
import { carregarModuloNativo } from './NativeModules'

/**
 * Identificador aleatório para registros do aplicativo (conversas, anexos).
 *
 * Por que isto existe em vez de `import { randomUUID } from 'expo-crypto'`:
 * o `expo-crypto` procura o módulo nativo **no import**
 * (`requireNativeModule('ExpoCrypto')`, em `node_modules/expo-crypto/build/ExpoCrypto.js`),
 * e o estado do chat está no caminho da abertura. Um `import` no topo, ali,
 * significava aplicativo fechando sem mensagem em aparelho onde esse módulo não
 * respondesse — o mesmo defeito de `lib/storage/MMKV.ts` (`BUGS_FOUND.md` §AN).
 *
 * A carga é sob demanda e existe reserva em JavaScript puro: identificador é
 * identificador, e nenhum deles precisa de qualidade criptográfica. Segredos
 * (senha, chave do cofre) **não** passam por aqui — eles usam
 * `lib/security/Crypto.ts`, que falha alto se não houver fonte confiável.
 */
const carregarCrypto = () =>
    carregarModuloNativo<typeof CryptoModule>('expo-crypto', () => require('expo-crypto'))

let avisou = false

/** Identificador único no formato UUID v4 (com reserva em JavaScript puro). */
export const novoId = (): string => {
    const cripto = carregarCrypto()
    if (cripto) {
        try {
            // A conferência não é desconfiança gratuita: já vimos, em teste, uma
            // implementação de `randomUUID` responder `undefined` em vez de
            // lançar. Um identificador vazio gravaria anexo sem dono.
            const gerado = cripto.randomUUID()
            if (typeof gerado === 'string' && gerado.length > 0) return gerado
            recordError('identificador', new Error('randomUUID devolveu valor vazio; usando reserva'))
        } catch (erro) {
            recordError('identificador', erro)
        }
    } else if (!avisou) {
        avisou = true
        recordError(
            'identificador',
            new Error('expo-crypto indisponível; usando identificador de reserva')
        )
    }
    return uuidDeReserva()
}

const hex = (digitos: number): string =>
    Array.from({ length: digitos }, () => Math.floor(Math.random() * 16).toString(16)).join('')

/** UUID v4 de reserva: formato correto, aleatoriedade suficiente para nomear registro. */
export const uuidDeReserva = (): string => `${hex(8)}-${hex(4)}-4${hex(3)}-a${hex(3)}-${hex(12)}`
