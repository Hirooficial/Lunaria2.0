/**
 * Trilha de abertura — o **lado JavaScript**.
 *
 * ## O buraco que isto fecha
 *
 * A trilha nativa (`android/.../CapturaDeFalha.kt`) conta até onde o arranque
 * chegou: captura instalada, aplicativo criado, React Native carregado, tela
 * criada, abertura concluída. Só que a parte mais provável de um fechamento
 * silencioso fica **no meio**: entre "React Native carregado" e "abertura
 * concluída". Ali rodam banco, migrações, cofre, bloqueio, tema e a primeira tela
 * — e, se o processo morrer no meio disso sem exceção, a trilha nativa para em
 * `4/5` sem dizer o quê.
 *
 * O JavaScript já tinha migalhas (`./Diagnostics`), mas elas moram no
 * `react-native-mmkv` e só o próprio JavaScript consegue lê-las. Para ler, é
 * preciso o aplicativo **abrir** — que é justamente o que não acontece quando ele
 * fecha ao abrir. Ficava assim: a evidência existia e era inalcançável.
 *
 * Aqui a etapa é gravada em **dois** lugares, de uma vez:
 *
 *  1. na trilha nativa, pela ponte `NativeModules.TrilhaJs` — mesmo arquivo das
 *     etapas nativas, colhido na próxima abertura e **levado para a pasta
 *     Downloads**, mesmo que o aplicativo morra de novo;
 *  2. nas migalhas do relatório (`breadcrumb`), que é o que aparece na tela de
 *     diagnóstico quando o aplicativo consegue abrir.
 *
 * ## Regras que não podem ser quebradas
 *
 * - **Nunca lança.** Gravar trilha não pode ser motivo de falha. Tudo aqui devolve
 *   `true`/`false` e nenhuma exceção sai do módulo.
 * - **Nunca é pré-requisito.** Se a ponte nativa não existir no aparelho (registro
 *   indisponível), nada acontece além de não gravar — o caminho de abertura é o
 *   mesmo. Isso é testado: `tests/trilha-js.test.mjs`.
 * - **O primeiro toque em `react-native` é tardio.** Este arquivo não importa
 *   `react-native` no topo; o `require` acontece dentro da primeira marcação, sob
 *   `try/catch`. É a mesma disciplina do porteiro (`./EntradaSegura`): nada do que
 *   existe para diagnosticar pode virar parte do problema.
 * - **Texto curto e sem dado pessoal.** Nome de etapa, nada de conversa, senha,
 *   chave ou conteúdo — a trilha é feita para ser enviada a quem conserta.
 */

import { breadcrumb } from './Diagnostics'

/** Quem grava a etapa na trilha nativa. Injetável para poder ser testado. */
export type EscritorDaTrilha = (texto: string) => void

/** Quem guarda a migalha do relatório na tela. Também injetável. */
export type EscritorDeMigalha = (texto: string) => void

/** Prefixo que separa as etapas do JavaScript das etapas nativas na trilha. */
export const PREFIXO_JS = 'js '

let escritorInjetado: EscritorDaTrilha | null = null
let migalhaInjetada: EscritorDeMigalha | null = null
let escritorDoAparelho: EscritorDaTrilha | null = null
let jaProcurou = false

/**
 * Procura a ponte nativa **uma vez** e guarda o resultado (inclusive o fracasso).
 * Não fica tentando a cada etapa: se não existe, não existe.
 */
const acharEscritorDoAparelho = (): EscritorDaTrilha | null => {
    if (jaProcurou) return escritorDoAparelho
    jaProcurou = true
    try {
        // Tardio de propósito: este `require` só acontece no primeiro uso.
        const { NativeModules } = require('react-native')
        const ponte = (
            NativeModules as { TrilhaJs?: { marcarEtapa?: (texto: string) => void } } | undefined
        )?.TrilhaJs
        const marcar = ponte?.marcarEtapa
        if (typeof marcar === 'function') escritorDoAparelho = (texto: string) => marcar(texto)
    } catch {
        escritorDoAparelho = null
    }
    return escritorDoAparelho
}

/**
 * Marca uma etapa do JavaScript. `etapa` deve ser curta e descritiva
 * (ex.: `3/7 tela inicial montou`).
 *
 * Devolve `true` quando a etapa chegou ao arquivo da trilha no aparelho e `false`
 * quando não (ponte ausente, falha ao gravar). Os dois casos são normais do ponto
 * de vista de quem chama: o valor existe para o teste poder afirmar, não para
 * decidir comportamento.
 */
export const marcarEtapaJs = (etapa: string): boolean => {
    const texto = `${PREFIXO_JS}${etapa}`.slice(0, 200)
    let gravou = false

    // Canal 1 — arquivo da trilha, o que sobrevive à morte do processo.
    try {
        const escritor = escritorInjetado ?? acharEscritorDoAparelho()
        if (escritor) {
            escritor(texto)
            gravou = true
        }
    } catch {
        gravou = false
    }

    // Canal 2 — migalhas do relatório na tela. Independente do primeiro: um pode
    // funcionar sem o outro, e é justamente por isso que são dois.
    //
    // O padrão é o `breadcrumb` do diagnóstico; o desvio existe porque o
    // carregador de módulos do Node pode criar **duas instâncias** do mesmo
    // arquivo quando o especificador é escrito de formas diferentes (uma com
    // extensão, outra sem). Sob o Metro — e no Jest — há um grafo único, mas o
    // teste que roda em Node precisa poder falar com a instância de verdade em
    // vez de adivinhar qual é. Ver `tests/trilha-js.test.mjs`.
    try {
        ;(migalhaInjetada ?? breadcrumb)(texto)
    } catch {
        // Sem migalhas a tela de diagnóstico fica mais pobre, e só.
    }

    return gravou
}

/** Usado pelos testes (e por um app que queira desviar a trilha). */
export const setEscritorDaTrilha = (novo: EscritorDaTrilha | null) => {
    escritorInjetado = novo
}

/** Desvia o canal das migalhas (usado pelos testes; `null` volta ao padrão). */
export const setEscritorDeMigalha = (novo: EscritorDeMigalha | null) => {
    migalhaInjetada = novo
}

/** Zera a memória do módulo (usado pelos testes). */
export const esquecerEscritorDaTrilha = () => {
    escritorInjetado = null
    migalhaInjetada = null
    escritorDoAparelho = null
    jaProcurou = false
}
