type LunariaResponseContext = {
    response: string
    latestUserMessage?: string
    previousAssistantMessage?: string
}

/** Never manufacture an answer or rewrite quotations, links and code. */
export const polishLunariaResponse = ({
    response,
    latestUserMessage = '',
}: LunariaResponseContext) => {
    const cleaned = response
        .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
        .replace(/^\s*Lunaria\s*:\s*/i, '')
        .trim()
    const userText = latestUserMessage.trim()
    const newline = cleaned.indexOf('\n')
    if (userText && newline >= 0) {
        const opening = cleaned.slice(0, newline).trim()
        const rest = cleaned.slice(newline + 1).trim()
        if (rest && opening === userText) return rest
    }
    return cleaned
}
