import * as Notifications from 'expo-notifications'
import { router } from 'expo-router'
import { useCallback, useEffect } from 'react'
import { AppState, Linking, Platform } from 'react-native'
import { useMMKVBoolean } from 'react-native-mmkv'

import Alert from '@components/views/Alert'
import { AppSettings } from '@lib/constants/GlobalValues'
import { useAppLock } from '@lib/state/AppLock'
import { Characters } from '@lib/state/Characters'
import { Chats } from '@lib/state/Chat'
import { Logger } from '@lib/state/Logger'

export const setupNotifications = () => {
    Notifications.setNotificationHandler({
        handleNotification: async () => ({
            shouldPlaySound: false,
            shouldSetBadge: false,
            shouldShowAlert: false,
            shouldShowBanner: false,
            shouldShowList: false,
        }),
    })
}

export async function registerForPushNotificationsAsync() {
    if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('lunaria', {
            name: 'Lunaria',
            importance: Notifications.AndroidImportance.DEFAULT,
            vibrationPattern: [250, 0, 250, 250],
            lightColor: '#7d6294',
        })
    }

    const existingPermissions = (await Notifications.getPermissionsAsync()) as unknown as {
        granted?: boolean
        status?: string
    }
    let granted = existingPermissions.granted ?? existingPermissions.status === 'granted'
    if (!granted) {
        const requestedPermissions = (await Notifications.requestPermissionsAsync()) as unknown as {
            granted?: boolean
            status?: string
        }
        granted = requestedPermissions.granted ?? requestedPermissions.status === 'granted'
    }
    if (!granted) {
        Alert.alert({
            title: 'Permissão necessária',
            description: 'A Lunaria precisa de permissão para enviar notificações.',
            buttons: [
                {
                    label: 'Cancelar',
                },
                {
                    label: 'Abrir permissões',
                    onPress: () => {
                        Linking.openSettings()
                    },
                },
            ],
        })
        return false
    }

    return true
}

export function useAppStateNotificationObserver() {
    const [autoLoad] = useMMKVBoolean(AppSettings.ChatOnStartup)
    const [useAuth] = useMMKVBoolean(AppSettings.LocallyAuthenticateUser)
    const { chat, loadChat } = Chats.useChat()
    const { setCard } = Characters.useCharacterStore()

    const redirect = useCallback(
        async (notification: Notifications.Notification) => {
            if (chat ?? autoLoad ?? useAuth) return

            const data = notification.request.content.data
            const chatId = data?.chatId as number | undefined
            const characterId = data?.characterId as number | undefined

            if (chatId && characterId) {
                // Bloqueado: a conversa **não** abre antes da autenticação.
                // A intenção fica guardada e é atendida depois do desbloqueio.
                const lock = useAppLock.getState()
                if (lock.settings.enabled && lock.locked) {
                    lock.setPendingChat({ chatId, characterId })
                    Logger.info('Notificação recebida com o aplicativo bloqueado')
                    return
                }

                Logger.info('Loading chat from notification')
                try {
                    await loadChat(chatId)
                    await setCard(characterId)
                    router.navigate('/screens/ChatScreen')
                    Notifications.clearLastNotificationResponse()
                } catch (e) {
                    Logger.error('Failed to load chat: ' + e)
                }
            }
        },
        [chat, autoLoad, useAuth, loadChat, setCard]
    )

    useEffect(() => {
        const listener = AppState.addEventListener('change', async (nextState) => {
            if (nextState !== 'active') return

            const response = Notifications.getLastNotificationResponse()
            if (!response?.notification) {
                if ((await Notifications.getPresentedNotificationsAsync()).length > 0) {
                    await Notifications.dismissAllNotificationsAsync()
                }
                return
            }

            redirect(response.notification)
        })

        return () => {
            listener.remove()
        }
    }, [redirect])
}
