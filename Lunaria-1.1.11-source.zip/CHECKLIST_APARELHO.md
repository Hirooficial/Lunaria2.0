# Checklist no aparelho — Lunaria 1.1.11 (Galaxy A05s)

Este é o roteiro das **25** verificações que **só o aparelho** pode responder. Nada
aqui foi marcado como aprovado: este ambiente não tem aparelho, nem emulador, nem
`/dev/kvm`, e o APK é arm64. Ordem pensada para você achar problema cedo.

Anote o que acontecer (mesmo "funcionou" está bom) e me diga o resultado — eu
corrijo o que aparecer e registro em `BUGS_FOUND.md`.

O que **não** está mais nesta lista, porque foi verificado aqui: geração real
(com um 429 ao vivo no meio, recuperado), cancelamento com o provedor confirmando
`imagens=0`, assinatura do APK conferida, e a presença dos 12 recursos anteriores
dentro do APK entregue. O que sobra aqui é o que só o seu telefone responde.

**Atenção: o APK desta rodada é de diagnóstico** — sai sem R8 (a redução de
código foi desligada de propósito; motivo em `android/gradle.properties`). Ele tem
a mesma assinatura (a da 1.0.0), então instala por cima de qualquer versão anterior,
normal. Foque
nos itens **18, 19, 23, 24 e 25** desta lista antes de qualquer outro: eles respondem
ao fechamento ao abrir, que é o problema mais grave agora.

Antes de começar: instale o `Lunaria-1.1.11-arm64-release.apk` **por cima** da
1.0.0, sem desinstalar. Se a instalação recusar, copie a mensagem literal do
erro — o erro é a informação mais útil, e não quero que você apague dados como
primeira tentativa.

---

## Parte 1 — Atualização e dados antigos (5 min)

**1. Instalação por cima**
Esperado: instala sem pedir desinstalação e abre normalmente; nas configurações
aparece a versão 1.1.3 (código de versão 5).

**2. Conversas antigas continuam lá**
Abra uma conversa que já existia.
Esperado: histórico intacto, personalidade e ajustes como estavam.

**3. Imagens antigas migradas**
Abra uma conversa em que você já tinha enviado/recebido imagem.
Esperado: a imagem continua aparecendo. (Por dentro, ela passou de `Attachments/`
para `private/` com extensão `.lunaenc`.)

---

## Parte 2 — Bloqueio (10 min)

**4. Ativar proteção**
Ajustes → Proteção por senha → crie uma senha de 6 dígitos.
Esperado: aceita; avisa que a senha protege conversas e imagens.

**5. Fechar e reabrir**
Feche o app (remova dos recentes) e abra de novo.
Esperado: pede a senha **antes** de mostrar qualquer conversa. Nenhum texto de
conversa pode aparecer, nem por um instante, antes da tela de desbloqueio.

**6. Senha errada**
Erre 3, 4 e 5 vezes seguidas.
Esperado: espera crescente (1 s, 2 s, 4 s…), aviso de quantas tentativas
restam, e **nada é apagado** em momento algum.

**7. Voltar do segundo plano**
Saia do app (botão início), espere mais que o tempo configurado (padrão 5 min) e
volte.
Esperado: pede a senha de novo. Com "Bloquear agora" nos ajustes é imediato.

**8. Abrir por notificação estando bloqueado**
Com o app bloqueado, toque na notificação de resposta da Lunaria.
Esperado: pede a senha primeiro; a conversa só abre depois de desbloquear.

**9. Prévia nos recentes**
Com o app bloqueado, abra o seletor de apps recentes.
Esperado: não aparece conteúdo da conversa (e, se "impedir capturas" estiver
ligado, aparece tela preta).

**10. Impedir capturas de tela**
Ligue a opção, tente tirar print e depois grave a tela.
Esperado: captura bloqueada (tela preta ou erro do sistema). Desligue a opção no
final, se quiser.

**11. Áudio e microfone ao bloquear**
Com a leitura em voz alta falando, use "Bloquear agora".
Esperado: a fala para na hora e o microfone é liberado (o ícone de gravação do
sistema desaparece).

**12. Biometria**
Com digital ou rosto cadastrado, ative a biometria no bloqueio.
Esperado: desbloqueia pela digital/rosto; e a senha continua funcionando como
alternativa (teste as duas).

**13. Trocar a senha**
Troque a senha sabendo a atual.
Esperado: aceita; as imagens antigas continuam abrindo depois da troca.
(Este é o teste mais importante da criptografia: se a troca de senha perdesse a
chave, as imagens não abririam mais.)

**14. Esqueci a senha (só ler, não precisa fazer)**
Abra a tela de redefinir e leia o aviso **sem confirmar**.
Esperado: explica que, sem a senha, o conteúdo cifrado não pode ser recuperado e
que nada é apagado sem você confirmar. Se você confirmar, o app apaga o cofre e
define nova senha — por isso diga antes se quer testar isso, porque as imagens
protegidas antigas se perdem de propósito.

---

## Parte 3 — Geração de imagem (10 min)

**15. Gerar uma imagem de verdade**
Na conversa, toque em "Gerar imagem". Escreva algo como "a Lunaria num terraço à
noite, estilo gótico" e escolha a proporção retrato.
Esperado: mostra a **descrição final** antes de enviar; depois os estados
(conectando, na fila, gerando) e a imagem ao final; o app continua respondendo
durante a espera (a AI Horde tem fila e pode levar ~25 s ou mais).

**16. Filas longas e instabilidade (corrigido no caminho até a 1.1.2)**
O que aconteceu aqui, e o que observar: com a chave anônima a fila costuma ter
200+ pedidos, e o provedor às vezes responde "muitas consultas" (429) enquanto a
geração está viva. Esperado agora: o app **espera e volta a tentar** (a mensagem
mostra "aguardando um pouco"), em vez de cancelar e dizer que a cota acabou.
Se a geração morrer dizendo que a cota acabou com uma fila desse tamanho, é
defeito — me avise com o horário.

**17. Cancelar, errar de propósito e mexer na imagem**
- Cancelar no meio de uma geração → esperado: para sem travar e avisa que foi cancelado (e, por dentro, o trabalho é cancelado **no provedor** também — isso eu confiro pela medição do meu lado).
- Desligar a internet e gerar → esperado: mensagem clara de conexão, sem travar a interface.
- Pedir algo proibido (nudez explícita ou ato sexual) → esperado: recusa **antes** de enviar, explicando o motivo.
- Depois de gerada: ampliar com pinça, apagar, salvar na galeria (deve avisar que a cópia fora da Lunaria perde a proteção) e compartilhar.

---

## Parte 4 — Diagnóstico (o fechamento ao abrir)

**18. Abrir o aplicativo (o defeito relatado)**
Esperado: abre normalmente, na versão **1.1.11**.
Se aparecer uma **tela de relatório** (texto de computador, botão "Copiar
diagnóstico"): toque em copiar, cole no chat e me mande. É o dado que faltava.

Se ele abrir mas avisar que **o armazenamento não respondeu** (a Lunaria entra em
modo de reserva: abre, mas não grava preferências durante a sessão), isso também é
resultado: significa que o defeito é o que eu corrigi nesta versão, e o relatório
mostra qual módulo falhou. Copie com "Copiar diagnóstico".

**19. Fechar sem mostrar nada**
Abra **duas vezes seguidas** mesmo que feche.
Esperado: na segunda, entrar em **modo seguro** — o aplicativo abre, com um aviso
no topo e o botão "Sair do modo seguro". Se ele abrir assim, me diga: já sei que o
defeito está numa das camadas novas (imagem, captura de tela ou notificações).
Se continuar fechando, me diga também: significa que o defeito é anterior a elas.

**20. O que mudou na versão anterior (1.1.5) — teste curto**
A 1.1.5 não muda nada do que você usa: ela corrige **o ponto mais crítico da
abertura**, e eu o encontrei medindo, não adivinhando. Em uma frase: o banco de
dados — onde vivem suas conversas — era **aberto no instante em que o aplicativo
carregava**, antes de qualquer tela, de qualquer proteção e de qualquer tratamento
de erro. Se essa abertura falhasse (arquivo de banco corrompido por uma instalação
anterior, disco cheio), o aplicativo fechava **sem mensagem** — que é exatamente o
seu sintoma. Agora o banco abre **no primeiro uso**, dentro do tratamento de erro
da tela: se falhar, a Lunaria abre e mostra o motivo.

Na mesma rodada, três pontos iguais foram fechados: o módulo de identificação
(`expo-crypto`), o de biometria (`expo-local-authentication`) e uma falha em que o
identificador de um anexo podia sair vazio.

Para conferir isso em 30 segundos: abra o aplicativo (item 18) e, se ele abrir,
use normalmente o que você mais usa (conversar, ditar, ler em voz alta). Não é
preciso reinstalar nada nem apagar dados — é a mesma assinatura, então instala por
cima da 1.1.4, da 1.1.3, da 1.1.2 ou da 1.0.0.

**21. Suas conversas antigas**
Depois de abrir, entre em uma conversa que já existia antes da atualização e
confira que as mensagens estão lá.
Esperado: tudo no lugar. O banco de dados é justamente o que passou a abrir sob
demanda, e nada foi apagado nem recriado. Se aparecer conversa vazia ou erro de
banco, me diga: é o item mais importante desta lista depois do 18.

**22. Se aparecer uma TELA DE AVISO (novidade desta versão)**
O que mudou na 1.1.6: o aplicativo agora tem um **porteiro de entrada** — um
trecho que roda primeiro, antes de qualquer tela, e que existe para uma coisa só:
se o aplicativo falhar ao carregar, **ele abre e mostra o motivo**, em vez de
fechar sem dizer nada.

Então, se ao abrir aparecer uma tela escura com o título **"A Lunaria não
conseguiu abrir"**, com um texto de computador e um botão **"Copiar diagnóstico"**:

  - toque em **Copiar diagnóstico** e cole no chat comigo (é o texto que nomeia a
    causa do fechamento);
  - se o botão não funcionar, **tire uma foto da tela** — o texto também está lá,
    selecionável;
  - **não faça mais nada**: não desinstale, não limpe dados. Suas conversas e
    imagens continuam no aparelho; a tela diz isso.

Isso não é um erro novo: é o aplicativo finalmente conseguindo dizer o que já
dava errado em silêncio. Com esse texto eu corrijo a causa.


**23. NOVO — se ele fechar: o registro que sobe sozinho para a pasta Downloads**
Esta versão passou a gravar o motivo de uma falha **antes** de o aplicativo tentar
carregar qualquer coisa — e grava em **dois** lugares, um deles acessível a você:

  - pasta **Downloads** do aparelho → arquivo **`lunaria-ultimo-erro.txt`**.

O que fazer: abra **Meus arquivos** (ou o gerenciador de arquivos do seu celular) →
**Downloads** → procure `lunaria-ultimo-erro.txt` → toque em compartilhar e me mande
aqui na conversa. **Não precisa de computador.**

O arquivo tem: versão do aplicativo, modelo do aparelho, versão do Android, o
horário e o rastro da falha (ou o motivo informado pelo próprio Android, quando a
morte não gera exceção — falha de biblioteca nativa, travamento, memória).

Se **não** existir esse arquivo em Downloads, me diga isso também: significa que a
falha acontece antes de o processo conseguir escrever qualquer coisa — e aí o
caminho passa a ser o `logcat` do Android, que eu te explico como capturar quando
chegar o caso.

Detalhe honesto: eu já tinha essa captura funcionando desde a 1.1.3, mas ela gravava
só na pasta **privada** do aplicativo — que não dá para abrir pelo celular. Ou seja,
o motivo do fechamento estava sendo registrado e você não tinha como me mandar. É o
que esta versão conserta.


**24. NOVO — a trilha: em que etapa o arranque parou**
Esta versão grava uma linha com horário a cada etapa da abertura: captura
instalada → aplicativo criado → React Native carregado → tela criada → **abertura
concluída**. Se a abertura **não** chegar ao fim, na abertura seguinte esse
histórico vai para o mesmo arquivo da pasta Downloads.

Então: se o aplicativo fechar, abra de novo e olhe **Downloads** →
`lunaria-ultimo-erro.txt`. O começo do arquivo vai dizer algo como:

```
tipo: A ABERTURA ANTERIOR NÃO CHEGOU AO FIM
onde parou: 2026-09-19 18:22:41.003  3/5 React Native carregado
```

Esse "onde parou" é a informação que eu não tinha: ele diz **em qual etapa** o
aplicativo morreu — antes do React Native, subindo o motor JavaScript, ou montando
a tela. Me mande o arquivo (ou só essas duas linhas).

Detalhe: se o aplicativo **funcionar** normalmente, o arquivo **não** é criado —
ausência do arquivo é a boa notícia, não um problema.

Observação sobre o item 23: o arquivo agora é usado pelos dois caminhos — falha com
exceção e falha sem exceção. É o mesmo nome (`lunaria-ultimo-erro.txt`), sempre na
pasta Downloads.

**Correção da 1.1.11 no item 23 — o arquivo agora chega completo.** Antes, o motivo
da morte e a trilha eram gravados por dois processos separados no mesmo arquivo, e um
podia apagar o outro: você podia me mandar só o motivo, ou só a trilha. Agora é uma
gravação só, com as duas partes juntas — o arquivo começa com
`RELATÓRIO DA ABERTURA ANTERIOR` e traz o motivo e, em seguida, a trilha etapa por
etapa. Se você receber um arquivo com esse cabeçalho, ele está completo.

**25. NOVO (1.1.10) — agora a trilha também mostra até onde o JavaScript chegou**
Antes, a trilha sabia dizer o que aconteceu **antes** do JavaScript começar. No meio
do caminho — banco, senha, tema, primeira tela — ela parava em "4/5 tela criada" sem
dizer mais nada. Agora o próprio aplicativo escreve as etapas dele na mesma trilha,
numeradas de 1 a 8:

```
js 1/8 porteiro instalado          (o aplicativo começou a carregar)
js 2/8 rotas carregadas            (as telas foram carregadas)
js 3/8 tela inicial montou
js 4/8 bloqueio pronto             (senha/biometria prontas)
js 5/8 imagens prontas
js 6/8 banco migrado
js 7/8 Lunaria iniciada
js 8/8 lista de conversas na tela  (você está vendo as conversas)
```

Como usar: se o aplicativo fechar, **abra de novo** e olhe `lunaria-ultimo-erro.txt`
em Downloads. A linha "onde parou" vai dizer a última etapa — nativa ou `js`. Me
mande essa linha. Exemplos do que ela significa:

- parou em `js 3/8` → morreu montando a tela inicial;
- parou em `js 4/8` → morreu ao preparar o bloqueio (senha/biometria);
- parou em `js 6/8` → morreu nas migrações do banco;
- parou em `js 7/8` → morreu iniciando a Lunaria (personagem, ajustes, memória);
- parou em `js 8/8` ou em `5/5 ABERTURA CONCLUÍDA` → a abertura terminou (o problema,
  então, é **depois** de abrir — me diga em que momento fecha).

Falhas também deixam linha, com um `!` no lugar do número (por exemplo,
`js ! falha ao preparar o bloqueio: …`). Se aparecer uma linha dessas, ela é ainda
mais direta: é o motivo, não só o ponto.

Ressalva honesta: esta parte foi toda testada aqui, mas **só no aparelho** se
confirma que o aplicativo consegue mesmo escrever essas linhas. Se elas **não**
aparecerem no arquivo, isso também é informação — e significa que a ponte de escrita
não funcionou naquele aparelho; me diga, porque nesse caso o caminho volta a ser o
`logcat`.

**Item novo dentro do 24 — o botão "Salvar em Downloads".** Se aparecer a tela de
aviso do aplicativo (aquela "A Lunaria não conseguiu abrir"), ela agora tem **dois
botões**: "Copiar diagnóstico" e **"Salvar em Downloads"**. O segundo grava o
relatório em `lunaria-diagnostico.txt`, na pasta Downloads. Use-o se o botão de
copiar não responder ou se preferir me mandar o arquivo direto — **é o caminho mais
seguro**, porque não depende de colar texto.

---

## Como me reportar

Para cada item, basta uma linha: número + "ok" ou o que aconteceu de diferente.
Se algo falhar, o mais útil é: o que você fez, o que esperava, o que apareceu (e
a mensagem de erro, se houver). Com isso eu corrijo a causa e registro no
`BUGS_FOUND.md`.

Se você só tiver tempo para o essencial, faça nesta ordem: **1, 5, 7, 8, 13, 15, 16**
— são os que mais provavelmente revelam problema.
