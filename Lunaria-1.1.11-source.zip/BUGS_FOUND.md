# Correções e pendências

Este arquivo lista o que foi corrigido, o que foi **verificado nesta rodada** e
o que continua pendente por falta de aparelho.

## Corrigido e verificado no código (com teste automatizado)

| Problema | Alteração | Verificação |
| --- | --- | --- |
| Acentos/emoji quebrados entre partes da resposta | Decodificação UTF-8 incremental e eventos SSE completos em `lib/engine/StreamDecoder.ts` e `lib/engine/SSEFetch.ts` | `tests/stream.test.mjs`, 5 testes, incluindo todos os cortes de byte de uma mensagem com emoji |
| Sobra de outra resposta/conversa prefixando uma resposta nova | O buffer de geração agora tem dono: `lib/engine/StreamBuffer.ts` + swipe informado por `Inference.ts`, `LocalInference.ts`, `Chat.ts` e `TTS.ts` | `tests/buffer.test.mjs`, 5 testes |
| Texto de outra conversa aparecendo na tela | `ChatTextLast.tsx` só renderiza o buffer do swipe exibido | inspeção de código + teste de `bufferBelongsToSwipe` |
| Frases prontas, eco e perda da formatação | `lib/persona/ResponseGuard.ts` preserva Markdown, links, números e emoji; remove só controles, prefixo e eco exato | `tests/persona.test.mjs`, 4 testes |
| Cópias da mesma notícia tratadas como confirmações separadas | Agrupamento por similaridade de trechos (`groupIndependentSources`) e prompt que separa fatos, divergências, opiniões e evidências insuficientes | `tests/research.test.mjs`, 2 testes novos |
| Pesquisa com leitura sem limites, URLs locais e fontes repetidas | Limites de corpo/tempo, validação de URL e redirecionamento, diversidade de domínios, links manuais | `tests/research.test.mjs` |
| Contagem de tokens sem tokenizador | Estimativa conservadora por bytes UTF-8 em `lib/engine/Tokenizer.ts` | inspeção de código |
| Voz padrão em idioma inadequado | Padrão pt-BR em `lib/state/TTS.ts` | inspeção de código |
| Chat carregado antes da preparação inicial | Inicialização coordenada em `app/index.tsx` | inspeção de código |
| Pesquisa ativa persistindo indevidamente | Só as notas são gravadas; o salvamento é explícito | `lib/state/ResearchMemory.ts`, `app/screens/ResearchScreen.tsx` |

## Verificado nesta rodada (sem aparelho)

- **Compilação arm64**: `:app:assembleRelease` terminou (`BUILD SUCCESSFUL`,
  14m32s). O erro de `Binary store`/`EOFException` da tentativa anterior **não
  reapareceu**; ele não se reproduziu com `-Pkotlin.incremental=false` e com um
  único worker. A causa real da falha anterior não pôde ser confirmada — o
  ambiente foi reiniciado antes do fim —, então o registro honesto é: não
  reproduzido agora, possível cache inconsistente.
- **Falta de espaço em disco**: durante o build o sistema ficou com 0 bytes
  livres e a tarefa `:cui-llama.rn:copyReleaseJniLibsProjectOnly` falhou com
  `No space left on device`. Era o ambiente, não o projeto; resolvido liberando
  espaço. Registrado para quem compilar com pouco disco.
- **OpenMP**: as 14 bibliotecas `librnllama*.so` arm64 do APK têm **zero**
  símbolos indefinidos `__kmpc*`/`omp_*` e só dependem de `liblog`, `libandroid`,
  `libm`, `libdl` e `libc`. O `UnsatisfiedLinkError` de `__kmpc_fork_call` da
  versão antiga não pode vir destes binários.
- **Tokenizador embutido**: `assets/models/llama3tokenizer.gguf` entra no APK
  como `res/RT.gguf` (o otimizador de recursos encurta o nome). O aviso
  `expo-asset: .gguf is not a supported asset type` é sobre o plugin de assets e
  não impede o arquivo de ser empacotado como recurso `raw`.
- **IA remota**: pedido real à AI Horde anônima, com os mesmos parâmetros do
  aplicativo, respondeu corretamente (7,8 s, fila 0, sem falha de nó).

## Pendências que exigem o aparelho

### 1. Instalação e inicialização

Não houve instalação: este ambiente não tem aparelho por USB, emulador Android
nem `/dev/kvm` (e é x86_64, enquanto o APK é arm64-v8a). Conferir no A05s:
instalação, primeira abertura, migrações do SQLite e reinício sem perder dados.

### 2. Carregamento do GGUF e inferência local

Falta importar um GGUF compatível e medir memória, tempo até o primeiro token e
tokens por segundo. O padrão conservador (contexto 4096, lote 256, 4 threads,
`ctx_shift`) foi escolhido para 6 GB de RAM, mas **não foi medido em aparelho**.
Sugestão para o A05s: modelo de 1 B a 3 B com quantização Q4_K_M; comece pelo
contexto 2048 se notar reinício do aplicativo.

### 3. Caracteres, cancelamento e repetição no uso real

Os testes cobrem o transporte e o estado, não o comportamento do modelo. Falta
observar no aparelho: acentos e emoji durante a geração local, cancelar na fila
remota, cancelar no meio da resposta local, reenviar depois de cancelar e
alternar entre duas conversas durante a geração.

### 4. Busca automática (DuckDuckGo)

No ambiente de desenvolvimento a busca automática foi bloqueada. O aplicativo
explica a indisponibilidade e aceita dois ou mais links HTTPS. Testar a busca
automática na rede do celular; se continuar bloqueada em uso normal, avaliar
outro provedor documentando limites e privacidade.

### 5. Voz, notificações e segundo plano

Faltam: ditar em pt-BR e conferir o encerramento do microfone ao sair da
conversa; ler uma resposta em voz alta; verificar a geração com o aplicativo em
segundo plano e a notificação de conclusão.

### 6. Assinatura e atualização

O APK desta entrega é assinado com a chave de release da Lunaria (fora do ZIP).
Falta confirmar no aparelho que uma segunda instalação por cima da primeira
funciona sem desinstalar.

## Critério para fechar uma pendência

Só marcar como resolvido com: reprodução, mudança aplicada, comando/teste
executado e resultado observado. Sem aparelho, modelo ou rede, a pendência
continua aberta e registrada como tal.

---

# Rodada 2 (18/09/2026) — geração de imagem e bloqueio por senha

## Falhas encontradas durante a implementação (e corrigidas)

### 1. Política de conteúdo bloqueava pedidos legítimos com negação explícita

**Como apareceu:** teste automatizado `imagepolicy.test.mjs` — a descrição
“Lunaria com choker de renda e vestido longo, pose sensual, sem nudez” era
recusada, porque o filtro via a palavra “nudez” e não entendia a negação.

**Correção:** a lista de explícito agora ignora ocorrências negadas
(“sem”, “não”, “evitar”, “nada de”, “without”). A exceção vale **apenas** para a
lista de explícito: menores e coerção continuam sem qualquer flexibilização.
**Estado:** corrigido e coberto por teste (`permite ... sem nudez`).

### 2. Copiar imagem gerada para `Attachments/` duplicaria conteúdo em claro

**Como apareceu:** revisão do caminho de anexo — `createAttachment` copia o
arquivo para `documentos/Attachments/`, o que desfaria a cifragem no exato
momento de anexar.

**Correção:** anexo de imagem gerada não é copiado; a linha do banco aponta para
`private://nome`, o arquivo continua só no cofre cifrado. Apagar o anexo também
apaga o arquivo cifrado e o índice.
**Estado:** corrigido; verificação no aparelho pendente.

### 3. Com o app bloqueado, a notificação abriria a conversa sem autenticação

**Como apareceu:** revisão do caminho de entrada — o observador de notificações
chamava `loadChat` + `router.navigate` sem consultar o bloqueio, e a navegação
aconteceria antes da tela de desbloqueio.

**Correção:** com o bloqueio ativo, a intenção fica guardada (`pendingChat`) e só
é executada depois do desbloqueio; a notificação é limpa, não fica pendurada.
**Estado:** corrigido; teste no aparelho pendente.

### 4. Salvar na galeria falhava por permissão não declarada

**Como apareceu:** revisão do manifesto — `READ_MEDIA_IMAGES` não estava
declarado, então `requestPermissionsAsync` retornaria negado no Android 13+ e o
salvamento seria abortado mesmo quando o sistema permitiria gravar (API 29+ grava
via MediaStore sem permissão).

**Correção:** permissão declarada no manifesto e o fluxo de salvamento tenta a
gravação de qualquer forma, com mensagem clara se o sistema recusar.
**Estado:** corrigido; verificação no aparelho pendente.

### 5. PBKDF2 inicialmente caro demais para um aparelho de entrada

**Como apareceu:** medição no desktop com 210.000 iterações (≈473 ms). Num
aparelho modesto isso poderia passar de 1,5 s a cada desbloqueio.

**Correção:** 150.000 iterações (≈358 ms no desktop), ainda acima do mínimo
recomendado pela OWASP para PBKDF2-HMAC-SHA256. O valor é um único ponto de
ajuste em `lib/security/Crypto.ts`.
**Estado:** ajustado; medição real no A05s pendente.

## Pendências desta rodada (não são falhas, são verificações que exigem aparelho)

1. Gerar imagem real pelo aplicativo nos dois provedores, com internet do
   celular; conferir fila, tempo, cancelamento e nova tentativa.
2. Salvar na galeria e compartilhar, conferindo o aviso de perda de proteção.
3. Apagar imagem pelo visualizador e confirmar que o arquivo cifrado sumiu.
4. Bloqueio: senha errada (espera progressiva), reinício do aplicativo, volta do
   segundo plano, abertura por notificação, biometria, troca de senha.
5. Migração: atualizar por cima de uma instalação 1.0.0 com imagens em
   `Attachments/` e confirmar que aparecem normalmente depois da migração.
6. Conferir que nenhum conteúdo aparece antes da tela de desbloqueio (teste
   visual, gravando a tela).

## Critério para fechar uma pendência

Inalterado: só marcar como resolvido com reprodução, mudança aplicada,
comando/teste executado e resultado observado.

---

# Rodada 2 — falhas do build nesta máquina (registro honesto)

O código compila, mas o ambiente de build (2 núcleos, 1,9 GB de RAM, sem
`/dev/kvm`) derrubou o build duas vezes. Registro do que aconteceu e do que foi
feito, porque isso não pode virar “funcionou de primeira”:

### A. Daemon do Gradle morto por falta de memória (1ª tentativa, exit=1)

- **Sintoma**: `Gradle build daemon disappeared unexpectedly` ao compilar
  `llama.cpp` (`cui-llama.rn`), com três processos `clang++` consumindo mais de
  1,3 GB somados numa máquina de 1,9 GB.
- **Causa**: eu havia rodado `tsc`, `eslint` e a suíte de testes **em paralelo**
  com o build (um `tsc` ficou órfão ocupando ~400 MB). O kernel escolheu o maior
  processo e matou o daemon.
- **Correção**: encerrar os processos paralelos, esperar as compilações órfãs
  terminarem (o trabalho delas é reaproveitado pelo CMake) e repetir o build sem
  nada mais rodando junto.

### B. `OutOfMemoryError: Metaspace` no lint de bibliotecas (2ª tentativa, exit=1)

- **Sintoma**: `:react-native-gesture-handler:lintVitalAnalyzeRelease FAILED`,
  com dezenas de `metaspace` esgotado no log.
- **Causa**: o `lintVitalAnalyzeRelease` roda para **cada** módulo de biblioteca
  e é o maior consumidor de Metaspace do build de release. Eu tinha reduzido
  `-XX:MaxMetaspaceSize` para 384 MB ao mesmo tempo em que tirei memória do heap
  — combinação que quebra o lint, não o aplicativo.
- **Correção**: `android/build.gradle` desativa `lintVital*` **apenas nos módulos
  de biblioteca** (não no `:app`), com o motivo comentado no próprio arquivo, e o
  Metaspace voltou para 512 MB. O lint é análise estática: **não** faz parte do
  APK e não altera comportamento. Em máquina com memória sobrando, basta remover
  o bloco para voltar a rodá-lo.
- **Registrado como limitação do ambiente**, não como correção de código.

### C. Tentativas repetidas de build em ambiente apertado

- **Correção**: parâmetro `CMAKE_BUILD_PARALLEL_LEVEL=2` em
  `lunaria-build/build-apk-2.sh` para limitar a compilação nativa paralela, e a
  disciplina de não rodar nada pesado durante o build.

Nenhuma dessas três ocorrências tem relação com a geração de imagem, com o
bloqueio por senha ou com qualquer código desta entrega.

---

# Incidente de 18/09 — perda do workspace e reconstrução da rodada 2

Isto não é um bug do aplicativo, é um registro do que aconteceu com o ambiente e
do que foi feito. Está aqui porque o pedido foi claro: nada de esconder problema.

## O que aconteceu

Entre uma sessão de trabalho e a seguinte, o workspace da máquina de build foi
**revertido**: a árvore de código voltou ao estado anterior à rodada 2 (a versão
1.0.0), e sumiram junto:

- todos os arquivos novos da rodada 2 (`lib/security/`, `lib/imagegen/`,
  `lib/utils/Binary.ts`, telas de geração de imagem e de bloqueio, componentes);
- o APK 1.1.0 que já havia sido compilado e verificado;
- o toolchain em `/opt` (JDK, SDK, NDK) e o `node_modules`;
- os caches do Gradle e as saídas de build.

**Sobreviveram**: o keystore de assinatura (com a senha, fora do projeto), os
scripts de build, os documentos (`STATUS.md`, `TEST_REPORT.md`, este arquivo,
`CHANGELOG.md`, `IMAGEM_LOCAL_VIABILIDADE.md`, `GERACAO_DE_IMAGEM_E_BLOQUEIO.md`)
e o `package.json`/`package-lock.json` com todas as dependências da 1.1.0.

## O que foi feito

1. O código da rodada 2 foi **reescrito do zero**, usando os documentos
   sobreviventes como especificação (provedor, política de conteúdo, parâmetros
   de criptografia, chaves de configuração, comportamento da tela de bloqueio).
   Mesmo critério de antes: nada de resposta pronta, nada de atalho.
2. Toolchain reinstalado (`setup-toolchain.sh`) e dependências reinstaladas
   (`npm ci`) a partir do lockfile original — as versões são as mesmas.
3. Todos os portões foram rodados de novo nesta máquina, do zero: suíte de
   testes, `tsc` e ESLint. Os números estão em `TEST_REPORT.md`.
4. O APK foi recompilado e reassinado com **o mesmo keystore**, então a
   atualização continua instalando por cima da 1.0.0.

## Aprendizado registrado

- O keystore guardado **fora** do projeto (em `lunaria-assinatura/`) foi o que
  salvou a compatibilidade de atualização. Se ele tivesse ficado só dentro da
  árvore de build, os usuários teriam de desinstalar para instalar a 1.1.0.
- Documento que descreve decisão de projeto (provedor, criptografia, política)
  vale tanto quanto código: foi o que permitiu reconstruir sem adivinhar.
- `CHECKSUMS.sha256` e o ZIP de código-fonte **precisam** ser refeitos a cada
  build; um ZIP gerado antes de uma perda de arquivos parece válido e não é.

---

# Build da reconstrução (18/09) — três tentativas, duas falhas de ambiente

Registro do que atrapalhou o build depois da reconstrução. Nenhuma delas é bug do
aplicativo, e todas estão reproduzidas porque não se deve apresentar "compilou de
primeira" quando não foi.

### D. `minifyReleaseWithR8` sem heap depois de 1h52 (`java.lang.OutOfMemoryError: Java heap space`)

- **Sintoma**: o build ficou quase duas horas e morreu em
  `:app:minifyReleaseWithR8` com `OutOfMemoryError: Java heap space`. A máquina
  tem 2 GB de RAM e entrou em troca de página pesada (2,3 GB de swap em uso).
- **Causa**: o R8 em modo completo (full mode) precisa de muito mais heap do que
  os 1536 MB reservados para ele, ainda mais num APK que embute `llama.cpp`,
  Firebase/MLKit e 48 bibliotecas nativas.
- **Correção**: `android.enableR8.fullMode=false` em `android/gradle.properties`
  (modo de compatibilidade: continua fazendo shrinking e ofuscação, só não aplica
  as otimizações mais caras), heap em 2560 MB e `-XX:+UseSerialGC`.
- **Resultado**: build completo em **5m 33s** (929 tarefas, 331 executadas).
- **Impacto no aplicativo**: nenhum no comportamento; muda o nível de otimização
  do bytecode. Em máquina com folga de RAM, a linha pode ser removida.
- **Ressalva honesta**: o executável `:app:minifyReleaseWithR8` da reconstrução
  não é byte a byte o mesmo que o da tentativa anterior, mas o APK é equivalente
  em funcionalidade. O que **precisou** coincidir — o certificado de assinatura —
  coincide: `c0271509…5719a`, o mesmo da 1.0.0.

### E. Primeira tentativa de build da reconstrução: daemon do Gradle derrubado

- **Sintoma**: `Gradle build daemon disappeared unexpectedly` durante a
  compilação nativa, com o `kswapd0` consumindo CPU sem parar.
- **Causa**: `-Xmx1536m` somado às compilações `clang++` do `llama.cpp` estourou a
  memória física da máquina.
- **Correção**: nada pesado em paralelo com o build (nem testes, nem `tsc`) e
  limite de paralelismo nativo em 2 (`CMAKE_BUILD_PARALLEL_LEVEL=2`, já no
  `build-apk-2.sh`).

### F. Terceira tentativa: sucesso

`BUILD SUCCESSFUL in 5m 33s`, com as tarefas nativas já compiladas sendo
reaproveitadas. APK arm64-v8a de 60.463.298 bytes, assinado, com
`READ_MEDIA_IMAGES`, `allowBackup=false` e `dataExtractionRules` aplicados.

---

# Segunda perda de workspace e a cadeia de builds até o APK final (18/09, tarde)

O resumo honesto: o APK que eu já havia entregue (`629894dd…`) **deixou de existir**
quando o workspace foi revertido de novo no limite do turno. O ZIP do código
sobreviveu, foi de lá que eu restaurei tudo, e o APK final saiu de **sete**
tentativas de build nesta máquina. Nenhuma das falhas é bug do aplicativo; todas
são limite de ambiente (memória, disco, NDK removido por erro meu). Estão aqui
porque o relatório tem que dizer o que realmente aconteceu.

### G. Rollback nº 2: o APK perdido, o ZIP salvo

- **Sintoma**: ao retomar o trabalho, `lib/security/`, `lib/imagegen/`, as telas
  novas e as imagens nativas… nada disso estava na árvore; a entrega tinha
  `Lunaria-1.1.0-source.zip` (intacto, sha `5f789b6a…`, conferido) mas o APK
  havia desaparecido.
- **Causa**: mesmo comportamento de snapshot do ambiente já registrado na seção C
  (uma reversão no limite do turno). Os arquivos grandes são os primeiros a
  sumir; o ZIP de 7,5 MB sobreviveu, o APK de 57,7 MB não.
- **Correção**: `unzip` do ZIP em diretório limpo → 388 arquivos, conferidos
  contra o próprio `CHECKSUMS.sha256` do pacote → **todos OK**. O
  `android/keystore.properties` local (fora do ZIP, por segurança) foi devolvido
  a partir da cópia preservada.
- **Lição aplicada**: a partir de agora o ZIP do código é a fonte de recuperação
  e é regerado a cada mudança relevante; a entrega fica com o mínimo de arquivos
  grandes possível.

### H. Build nº 4: o kernel matou o Gradle (`Out of memory: Killed process`)

- **Sintoma**: `DaemonDisappearedException` depois de 40 min, com
  `dmesg` mostrando `oom-kill: … task=java,pid=13525` e
  `anon-rss:1691656kB`. Naquele momento o R8 **já tinha passado** — ou seja, a
  correção da seção D funcionou.
- **Causa raiz**: o daemon do Kotlin herdava `-Xmx2560m` do Gradle. Dois JVMs
  pedindo 2,5 GB numa máquina de 1,9 GB → o kernel escolheu um e matou.
- **Correção**: `kotlin.daemon.jvmargs=-Xmx1024m -XX:MaxMetaspaceSize=256m` em
  `android/gradle.properties` (teto explícito, em vez de herdar).
- **Não era**: falta de swap no primeiro momento — mas foi o que me levou a
  criar swap extra, que depois atrapalhou por consumir disco (seção K).

### I. Build nº 5: NDK apagado por engano (erro meu, não do projeto)

- **Sintoma**: `BUILD FAILED in 43s`, com AGP tentando instalar
  `NDK (Side by side) 27.0.12077973` e falhando com
  `java.io.IOException: No space left on device`.
- **Causa**: para liberar disco eu apaguei o NDK 27.0.12077973, deduzindo pelo
  plugin de compatibilidade do Expo que o projeto usaria só o 27.1.12297006.
  Errado: o script de toolchain instala **os dois de propósito** — o app compila
  com 27.1 e uma dependência Expo exige o 27.0 (isso já estava anotado em
  `COMECE_AQUI_ARENA.md`, eu não reli).
- **Correção**: `sdkmanager --install "ndk;27.0.12077973"` (27 s de download) e
  espaço em disco liberado antes. Registro para não repetir: **não remover NDK
  nenhum deste projeto**.

### J. Build nº 6: disco cheio (`No space left on device`)

- **Sintoma**: build morreu aos 14 min com `No space left on device`; o disco
  ficou em 100% (1,4 MB livres).
- **Causa**: as tentativas anteriores regeneraram transforms do Gradle
  (~2,9 GB) e `merged_native_libs` (~500 MB) em cima de um disco de 25 GB já
  ocupado por SDK (4,9 GB), dois NDKs (4 GB), `node_modules` (2,7 GB) e 6,8 GB de
  swap em arquivo.
- **Correção**: devolver o swap extra (`swapfile2`, 2,8 GB) — o motivo real da
  falta de memória era o daemon do Kotlin, já limitado — e remover bibliotecas
  de ciência de dados do Python da imagem base que este trabalho não usa.
  Espaço livre passou de 1,4 MB para 3,9 GB.

### K. Build nº 7: sucesso

```
> Task :app:minifyReleaseWithR8
BUILD SUCCESSFUL in 3m 17s
929 actionable tasks: 120 executed, 809 up-to-date
--- exit=0 Fri Sep 18 13:49:28 UTC 2026 ---
```

APK arm64-v8a de **60.463.298 bytes**, SHA-256
`6bcbede3ae8a2bf40aebc5f3549062a2ebe5dfd749ce3cf96a2559e2d1236608`, assinado
com o mesmo certificado da 1.0.0 (`c0271509…5719a`).

O `assets/index.android.bundle` saiu com **6.424.936 bytes** e o
`res/RT.gguf` com **7.818.140 bytes** — exatamente os mesmos tamanhos do APK
perdido, o que mostra que o código reconstruído é o mesmo; o que muda entre as
duas compilações é só o bytecode de assinatura/timestamps.

### Mudanças permanentes em `android/gradle.properties` por causa disso

- `android.enableR8.fullMode=false` — R8 em modo de compatibilidade (seção D).
- `kotlin.daemon.jvmargs=-Xmx1024m -XX:MaxMetaspaceSize=256m` — teto do daemon
  do Kotlin (seção H).
Nenhuma das duas altera o comportamento do aplicativo: uma muda o nível de
otimização do bytecode, a outra limita a memória de um processo de compilação.

### L. Causa provável das duas perdas de arquivo: teto de tamanho do workspace

- **Sintoma**: em duas ocasiões seguidas os artefatos grandes da entrega
  desapareceram entre um turno e outro — primeiro a árvore inteira da rodada 2,
  depois só o APK de 57,7 MB, sempre com os arquivos pequenos sobrevivendo
  (inclusive o ZIP de 7,5 MB).
- **Causa provável**: o workspace desta máquina é salvo com teto de
  aproximadamente **128 MB**. Medido agora: a pasta `/home/user` (sem os
  diretórios que ficam fora do snapshot, como `node_modules` e caches) somava
  **152 MB**, sendo 128 MB só da pasta `entrega` — com dois APKs de ~58 MB cada.
  Ou seja: o snapshot não cabia, e os arquivos maiores foram os sacrificados.
- **Correção aplicada**: manter na entrega apenas o artefato atual (APK 1.1.0 +
  ZIP do código) e remover o APK da 1.0.0, que está superado e pode ser
  reconstruído a partir de `Lunaria-1.0.0-source.zip` com o mesmo keystore.
  Total do snapshot caiu para ~95 MB, com folga em relação ao teto.
- **Lição**: a entrega é regenerável, mas o **ZIP do código é o item mais
  valioso em caso de perda** — é pequeno, sobrevive, e foi ele que permitiu
  restaurar tudo nas duas vezes.

---

# Camada de testes de renderização (18/09, depois do APK)

Resumo honesto: **nenhum bug do aplicativo foi encontrado** ao executar as
telas. Os 49 testes passaram depois de corrigir erros do próprio teste. O que
está registrado abaixo são aprendizados de ambiente e hipóteses minhas que
estavam erradas — vale guardar para não repetir.

### M. As telas nunca haviam sido executadas

- **Situação**: os 87 testes cobriam lógica pura. Um import quebrado, um
  símbolo inexistente numa tela ou um hook fora de ordem só apareceriam no
  aparelho — e não havia como saber se a tela de bloqueio, a de geração de
  imagem e a de conversa sequer montavam.
- **Ação**: camada nova com jest + jest-expo (preset que o `package.json` já
  declarava, mas nunca tinha sido usado): 49 testes em 6 suítes.
- **Resultado**: tudo passou. As telas montam e o ciclo da senha funciona com o
  código real. Não havia bug escondido nessa parte — mas isso **passou a ser
  sabido**, em vez de suposto.

### N. `jest.mock` não aceita variável de fora sem prefixo `mock`

- **Sintoma**: `The module factory of jest.mock() is not allowed to reference
  any out-of-scope variables. Invalid variable access: lockState`.
- **Causa**: o jest exige prefixo `mock` em qualquer variável usada dentro do
  `jest.mock` (proteção contra variável não inicializada).
- **Correção**: renomear para `mockLockState`. Serve de regra: em arquivo de
  teste, o que o mock usa começa com `mock`.

### O. Reanimated 4 e Worklets não rodam fora do aparelho

- **Sintoma**: `WorkletsError: Native part of Worklets doesn't seem to be
  initialized` — a suíte inteira morria no primeiro import.
- **Causa**: os dois dependem de código nativo (JSI).
- **Correção**: shims em `tests/render/mocks/reanimated.js` e `worklets.js`,
  ligados por `moduleNameMapper`. O shim dos componentes devolve os
  equivalentes do React Native (a árvore renderizada é a mesma, então dá para
  afirmar o que apareceu e o que não apareceu) e um Proxy cobre o resto.
- **Detalhe que quase passou batido**: o mock oficial
  (`react-native-reanimated/mock`) também importa o runtime nativo por dentro;
  não serve aqui.

### P. Três hipóteses minhas estavam erradas (erro no teste, não no código)

1. `privateVault.writeFile` eu supus `(nome, bytes)` e assíncrono; a assinatura
   real é `(bytes, label?)` e **síncrona**, devolvendo `{ fileName, uri }`, e a
   leitura é por `fileName`. O erro `label.trim is not a function` foi o aviso.
2. `defaultLockSettings` não existe em `LockPolicy` — o padrão seguro
   (`hideInNotifications: true`) mora em `AppLock.ts`. O teste passou a verificar
   o estado real do aplicativo, que é o que importa.
3. Supus que a senha não poderia estar na árvore renderizada. Ela está — no
   `value` do campo controlado, porque é assim que um campo de texto funciona
   no React. O que precisa ser verdade é: entrada mascarada, nenhum texto
   exibindo a senha, e nada dela em claro no armazenamento. Foi assim que o
   teste ficou, e essa versão verifica algo de valor.

### Q. Sons de plataforma: MMKV, SQLite, Nitro, teclado, toast

Cada um derrubou a suíte uma vez até entrar o mock correspondente
(`jest.setup.js`). O mais instrutivo: `expo-sqlite` falha ao abrir o banco nativo
e a cadeia chega até ele por caminhos inesperados (a tela de bloqueio importa o
plano de migração, que importa o banco). Depois disso, o sistema de arquivos
virou um sistema **em memória de verdade** — o que permitiu testar o cofre
ponta a ponta e provar que o arquivo gravado não tem o conteúdo em claro.

### R. O toolchain de build não sobrevive entre turnos (`/opt` é volátil)

- **Situação**: ao voltar para atualizar a documentação, `/opt/android-sdk` e
  `/opt/lunaria-tools/jdk17` estavam vazios — fora de `/home/user`, nada disso
  entra no snapshot. Foi por isso que uma verificação de assinatura falhou com
  `apksigner: No such file or directory`.
- **Consequência prática**: o APK entregue **não** foi afetado (o arquivo está em
  `/home/user/entrega`, byte a byte o mesmo que foi verificado: SHA-256
  `6bcbede3…6608`), mas qualquer build novo exige reinstalar o toolchain.
- **Como recuperar**: `bash /home/user/lunaria-build/setup-toolchain.sh` (JDK 17 +
  SDK android-36 + os **dois** NDKs + CMake + swap) e depois
  `bash /home/user/lunaria-build/build-apk-2.sh <log>` — o script já traz, no
  cabeçalho, os quatro requisitos aprendidos na maratona (memória, disco, NDKs,
  R8 em modo de compatibilidade).
- **Lição**: entre turnos, trate `/opt`, `node_modules` e `.gradle` como
  descartáveis; o que precisa durar tem de estar em `/home/user`.

---

# Rodada de verificação com o provedor real (18/09, à noite)

### S. DEFEITO REAL — 429 na consulta de status abortava a geração

- **Como apareceu**: gerando uma imagem de verdade pela linha de comando, com os
  mesmos parâmetros e cabeçalhos do aplicativo. O pedido foi aceito (HTTP 202,
  kudos 7,0, fila em **262** pedidos, espera estimada de ~970 s) — e a consulta de
  status começou a responder **429 (Too Many Requests)**. A chave anônima da
  Horde limita consultas repetidas; o 429 acontece mesmo com tudo certo.
- **Por que isso quebrava o aplicativo**: o laço de consulta fazia
  `if (!response.ok) throw errorFromStatus(response.status, …)`. Um 429 no meio
  de uma fila longa derrubava a geração inteira e mostrava **"cota esgotada"**
  para quem não tinha cota esgotada nenhuma — e a fila de 262 é o caso comum com
  a chave anônima, não a exceção.
- **Correção (na causa, não no sintoma)**: 429 e 5xx durante a consulta passaram a
  ser tratados como **passageiros** — o app espera e volta a consultar, com
  espera crescente (5 s → 10 s → 20 s, teto de 30 s), respeitando `Retry-After`
  quando o provedor manda. O que continua sendo erro definitivo: 401/403
  (autenticação), 404 (trabalho não encontrado) e 400 (pedido inválido). O
  intervalo entre consultas subiu de 3 s para 5 s.
- **Prova**: 6 testes novos em `tests/imageprovider.test.mjs` (arquivo com 19):
  429 repetido não cancela e a geração conclui; a espera tem teto; `Retry-After`
  é respeitado; 5xx é tolerado; 401 e 404 continuam abortando.
- **Estado**: corrigido e testado. **Não testado no aparelho** (segue no
  checklist), mas o caminho do provedor foi exercitado de verdade hoje.

### T. O que o verificador de assinatura sem SDK prova (e o que não prova)

- **O que prova** (`tools/verificar_assinatura.py`, entregue no ZIP): o
  certificado de assinatura e sua impressão digital SHA-256, que a chave pública
  do bloco de assinatura é a do certificado, e a validade criptográfica da
  assinatura sobre os dados assinados (conferida com `openssl`).
  Resultado para o APK da compilação nº 7: certificado
  `c0271509ad829da96e8fd205faa99b7103bf43c358a8501c0925606c7b55719a` — o mesmo
  registrado pelo `apksigner` para a 1.0.0 — e assinatura **"Verified OK"**.
- **O que não prova**: que o *conteúdo* do APK corresponde ao resumo assinado
  (árvore de Merkle). Tentei reproduzir o algoritmo (blocos de 1 MB, prefixo
  `0x5a`, com e sem ajuste do deslocamento do diretório central, arquivo inteiro,
  blocos de 4 KB, várias combinações): **nenhuma variante** gerou o resumo
  declarado. Falta algum detalhe do `apksig` que eu não tenho como conferir sem
  o SDK. Portanto: essa parte **não** está reproduzida aqui — depende do
  `apksigner`. Está registrado como pendente, não como verificado.
- **O que fecha a lacuna**: o `apksigner` roda quando o SDK está instalado (é o
  caso agora, para a recompilação), e foi ele que verificou o mesmo arquivo
  (mesmo SHA-256) antes.

### U. Sustos que NÃO eram defeito (registrados para não "consertar" de novo)

1. **403 da AI Horde com Python**: `urllib` com o agente padrão
   (`Python-urllib/3.13`) leva **403** do WAF. Testei os agentes que o
   aplicativo poderia usar: `okhttp/4.12.0` (o do React Native no Android),
   `okhttp/3.x`, `Dart`, `axios`, `curl`, um agente próprio `Lunaria/1.1.0` e até
   **sem** User-Agent — **todos passam (HTTP 200)**. Ou seja: o aplicativo não tem
   esse problema e **nenhuma mudança de cabeçalho é necessária**. Fica o registro,
   porque a tentação de "adicionar um User-Agent para resolver" seria mexer no que
   não está quebrado.
2. **`toast`/`haptics`/`clipboard` ausentes**: ao escrever os testes de
   renderização eu supus que o projeto usava esses pacotes e o `jest.mock`
   falhou ("Cannot find module"). Não existem no projeto — o mock é que estava
   errado. Lição: mocar só o que o projeto realmente importa.

### V. DEFEITO DE PROCESSO — a formatação automática quebrou a suíte de telas

- **O que aconteceu**: depois de escrever os testes novos, rodei `eslint . --fix`
  (formatação automática). A suíte de telas, que passava com 50 testes, caiu para
  41 e uma suíte inteira deixou de rodar, com
  `TypeError: Cannot read properties of undefined (reading 'subscribe')` em
  `lib/state/TTS.ts`.
- **Causa**: em `tests/render/screens.test.tsx` os `jest.mock(...)` precisam vir
  **antes** dos imports das telas (aqui o `jest.mock` não é içado). O `--fix`
  aplicou `import/first` e subiu os imports para o topo, fazendo o arquivo
  carregar os módulos de verdade. Depois, ao desligar `import/first`, a regra
  `import/order` apenas reordenou o bloco — e **isso também quebrou**, porque a
  ordem alfabética pôs `ImageViewer` antes das telas e a cadeia de imports
  carregou `lib/state/TTS` antes do mock de `useInference`.
- **Segundo erro, meu**: minha primeira tentativa de blindar o arquivo adicionou
  um **segundo `rules:`** no mesmo bloco do `eslint.config.js`. Em JavaScript a
  chave repetida sobrescreve a anterior — a proteção simplesmente não existia.
  Só descobri comparando o arquivo antes/depois do `--fix`.
- **Correção**: `import/first` **e** `import/order` desligados para `tests/**` e
  `tools/**` no `eslint.config.js`, com o motivo escrito, e a ordem dos imports
  do arquivo restaurada. Verificado: rodar `--fix` de novo não altera o arquivo,
  e a suíte volta a 50/50.
- **Lição registrada**: formatação automática pode mudar *comportamento* quando a
  ordem dos imports faz parte do teste. Depois de rodar `--fix`, sempre rodar a
  bateria de novo — foi o que pegou o problema.

### W. O kernel matou o Gradle por memória (build nº 8)

- **O que aconteceu**: com `-Xmx2560m` (o ajuste que tinha funcionado antes), a
  compilação da 1.1.1 morreu depois de 1.046 tarefas com
  `Gradle build daemon disappeared unexpectedly`. Não era erro de código: o
  `dmesg` mostrou `Out of memory: Killed process … (java) total-vm:5857788kB`.
  A máquina tem 1,9 GB de RAM e o Java reservou 5,8 GB de espaço virtual com
  1,7 GB residentes; o kernel escolheu o processo maior e o matou.
- **Correção**: teto do Gradle baixado para `-Xmx2048m`, metaspace para 384m e
  daemon do Kotlin para `-Xmx768m`. A compilação seguinte terminou em **2m30s**
  (incremental, 91 tarefas executadas). O ajuste está em `build-apk-2.sh` e em
  `android/gradle.properties`, com o motivo escrito nos comentários.
- **Também corrigido no caminho**: eu havia quebrado o script numa edição (uma
  linha `)` solta no comentário). Só notei porque rodei `bash -n` antes de usar.
  Editar script com script pede conferência — a mesma lição do `grep-verify`.

### X. LIMITE MEDIDO (não é defeito do app) — idioma na Pollinations

- Descrição em português pedindo uma jovem de vestido vitoriano: a Pollinations
  devolveu imagens **sem relação** com o pedido em **três** tentativas, com
  sementes diferentes. A mesma descrição **em inglês** devolveu exatamente o
  retrato pedido (moça de preto, cabelo longo, luz de vela).
- Não é filtro de conteúdo nem erro do aplicativo: é limitação de compreensão do
  modelo. O que o app faz a respeito: (1) sempre envia semente própria, o que
  elimina o caso da imagem de cache; (2) avisa na tela de ajustes de imagem que
  este provedor entende melhor inglês e que a AI Horde se saiu melhor com
  descrições em português; (3) mantém a AI Horde como provedor padrão.
- Fica registrado como **limite conhecido**, com a medição, em vez de virar
  promessa vazia de "qualidade igual nos dois provedores".

### Y. DEFEITO REAL — "Cancelar" parava a espera, mas o provedor seguia gerando

- **Como apareceu**: revisando o código depois de entregar a 1.1.1, notei que
  `cancelHordeJob` existia no provedor mas **ninguém chamava**. Ou seja: ao tocar
  em "Cancelar", o aplicativo abortava a espera localmente e pronto.
- **Medido com o serviço real** (18/09, à noite): um trabalho da Horde abandonado
  — ninguém consultando — **termina sozinho**. Acompanhei por 60 s sem nenhuma
  consulta: `gerando=1` aos 30 s e `done=true`, com 1 imagem pronta, aos 60 s.
  O mesmo acontece com o cancelamento do aplicativo: o trabalho fica na fila, é
  gerado por um worker voluntário e a imagem vai para o lixo. Quem cancelou gasta
  do mesmo jeito a sua prioridade (kudos) — que na chave anônima é o que decide a
  posição na fila.
- **Correção**: o laço de consulta passou a ser envolvido por um `try/catch`; se
  a falha for cancelamento (`signal.aborted`), o aplicativo **avisa o provedor**
  (`DELETE /generate/status/{id}`) antes de devolver o erro. O caminho de sucesso
  não manda cancelamento nenhum (provado por teste), e nem erros que não são
  cancelamento (401/404) — para não jogar fora imagem já pronta.
- **Conferido também na API real**: o `DELETE` funciona **sem** cabeçalho de
  chave (HTTP 200, o trabalho sai da fila: `waiting 0`, `done true`) — então o
  caminho de timeout, que já fazia isso, estava correto desde antes.
- **Prova**: 3 testes novos em `tests/imageprovider.test.mjs` (arquivo com 30):
  cancelar avisa o provedor exatamente uma vez e para o trabalho certo; geração
  concluída não manda cancelamento; erro de autenticação não manda cancelamento.

### Z. Build nº 10 — o metaspace esgotou no fim (e o que salvou o trabalho)

- **O que aconteceu**: a compilação a frio da 1.1.2 rodou 3 h (o R8 sozinho
  consumiu ~58 min de CPU numa máquina de 2 GB com 2 núcleos, trocando memória em
  swap) e, nas últimas tarefas de empacotamento, o daemon avisou
  `ran out of JVM Metaspace` com o teto de **384m** e entrou em espiral de coleta
  de lixo: CPU a 100% sem escrever nada no log. Uma tarefa falhou
  (`:app:collectReleaseDependencies`).
- **Correção**: teto do heap de 2048m para **1600m** (cabe melhor nos 2 GB físicos,
  menos troca de páginas) e metaspace de 384m para **768m** (era o que faltava).
  Está em `build-apk-2.sh`, com o motivo escrito.
- **O que salvou 3 h de trabalho**: encerrei o daemon travado em vez de apagar
  qualquer cache. Ao retomar, o Gradle reaproveitou a saída do R8
  (`> Task :app:minifyReleaseWithR8 UP-TO-DATE`) e o build terminou em
  **1m 06s** (41 tarefas executadas, 888 reaproveitadas). Lição: em build longo,
  nunca apagar diretório de build para "limpar" — a saída intermediária é o que
  permite retomar.
- **Detalhe de operação**: `pkill -f GradleDaemon` matou o meu próprio shell,
  porque o padrão casou com a linha de comando do comando que estava rodando.
  Para encerrar processo específico, usar o PID (a lição já estava registrada
  para `grep-verify`; agora vale também para `pkill -f`).

### AA. Limite medido (não é defeito) — fidelidade dos modelos gratuitos

- Descrição: *"retrato gótico de uma jovem adulta com um gato preto no colo, luz de
  vela, pintura digital"* (512×768, AI Horde, chave anônima, fila real).
- Resultado: veio **o gato preto, a luz de vela e o estilo de pintura** — e **não**
  veio a figura humana. Arquivo: `entrega/exemplo_horde_429_recuperado.webp`.
- Não é defeito do aplicativo: o pedido saiu correto (descritivo, sem violar
  política), a fila era comunitária e o worker escolheu um caminho do modelo. É o
  mesmo tipo de limite que a Pollinations mostrou com português (seção X).
- Consequência prática, dita de forma clara nas telas e nos guias: **os modelos
  gratuitos acertam o pedido na maior parte das vezes, não sempre**. Quem precisa
  de fidelidade alta usa modelo próprio (campo "Modelo" nas configurações de
  imagem) ou um serviço pago, que continua **desligado por padrão**.

### AB. Ferramentas de prova entregues no ZIP (para você repetir)

- `tools/gerar_imagem_real.mjs` — gera uma imagem de verdade com o **mesmo código
  do botão** e confere o arquivo recebido (cabeçalho real, dimensões, sha256).
- `tools/cancelar_geracao_real.mjs` — cria um trabalho real, cancela pelo caminho
  do aplicativo e **pergunta ao provedor** o que sobrou; o veredito é
  `CANCELADO OK` (0 imagens) ou `FALHOU`.
- `tools/verificar_assinatura.py` — confere a assinatura do APK **sem** Android
  SDK (certificado, chave do bloco e assinatura RSA via `openssl`).
- As três rodam com `node --import tsx` / `python3` dentro da pasta do projeto.

### AC. Meu próprio verificador errou primeiro (e o erro era meu, não do app)

- Ao escrever `tools/verificar_preservacao.py`, esperei as bibliotecas nativas com
  os nomes "clássicos" do llama.cpp (`libllama.so`, `libggml.so`) e o marcador do
  modelo embutido como caminho (`res/RT.gguf`). O verificador acusou **FALTA** nos
  dois — mas o pacote estava certo: os nomes reais são `librnllama*.so` (17
  arquivos) e `libggml-htp-*.so`, e o caminho é comparado pelo nome do arquivo.
- Corrigi **o verificador**, não o app: primeiro listei o que existe de verdade no
  pacote (`zipfile.namelist()`), depois ajustei as expectativas. Resultado final:
  12 de 12 recursos encontrados.
- Fica registrado porque é o padrão que mais me custa tempo: supor nome de arquivo
  em vez de listar. Vale para NDK, bibliotecas nativas e chaves de JSON — listar
  primeiro, supor depois (ou nunca).
- **Terceira vez na mesma rodada, agora com formato de arquivo:** na conferência
  final da assinatura supus que o arquivo de chave extraído do bloco v2 tinha um
  prefixo de 4 bytes com o tamanho. Não tem — o extrator já entrega o DER puro. A
  comparação acusou "chave diferente do certificado", o que teria virado um alarme
  falso grave (pareceria troca de chave). Testando as três leituras possíveis, a
  correta apareceu: **chave idêntica ao certificado** e assinatura **Verified OK**.
  Regra prática que fica: quando uma comparação de bytes falhar, **teste as
  variantes de leitura antes de concluir** que o dado mudou.

### AD. Limite desta camada de verificação (para não parecer mais do que é)

- `verificar_preservacao.py` prova que os recursos **estão no pacote enviado**:
  textos no bundle compilado e arquivos nativos no APK. Ele **não** prova que o
  recurso funciona no aparelho — isso continua no `CHECKLIST_APARELHO.md`.
- Ele também não prova que o comportamento de cada recurso está correto: isso é
  papel das suítes de lógica e de renderização (`tests/`). As três camadas juntas
  cobrem "existe no pacote", "o comportamento tem teste" e "funciona no aparelho"
  — esta última só você pode responder.

### AE. Keystore de depuração dentro do ZIP público (achado na conferência final)

- **Como apareceu**: ao revisar o que sobe na entrega, procurei "keystore" no ZIP
  e apareceu `android/app/debug.keystore`. Nas entregas anteriores a busca era por
  `*.jks` — que **não** casa com a extensão `.keystore`. O arquivo passava batido.
- **O que é, de fato**: comparado byte a byte, é **idêntico** ao keystore de
  depuração dos templates oficiais (React Native e Expo bare-minimum):
  sha256 `221e0a3106aa4c3ccc154e0a418b55020b3f9ea6…`, 2.257 bytes, senha pública
  `android`, alias `androiddebugkey`. Não é segredo do Hamura e **não** assina
  atualizações do app (o certificado de liberação é outro: `c0271509…5719a`).
- **Decisão**: mesmo sendo público, ele **saiu** do ZIP. A regra declarada é
  "nenhum keystore no pacote público", e um arquivo chamado `debug.keystore` num
  backup público gera dúvida legítima de quem audita. Custo de remover: zero para
  quem já tem o repositório; para quem quiser compilar em modo de depuração a
  partir do ZIP, o `LEIA-ME.md` explica como recriar (uma linha de `keytool`).
- **Lição**: buscar por **conteúdo e por sufixo**, não só por `*.jks`. E listar o
  que existe antes de afirmar que está limpo — o mesmo erro de "supor nome", duas
  vezes na mesma rodada (§AC e aqui).

### AF. Fechamento ao abrir na 1.1.2 (relato do Hamura) — causa ainda não confirmada

- **O relato, literal**: "O aplicativo está crashando quando aperto em abrir."
  Instalado no Galaxy A05s, ele fecha em vez de abrir. Não há `logcat` deste
  ambiente (sem aparelho, sem emulador), então a **causa raiz ainda não está
  confirmada** — e este registro existe para que ninguém, eu inclusive, trate
  uma hipótese como conclusão.
- **O que já foi descartado, com prova:**
  - *módulo nativo faltando*: os quatro módulos acrescentados na 1.1.x
    (`expo-secure-store`, `expo-screen-capture`, `expo-media-library`,
    `expo-sharing`) têm classe nativa e bibliotecas dentro do APK entregue —
    conferido no `classes.dex` e em `lib/arm64-v8a/`;
  - *configuração de build diferente da versão que funcionava*: o `app.config.js`
    da 1.0.0 e o da 1.1.3 são **idênticos**, exceto o número da versão (R8,
    `largeHeap`, `useLegacyPackaging`, plugins — tudo igual);
  - *dependência nova incompatível*: as seis acrescentadas foram listadas; duas
    são JavaScript puro (`@noble/ciphers`, `@noble/hashes`) e não podem derrubar
    a inicialização nativa;
  - *motor do MMKV/Nitro ausente*: `libNitroMmkv.so`, `libNitroModules.so` e
    `libmmkv.so` estão no pacote — e o `createMMKV()` roda na importação de mais
    de vinte módulos, ou seja, seria falha imediata e sempre;
  - *pista falsa que quase virou diagnóstico errado*: procurar `screencapture`
    nas classes deu zero, o que parecia "módulo de captura faltando". O nome
    `ExpoScreenCapture` aparece na tabela de strings do dex (é o nome registrado
    do módulo), e o R8 renomeia classes — busca por **nome de classe em código
    ofuscado não prova ausência**. Usei o mesmo raciocínio de "listar antes de
    supor" das seções AC/AE: aqui, listar o **registro de módulos**, não o nome
    que eu imaginava.
- **Por que não corrigi "na unha"**: sem a mensagem do aparelho, qualquer remendo
  seria chute. O trabalho foi fazer o aplicativo **falar** em vez de morrer calado
  (1.1.3): migalhas de percurso, captura de erro de JavaScript, captura de falha
  nativa em arquivo (escrita no `MainApplication.kt` antes de fechar), tela de
  relatório copiável, **modo seguro** depois de duas aberturas que não terminam, e
  cada camada nova isolada em `try/catch` — inclusive o `expo-screen-capture`, que
  saiu do topo do arquivo e passou a ser carregado só quando a opção é ligada.
- **O que isso significa de verdade**: se o fechamento vinha de uma das camadas
  novas (bloqueio, cofre, imagens, captura de tela), ele **deixa de derrubar o
  aplicativo** nesta versão e o motivo aparece na tela. Se vinha de outro lugar, o
  relatório aponta o lugar exato — e aí a correção é cirúrgica, com dado real na
  mão.
- **Lição de processo**: em versão de produção não existe caixa vermelha. Um
  aplicativo que fecha sem registrar nada transforma qualquer defeito em
  adivinhação; a instrumentação de abertura não é enfeite, é o que permite
  consertar sem ter o aparelho na mão.

### AG. O ambiente reiniciou e levou 2h10 de build (build nº11 da 1.1.3)

- **O que aconteceu**: o build da 1.1.3 começou 00:42 UTC e estava na fase de R8
  (a mais longa) às 02:52, quando a máquina reiniciou — `uptime` voltou a zero.
  Com o reinício, `/opt` (JDK + Android SDK/NDK), `node_modules` e **a pasta
  `android/app/build`** desapareceram, e o processo do Gradle morreu com tudo.
- **Por que a pasta `build` vai embora**: ela é excluída do instantâneo do
  workspace por definição (junto de `node_modules`, `dist`, `target`…). Então, ao
  contrário de uma simples perda de sessão, aqui não sobrou nem o cache do R8 que
  salvou o build nº10 — recomeça do zero.
- **Lição prática, que eu já tinha escrito e mesmo assim me custou 2h**: trabalho
  longo demais numa máquina que reinicia é aposta. O caminho certo continua sendo
  **um build por rodada de correções**, com os portões (`tsc`, `eslint`, testes)
  fechados antes de começar — foi o que fiz, então o que se perdeu foi tempo de
  CPU, não correção de código.
- **O que não se perdeu**: o código da 1.1.3 está na árvore e verificado
  (115 testes de lógica, 55 de renderização, `tsc` e `eslint` limpos); os
  documentos desta rodada estão escritos; o APK 1.1.2 entregue continua íntegro em
  `entrega/`.

### AH. R8 morreu de falta de heap porque a configuração "validada" nunca foi testada (build nº12)

- **O que aconteceu**: o build nº12 (19/09) rodou 5h35 e falhou em
  `:app:minifyReleaseWithR8` com `java.lang.OutOfMemoryError: Java heap space`.
- **A parte que me interessa registrar**: eu havia baixado o heap para 1600m no
  build nº18 e o considerava validado porque aquele build passou. Mas no nº18 o
  `minifyReleaseWithR8` estava **UP-TO-DATE** — ele reutilizou o dex do build
  nº10 e **não executou**. Ou seja: o R8 nunca tinha rodado com 1600m, e a minha
  "validação" era do caminho errado.
- **Correção**: heap de volta a 2048m (o valor com que o R8 do build nº10 chegou
  ao fim) **somado** ao metaspace de 768m (o que resolveu o estouro do nº10).
  Total do daemon ~2,8 GB, coberto por 4 GB de swap — sacrifica velocidade,
  mantém a conclusão.
- **Lição de método, que vale mais que o defeito**: `UP-TO-DATE` não é prova de
  que uma etapa funciona — é prova de que ela **não rodou**. Antes de dizer que
  uma configuração está validada, é preciso olhar se a tarefa que ela afeta
  executou de fato. É a mesma família dos erros §AC/AE: validar o que se vê, não o
  que se supõe.
- **Ganho colateral**: como os insumos do R8 ficaram no disco, a retomada não
  recomeça da estaca zero — pula compilação Java/Kotlin e as partes nativas.
- **Desfecho, medido**: com 2048m de heap + 768m de metaspace, o mesmo R8 que
  ficou ~1h50 em CPU e morreu de estouro completou em **~5 minutos** (build nº13,
  `BUILD SUCCESSFUL in 7m 24s` contando as demais tarefas). A conclusão que os
  números sustentam: a "demora de horas" do R8 a 1600m não era trabalho — era
  **coleta de lixo em espiral**, o mesmo padrão do metaspace no build nº10. Um
  valor de memória abaixo do necessário não deixa o build só mais lento: ele o
  transforma em horas de trabalho jogado fora.
- **A perda seguinte, que não era do build**: o APK do build nº13 foi gerado e,
  minutos depois, o ambiente apagou `android/app/build` — a pasta é **excluída do
  instantâneo do workspace** e o ambiente a remove no fim do turno. O build estava
  certo; a forma de guardar o resultado é que estava errada. Correção: um vigia
  (`lunaria-build/vigia-apk.sh`) que copia o APK para `entrega/` assim que ele
  aparece, e o cache do Gradle movido para `/opt` (fora do workspace, sobrevive ao
  apagamento). Regra que fica: **em ambiente que limpa pastas de build, o resultado
  tem de sair da pasta de build imediatamente.**

### AI. APK de diagnóstico entregue — e o que ele ainda não prova

- **O que foi entregue**: `Lunaria-1.1.3-arm64-release.apk`, mesma assinatura
  (`c0271509…5719a`), versão 1.1.3 (código 5), com a camada de diagnóstico inteira
  dentro do bundle: migalhas, contagem de aberturas que não terminam, modo seguro,
  captura de erro de JavaScript, gravação do erro **nativo** em arquivo pelo
  `MainApplication.kt`, e a tela de relatório com "Copiar diagnóstico".
- **O que mudou no comportamento em caso de erro**: antes, cada camada nova rodava
  solta na abertura e um erro em qualquer uma derrubava tudo; agora cada uma está
  isolada, o `expo-screen-capture` deixou de ser `import` de topo (era o candidato
  mais forte a derrubar a abertura inteira) e, depois de duas aberturas que não
  terminam, o **modo seguro** abre o aplicativo sem as camadas novas.
- **O que continua sem prova**: que o fechamento da 1.1.2 tinha estas causas. Isto
  é instrumentação e contenção, não diagnóstico fechado. O teste é no aparelho, e
  os três desfechos possíveis estão no `CHECKLIST_APARELHO.md` (abre normal, mostra
  relatório, fechar calado duas vezes → modo seguro).
- **R8 desligado**: registrado em `android/gradle.properties` com o motivo. É
  decisão de diagnóstico, não de produto: a entrega final volta com R8 ligado, já
  com as regras de `keep` revisadas — e a comparação entre os dois APKs é, ela
  mesma, um teste da hipótese de redução de código.

### AJ. O instantâneo do workspace tem teto de tamanho — e ele já me comeu um APK

- **O que aconteceu**: o APK da 1.1.3 foi construído às 10:51 de 19/09 e o vigia o
  copiou corretamente para `entrega/` (registro: 66.612.435 bytes). No fim do
  turno, o arquivo **desapareceu**. Motivo: com o APK 1.1.2 (60 MB) e o 1.1.3
  (66 MB) na mesma pasta, o workspace passou do **teto de ~128 MB** do instantâneo
  e o ambiente descartou o arquivo maior — justamente o mais novo.
- **O mesmo restauro reverteu outra coisa, em silêncio**: o
  `android/gradle.properties` voltou a ter `enableMinifyInReleaseBuilds=true`,
  desfazendo a decisão de gerar o APK de diagnóstico **sem R8**. Descobri porque o
  próximo build começou a rodar o R8 de novo (o log mostrou `minifyReleaseWithR8`).
  Desperdício: ~35 min de build mais a interrupção de outro.
- **Correções de raiz, não de sintoma**:
  1. **Espaço**: o APK 1.1.2 saiu da pasta (você já o tem instalado; o sha256
     `e39b3ae7…319b` fica registrado nos documentos) e os logs antigos de build
     foram resumidos. `entrega/` caiu de 72 MB para 14 MB, e o APK novo entrou com
     folga no orçamento do instantâneo.
  2. **R8**: a decisão deixou de depender de um arquivo que pode ser revertido — o
     próprio `build-apk-2.sh` força o estado (`SEM_R8=1` por padrão) e **imprime o
     valor efetivo** no começo de cada build. Configuração que importa passa a ser
     verificável no log, não presumida.
- **Lição**: em ambiente com teto de tamanho, o resultado precisa caber no
  orçamento — e a decisão de build precisa estar no script que a executa, não num
  arquivo de configuração que pode voltar atrás sem avisar.

### AK. Auditoria de classes possível sem R8 — e uma hipótese minha derrubada

- **Como**: o APK de diagnóstico sai sem R8, então os nomes de classe aparecem
  inteiros no dex. Na 1.1.2 (com R8/Otimização) a mesma busca era inconclusiva —
  eu já tinha até confundido nome de módulo com nome de classe (§AF).
- **Resultado medido no APK entregue**: `expo/modules/screencapture` **19 classes**
  (incluindo `BuildConfig`), `securestore` 51, `medialibrary` 105, `sharing` 31,
  `localauthentication` 21, `camera` 150, `speechrecognition` 77. Dex de 30,2 MB em
  4 arquivos, contra 14,0 MB da 1.1.2 — a diferença **prova** que o R8 ficou
  desligado neste build.
- **Hipótese derrubada, registrada**: eu suspeitava que o módulo de captura de tela
  não tivesse sido compilado no app e que o `import` de topo no `_layout.tsx`
  derrubasse a abertura. Não é isso: o módulo está lá, completo e registrado. A
  remoção daquele `import` de topo (agora carga tardia com `catch`) continua sendo
  melhoria de resiliência, mas **não** era a causa do fechamento.
- **O que sobra como causa possível**: nada provado. Sem `logcat` do aparelho, a
  1.1.3 é instrumentação e contenção — não diagnóstico fechado. E isso está dito
  assim em todos os documentos, inclusive no `LEIA-ME.md` que você vai ler.

### AL. Quatro hipóteses eliminadas por auditoria do APK (sem aparelho)

Todas as verificações abaixo rodaram **sobre o APK entregue**, com ferramentas do
SDK e leitura binária. Nenhuma delas encontrou defeito — e é exatamente por isso
que ficam registradas: cada uma que eu elimino é um caminho que ninguém precisa
percorrer de novo, e o diagnóstico verdadeiro só pode estar no que sobra.

| Hipótese | Como foi testada | Resultado |
| --- | --- | --- |
| **Biblioteca nativa com dependência faltando** (causa clássica de fechamento na abertura, o `UnsatisfiedLinkError`) | `readelf -d` em todas as **53** bibliotecas do APK: li os `NEEDED` de cada uma e cruzei com o que o pacote oferece (`SONAME`) e com as bibliotecas do sistema | **Nada faltando.** 30 dependências distintas; todas presentes no pacote ou no sistema. `libc++_shared.so`, `libmmkv.so`, `libNitroMmkv.so`, `libNitroModules.so`, `libjsi.so`, `libhermesvm.so`, `libfbjni.so` — todas empacotadas |
| **Arquitetura errada** | `readelf -h` nas 53 | 48 **AArch64** + 5 `libggml-htp-*` (DSP Qualcomm Hexagon, carregadas só quando existe NPU) — nenhuma x86 |
| **Classe declarada no manifesto e inexistente no dex** (`ClassNotFoundException` mata na abertura) | parse do `AndroidManifest.xml` + busca dos descritores no dex | **24 classes instanciadas pelo Android, todas presentes** — incluindo `MainApplication`, `MainActivity`, o serviço de reconhecimento de fala e os provedores de notificação |
| **Dex corrompido** | `dexdump` nos 4 arquivos | Todos abrem, versão `037`, tamanhos coerentes |
| **Bytecode Hermes incompatível com o runtime** (dá "Unsupported bytecode version" e fecha) | comparei o cabeçalho do bundle (magic + versão) com o que o compilador do próprio projeto emite | Magic `0x1F1903C103BC1FC6` correto e **HBC 96 nos dois** — compatível |

**O que sobra**: nada provado. O fechamento da 1.1.2 pode ter vindo de uma falha
de execução (não de empacotamento) — biblioteca que carrega mas falha ao
inicializar, ordem de inicialização, estado do aparelho — ou de algo que só existe
no seu Galaxy A05s. É para isso que a 1.1.3 serve: se for falha de execução, ela
**mostra** o motivo em vez de morrer calada.

# Rodada de 19/09 — a hipótese principal testada contra o próprio APK que falhou

## §AM — Hipótese testada e **REFUTADA**: renomeação de classes pelo R8

A hipótese que eu vinha tratando como principal era: o R8 renomeia classes que o
código nativo procura **por nome**, e é isso que derruba o aplicativo na
abertura. Ela tinha evidência de apoio (as bibliotecas procuram esses nomes:
`strings` dentro das `.so` mostra `com/tencent/mmkv/MMKV`,
`com/margelo/nitro/NitroModules`, `com/margelo/nitro/mmkv/HybridMMKVPlatformContext`;
nem `react-native-mmkv` nem `react-native-nitro-modules` publicam regras de
consumo; não havia `@DoNotStrip` nessas classes).

**O teste decisivo apareceu porque o APK da 1.1.2 — o que fechava — ainda existia
no arquivo de instantâneo do ambiente** (`/tmp/arena-workspace/hydrate.zip`,
60.466.386 bytes, sha256 `e39b3ae7f41614e95d9da83cfe3760e17761bfb9188f6628a2cd4df5f4fa319b`,
byte a byte o mesmo que foi entregue). Com ele em mãos, a hipótese vira medida:

| medida | 1.1.2 (**com** R8, era a que fechava) | 1.1.3 (**sem** R8) |
| --- | --- | --- |
| tamanho do dex | 14,0 MB | 30,2 MB |
| classes **definidas** | 18.399 | 29.068 |
| `com.tencent.mmkv.MMKV` | definida | definida |
| `com.margelo.nitro.NitroModules` | definida | definida |
| `com.margelo.nitro.mmkv.HybridMMKVPlatformContext` (+`Spec`) | definida | definida |
| `com.margelo.nitro.core.HybridObject` | definida | definida |
| `expo.modules.kotlin.jni.JavaScriptObject` | definida | definida |
| bibliotecas nativas (`lib/arm64-v8a`) | 48 | 48 (conjunto **idêntico**) |
| `assets/` | 12 | 12 (idênticos) |
| manifesto (elementos + atributos) | 162 | 162 — a **única** diferença é `versionName` |

Além das classes, comparei os **métodos** das classes críticas: `MMKV`,
`NitroModules` e `HybridMMKVPlatformContext` têm as mesmas assinaturas nos dois
APKs, incluindo os `native` (`initHybrid`, `install(JLcom/facebook/react/turbomodule/core/CallInvokerHolderImpl;)`,
`getBaseDirectory`, etc.). E conferi as 24 classes que o **manifesto** instancia:
todas presentes nos dois.

O que o R8 realmente removeu: 125 recursos a **mais** na 1.1.3, todos selectors de
cor do Material com o nome de arquivo ofuscado na 1.1.2 (`res/0w.xml`,
`res/color/m3expressive_*`), nenhum recurso nomeado usado em execução; e 51
arquivos `META-INF/*.kotlin_module`, que são metadados de compilação e não
existem em execução.

**Conclusão, sem enfeite: a hipótese estava errada.** O R8 preservou tudo o que o
código nativo procura por nome — classes, métodos e o que o manifesto instancia.
Registro isto porque o inverso (apresentar hipótese como causa) seria exatamente o
tipo de erro que o Hamura pediu para não cometer.

**Mesmo assim**, deixei em `android/app/proguard-rules.pro` as regras de `-keep`
para esses pacotes (MMKV, Nitro, worklets, screens, penfeizhou, avif, expo.modules),
com comentário explicando que são **proteção para builds futuros**, não a correção
deste defeito. Nenhum desses pacotes publica regras próprias, e depender de o R8
"por sorte" manter essas classes não é uma decisão que se tome duas vezes.

## §AN — Defeito **real** encontrado e corrigido: chamada nativa no escopo do módulo

Investigando o resto do caminho de abertura, a pergunta certa era: *o que roda no
instante em que o pacote JavaScript é avaliado?* Nesse instante não existe tela,
não existe `try/catch` e não existe relatório de diagnóstico — se algo falha ali,
o aplicativo fecha e o usuário não vê nada. É o sintoma relatado.

**A resposta medida no pacote instalado** (`node_modules/react-native-mmkv/lib/`):

- `createMMKV/createMMKV.js` — a criação nativa acontece **dentro da função**:
  `platformContext = NitroModules.createHybridObject('MMKVPlatformContext')`;
- `hooks/createMMKVHook.js` — a instância padrão é resolvida **no corpo do hook**
  (`const mmkv = instance ?? getDefaultMMKVInstance()`), isto é, na renderização,
  não no `import`;
- logo, no aplicativo inteiro havia **uma única** chamada nativa no momento do
  `import`: `lib/storage/MMKV.ts`, linha 6 — `export const mmkv = createMMKV()`;
- e esse arquivo está no **caminho da abertura**: `lib/utils/Startup.ts` importa
  `mmkv`, e `app/index.tsx` executa `startupApp()`.

Se essa criação falhar no aparelho (módulo Nitro não registrado, biblioteca
incompatível, arquivo de MMKV corrompido de uma instalação anterior), o pacote
JavaScript morre **durante a avaliação**: antes da primeira tela, antes do limite
de erro, antes de qualquer registro. Fecha sem mensagem. Coincide com o relato.

**Correção aplicada** — `lib/utils/NativeModules.ts` (novo): carga sob demanda,
memorizada, com `try/catch` que registra a falha no relatório em vez de derrubar o
aplicativo. Aplicada a:

| arquivo | módulo | comportamento quando não responde |
| --- | --- | --- |
| `lib/storage/MMKV.ts` | `react-native-mmkv` | **reserva em memória** — o aplicativo abre e avisa no relatório |
| `lib/security/SecureVault.ts` | `expo-secure-store`, `expo-crypto` | cofre indisponível com mensagem clara; nada é apagado |
| `lib/state/AppLock.ts` | `expo-local-authentication` | biometria some da tela; a senha continua valendo |
| `lib/state/ImageGeneration.ts` | `expo-media-library`, `expo-sharing` | salvar/compartilhar avisa; a imagem continua no cofre |

**O que isso é e o que não é.** É um defeito **real**, comprovado por leitura do
código do pacote e do caminho de importação — e é a única construção do
aplicativo capaz de produzir "fecha ao abrir sem mensagem". **Não** é prova de
que era esta a causa no aparelho do Hamura: sem o relatório do aparelho, tratar
como certo seria repetir o erro do §AF. O que ele garante: essa classe inteira de
fechamento silencioso deixou de existir, e se ainda houver falha, ela aparece no
relatório em vez de sumir.

**Testes**: 8 novos em `tests/nativemodules.test.mjs` — comportamento da carga
protegida (carrega, falha, memoriza, trata módulo vazio) e **guardas de fonte**
que impedem o retorno do defeito (nenhum arquivo pode importar no topo os módulos
convertidos; `createMMKV()` não pode voltar ao escopo do módulo). Total: 123
testes de lógica; 60 de renderização; `tsc` e `eslint` limpos.

## §AO — O build da 1.1.4: três tentativas, duas perdidas para disco cheio

Esta parte não é sobre o aplicativo, é sobre o ambiente — e ficou registrada porque
custou tempo e porque a causa foi **decisão minha**, não do acaso.

- **Tentativa 1 (log `gradle-27.log`, 13:11→13:15)**: falhou com
  `Failed to transform react-android-0.83.6-release.aar …` e o disco em 100%. Para
  abrir espaço eu havia apagado ~2 GB de pastas de compilação dentro de
  `node_modules` (do tipo `android/build` e `.cxx`), tratando-as como "regeneráveis
  e baratas". Elas foram **recompiladas do zero** — CMake de reanimated, worklets,
  nitro-modules e llama.cpp — e o pico de disco ficou **maior** do que o espaço que
  elas ocupavam paradas. **Lição: em disco apertado, apagar artefato de compilação
  frio troca espaço por espaço e ainda cobra o tempo de recompilar.**
- **Tentativa 2 (log `gradle-27.log`, 13:17→13:32)**: falhou por disco cheio outra
  vez. Registrou um custo que eu não previa: eu havia apagado o NDK
  `27.0.12077973` (2 GB) por não vê-lo em uso — só o `27.1.12297006` aparecia nos
  logs — e o Gradle **baixou o NDK de volta** durante o build. Ou seja: **os dois
  NDKs são necessários**, porque módulos diferentes fixam versões diferentes.
  Não repetir essa remoção.
- **Tentativa 3 (log `gradle-28.log`, 13:32→13:41)**: **BUILD SUCCESSFUL em
  8m12s** — 952 tarefas (689 executadas, 142 vindas do cache, 121 já atualizadas).
  O que destravou de verdade: apagar o **cache de transformações do Gradle**
  (`caches/9.0.0/transforms`, 3 GB, este sim regenerável e inerte entre builds),
  preservando os objetos nativos já compilados (`.cxx`). A parte caríssima não se
  repetiu e a rodada terminou com espaço de sobra.

**Erro de processo meu, também registrado**: o empacotador
(`tools/empacotar_entrega.sh`) sincroniza os documentos da **árvore** para `entrega/`
— a árvore é a fonte da verdade. Eu editei os documentos direto em `entrega/` e o
empacotador os **sobrescreveu** com as versões antigas (aconteceu uma vez com o
`empacotar_entrega.sh` e a versão do ZIP, e de novo agora, com os textos). Os
textos estavam guardados e foram reaplicados na árvore; o `TEST_REPORT.md`, que só
existia na árvore, passou a constar na lista de sincronização. **Regra daqui em
diante: documento se edita na árvore, nunca só na pasta de entrega.**

## §AP — Verificação do APK entregue (1.1.4)

| verificação | resultado |
| --- | --- |
| arquivo | `Lunaria-1.1.4-arm64-release.apk` |
| tamanho | 66.615.443 bytes |
| sha256 | `59d914e7687403d91025ede5fe274e6d98ef1daa8cc5703b45dd758ede45b963` |
| versão | 1.1.4 (código 6) |
| assinatura | v2 **Verifies**; certificado `c0271509…5719a` — o mesmo desde a 1.0.0, então instala por cima |
| R8 | desligado de propósito (dex com 30,2 MB em 4 arquivos) |
| bundle | 6.445.276 bytes, com `Lunaria:1.1.4` |
| **código novo presente** | `ModuloNativo:` e `modulo nativo indisponivel` no bundle (a carga protegida, §AN) e as mensagens de reserva ("armazenamento seguro", "Galeria indispon", "Compartilhamento indispon", "Nada foi apagado") |
| bibliotecas | 48 arm64-v8a + 5 Hexagon DSP; `res/RT.gguf` com 7.818.140 bytes |
| preservação | **14/14** — `tools/verificar_preservacao.py` sobre o APK entregue |

**Método de auditoria que vale guardar**: strings **acentuadas** dentro do bytecode
do Hermes **não** aparecem em busca de 8 bits — o `grep` simples respondeu "ausente"
para mensagens que estavam no pacote. É preciso `strings -el` (16 bits). Quase
registrei uma conclusão errada por causa disso: mesma família do §AM, onde procurar
nome de classe em dex reduzido deu falso positivo. Nos dois casos, o erro estava no
instrumento, não no produto — vale conferir sempre o método antes de concluir.

## §AQ — O defeito de abertura estava no banco de dados, no instante do carregamento (corrigido na 1.1.5)

Esta rodada continuou a caça ao "fecha ao abrir" pelo mesmo método: **medir o
caminho de abertura**, não adivinhar. O §AN havia fechado o buraco do
armazenamento de preferências; ao varrer o caminho inteiro procurando a **mesma
construção** (chamada nativa executada na avaliação do pacote, antes de qualquer
tela e de qualquer `try/catch`), o banco de dados apareceu — e ele é o recurso
mais crítico do aplicativo.

### O que foi medido

`db/db.ts` na 1.1.4 tinha **11 linhas** e quatro chamadas nativas no escopo do
módulo:

```ts
export const sqliteDB = openDatabaseSync('db.db', { enableChangeListener: true })
if (extension) sqliteDB.loadExtensionAsync(extension?.libPath, extension?.entryPoint)
export const db = drizzle(sqliteDB, { schema })
sqliteDB.execAsync('PRAGMA foreign_keys = ON;')
```

E `db/db.ts` é importado pela **primeira tela** (`app/index.tsx`, para
`useMigrations(db, migrations)`). Sequência do defeito:

1. `expo-sqlite` procura o módulo nativo **no import** —
   `node_modules/expo-sqlite/build/ExpoSQLite.js`:
   `export default requireNativeModule('ExpoSQLite')`;
2. o banco era **aberto** ali mesmo, no escopo do módulo;
3. a abertura acontecia antes de existir tela, proteção de conteúdo ou
   `try/catch` — inclusive antes do `try/catch` de `startupApp`, que não tem como
   socorrer uma exceção lançada no import;
4. qualquer falha de abertura (arquivo de banco corrompido por instalação
   anterior, disco cheio, extensão `sqlite-vec` incompatível) fecha o aplicativo
   **sem mensagem**: é exatamente o sintoma relatado.

**Segundo caminho, no mesmo arquivo:** mesmo trocando `expo-sqlite` por carga
tardia, o `import { drizzle } from 'drizzle-orm/expo-sqlite'` reabria o buraco —
`node_modules/drizzle-orm/expo-sqlite/query.js:1` faz
`import { addDatabaseChangeListener } from "expo-sqlite"`. Ou seja: o pacote do
Drizzle importa o SQLite por conta própria. **Os dois** passaram a ser carregados
sob demanda.

Detalhe adicional: `loadExtensionAsync` e `execAsync` são promessas sem espera —
na versão antiga, uma falha nelas virava promessa rejeitada sem dono. Agora as
duas têm `.catch` que registra no relatório de diagnóstico.

### Correção aplicada (1.1.5)

`db/db.ts` passou a expor `db` e `sqliteDB` por acesso **sob demanda** (Proxy):
o banco abre na primeira leitura de propriedade, uma única vez, dentro do
`try/catch` de quem chamou. O tipo devolvido é o mesmo de antes, então nenhum
consumidor precisou mudar (47 usos de `db.mutate`, 38 de `db.query`, `db.insert`,
`db.update`, `db.delete`, além de `sqliteDB` direto em `EmbeddingScreen.tsx`).
`then`/`catch`/`finally` ficam de fora de propósito: `await banco` não pode
disparar a abertura — só o uso de verdade dispara.

### Outros três pontos do mesmo tipo, corrigidos na mesma rodada

| arquivo | defeito | correção |
| --- | --- | --- |
| `lib/state/Chat.ts`, `app/screens/ChatScreen/ChatInput/index.tsx` | `import { randomUUID } from 'expo-crypto'` no topo; o `expo-crypto` procura o nativo **no import** (`build/Crypto.js` → `build/ExpoCrypto.js`: `requireNativeModule('ExpoCrypto')`) e o estado do chat está no caminho da abertura | novo `lib/utils/RandomId.ts`: carga tardia e protegida, com reserva em JavaScript puro (UUID v4) |
| `lib/hooks/LocalAuth.tsx` | `expo-local-authentication` importado no topo (mesma construção) | carga tardia; sem o módulo, o gancho degrada para "sem prompt de biometria" em vez de deixar o usuário preso (o botão de repetir chamaria para sempre um módulo que não existe). A proteção por senha da Lunaria continua valendo por conta própria |
| `lib/utils/RandomId.ts` | defeito **encontrado pelo próprio teste**: quando a função nativa responde `undefined` em vez de lançar, o identificador saía vazio | o valor gerado é conferido; se não for texto não vazio, cai para a reserva e o fato entra no relatório |

### O que **continua** em aberto (registrado, não varrido para baixo do tapete)

`expo-file-system` também procura o módulo nativo no import
(`node_modules/expo-file-system/src/ExpoFileSystem.ts:24`:
`requireNativeModule<ExpoFileSystemModule>('FileSystem')`) e é importado no topo
de vários arquivos do caminho de abertura (medido: `lib/utils/File.ts`,
`lib/utils/Startup.ts`, `lib/state/Characters.ts`, `lib/security/PrivateStorage.ts`,
`lib/security/PrivateImageCache.ts`, `lib/security/Migration.ts`,
`app/components/views/DiagnosticReport.tsx`,
`app/screens/AppSettingsScreen/DatabaseSettings.tsx`). Diferente dos anteriores,
fechar esse ponto exige refatorar dezenas de telas — **não foi feito nesta
rodada**, para não trocar um defeito conhecido por uma regressão em massa às
vésperas de uma entrega. Fica registrado como pendente.

**Atenuação verificada no APK entregue**: `expo.modules.filesystem.FileSystemModule`
**está registrado** na lista de módulos
(`expo.modules.ExpoModulesPackageList`), conferida dentro do dex do APK da 1.1.4.
Ou seja: nesse build, a procura por esse módulo tem o que encontrar.

### Método novo desta rodada: conferir o **registro** dos módulos, não só a presença

O §AM havia conferido presença de classes. Presença não garante registro. O
registro foi lido agora **de dentro do APK entregue**, com
`apkanalyzer dex code --class expo.modules.ExpoModulesPackageList`, e os módulos
usados pelo aplicativo aparecem todos:

```
expo.modules.crypto.CryptoModule            expo.modules.sqlite.SQLiteModule
expo.modules.filesystem.FileSystemModule    expo.modules.securestore.SecureStoreModule
expo.modules.medialibrary.MediaLibraryModule  expo.modules.sharing.SharingModule
expo.modules.localauthentication.LocalAuthenticationModule  expo.modules.screencapture.ScreenCaptureModule
```

Conclusão honesta: **"módulo nativo faltando no pacote" não explica o
fechamento** relatado pelo Hamura — os módulos estão no pacote e registrados.

### Estado da investigação depois desta rodada

| hipótese | estado | como foi decidida |
| --- | --- | --- |
| módulo nativo ausente no APK | **refutada** (medida) | classes e **registro** conferidos dentro do dex do APK |
| R8 renomeando classes | **refutada** (medida) | comparação 1.1.2 (com R8) × 1.1.3 (sem R8) — §AM |
| manifesto/configuração divergente | **refutada** | manifesto e bibliotecas idênticos entre as duas |
| **falha na avaliação do pacote (chamada nativa no import)** | **defeito real, corrigido nos pontos alcançáveis** | auditoria do caminho + testes que provam que o import do banco já não toca o nativo |
| causa exata no A05s | **ainda não provada** | depende do relatório de diagnóstico do aparelho — a 1.1.5 leva a captura de erro nativo e o relatório com falhas de módulo nomeadas |

Isto é o que se pode afirmar com prova. O aplicativo não pode ser declarado
"corrigido" sem o teste no aparelho.

## §AR — Quase foi entregue um APK **velho** com nome de versão nova (19/09, corrigido)

Armadilha de instrumento, mesma família do §AM e do §AP — desta vez no processo de
entrega, não no produto.

### O que aconteceu

O build da 1.1.4 deixou o APK pronto em
`android/app/build/outputs/apk/release/app-release.apk`. Esse diretório é uma
pasta **excluída do instantâneo** do workspace, então o arquivo sobreviveu ao fim
do turno. Ao iniciar o build da 1.1.5, o vigia — um processo que espera o APK
aparecer e copia para `entrega/` com o nome da versão lida do `package.json` —
encontrou **o APK antigo** e o copiou como `Lunaria-1.1.5-arm64-release.apk`:

```
13:57:06 COPIADO 66615443 bytes -> entrega/Lunaria-1.1.5-arm64-release.apk
         (sha256 59d914e7687403d9…)      <-- este é o sha da 1.1.4
```

O mesmo log registra ocorrência igual às 13:41 (arquivo batizado como 1.1.3). Ou
seja: **dois** arquivos enganosos foram criados por esse caminho em um único dia.

### Por que isso é grave

O nome do arquivo passou a afirmar algo falso. Se o build novo falhasse e o pacote
fosse publicado assim, o Hamura receberia o APK da 1.1.4 dizendo ser 1.1.5 —
exatamente o que ele proibiu ("não use um APK velho como se fosse o resultado
deste código"). Nada no produto estava errado; o erro estava no instrumento de
entrega.

### Correção

1. Os dois arquivos enganosos foram **apagados** de `entrega/`.
2. O vigia passou a conferir a **versão gravada dentro do APK** antes de copiar:

```bash
VERSAO_NO_APK="$(apkanalyzer manifest version-name "$ORIGEM" | tr -d '\r\n ')"
if [ "$VERSAO_NO_APK" != "$VERSAO" ]; then
    echo "IGNORADO: APK no diretório de saída é da versão '$VERSAO_NO_APK' e o pedido é '$VERSAO'"
    continue
fi
```

Se o arquivo no diretório de saída não for da versão pedida, ele é **ignorado** —
o vigia continua esperando o build de verdade. A conferência da versão interna
passou a valer para toda entrega futura.

### Lição registrada

Três rodadas seguidas terminaram com um erro de **instrumento** quase virando
conclusão errada: procurar nome de classe em dex reduzido (§AM), procurar texto
acentuado com `grep` de 8 bits (§AP) e agora confiar no nome do arquivo (§AR).
Antes de afirmar qualquer coisa sobre o produto, vale perguntar: **a ferramenta
mede o que eu penso que ela mede?** Neste caso, a versão dentro do pacote é a
prova; o nome do arquivo não é.

## §AS — Fechada a **classe** do defeito: porteiro de entrada (1.1.6)

Até aqui a caça ao "fecha ao abrir" tratou **casos**: o armazenamento de
preferências (§AN), o banco de dados e o identificador (§AQ). Cada correção fechava
um ponto e deixava os outros de pé — e sobram pontos que fechar exigiria refatorar
dezenas de telas (o `expo-file-system`, em nove arquivos do caminho de abertura).

Esta rodada mudou a pergunta. Em vez de "qual módulo ainda está desprotegido?", a
pergunta foi: **"por que uma falha na avaliação de um módulo fecha o aplicativo em
silêncio, sem deixar nenhuma pista?"** A resposta é estrutural: os `import` são
resolvidos antes de qualquer tela, de qualquer proteção e de qualquer `try/catch`
do aplicativo. Não existia nada — literalmente nada — rodando **antes** disso.

### O que entrou

| peça | o que faz |
| --- | --- |
| `index.js` (novo `main` do aplicativo) | primeiro código a rodar: instala o registro de erros fatais e só então carrega `expo-router/entry` **dentro de `try/catch`** |
| `lib/utils/EntradaSegura.js` | o porteiro: registra a falha e, se o aplicativo não chegou a montar, **registra uma tela de aviso como tela inicial** |
| tela de aviso | abre com o motivo, a versão, o horário e o botão **"Copiar diagnóstico"**; feita só com o básico do React Native (nada de tema, nada de componente nosso) |

O resultado prático: qualquer falha **na avaliação de módulo** — a que antes
produzia fechamento sem mensagem — passa a **abrir o aplicativo numa tela que diz o
que aconteceu**. Não é mais preciso adivinhar qual módulo faltou no aparelho.

### Três decisões de projeto que sustentam isso

1. **O porteiro não importa nada — nem `react`, nem `react-native`.** Se ele
   dependesse de um módulo nativo, morreria da mesma doença que existe para
   diagnosticar, e não haveria testemunha. Tudo é obtido na hora do uso, dentro de
   `try/catch`. Isso é travado por teste (`tests/nativemodules.test.mjs`: "o
   porteiro de entrada não importa nada no topo"), que olha só as linhas da
   **coluna 0** — `require` dentro de função, em tempo de uso, é o desenho correto.
2. **Os dois tratadores de erro convivem.** O aplicativo já instala o dele em
   `app/_layout.tsx` (`installGlobalErrorCapture`). Como este roda antes, o
   `setGlobalHandler` é **envolvido**: quem instalar depois entra na cadeia. Sem
   isso, o tratador do aplicativo substituiria o do porteiro — e o silêncio
   voltaria justamente no caso mais grave.
3. **A tela de aviso só entra antes de o aplicativo montar.** Se as rotas já
   carregaram, um erro fatal continua sendo tratado pelo relatório de diagnóstico
   que já existia: seqüestrar a interface de um aplicativo em uso seria trocar um
   defeito por outro. E ela é um componente **de classe**, criado sob demanda: em
   caminho de emergência não se arrisca ordem de chamada de hook.

### Por que a ordem de carregamento é garantida

`index.js` usa `require` (CommonJS) em vez de `import`: com `import`, o empacotador
pode reordenar a avaliação; com `require` explícito, a ordem é literalmente a ordem
escrita. O `main` do `package.json` aponta para `index.js` (padrão documentado do
Expo Router para entrada personalizada). Dois testes travam os dois pontos: a ordem
dos `require` dentro do arquivo e o valor do `main`.

### O que isto prova — e o que não prova

**Prova** (executado nesta máquina, 128 testes de lógica + 74 de renderização, 9
novos só para o porteiro): o porteiro instala o registro antes de tudo; uma falha
fatal antes das rotas registra a tela de aviso como tela inicial; depois das rotas
carregadas ele **não** interfere; o tratador do aplicativo continua recebendo os
erros; o relatório é montado sem quebrar nem com um objeto hostil (com `message` e
`toString` que lançam).

**Não prova**: que era essa a causa no Galaxy A05s. Um porteiro de JavaScript não
alcança falhas que acontecem **antes** de qualquer JavaScript rodar (biblioteca
nativa que não carrega, `.so` incompatível, instalação recusada). Nesse cenário, o
aplicativo não fecha "por causa de um módulo JS" — e aí a evidência tem de vir do
próprio Android (`adb logcat`), que é a próxima fronteira se a 1.1.6 ainda fechar.

### Se ainda fechar na 1.1.6

Então a falha é anterior ao JavaScript, e a hipótese muda de lugar: passa a ser
carregamento de biblioteca nativa ou instalação. O caminho para provar isso não é
mais leitura de código — é `logcat` no aparelho (ou o relatório do Android se o
aplicativo conseguir gravar `tombstone`). Está registrado aqui para não se perder.

## §AT — Verificação do APK entregue (1.1.6)

| verificação | resultado |
| --- | --- |
| arquivo | `Lunaria-1.1.6-arm64-release.apk` |
| tamanho | 66.824.323 bytes |
| sha256 | `b05441db3e032f6297f7484cbfbecf8938a20d2bc07b43c4f88d0be855e25c61` |
| versão **dentro do pacote** | **1.1.6**, código **8** (conferida com `apkanalyzer manifest version-name`, não pelo nome do arquivo — lição do §AR) |
| SDK | mínimo 24, alvo 36 |
| assinatura | v2 **Verifies**; certificado `c0271509ad829da96e8fd205faa99b7103bf43c358a8501c0925606c7b55719a` — **o mesmo desde a 1.0.0**, então instala por cima sem desinstalar |
| R8 | desligado de propósito (`android.enableMinifyInReleaseBuilds=false`) |
| bibliotecas | 48 arm64-v8a; `res/RT.gguf` com 7.818.140 bytes (modelo local intacto) |
| preservação | `tools/verificar_preservacao.py` sobre o APK entregue: **tudo o que já funcionava continua dentro** |
| bundle | 6.654.156 bytes |

### O porteiro está **dentro** do pacote entregue

Isto foi conferido nas duas codificações — e a lição do §AP se repetiu: mensagens
**acentuadas** dentro do bytecode do Hermes não aparecem em busca de 8 bits. A busca
certa é em bytes, nas duas formas (UTF-8 e UTF-16LE):

| texto | UTF-8 | UTF-16LE |
| --- | --- | --- |
| `A Lunaria não conseguiu abrir` | 0 | **1** |
| `Copiar diagnóstico` | 0 | **2** |
| `Isto NÃO é uma tela normal` | 0 | **1** |
| `Suas conversas e imagens continuam no aparelho` | 0 | **2** |
| `Último erro registrado antes deste` | 0 | **1** |
| `Não foi possível abrir o banco de dados…` (§AQ) | 0 | **1** |
| `instalarTratador`, `mostrarFalha`, `criarTelaDeAviso`, `lunariaRotasCarregadas` | **1 cada** | 0 |

Ou seja: a tela de aviso, a captura de erro da abertura e a mensagem do banco
**estão no arquivo que o Hamura vai instalar** — conferido no pacote, não no código.

### O que esta verificação **não** diz

Que o aplicativo abre no Galaxy A05s. Isso continua dependendo do aparelho (itens
18 a 22 do `CHECKLIST_APARELHO.md`). O que se pode afirmar com prova é: o mecanismo
que transforma falha de carregamento em **mensagem na tela** está dentro do pacote,
e o banco não é mais tocado no carregamento.

## §AU — A prova do defeito existia e era **inalcançável** (defeito do próprio diagnóstico, corrigido na 1.1.7)

Esta seção registra um defeito que não é do aplicativo, e sim do **instrumento de
diagnóstico** — e que quase nos custou a investigação inteira.

### O que existia

Desde a rodada da 1.1.3, o `MainApplication.kt` já instalava um tratador de
exceções não tratadas que gravava o rastro em `filesDir/diagnostico-nativo.txt`, e o
relatório em JavaScript já lia esse arquivo
(`app/components/views/DiagnosticReport.tsx`). Ou seja: havia captura funcionando.

### O defeito

`filesDir` é a pasta **privada** do aplicativo: `/data/data/<pacote>/files`. Sem
computador, sem `adb`, sem root, o Hamura **não tem como abrir essa pasta**. Se o
aplicativo fechasse sempre — exatamente o sintoma relatado — o arquivo com a causa
ficaria gravado, **correto e inutilizável**, dentro do aparelho. O instrumento
funcionava e não entregava nada: a prova existia do lado de dentro de uma porta
trancada.

Isto repete, em outro plano, os três erros de instrumento já registrados nesta
caçada: procurar nome de classe em dex reduzido (§AM), procurar texto acentuado com
`grep` de 8 bits (§AP) e confiar no nome do arquivo do APK (§AR). A pergunta que
faltou nas quatro vezes é a mesma: **"quem consegue ler o que este instrumento
grava?"**

### Também faltava: a morte que **não** gera exceção

Um tratador de exceções só vê exceções. Falha nativa de verdade (violação de memória
dentro de uma biblioteca `.so`), travamento (ANR) e morte por memória **não** passam
por ele: o processo é morto pelo sistema e o tratador nunca roda. Para esses casos,
quem sabe o motivo é o próprio Android — e ele guarda isso por aplicativo
(`ApplicationExitInfo`, desde o Android 11), inclusive com o rastro da falha nativa.

### Correção (1.1.7)

| peça | o que faz |
| --- | --- |
| `CapturaDeFalha.kt` (novo) | instala o tratador antes de qualquer biblioteca carregar e grava o rastro em **dois lugares**: a pasta privada (relatório na tela) e a pasta **Downloads** do aparelho (arquivo `lunaria-ultimo-erro.txt`, alcançável pelo celular e enviável por compartilhamento) |
| `registrarSaidasAnteriores` | na abertura seguinte, lê o histórico do Android (`getHistoricalProcessExitInfos`) e registra a morte **anormal** anterior — motivo em português, memória no fim e rastro da falha nativa. Saída normal (usuário fechou, sistema liberou) é ignorada; a mesma morte não é repetida em toda abertura |
| `DiagnosticReport.tsx` | passa a **dizer onde o arquivo está** e como enviá-lo sem computador, e repete isso no texto copiado |
| `EntradaSegura.js` (porteiro) | o relatório da tela de aviso também diz para procurar o arquivo em Downloads, para o caso em que nenhuma tela do aplicativo conseguiu aparecer |

A gravação em Downloads usa `MediaStore` no Android 10 ou superior (caminho
permitido, sem permissão especial) e o caminho direto nas versões antigas, com falha
tolerada: se não der, o registro privado continua valendo. O tratador anterior é
**preservado** e chamado no fim — registrar não é engolir o comportamento do
Android. E a gravação é protegida: falhar ao gravar **nunca** vira um segundo
problema.

### Provas (executadas aqui)

- **8 testes novos de estrutura** (`tests/capturaNativa.test.mjs`): grava nos dois
  lugares; o nome do arquivo privado é **o mesmo** dos dois lados (Kotlin ×
  JavaScript) — se um lado renomear o arquivo e o outro não, o teste falha, porque o
  relatório ficaria vazio em silêncio; a captura é instalada **antes** de
  `loadReactNative`; a morte sem exceção é lida do histórico; versão e aparelho
  entram no registro; o tratador anterior é preservado.
- **2 testes de tela**: com registro nativo, a tela **diz** que o arquivo está em
  Downloads e o texto copiado o menciona; sem registro nativo, a tela **não** fala
  em Downloads (nada de aviso fantasma).

### O que continua **não** provado

Que o aplicativo abre no Galaxy A05s — o mesmo de sempre. O que esta rodada muda é
que, **se ainda fechar**, existe agora um caminho para o motivo sair do aparelho sem
computador: o arquivo em Downloads. Se nem isso existir, a morte aconteceu antes de
o processo conseguir escrever qualquer coisa, e a resposta passa a ser do
`logcat`/relatório do Android.

## §AV — Escrevi um método de API "de memória" e o build me corrigiu (19/09, mesmo dia)

Registro curto, porque a lição vale mais que o defeito.

Ao escrever a leitura do histórico de mortes do Android em `CapturaDeFalha.kt`,
usei o nome `getHistoricalProcessExitInfos()`. O método **não existe**: o correto é
`getHistoricalProcessExitReasons(...)` — e o build falhou em
`:app:compileReleaseKotlin` com `Unresolved reference`, exatamente no meu arquivo:

```
e: CapturaDeFalha.kt:98:38 Unresolved reference 'getHistoricalProcessExitInfos'.
e: CapturaDeFalha.kt:99:65 Unresolved reference 'reason'.
```

Dois defeitos no mesmo trecho, revelados pelo compilador:

1. **nome do método inventado** — escrevi de memória em vez de conferir;
2. **constantes no lugar errado** — `REASON_CRASH_NATIVE` e companhia ficam em
   `ApplicationExitInfo`, não em `ActivityManager`; e `peakRss`, que eu usei para
   registrar o pico de memória, **não existe** nessa classe.

### Como foi corrigido — e o que passou a ser regra

Em vez de tentar de novo, conferi a API **contra o `android.jar` da plataforma**
compilada, que é a fonte de verdade disponível nesta máquina:

```bash
javap -classpath /opt/android-sdk/platforms/android-36/android.jar android.app.ApplicationExitInfo
javap -classpath /opt/android-sdk/platforms/android-36/android.jar android.app.ActivityManager | grep Historical
```

Com as assinaturas reais em mãos, a correção foi mecânica. Antes de rodar o build de
30 minutos inteiro, compilei **só o ponto que falhou**:

```bash
cd android && ANDROID_HOME=/opt/android-sdk ./gradlew :app:compileReleaseKotlin
```

`BUILD SUCCESSFUL in 2m 14s` — e só então o build completo foi disparado. Duas
mudanças de método, ambas para ficar:

- **API do Android não se escreve de memória: confere-se no `android.jar` com
  `javap`.** O custo é 10 segundos; o custo de não fazer é um build inteiro perdido
  (ou pior, uma correção que só se prova no aparelho).
- **Antes do build completo, compilar a tarefa que falhou.** `:app:compileReleaseKotlin`
  leva dois minutos e responde à pergunta "meu código novo compila?" sem gastar meia
  hora.

No mesmo dia, um detalhe de ambiente cobrou o mesmo pedágio: a invocação manual do
`gradlew` falhou com *"SDK location not found"* porque eu não exportei
`ANDROID_HOME`. O script de build exporta — por isso ele existe e por isso vale usar
sempre ele.

## §AW — Verificação do APK entregue (1.1.7)

| verificação | resultado |
| --- | --- |
| arquivo | `Lunaria-1.1.7-arm64-release.apk` |
| tamanho | 66.829.187 bytes |
| sha256 | `22113359255349455790f4b1c2ffdbfd3c94529342891695d045b65a653a8c47` |
| versão **dentro do pacote** | **1.1.7**, código **9** (`apkanalyzer manifest version-name` — não pelo nome do arquivo, lição do §AR) |
| SDK | mínimo 24, alvo 36 |
| assinatura | certificado `c0271509ad829da96e8fd205faa99b7103bf43c358a8501c0925606c7b55719a` — **o mesmo desde a 1.0.0** (instala por cima) |
| preservação | `tools/verificar_preservacao.py`: tudo o que já funcionava continua dentro |
| bibliotecas | 48 arm64-v8a; `res/RT.gguf` 7.818.140 bytes |
| bundle | 6.655.420 bytes |

### A captura nativa está **dentro** do pacote entregue (conferido, não presumido)

No dex, dentro do APK:

| verificação | resultado |
| --- | --- |
| classe nova | `br.aurora.luna.lunaria.next.CapturaDeFalha` **presente** (e as duas lambdas geradas pelo Kotlin) |
| nome do arquivo público | `lunaria-ultimo-erro.txt` — 3 ocorrências |
| nome do arquivo privado | `diagnostico-nativo.txt` — 2 ocorrências |
| motivo legível | `falha NATIVA (biblioteca)` — presente |
| API do histórico | `getHistoricalProcessExitReasons` — presente; `ApplicationExitInfo` — 11 ocorrências |

No bundle JavaScript (busca em bytes, UTF-8 e UTF-16LE — lição do §AP):

| texto | onde |
| --- | --- |
| `lunaria-ultimo-erro.txt` | 1 ocorrência (UTF-8) |
| `Dá para me enviar sem computador` | 1 ocorrência (UTF-16LE — acentuado) |
| `Existe um registro de falha gravado pelo Android` | 1 ocorrência (UTF-8) |
| `A Lunaria não conseguiu abrir` (porteiro, §AS) | 1 ocorrência (UTF-16LE) |
| `Lunaria:1.1.7` (identificação do cliente no provedor) | 1 ocorrência |

### O que esta verificação **não** diz

Que a gravação **funciona** no Galaxy A05s: isso depende do sistema de arquivos e da
MediaStore reais. E continua **não** provado que o aplicativo abre. O que está
provado: o código que grava o motivo — e a instrução que diz ao usuário onde
encontrá-lo — estão **no arquivo que o Hamura vai instalar**.

### Build desta rodada

`BUILD SUCCESSFUL in 15m 21s` (`logs/gradle-33.log`), 952 tarefas acionáveis (510
executadas, 334 do cache, 108 já atualizadas). Antes dele houve **uma tentativa
perdida** — a que revelou o defeito da API inventada (§AV) — e o build anterior
havia sido interrompido no meio por queda do ambiente de execução; o cache do Gradle
preservado em `/opt` transformou a retomada em 15 minutos em vez de 30.

## §AX — Auditoria do manifesto somado ao APK: hipóteses que caíram com prova (1.1.8)

Antes de mexer em mais código, fiz o que faltava ler linha a linha: o
`MainActivity.kt`, o manifesto de origem, e — o que importa de verdade — o
**manifesto mesclado dentro do APK entregue**, com os recursos que ele referencia.
Não foi para "dar uma olhada": cada item abaixo é uma forma conhecida de o
aplicativo morrer **antes de qualquer JavaScript**, que é exatamente onde a
investigação ainda não tinha prova.

| hipótese | como foi testada | resultado |
| --- | --- | --- |
| recurso XML referenciado pelo manifesto **ausente** (`networkSecurityConfig`, `dataExtractionRules`) | `aapt2 dump resources` no APK: resolver os dois IDs | **refutada** — `0x7f140001 → xml/data_extraction_rules`, `0x7f140007 → xml/network_security_config`, ambos presentes |
| `network_security_config.xml` **malformado** (derruba o processo no arranque) | `aapt2 dump xmltree res/8G.xml` — parse real do XML binário | **refutada** — `base-config cleartextTrafficPermitted=false`, `trust-anchors: system`, `debug-overrides: user`. Estrutura válida |
| tema da atividade **ausente** (crash clássico: `Resources$NotFoundException`) | manifesto mesclado + tabela de recursos | **refutada** — `MainActivity` usa `@ref/0x7f120266` = `style/Theme.App.SplashScreen`, que existe |
| **cadeia de pais** do tema quebrada (`InflateException` no arranque) | `Theme.App.SplashScreen` → pai `style/Theme.SplashScreen (0x7f1202da)`; `postSplashScreenTheme = @style/AppTheme (0x7f12000d)` | **refutada** — a cadeia resolve inteira; ambos os estilos existem |
| atividades/serviços com problema de declaração | manifesto mesclado: `MainActivity` com `exported=true`, `MAIN`/`LAUNCHER` | **refutada** — declaração completa e correta |

### O que a auditoria **achou** de verdade (achados menores, registrados e tratados)

1. **`<service>` declarado duas vezes** no manifesto de origem
   (`android/app/src/main/AndroidManifest.xml`): a mesma linha, idêntica, repetida —
   e as **duas** chegavam ao manifesto mesclado
   (`com.asterinet.react.bgactions.RNBackgroundActionsTask`, ambas com
   `foregroundServiceType="0x1"`). Duplicata idêntica é inofensiva em execução
   (Android registra o mesmo componente duas vezes, a segunda vale), mas é lixo que
   confunde quem lê e pode virar divergência real se um dia um dos lados mudar.
   **Removida**; há teste de estrutura que confere que a declaração aparece **uma
   vez**.
2. **Nomes de recurso encurtados** no APK (`res/8G.xml`, `res/4j.xml`): é a
   otimização de recursos do AGP, ligada por padrão. Ela é inofensiva para este
   aplicativo (nada aqui procura recurso **por nome** em tempo de execução), mas
   explica por que uma busca por `res/xml/` no ZIP não acha nada — foi a primeira
   pista falsa desta auditoria, e vale a nota para a próxima vez.

### O que este § muda no diagnóstico

Fecha, com prova, a família "o aplicativo morre **por causa de recurso do
manifesto**" — que era uma das poucas explicações ainda de pé para uma morte
**antes do JavaScript**. O que continua de pé é a família "morte sem exceção"
(falha nativa, memória, sinal), que agora tem instrumento próprio: a trilha de
abertura do §AY.

## §AY — Trilha de abertura: a resposta para a morte que não deixa exceção (1.1.8)

O §AU fez o registro de falha sair do aparelho. Faltava o caso em que **não há
registro nenhum para sair**: falha nativa de verdade (violação de memória dentro de
uma biblioteca), morte por sinal, ou o sistema matando o processo por memória. Nada
disso gera exceção Java — o tratador de erro nunca roda — e a abertura termina sem
deixar uma linha sequer. Era o último ponto cego.

### A ideia

Se não há erro para registrar, registre **o caminho**. Cada etapa do arranque grava
uma linha com horário num arquivo (`filesDir/trilha-abertura.txt`). Quando uma
abertura **não** chega ao fim, a abertura seguinte encontra a trilha inacabada e a
promove — para o relatório na tela e para o arquivo na pasta Downloads — com um
cabeçalho que diz, em português, **onde parou**.

### As cinco etapas

| etapa | onde é marcada | o que significa se o processo morrer depois dela |
| --- | --- | --- |
| `1/5 captura de falha instalada` | `attachBaseContext` (o ponto mais cedo que existe em Java) | morreu carregando classes básicas ou no próprio `Application` |
| `2/5 aplicativo criado` | `MainApplication.onCreate` | morreu antes de tocar no React Native |
| `3/5 React Native carregado` | depois de `loadReactNative(this)` | morreu subindo o motor JS / módulos nativos |
| `4/5 tela principal criada` | `MainActivity.onCreate` | morreu montando a tela / o bundle |
| `5/5 ABERTURA CONCLUÍDA` | `MainActivity.onResume` | **chegou à frente**: o aplicativo abriu |

A marca final vem do ciclo de vida (`onResume`), não de chamada do JavaScript: é o
sinal de que a tela realmente apareceu — e não depende de nenhuma ponte que possa
estar quebrada justamente quando é preciso.

### Três decisões que sustentam o instrumento

1. **Instalar em `attachBaseContext`, não em `onCreate`.** É o ponto mais cedo que
   existe em Java; se o arranque morre no próprio `onCreate` ou no carregamento das
   bibliotecas nativas, a captura e a trilha já estão no lugar. A instalação é
   idempotente (trava interna), então não há duplo envolvimento do tratador.
2. **Colher e limpar a trilha numa passagem só.** Ler e depois limpar seriam dois
   passos: a limpeza atrasada poderia apagar as linhas da abertura **atual** — e o
   diagnóstico sumiria exatamente quando é preciso. Há teste que trava a ordem
   (`ler` antes de `limpar`).
3. **Abertura que termina não vira alarme.** Se a última linha é `ABERTURA
   CONCLUÍDA`, não há nada a reportar e o arquivo é apenas reiniciado. Sem isso, o
   instrumento viraria alarme falso em toda abertura normal — e ninguém olharia mais
   para ele.

### Provas (executadas aqui)

**9 testes novos de estrutura** (`tests/capturaNativa.test.mjs`), que leem o Kotlin:
as cinco etapas existem e estão nos arquivos certos; a instalação está **dentro** de
`attachBaseContext` e **antes** de `onCreate`; a marca final vem de `onResume`; a
conclusão acontece **uma vez por processo**; a trilha inacabada é promovida com o
texto "A ABERTURA ANTERIOR NÃO CHEGOU AO FIM" e o ponto onde parou; a abertura
concluída **não** é promovida; a colheita lê antes de limpar; a trilha tem teto de
linhas; cada linha tem horário; e a trilha inacabada sai **também** na pasta
Downloads.

Total desta rodada: **145 testes de lógica** (eram 136) e **76 de renderização**,
`tsc` e `eslint` sem erros.

### O que isto muda no diagnóstico, dito sem enfeite

Antes: "o aplicativo fecha ao abrir, e quando não há exceção não sabemos nada".
Depois: "o aplicativo fecha ao abrir, e o arquivo em Downloads diz que parou **depois
de '3/5 React Native carregado'**" — ou seja, entre subir o motor JavaScript e
montar a tela. Isso é a diferença entre investigar às cegas e investigar com um
endereço.

Continua **não** provado que o aplicativo abre no Galaxy A05s. O que está provado é
que, se não abrir, a próxima abertura tem como dizer onde parou.

## §AZ — Verificação do APK entregue (1.1.8)

| verificação | resultado |
| --- | --- |
| arquivo | `Lunaria-1.1.8-arm64-release.apk` |
| tamanho | 66.830.487 bytes |
| sha256 | `32fa0bfb9c77ac55db2aae3a22e80db16d2204717c968af1cd89175b47082741` |
| versão **dentro do pacote** | **1.1.8**, código **10** (conferida com `apkanalyzer`, não pelo nome do arquivo) |
| SDK | mínimo 24, alvo 36 |
| assinatura | o mesmo certificado `c0271509…5719a` desde a 1.0.0 — instala por cima |
| preservação | `tools/verificar_preservacao.py`: tudo o que já funcionava continua dentro |
| bibliotecas / dex | 48 arm64-v8a; 4 dex (R8 desligado); `res/RT.gguf` 7.818.140 bytes |
| duplicata do `<service>` | **corrigida**: o `RNBackgroundActionsTask` aparece **1×** no manifesto mesclado (aparecia 2× na 1.1.7) |

### A trilha de abertura está **dentro** do pacote (conferido no dex)

| texto / símbolo | onde foi encontrado |
| --- | --- |
| `trilha-abertura.txt` | `CapturaDeFalha` (4 ocorrências) |
| `ABERTURA CONCLUÍDA` | `CapturaDeFalha` (3) |
| `A ABERTURA ANTERIOR NÃO CHEGOU AO FIM` | `CapturaDeFalha` (1) |
| `1/5 captura de falha instalada` | `CapturaDeFalha` (1) |
| `2/5 aplicativo criado` | `MainApplication` (presente) |
| `3/5 React Native carregado` | `MainApplication` (presente) |
| `4/5 tela principal criada` | `MainActivity` (presente) |
| `lunaria-ultimo-erro.txt` | `CapturaDeFalha` (4) |
| `getHistoricalProcessExitReasons` | `CapturaDeFalha` (1) |

Ou seja: **as cinco etapas e o caminho de saída para Downloads estão no arquivo que o
Hamura vai instalar** — a etapa `5/5` é gravada em tempo de execução pela chamada de
`onResume`, portanto a string aparece no código da captura, não no `MainActivity`.

### Build desta rodada

`BUILD SUCCESSFUL in 6m 46s` (`logs/gradle-34.log`) — com o cache do Gradle quente, o
build caiu de ~30 minutos (frio) para menos de 7. Antes dele, a compilação isolada de
`:app:compileReleaseKotlin` (3m04) já havia aprovado o Kotlin — foi ela que pegou, na
rodada anterior, o defeito da API inventada (§AV).

### O que esta verificação **não** diz

Que a trilha grava no Galaxy A05s (depende do sistema de arquivos e da MediaStore
reais) e, mais uma vez, **não** prova que o aplicativo abre. Prova que o instrumento
que responde "em que etapa parou" está dentro do pacote entregue.

## §BA — Auditoria de encerramento silencioso e a terceira saída para o relatório (1.1.9)

Duas frentes nesta rodada. A primeira fecha uma hipótese que **nenhum instrumento
meu alcança**; a segunda resolve um problema prático que sobrou das rodadas
anteriores.

### 1. Auditoria: existe algum encerramento **deliberado** na abertura?

Toda a instrumentação das rodadas anteriores (porteiro, captura nativa, trilha)
supõe que a abertura termina por **falha**. Existe outra possibilidade, mais
incômoda: o aplicativo ser encerrado **de propósito** por algum código, ou pelo
sistema operacional sob instrução do aplicativo. Nesse caso não há exceção, não há
falha nativa, não há rastro — só o aplicativo fechando, exatamente como relatado.

Foi procurado (no código JavaScript e no Kotlin):

| procurado | resultado |
| --- | --- |
| `DevSettings.reload()`, `reloadAsync`, `expo-updates` (recarregar no arranque) | **não existe** no código |
| `BackHandler.exitApp()`, `process.exit`, `System.exit`, `killProcess`, `exitProcess` | **não existe** |
| `finish()`, `finishAffinity()` (encerrar a tela) | **não existe** |
| `BackHandler` em geral | existe só em telas (menu de contexto, gaveta, lista de personagens) — nenhum no caminho de abertura |

Ou seja: **nada no aplicativo encerra a si mesmo**, e não há caminho de
recarregamento remoto (o `expo-updates` está desligado por configuração:
`expo.modules.updates.ENABLED=false`, conferido no manifesto mesclado). Hipótese
refutada com prova — e vale registrar porque, se fosse verdadeira, todo o
instrumento das três rodadas anteriores estaria apontando para o lado errado.

### 2. A terceira saída para o relatório sair do aparelho

O levantamento anterior (`§AU`) mostrou que o relatório precisa **sair** do aparelho
para servir para alguma coisa. Havia dois caminhos, e os dois podem falhar:

| caminho | cobre | pode falhar quando |
| --- | --- | --- |
| botão "Copiar diagnóstico" (área de transferência) | qualquer falha, **depois** que a tela aparece | a área de transferência está indisponível (e é justamente o tipo de coisa que quebra junto com o resto) |
| arquivo `lunaria-ultimo-erro.txt` em Downloads (captura nativa) | falhas **antes** do JavaScript | a falha é dentro do JavaScript (o arquivo nem é criado) |

Faltava o caso mais provável: **falha dentro do JavaScript, com a tela de aviso no
ar**. O texto está na tela, mas só sai por cópia — e, se a cópia não funcionar, resta
fotografar a tela.

Entrou o terceiro caminho: botão **"Salvar em Downloads"**, presente na tela de aviso
do porteiro **e** no relatório de diagnóstico. Ele grava o mesmo texto em
`lunaria-diagnostico.txt`, na pasta Downloads do aparelho, pelo utilitário que o
aplicativo já usa para exportar arquivos (`lib/utils/File.ts` →
`saveStringToDownload`). Sem inventar API nova, sem pedir permissão extra.

Três decisões que sustentam o botão:

1. **Carga tardia e cercada.** `lib/utils/File.ts` importa `expo-file-system` e
   `expo-document-picker` no topo — e os dois procuram módulo nativo **no import**
   (`BUGS_FOUND.md` §AN). Como este botão vive na tela de emergência, o utilitário é
   carregado **na hora do toque**, dentro de `try/catch`; o caminho é relativo
   (`./SalvarDiagnostico`), sem depender de apelido de configuração.
2. **Nunca lança.** Falha ao salvar devolve `false` e o usuário continua com o texto
   na tela e o botão de copiar. Ali dentro o usuário já está sem aplicativo; perder o
   relatório seria perder tudo.
3. **É o mesmo texto.** O que vai para o arquivo é exatamente o relatório que está na
   tela (o teste confere isso), não um resumo.

### 3. Provas (executadas aqui)

| teste | o que prova |
| --- | --- |
| **integração do porteiro** (`entrada-rotas-falham.test.tsx`) | **o encadeamento inteiro, com o `index.js` de verdade e as rotas lançando na avaliação**: o aplicativo não explode, a tela de aviso é registrada como tela principal, **renderiza o motivo real da falha** e oferece as duas saídas. Este é o teste que faltava: os anteriores provavam pedaços, e um pedaço pode passar com o encadeamento quebrado |
| botão "Salvar em Downloads" na tela de aviso | grava o relatório completo e dá retorno ao usuário |
| `salvarDiagnosticoNoAparelho` usa o utilitário certo | nome `lunaria-diagnostico.txt`, codificação `utf8`, texto idêntico ao da tela |
| falha ao salvar | devolve `false` e **não lança** |
| botão no relatório de diagnóstico | grava e avisa; se falhar, a tela continua de pé com o botão de copiar |

Total: **145 testes de lógica** e **86 de renderização** (eram 76), em **12 suítes**
(eram 10), com `tsc` e `eslint` limpos.

### 4. Duas armadilhas novas de teste, registradas para não voltarem

1. **`jest.resetModules()` com a biblioteca de testes requerida dentro do teste**
   registra hooks aninhados e o próprio Jest aborta ("Hooks cannot be defined inside
   tests"). Solução: carregar tudo uma vez, no topo do arquivo.
2. **Passar a fábrica da tela direto ao React** faz o React tratá-la como componente
   funcional e receber de volta uma **classe** — que não é filho válido, e a tela sai
   vazia. O teste "passava" a olhar uma árvore vazia. A fábrica **precisa ser
   chamada**: é ela que lê `react` e `react-native` na hora do uso, de propósito
   (para não importar nada no topo). Ambas as armadilhas estão comentadas no arquivo
   de teste, onde alguém vai tropeçar nelas de novo.

### 5. O que isto muda

Antes: se o aplicativo falhasse ao carregar, havia **duas** formas de o motivo sair
do aparelho — e as duas com furo conhecido. Agora há três, e a terceira cobre
justamente o caso em que a tela de aviso aparece mas a área de transferência não
responde.

Continua **não** provado que o aplicativo abre no Galaxy A05s. O que está provado
por teste de integração é que, se ele falhar ao carregar, **abre numa tela com o
motivo e duas formas de me enviar**.

## §BB — O pacote de fonte quase saiu com as senhas da chave dentro (1.1.9)

Este é o tipo de defeito que não aparece em teste nenhum e não quebra nada no
aparelho: ele quebra a **entrega**. Vale registrar inteiro, porque a barreira que
existe hoje foi desenhada em cima do erro real.

### O que aconteceu

Ate esta rodada, o ZIP de fonte era montado à mão, com uma lista de exclusões
escrita no momento. Nesta rodada virou script (`lunaria-build/empacotar-fonte.sh`)
com lista própria. A lista nova excluía `*.keystore`, `*.jks`, `*.p12` e `*.pem` —
**por extensão**. O arquivo de credenciais da assinatura, porem, chama-se
`android/keystore.properties`, e `.properties` não estava na lista.

Resultado: o ZIP de 1.1.9 saiu com **1 arquivo a mais** que o de 1.1.8, e esse
arquivo continha `storeFile`, `storePassword`, `keyAlias` e `keyPassword` — ou seja,
**as duas senhas da chave de assinatura** em texto puro, num pacote destinado a
publicação.

### Como foi pego

Não por teste (nenhum cobre empacotamento), e sim por **comparação com a entrega
anterior**: a lista de arquivos do ZIP novo foi posta lado a lado com a do ZIP de
1.1.8 (`comm` sobre as duas listas). "Só na 1.1.9" deveria trazer exatamente os três
arquivos novos de código; veio um quarto, que ninguém tinha escrito nesta rodada.

Diferença de lista é barata e pega o que não se está procurando. Fica como prática
fixa do empacotamento.

### O que mudou

A conferência passou a ter **duas barreiras**, e a segunda é a que importa:

| barreira | o que procura | por que |
| --- | --- | --- |
| nome | `*keystore.properties`, `*.keystore`, `*.jks`, `*.p12`, `*.pem` | é a forma direta; foi o que faltou |
| **conteúdo** | o **formato** de um arquivo de chave preenchido: `storeFile` **e** `storePassword` com valor literal, no mesmo arquivo; ou um bloco `BEGIN ... PRIVATE KEY` | pega o arquivo mesmo se ele for renomeado, e não depende de adivinhar nome |

A barreira de conteúdo tem uma sutileza que custou uma iteração: a primeira versão
procurava as palavras `storePassword`/`keyPassword` e acusou **três arquivos
legítimos** — o próprio plugue de assinatura, o `build.gradle` e o `BUILDING.md`,
todos eles **citando** as propriedades (`getProperty('storePassword')`, chave de
depuração `'android'`, modelo de documentação `storePassword=...`). Barreira que
grita em falso é barreira que alguém desliga no primeiro aperto. A regra final
ignora valores que são uso (`getProperty`), modelo (`...`, `<...>`) ou variável
(`$...`), e exige o **par** `storeFile` + `storePassword` literal — combinação que só
existe em arquivo de chave de verdade.

### Provas

| prova | resultado |
| --- | --- |
| ZIP 1.1.9 refeito, lista comparada com a 1.1.8 | só na 1.1.9: os **3** arquivos de código novos; nada desapareceu |
| `keystore.properties` no ZIP entregue | **0** ocorrências |
| ZIPs públicos anteriores (1.0.0 e 1.1.8) | **0** ocorrências — nenhuma entrega anterior vazou |
| barreira de conteúdo **testada contra o arquivo real** | aponta `android/keystore.properties` e aborta o pacote (teste negativo, feito de propósito) |
| somas internas do ZIP | 427 de 427 OK |

O arquivo nunca saiu daqui: foi pego entre a montagem e a entrega. Mas o susto é
registrado porque a lição não é "faltou uma extensão na lista" — é que **empacotar
precisa de conferência automática e de comparação com a entrega anterior**, e que
barreira de segurança se testa tentando furá-la, não escrevendo que ela funciona.

## §BC — A trilha chegava até a metade: agora o JavaScript também escreve nela (1.1.10)

### O buraco, dito em uma frase

A trilha nativa responde "até onde o arranque chegou" **antes** do JavaScript. A
parte mais provável de um fechamento silencioso, porem, fica **depois**: entre
"React Native carregado" e a primeira tela. Ali moram as migrações do banco, o
cofre, a política de bloqueio, o tema e a tela em si. Se o processo morre no meio
disso sem exceção, a trilha parava em `4/5 tela criada` — e **não dizia o quê**.

O JavaScript **já** tinha migalhas (`lib/utils/Diagnostics.ts`, anel de 40). Só que
elas moram no `react-native-mmkv`, que só o próprio JavaScript lê. Para lê-las é
preciso o aplicativo **abrir** — que é exatamente o que não acontece quando ele
fecha ao abrir. A evidência existia e era inalcançável.

### O que mudou

O JavaScript passou a escrever na **mesma** trilha do lado nativo:

| peça | papel |
| --- | --- |
| `TrilhaJsModule.kt` | módulo nativo mínimo (`NativeModules.TrilhaJs`) com um método: receber uma linha de texto |
| `TrilhaJsPackage.kt` | pacote que registra o módulo; adicionado em `MainApplication` **dentro de try/catch** |
| `CapturaDeFalha.marcarEtapaDeJs` | escreve na trilha existente; contexto ausente, texto vazio ou maior que 200 caracteres são descartados em silêncio |
| `lib/utils/TrilhaJs.ts` | lado JavaScript: duas vias por etapa, nunca lança, nunca é pré-requisito |

Como a colheita da abertura anterior é do lado nativo (`colherTrilhaAnterior`), a
próxima abertura leva **tudo** — etapas nativas e etapas do JavaScript — para
`lunaria-ultimo-erro.txt` na pasta Downloads, mesmo que o aplicativo morra de novo
e o Hamura nunca veja tela nenhuma.

### As oito etapas (e o que cada ausência significa)

| etapa | gravada quando | se ela faltar, morreu em |
| --- | --- | --- |
| `js 1/8 porteiro instalado` | `index.js`, logo após instalar o tratador | avaliação do próprio `index.js` |
| `js 2/8 rotas carregadas` | `expo-router/entry` carregou inteiro | carregamento das rotas (o porteiro mostra a tela de aviso) |
| `js 3/8 tela inicial montou` | primeiro efeito de `app/_layout.tsx` | montagem do React / provedores |
| `js 4/8 bloqueio pronto` | `init()` do bloqueio resolveu | leitura da política de bloqueio (cofre, biometria, senha) |
| `js 5/8 imagens prontas` | ajustes de imagem lidos (ou "puladas" no modo seguro) | inicialização do gerador de imagem |
| `js 6/8 banco migrado` | `useMigrations` deu certo | migrações do banco |
| `js 7/8 Lunaria iniciada` | `startupApp()` resolveu | inicialização do aplicativo (personagem, ajustes, memória) |
| `js 8/8 lista de conversas na tela` | a lista renderizou de fato | renderização da tela principal |

Falhas também deixam linha, com o mesmo prefixo e um `!` (`js ! falha ao preparar o
bloqueio: …`), para que a linha final da trilha nunca seja ambígua entre "parou
aqui" e "falhou aqui".

### Por que **não** usar `expo-file-system` de dentro do JavaScript

Era o caminho óbvio: o aplicativo já exporta arquivos com ele. Foi descartado por
um motivo de lógica: `expo-file-system` é justamente um dos módulos sob suspeita.
Uma trilha que depende do módulo investigado falha exatamente no caso em que é
preciso — e falha em silêncio, porque trilha não grita. A ponte nativa não depende
de nenhum módulo do caminho de abertura.

### O que esta rodada **não** prova (e está escrito no relatório)

Não prova que a ponte funciona no aparelho. O registro de um módulo nativo legado
sob a arquitetura nova depende do React Native, e isso **só se verifica ligando**.
O que está provado por teste é o outro lado, que é o que protege o aplicativo:

- sem a ponte, `marcarEtapaJs` devolve `false` e **não lança**;
- ponte sem o método esperado, ou com método que lança, é tratada como ausência;
- a ponte é procurada **uma vez** (memoriza o fracasso, não fica tentando a cada etapa);
- a falha do canal das migalhas não afeta o canal do arquivo, e vice-versa.

Ou seja: no pior caso, o aplicativo abre exatamente como abria e a evidência extra
não aparece. Nenhum caminho novo de falha foi criado — e isso é testado, não
prometido.

### Duas armadilhas de teste encontradas (registradas para não voltarem)

1. **O carregador do Node cria duas instâncias do mesmo arquivo.** `lib/utils/
   TrilhaJs.ts` importa `./Diagnostics` (sem extensão); o teste importava
   `../lib/utils/Diagnostics.ts` (com extensão). Sob `node --import tsx`, isso são
   **dois** módulos: cada um com o seu armazenamento de memória. O teste do
   "segundo canal" falhava porque `readSteps()` falava com a instância que o módulo
   **não** usava. Provado com uma comparação de identidade (`D === T.__diagnostico`).
   Sob o Metro — e no Jest — há um grafo único. Correção: o canal das migalhas
   passou a ser injetável (`setEscritorDeMigalha`), o teste de lógica usa a injeção,
   e a **integração real** com o `Diagnostics` é afirmada no Jest, onde ela é
   verificável de verdade.
2. **Ordem no texto do arquivo não é ordem de execução.** A guarda de fonte exigia
   `6/8` antes de `7/8` pelo `indexOf`. Mas `startLunaria` (que marca `7/8`) é
   declarada **antes** do efeito que marca `6/8`, e ainda assim roda depois. A
   guarda passou a prender cada marca ao trecho que a executa (`6/8` antes de
   `void startLunaria()`, `7/8` depois de `await startupApp()`).

## §BD — Dois escritores, um arquivo: a evidência podia chegar pela metade (1.1.11)

Este defeito não aparece em teste de tela, não quebra nada no aparelho e não tem
sintoma visível. Ele estraga **exatamente o que o Hamura precisa me mandar** — e foi
encontrado lendo o próprio código que eu acabei de escrever na rodada anterior.

### O defeito

Duas origens de evidência, cada uma na sua thread, gravando o **mesmo** arquivo em
Downloads:

| origem | quando roda | o que traz |
| --- | --- | --- |
| colheita da abertura anterior | `instalar()`, no `attachBaseContext` | a **trilha** — até que etapa o arranque chegou |
| histórico do Android (`getHistoricalProcessExitReasons`) | `onCreate` | o **motivo** — inclusive falha nativa, que não gera exceção |

As duas chamavam `gravarPublico(app, ARQUIVO_PUBLICO, conteudo)`, que abre o arquivo
do MediaStore em modo `"wt"` — **escrever do começo, apagando o que havia**. Não há
ordem garantida entre duas threads. Ou seja: numa abertura depois de uma falha — o
caso em que a evidência importa — o arquivo podia chegar com **o motivo sem a
trilha** ou com **a trilha sem o motivo**. Metade da história, e sem aviso de que
faltava a outra metade.

O agravante é que as duas informações são complementares de propósito: o motivo
diz *que tipo* de morte foi; a trilha diz *onde* ela parou. Uma sem a outra deixa a
investigação no mesmo lugar em que estava.

### O conserto

Um **registro de seções em memória** e **uma única** função de gravação:

```
@Synchronized
private fun publicar(app, secao) {
    if (!secoes.contains(secao)) secoes.add(secao)
    val conteudo = cabecalho(app) + secoes.joinToString("\n\n")
    gravarPrivado(app, conteudo)
    gravarPublico(app, ARQUIVO_PUBLICO, conteudo)
}
```

Quem publica (o tratador de exceção e a colheita) entrega **a sua seção**; a função
junta tudo o que já foi publicado nesta abertura e regrava o arquivo inteiro. Com
isso a ordem de chegada deixa de importar: **a última gravação contém tudo**. O pior
caso possível passa a ser "escreveu duas vezes a mesma coisa" — em vez de "apagou a
metade que faltava".

Também nesta rodada:

- a colheita passou a ser **uma só**: lê o histórico do Android, colhe a trilha e
  monta um relatório único, com o motivo primeiro (curto, direto) e a trilha depois
  (o detalhe, etapa por etapa). O segundo coletor no `MainApplication` foi removido;
- o cabeçalho do relatório não se repete mais dentro das seções;
- a leitura do histórico (`lerSaidaAnormal`) **não grava nada** — separar ler de
  gravar foi o que tornou possível ter um único escritor.

### Provas

O arquivo Kotlin não roda aqui (não há emulador nem aparelho), então a prova é
**estrutural**, e ela é forte o bastante para prender o defeito:

| teste (em `tests/capturaNativa.test.mjs`) | o que trava |
| --- | --- |
| "só existe UM caminho que grava o relatório público" | `gravarPublico(app, ARQUIVO_PUBLICO` tem de aparecer **exatamente uma vez** no arquivo, e dentro de `publicar` |
| "publicar junta as seções em vez de sobrescrever" | o registro `secoes`, o `joinToString` na hora de gravar e a trava `@Synchronized` |
| "os dois produtores de evidência passam por publicar" | tratador de exceção **e** colheita usam `publicar`, nenhum grava direto |
| "a colheita acontece uma vez, e não duas" | `MainApplication` não pode voltar a chamar o segundo coletor |
| "a captura é instalada ANTES de o React Native carregar" | a colheita sai de `instalar()`, que roda no `attachBaseContext` |

Um sexto teste, da rodada anterior, **falhou** ao fazer esta mudança — e está
correto que tenha falhado: ele prendia a fiação antiga (`registrarSaidasAnteriores`
no `MainApplication`). Foi reescrito para prender o arranjo novo, em vez de
simplesmente apagado.

### O que isto muda para quem vai testar

Se o aplicativo fechar ao abrir, o arquivo `lunaria-ultimo-erro.txt` passa a chegar
**completo**: motivo *e* trilha, juntos, numa gravação só. É a diferença entre uma
tentativa de diagnóstico e duas.

## §BE — Correção de uma afirmação imprecisa: o texto das conversas NÃO é cifrado (1.1.11)

Registro de honestidade, não de código. Enquanto conferia o que a entrega promete,
encontrei uma afirmação **imprecisa** na documentação do projeto
(`MATRIZ_DE_CRITERIOS.md`):

> "Criptografia real de conversas, memória e imagens privadas — AES-256-GCM +
> PBKDF2-SHA256 … [auto-render] os bytes gravados não contêm o conteúdo"

A evidência citada é verdadeira — **para os arquivos do cofre** (as imagens). Mas o
critério falava também de **conversas e memória**, e essas não são cifradas pela
Lunaria. Verificado no código desta entrega:

| onde | o que se vê |
| --- | --- |
| `db/schema.ts` | a coluna do texto (`swipe`) é `text('swipe')`, sem transformação |
| `lib/state/Chat.ts` (gravação) | o texto entra direto no banco, com macros expandidas |
| `lib/state/ResearchMemory.ts` | a memória de pesquisa é persistida em MMKV, em claro |
| `lib/security/*` | só o cofre de **arquivos** (imagens) tem cifra e migração |

Ou seja: as conversas e a memória estão protegidas pelo **cofre de arquivos do
Android**, pela pasta privada do aplicativo e pela porta de bloqueio — mas **não**
são cifradas pela própria Lunaria. Dizer "criptografia real de conversas" era
afirmação a mais, e ficou corrigida na matriz.

### Por que não foi implementado nesta rodada (decisão, com motivo)

O mecanismo é viável e está mapeado — não é falta de caminho:

1. a cifra do projeto é **síncrona** (`@noble/ciphers`, `encryptString`/`decryptString`),
   então caberia num tipo de coluna do drizzle, sem tocar em dezenas de telas;
2. a chave já vive em memória com acessador síncrono (`PrivateVault` em
   `lib/security/PrivateStorage.ts`), então o banco conseguiria usá-la.

Mas há três problemas **reais**, e o terceiro é decisivo:

1. **A busca de mensagens é SQL sobre o próprio texto** (`lib/state/Chat.ts`, `LIKE`
   sobre `swipe`). Cifrar a coluna sem refazer a busca quebraria a busca
   **em silêncio** — resultado pior que o atual, na mesma classe dos defeitos que
   este projeto já decidiu não trocar às pressas.
2. **As conversas existentes estão em claro**: migrar tudo exige reescrever as
   linhas, com releitura verificada antes de apagar o original (é o padrão que a
   migração de imagens já usa, e que precisa ser repetido com o mesmo cuidado).
3. **Nada disso seria verificável aqui.** O aplicativo **não executa** neste
   ambiente. Uma cifra que falhe na leitura na sua conversa é pior do que uma
   cifra que ainda não existe — e, pior, contaminaria o diagnóstico em curso: se a
   próxima abertura falhar, não haveria como saber se a causa é o defeito antigo ou
   a camada nova.

Sequência decidida: (1) o aplicativo precisa **abrir**; (2) então a cifra do texto
entra, com a busca refeita em JavaScript e a migração verificada antes de apagar
qualquer original. O caminho técnico está mapeado acima e a pendência está visível
no próprio conjunto de testes (`tests/privatefiles.test.mjs`, teste marcado como
pendente — aparece como "skip" em toda execução).

O que **não** foi feito: nenhuma promessa foi maquiada. A matriz foi corrigida, o
escopo real está escrito no guia da entrega, e o item segue aberto.
