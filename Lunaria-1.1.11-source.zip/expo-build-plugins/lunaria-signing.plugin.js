const { withAppBuildGradle } = require('@expo/config-plugins')
const fs = require('fs')
const path = require('path')

/**
 * Lunaria — assinatura de release.
 *
 * O template do Expo assina o release com a chave de depuração (`debug.keystore`),
 * que não serve para distribuição. Este plugin injeta um `signingConfigs.release`
 * que lê as credenciais de `android/keystore.properties` (arquivo local, nunca
 * versionado) ou das variáveis de ambiente LUNARIA_*.
 *
 * Sem `keystore.properties`, o build continua funcionando com a chave de
 * depuração, exatamente como antes — o plugin não quebra ambientes sem chave.
 *
 * Formato do `android/keystore.properties`:
 *   storeFile=/caminho/absoluto/lunaria-release.jks
 *   storePassword=...
 *   keyAlias=lunaria
 *   keyPassword=...
 */

const SIGNING_ANCHOR = '    signingConfigs {\n'
const RELEASE_ANCHOR =
    '            // Caution! In production, you need to generate your own keystore file.\n' +
    '            // see https://reactnative.dev/docs/signed-apk-android.\n' +
    '            signingConfig signingConfigs.debug'

const RELEASE_SIGNING = `            // Lunaria: assinatura de release com chave própria.
            // O arquivo android/keystore.properties é local e não deve ser publicado.
            if (lunariaSigningAvailable) {
                signingConfig signingConfigs.lunariaRelease
            } else {
                signingConfig signingConfigs.debug
            }`

const HELPER = `    signingConfigs {
        lunariaRelease {
            storeFile lunariaSigningStoreFile
            storePassword lunariaSigningProperties.getProperty('storePassword')
            keyAlias lunariaSigningProperties.getProperty('keyAlias')
            keyPassword lunariaSigningProperties.getProperty('keyPassword')
        }`

const PRELUDE = `// --- Lunaria: credenciais de assinatura (gerado pelo plugin lunaria-signing) ---
def lunariaSigningProperties = new Properties()
def lunariaSigningPropertiesFile = rootProject.file('keystore.properties')
if (lunariaSigningPropertiesFile.exists()) {
    lunariaSigningPropertiesFile.withInputStream { lunariaSigningProperties.load(it) }
}
def lunariaSigningStoreFile = lunariaSigningProperties.getProperty('storeFile')
    ? rootProject.file(lunariaSigningProperties.getProperty('storeFile'))
    : null
def lunariaSigningAvailable = lunariaSigningStoreFile != null && lunariaSigningStoreFile.exists()

// --- fim do bloco Lunaria ---

`

const withLunariaSigning = (config) => {
    return withAppBuildGradle(config, (config) => {
        if (config.modResults.language !== 'groovy') return config
        let contents = config.modResults.contents

        if (!contents.includes('lunariaSigningProperties')) {
            // 1) prelúdio com a leitura das credenciais
            const androidIndex = contents.indexOf('android {')
            if (androidIndex === -1) throw new Error('android/app/build.gradle sem bloco android')
            contents = contents.slice(0, androidIndex) + PRELUDE + contents.slice(androidIndex)

            // 2) bloco de assinatura próprio
            if (!contents.includes(SIGNING_ANCHOR))
                throw new Error('android/app/build.gradle sem signingConfigs')
            contents = contents.replace(SIGNING_ANCHOR, HELPER + '\n')

            // 3) release usa a chave própria quando ela existe
            if (!contents.includes(RELEASE_ANCHOR))
                throw new Error('bloco de release inesperado em android/app/build.gradle')
            contents = contents.replace(RELEASE_ANCHOR, RELEASE_SIGNING)

            console.log(
                'Lunaria: assinatura de release configurada (usa android/keystore.properties quando presente).'
            )
        }

        config.modResults.contents = contents
        return config
    })
}

module.exports = withLunariaSigning
