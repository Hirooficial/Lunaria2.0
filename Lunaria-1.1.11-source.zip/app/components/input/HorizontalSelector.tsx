import { MaterialIcons } from '@expo/vector-icons'
import { useEffect, useRef } from 'react'
import { Pressable, Text, View, ViewStyle } from 'react-native'
import Animated, {
    Easing,
    useAnimatedStyle,
    useSharedValue,
    withTiming,
} from 'react-native-reanimated'

import { Theme } from '@lib/theme/ThemeManager'

type HorizontalSelectorProps<T> = {
    values: {
        label: string
        value: T
        icon?: keyof typeof MaterialIcons.glyphMap
        iconSize?: number
    }[]
    selected: T
    onPress: (selected: T) => void
    label?: string
    description?: string
    style?: ViewStyle
    capitalizeValues?: string
}

const HorizontalSelector = <T,>({
    values,
    selected,
    onPress,
    label,
    description,
    style,
}: HorizontalSelectorProps<T>) => {
    const { color, spacing, fontSize } = Theme.useTheme()
    const viewRef = useRef<View>(null)
    const initialRender = useRef(true)
    const animatedValues = useSharedValue({
        top: 0,
        left: 0,
        width: 0,
        height: 0,
    })
    const animatedStyle = useAnimatedStyle(() => {
        return animatedValues.value
    })

    useEffect(() => {
        if (!viewRef.current) return
        viewRef.current.measure((x, y, width, height, pageX, pageY) => {
            animatedValues.value = withTiming(
                {
                    top: y,
                    left: x,
                    width: width - 4,
                    height: height - 4,
                },
                { duration: initialRender.current ? 0 : 300, easing: Easing.out(Easing.ease) }
            )
        })
        initialRender.current = false
    }, [animatedValues, selected])

    return (
        <View style={[{ flex: 1 }, style]}>
            {label && (
                <Text
                    style={{
                        flex: style?.flex ?? 1,
                        color: color.text._100,
                    }}>
                    {label}
                </Text>
            )}

            <View
                style={{
                    flex: style?.flex ?? 1,
                    flexDirection: 'row',
                    justifyContent: 'space-evenly',
                    borderColor: color.primary._200,
                    backgroundColor: color.neutral._100,
                    borderWidth: 2,
                    borderRadius: 8,
                    marginTop: 8,
                }}>
                <Animated.View
                    style={[
                        {
                            position: 'absolute',
                            backgroundColor: color.primary._300,
                            borderRadius: 8,
                        },
                        animatedStyle,
                    ]}
                />

                {values.map((item, index) => {
                    const isSelected = item.value === selected
                    return (
                        <Pressable
                            ref={isSelected ? viewRef : null}
                            key={index}
                            onPress={() => onPress(item.value)}
                            style={{
                                flex: 1,
                                paddingVertical: spacing.m,
                                alignItems: 'center',
                                flexDirection: 'row',
                                justifyContent: 'center',
                                columnGap: 8,
                            }}>
                            {item.icon && (
                                <MaterialIcons
                                    name={item.icon}
                                    size={item.iconSize ?? 16}
                                    color={color.text[isSelected ? '_200' : '_500']}
                                />
                            )}
                            <Text
                                style={{
                                    color: color.text[isSelected ? '_200' : '_500'],
                                    fontSize: fontSize.s,
                                }}>
                                {item.label}
                            </Text>
                        </Pressable>
                    )
                })}
            </View>

            {description && (
                <Text
                    style={{
                        color: color.text._400,
                        marginTop: 4,
                        paddingBottom: spacing.xs,
                        marginBottom: spacing.m,
                    }}>
                    {description}
                </Text>
            )}
        </View>
    )
}

export default HorizontalSelector
