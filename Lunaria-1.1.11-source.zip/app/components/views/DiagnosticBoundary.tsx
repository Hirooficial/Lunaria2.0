/**
 * Última linha de defesa da abertura.
 *
 * Um erro durante a montagem das telas do React **não** passa por `try/catch`:
 * em versão de produção ele simplesmente fecha o aplicativo. Este limite de erro
 * transforma esse fechamento numa tela legível, com o relatório e o botão de
 * tentar de novo — e esconde a tela de abertura, que de outro modo ficaria
 * cobrindo o relatório e pareceria "travou".
 */

import { SplashScreen } from 'expo-router'
import { Component, ReactNode } from 'react'

import DiagnosticReport from '@components/views/DiagnosticReport'
import { recordError } from '@lib/utils/Diagnostics'

type Props = {
    children: ReactNode
}

type State = {
    error?: Error
}

export default class DiagnosticBoundary extends Component<Props, State> {
    state: State = {}

    static getDerivedStateFromError(error: Error): State {
        return { error }
    }

    componentDidCatch(error: Error) {
        recordError('tela', error)
        void SplashScreen.hideAsync().catch(() => undefined)
    }

    render() {
        if (this.state.error)
            return (
                <DiagnosticReport
                    title="A Lunaria encontrou um erro na tela"
                    detail={this.state.error.message}
                    onRetry={() => this.setState({ error: undefined })}
                />
            )
        return this.props.children
    }
}
