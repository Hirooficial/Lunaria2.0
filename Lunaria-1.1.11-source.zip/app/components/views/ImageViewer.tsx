/**
 * Visualizador de imagem em tela cheia.
 *
 * Fica montado uma única vez, no layout raiz, e é aberto pela store
 * `useImageViewer`. Recursos: ampliar com pinça e toque duplo, salvar na
 * galeria, compartilhar e apagar — os dois primeiros sempre avisando que a
 * cópia externa perde a proteção da Lunaria.
 */

import { Ionicons } from '@expo/vector-icons'
import React, { useCallback, useEffect, useState } from 'react'
import { ActivityIndicator, Modal, Pressable, StyleSheet, Text, View } from 'react-native'
import { Gesture, GestureDetector } from 'react-native-gesture-handler'
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated'

import ThemedButton from '@components/buttons/ThemedButton'
import Alert from '@components/views/Alert'
import { isPrivateUri, resolvePrivateImage } from '@lib/security/PrivateImageCache'
import { Chats } from '@lib/state/Chat'
import { useImageViewer } from '@lib/state/components/ImageViewer'
import { useImageGeneration } from '@lib/state/ImageGeneration'

/** Fundo escuro fixo: o visualizador não deve depender do tema claro. */
const VIEWER_BACKGROUND = '#05040a'
const MAX_ZOOM = 6
const DOUBLE_TAP_ZOOM = 2.5

const ImageViewer: React.FC = () => {
    const target = useImageViewer((state) => state.target)
    const visible = useImageViewer((state) => state.visible)
    const close = useImageViewer((state) => state.close)
    const removeAttachment = Chats.useChatState((state) => state.removeAttachment)
    const library = useImageGeneration((state) => state.library)
    const saveImageToGallery = useImageGeneration((state) => state.saveImageToGallery)
    const shareImage = useImageGeneration((state) => state.shareImage)
    const deleteImage = useImageGeneration((state) => state.deleteImage)

    const [resolvedUri, setResolvedUri] = useState<string | undefined>(undefined)
    const [loading, setLoading] = useState(false)

    const scale = useSharedValue(1)
    const savedScale = useSharedValue(1)

    // Resolve a referência do cofre para um arquivo temporário exibível.
    useEffect(() => {
        let cancelled = false
        const resolve = async () => {
            if (!target) return
            if (!isPrivateUri(target.uri)) {
                setResolvedUri(target.uri)
                return
            }
            setLoading(true)
            try {
                const uri = await resolvePrivateImage(target.uri)
                if (!cancelled) setResolvedUri(uri)
            } finally {
                if (!cancelled) setLoading(false)
            }
        }
        setResolvedUri(undefined)
        resolve()
        return () => {
            cancelled = true
        }
    }, [target])

    useEffect(() => {
        scale.value = 1
        savedScale.value = 1
    }, [target?.uri, savedScale, scale])

    const pinch = Gesture.Pinch()
        .onUpdate((event) => {
            scale.value = Math.min(Math.max(savedScale.value * event.scale, 1), MAX_ZOOM)
        })
        .onEnd(() => {
            savedScale.value = scale.value
            if (scale.value < 1.05) {
                scale.value = withTiming(1)
                savedScale.value = 1
            }
        })

    const doubleTap = Gesture.Tap()
        .numberOfTaps(2)
        .onEnd(() => {
            const next = savedScale.value > 1.05 ? 1 : DOUBLE_TAP_ZOOM
            scale.value = withTiming(next)
            savedScale.value = next
        })

    const animatedStyle = useAnimatedStyle(() => ({
        transform: [{ scale: scale.value }],
    }))

    const resetZoom = useCallback(() => {
        scale.value = withTiming(1)
        savedScale.value = 1
    }, [savedScale, scale])

    if (!target) return null

    const storedName = isPrivateUri(target.uri) ? target.uri.replace('private://', '') : undefined
    const libraryEntry = storedName
        ? library.find((item) => item.fileName === storedName)
        : undefined

    const handleDelete = () => {
        const removeFromChat = () => {
            if (target.attachmentId !== undefined && target.entryIndex !== undefined) {
                removeAttachment(target.entryIndex, target.attachmentId)
            }
            close()
        }

        if (libraryEntry) {
            Alert.alert({
                title: 'Apagar imagem',
                description:
                    'A imagem sai do cofre da Lunaria e não pode ser recuperada. Se você já salvou uma cópia na galeria, essa cópia continua lá — a Lunaria não controla arquivos fora dela.',
                buttons: [
                    { label: 'Cancelar', type: 'default' },
                    {
                        label: 'Apagar',
                        type: 'warning',
                        onPress: () => {
                            deleteImage(libraryEntry)
                            removeFromChat()
                        },
                    },
                ],
            })
            return
        }

        Alert.alert({
            title: 'Remover imagem',
            description:
                'A imagem será removida desta conversa. Cópias que já estejam na galeria não são afetadas.',
            buttons: [
                { label: 'Cancelar', type: 'default' },
                { label: 'Remover', type: 'warning', onPress: removeFromChat },
            ],
        })
    }

    return (
        <Modal visible={visible} transparent animationType="fade" onRequestClose={close}>
            <View style={styles.container}>
                <View style={styles.header}>
                    <Pressable onPress={close} style={styles.iconButton} hitSlop={12}>
                        <Ionicons name="close" size={26} color="#ffffff" />
                    </Pressable>
                    <Text style={styles.title} numberOfLines={1}>
                        {libraryEntry ? 'Imagem gerada pela Lunaria' : 'Imagem'}
                    </Text>
                    <Pressable onPress={resetZoom} style={styles.iconButton} hitSlop={12}>
                        <Ionicons name="contract-outline" size={22} color="#ffffff" />
                    </Pressable>
                </View>

                <GestureDetector gesture={Gesture.Simultaneous(pinch, doubleTap)}>
                    <Animated.View style={styles.imageArea}>
                        {resolvedUri ? (
                            <Animated.Image
                                source={{ uri: resolvedUri }}
                                style={[styles.image, animatedStyle]}
                                resizeMode="contain"
                            />
                        ) : (
                            <ActivityIndicator color="#ffffff" />
                        )}
                    </Animated.View>
                </GestureDetector>

                <Text style={styles.zoomHint}>
                    {loading
                        ? 'Abrindo a imagem protegida…'
                        : 'Dois dedos para ampliar · toque duas vezes para aproximar'}
                </Text>

                <View style={styles.actions}>
                    <ThemedButton
                        label="Salvar"
                        iconName="download"
                        variant="secondary"
                        buttonStyle={{ flex: 1 }}
                        opacity={libraryEntry ? 1 : 0.4}
                        onPress={() => libraryEntry && saveImageToGallery(libraryEntry)}
                    />
                    <ThemedButton
                        label="Compartilhar"
                        iconName="share-alt"
                        variant="secondary"
                        buttonStyle={{ flex: 1 }}
                        opacity={libraryEntry ? 1 : 0.4}
                        onPress={() => libraryEntry && shareImage(libraryEntry)}
                    />
                    <ThemedButton
                        label="Apagar"
                        iconName="delete"
                        variant="critical"
                        buttonStyle={{ flex: 1 }}
                        onPress={handleDelete}
                    />
                </View>

                {libraryEntry && (
                    <Text style={styles.meta}>
                        {libraryEntry.width}×{libraryEntry.height} ·{' '}
                        {Math.round(libraryEntry.bytes / 1024)} KB · {libraryEntry.seconds}s ·
                        guardada cifrada no cofre
                    </Text>
                )}
            </View>
        </Modal>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: VIEWER_BACKGROUND,
        paddingTop: 48,
        paddingBottom: 24,
        paddingHorizontal: 16,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    iconButton: {
        padding: 6,
    },
    title: {
        color: '#ffffff',
        fontSize: 16,
        flex: 1,
        textAlign: 'center',
    },
    imageArea: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    image: {
        width: '100%',
        height: '100%',
    },
    zoomHint: {
        color: '#b9aecb',
        fontSize: 12,
        textAlign: 'center',
        marginTop: 8,
    },
    actions: {
        flexDirection: 'row',
        columnGap: 8,
        marginTop: 12,
    },
    meta: {
        color: '#b9aecb',
        fontSize: 11,
        textAlign: 'center',
        marginTop: 10,
    },
})

export default ImageViewer
