/**
 * Relatório de diagnóstico na tela.
 *
 * Aparece quando a abertura falha ou quando uma tela estoura um erro — no lugar
 * do silêncio (ou de uma tela preta). O texto é feito para ser copiado e enviado
 * a quem conserta: só passos e mensagens de erro, nada de conversa.
 */

import * as Application from 'expo-application'
import { setStringAsync } from 'expo-clipboard'
import * as Device from 'expo-device'
import { Paths } from 'expo-file-system'
import { useEffect, useMemo, useState } from 'react'
import { Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'

import ThemedButton from '@components/buttons/ThemedButton'
import { Theme } from '@lib/theme/ThemeManager'
import {
    buildReport,
    clearDiagnostics,
    isSafeMode,
    readFailures,
    setSafeMode,
} from '@lib/utils/Diagnostics'
import { readStringAsync } from '@lib/utils/File'
import { NOME_ARQUIVO_DIAGNOSTICO, salvarDiagnosticoNoAparelho } from '@lib/utils/SalvarDiagnostico'

type Props = {
    title?: string
    /** Detalhe curto do que falhou (mensagem crua, quando existe). */
    detail?: string
    /** Se informado, mostra o botão de tentar de novo. */
    onRetry?: () => void
    /** Chamado depois de desligar o modo seguro. */
    onSafeModeChanged?: () => void
}

/**
 * Nome do arquivo que a captura nativa grava na pasta **Downloads** do aparelho
 * (ver `android/.../CapturaDeFalha.kt`). É o caminho pelo qual o registro sai do
 * aparelho **sem computador**: se o aplicativo fechar, o Hamura abre os
 * Downloads pelo próprio celular e me envia o arquivo.
 */
export const ARQUIVO_DE_FALHA_EM_DOWNLOADS = 'lunaria-ultimo-erro.txt'

const formatarMemoria = () => {
    const total = Device.totalMemory
    if (!total) return '?'
    return `${(total / 1024 ** 3).toFixed(1)} GB`
}

const DiagnosticReport = ({ title, detail, onRetry, onSafeModeChanged }: Props) => {
    const { color, spacing, fontSize } = Theme.useTheme()
    const styles = useStyles()
    const [copiado, setCopiado] = useState(false)
    const [salvo, setSalvo] = useState(false)

    const relatorio = useMemo(
        () =>
            buildReport({
                appVersion: Application.nativeApplicationVersion ?? '?',
                build: Application.nativeBuildVersion ?? '?',
                model: Device.modelName ?? '?',
                system: `${Device.osName ?? Platform.OS} ${Device.osVersion ?? '?'}`,
                memory: formatarMemoria(),
            }),
        []
    )

    // Erro nativo (fechamento por falha de biblioteca) fica num arquivo escrito
    // pelo próprio Android antes de fechar; se existir, entra no relatório.
    const [nativo, setNativo] = useState<string | undefined>(undefined)
    useEffect(() => {
        let cancelado = false
        readStringAsync(`${Paths.document.uri}diagnostico-nativo.txt`)
            .then((texto) => {
                if (!cancelado && texto) setNativo(texto)
            })
            .catch(() => undefined)
        return () => {
            cancelado = true
        }
    }, [])

    const textoFinal = useMemo(
        () =>
            nativo
                ? `${relatorio}\n\n--- erro nativo registrado pelo Android ---\n${nativo}` +
                  `\n--- este mesmo registro também está em: Downloads/${ARQUIVO_DE_FALHA_EM_DOWNLOADS} ---`
                : relatorio,
        [relatorio, nativo]
    )

    // Estado local de propósito: desligar o modo seguro tem de **refletir na
    // tela na hora** — o aviso não pode continuar ali depois do toque.
    const [safeMode, setSeguro] = useState(() => isSafeMode())
    const falhas = readFailures()

    const copiar = async () => {
        await setStringAsync(textoFinal)
        setCopiado(true)
    }

    // Segundo caminho: grava o relatório na pasta Downloads do aparelho. Se
    // falhar, o texto continua na tela e o botão de copiar continua ali — o
    // usuário não fica sem saída.
    const salvar = async () => {
        const deu = await salvarDiagnosticoNoAparelho(textoFinal)
        if (deu) setSalvo(true)
    }

    const sairDoModoSeguro = () => {
        setSafeMode(false)
        clearDiagnostics()
        setSeguro(false)
        onSafeModeChanged?.()
    }

    return (
        <ScrollView
            style={{ flex: 1, backgroundColor: color.neutral._100 }}
            contentContainerStyle={{
                padding: spacing.xl,
                rowGap: spacing.l,
                paddingBottom: spacing.xl3,
            }}>
            <Text style={[styles.title, { color: color.text._300, fontSize: fontSize.xl2 }]}>
                {title ?? 'A Lunaria encontrou um erro'}
            </Text>
            <Text style={{ color: color.text._400 }}>
                Isto é o relatório do que aconteceu. Nada foi apagado: conversas, imagens e ajustes
                continuam no aparelho.
            </Text>
            {!!detail && <Text style={styles.detail}>{detail}</Text>}

            {safeMode && (
                <View style={styles.safeBox}>
                    <Text style={styles.safeTitle}>Modo seguro ligado</Text>
                    <Text style={{ color: color.text._400 }}>
                        {`A abertura falhou ${falhas} vez(es) seguida(s). Para o aplicativo conseguir abrir, as camadas novas ficaram de fora: geração de imagem, bloqueio de captura de tela e observador de notificações. A proteção por senha e o conteúdo cifrado continuam valendo.`}
                    </Text>
                    <ThemedButton
                        label="Sair do modo seguro"
                        onPress={sairDoModoSeguro}
                        buttonStyle={{ marginTop: spacing.m }}
                    />
                </View>
            )}

            <View style={styles.reportBox}>
                <ScrollView horizontal showsHorizontalScrollIndicator>
                    <Text style={styles.reportText} selectable>
                        {textoFinal}
                    </Text>
                </ScrollView>
            </View>

            <View style={styles.row}>
                <ThemedButton label="Copiar diagnóstico" onPress={() => void copiar()} />
                <ThemedButton label="Salvar em Downloads" onPress={() => void salvar()} />
                {!!onRetry && <ThemedButton label="Tentar novamente" onPress={onRetry} />}
            </View>
            {salvo && (
                <Text style={{ color: color.text._400 }}>
                    {`Relatório salvo na pasta Downloads, no arquivo ${NOME_ARQUIVO_DIAGNOSTICO}. Abra os Downloads do aparelho e me envie o arquivo.`}
                </Text>
            )}
            {!!nativo && (
                <View style={styles.safeBox}>
                    <Text style={styles.safeTitle}>
                        Existe um registro de falha gravado pelo Android
                    </Text>
                    <Text style={{ color: color.text._400 }}>
                        {`Ele está na pasta Downloads do aparelho, no arquivo ${ARQUIVO_DE_FALHA_EM_DOWNLOADS}. Dá para me enviar sem computador: abra os Downloads no celular e compartilhe o arquivo na conversa.`}
                    </Text>
                </View>
            )}
            {copiado && (
                <Text style={{ color: color.text._400 }}>
                    Relatório copiado. Cole na conversa e eu identifico a causa.
                </Text>
            )}

            <TouchableOpacity onPress={() => void setStringAsync(textoFinal)}>
                <Text style={{ color: color.text._500, fontSize: fontSize.s }}>
                    Toque em “Copiar diagnóstico”, cole no chat e o defeito deixa de ser mistério.
                </Text>
            </TouchableOpacity>
        </ScrollView>
    )
}

export default DiagnosticReport

const useStyles = () => {
    const { color, spacing } = Theme.useTheme()
    return StyleSheet.create({
        title: {
            fontWeight: '600',
        },
        detail: {
            color: color.text._200,
            backgroundColor: 'black',
            padding: spacing.l,
            borderRadius: 12,
            fontSize: 13,
        },
        reportBox: {
            backgroundColor: 'black',
            padding: spacing.l,
            borderRadius: 12,
            maxHeight: 320,
        },
        reportText: {
            color: color.text._300,
            fontFamily: Platform.select({ android: 'monospace', default: 'Courier' }),
            fontSize: 11,
        },
        row: {
            flexDirection: 'row',
            columnGap: spacing.l,
            flexWrap: 'wrap',
        },
        safeBox: {
            borderWidth: 1,
            borderColor: color.primary._500,
            borderRadius: 12,
            padding: spacing.l,
        },
        safeTitle: {
            color: color.primary._400,
            fontWeight: '600',
            marginBottom: spacing.s,
        },
    })
}
