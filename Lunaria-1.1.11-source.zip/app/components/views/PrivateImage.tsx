/**
 * Imagem que vive cifrada no cofre.
 *
 * O componente recebe a referência `private://…`, pede a decifragem para um
 * arquivo temporário e mostra o resultado. Enquanto isso, aparece um placeholder
 * — nada de "piscar" a tela nem de travar a conversa enquanto decifra.
 */

import React, { useCallback, useEffect, useState } from 'react'
import { ActivityIndicator, Image, StyleSheet, View, ViewStyle } from 'react-native'

import { resolvePrivateImage } from '@lib/security/PrivateImageCache'

type PrivateImageProps = {
    uri: string
    style?: ViewStyle
    resizeMode?: 'cover' | 'contain'
}

const PrivateImage: React.FC<PrivateImageProps> = ({ uri, style, resizeMode = 'cover' }) => {
    const [localUri, setLocalUri] = useState<string | undefined>(undefined)
    const [failed, setFailed] = useState(false)

    const load = useCallback(async () => {
        try {
            setFailed(false)
            const resolved = await resolvePrivateImage(uri)
            setLocalUri(resolved)
            if (!resolved) setFailed(true)
        } catch {
            // Cofre bloqueado ou arquivo ausente: mostra o placeholder neutro.
            setFailed(true)
        }
    }, [uri])

    useEffect(() => {
        setLocalUri(undefined)
        load()
    }, [load])

    return (
        <View style={[styles.container, style]}>
            {localUri ? (
                <Image
                    source={{ uri: localUri }}
                    style={StyleSheet.absoluteFill}
                    resizeMode={resizeMode}
                    onError={() => setFailed(true)}
                />
            ) : failed ? (
                <View style={styles.placeholder} />
            ) : (
                <View style={styles.placeholder}>
                    <ActivityIndicator />
                </View>
            )}
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        overflow: 'hidden',
        backgroundColor: '#1b1622',
        alignItems: 'center',
        justifyContent: 'center',
    },
    placeholder: {
        ...StyleSheet.absoluteFillObject,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#1b1622',
    },
})

export default PrivateImage
