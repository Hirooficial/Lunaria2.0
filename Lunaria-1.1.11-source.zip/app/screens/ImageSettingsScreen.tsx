/**
 * Ajustes de imagem: provedor, chave própria, modelo e o perfil visual da Lunaria.
 *
 * Os limites de cada opção gratuita ficam escritos na própria tela — sem prometer
 * mais do que o serviço entrega. Serviço pago não existe como padrão: só entra se
 * o usuário colar a própria chave.
 */

import React, { useEffect, useState } from 'react'
import { ScrollView, StyleSheet, Text, View } from 'react-native'

import ThemedButton from '@components/buttons/ThemedButton'
import HorizontalSelector from '@components/input/HorizontalSelector'
import ThemedTextInput from '@components/input/ThemedTextInput'
import SectionTitle from '@components/text/SectionTitle'
import Alert from '@components/views/Alert'
import { ImageProviderId, PROVIDER_INFO } from '@lib/imagegen/ImageProviders'
import {
    CONSISTENCY_NOTE,
    DEFAULT_LUNARIA_PROFILE,
    LUNARIA_PROFILE_FIELDS,
    LunariaProfile,
    POLICY_NOTE,
} from '@lib/imagegen/ImageStyles'
import { useImageGeneration } from '@lib/state/ImageGeneration'
import { Theme } from '@lib/theme/ThemeManager'

const ImageSettingsScreen: React.FC = () => {
    const styles = useStyles()

    const prefs = useImageGeneration((state) => state.prefs)
    const profile = useImageGeneration((state) => state.profile)
    const setProvider = useImageGeneration((state) => state.setProvider)
    const setApiKey = useImageGeneration((state) => state.setApiKey)
    const setModel = useImageGeneration((state) => state.setModel)
    const saveProfile = useImageGeneration((state) => state.saveProfile)
    const init = useImageGeneration((state) => state.init)

    const [draftProfile, setDraftProfile] = useState<LunariaProfile>(profile)
    const [apiKeyDraft, setApiKeyDraft] = useState(prefs.apiKey ?? '')

    useEffect(() => {
        init()
    }, [init])

    useEffect(() => {
        setDraftProfile(profile)
    }, [profile])

    const providerInfo = PROVIDER_INFO[prefs.provider]

    return (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.container}>
            <SectionTitle>Provedor de imagem</SectionTitle>
            <HorizontalSelector
                label="Quem gera"
                values={[
                    { label: 'AI Horde', value: 'horde' as ImageProviderId },
                    { label: 'Pollinations', value: 'pollinations' as ImageProviderId },
                ]}
                selected={prefs.provider}
                onPress={setProvider}
            />
            <Text style={styles.note}>
                {PROVIDER_INFO.horde.label}: {PROVIDER_INFO.horde.limits}
            </Text>
            <Text style={styles.note}>
                {PROVIDER_INFO.pollinations.label}: {PROVIDER_INFO.pollinations.limits}
            </Text>
            <Text style={styles.note}>{PROVIDER_INFO.pollinations.languageNote}</Text>
            <Text style={styles.note}>
                Nada de pago vem ligado por padrão. As duas opções acima são gratuitas e não pedem
                cadastro. Se você tiver conta em um serviço pago, cole a chave no campo abaixo: a
                chave fica no armazenamento privado do aplicativo, não vai para log e não entra em
                backup.
            </Text>

            <SectionTitle>Chave própria (opcional)</SectionTitle>
            <ThemedTextInput
                label="Chave de API"
                description={`Vazia usa a chave pública anônima. Provedor atual: ${providerInfo.label}.`}
                value={apiKeyDraft}
                onChangeText={setApiKeyDraft}
                autoCapitalize="none"
                secureTextEntry
            />
            <ThemedButton
                label="Salvar chave"
                variant="secondary"
                onPress={() => {
                    setApiKey(apiKeyDraft.trim())
                    Alert.alert({
                        title: 'Chave salva',
                        description:
                            'A chave é usada só para falar com o provedor escolhido e nunca é escrita em log nem em backup.',
                        buttons: [{ label: 'Entendi' }],
                    })
                }}
            />
            <ThemedTextInput
                label="Modelo (opcional)"
                description="Nome exato do modelo no provedor. Vazio deixa o provedor escolher."
                value={prefs.model ?? ''}
                onChangeText={setModel}
                autoCapitalize="none"
            />

            <SectionTitle>Aparência da Lunaria</SectionTitle>
            <Text style={styles.note}>
                Usada apenas quando você liga “Incluir a aparência da Lunaria”. Escreva em inglês ou
                português; em inglês os modelos costumam acertar melhor.
            </Text>
            {LUNARIA_PROFILE_FIELDS.map((field) => (
                <ThemedTextInput
                    key={field.key}
                    label={field.label}
                    description={field.hint}
                    value={draftProfile[field.key]}
                    onChangeText={(text) =>
                        setDraftProfile((current) => ({ ...current, [field.key]: text }))
                    }
                    multiline
                    numberOfLines={2}
                />
            ))}
            <View style={styles.actions}>
                <ThemedButton
                    label="Salvar aparência"
                    variant="primary"
                    buttonStyle={{ flex: 1 }}
                    onPress={() => {
                        saveProfile(draftProfile)
                        Alert.alert({
                            title: 'Aparência salva',
                            description: 'O próximo pedido de imagem já usa este perfil.',
                            buttons: [{ label: 'Entendi' }],
                        })
                    }}
                />
                <ThemedButton
                    label="Voltar ao padrão"
                    variant="tertiary"
                    buttonStyle={{ flex: 1 }}
                    onPress={() => {
                        setDraftProfile({ ...DEFAULT_LUNARIA_PROFILE })
                        saveProfile({ ...DEFAULT_LUNARIA_PROFILE })
                    }}
                />
            </View>

            <Text style={styles.note}>{CONSISTENCY_NOTE}</Text>
            <Text style={styles.note}>{POLICY_NOTE}</Text>
        </ScrollView>
    )
}

export default ImageSettingsScreen

const useStyles = () => {
    const { color, spacing, fontSize } = Theme.useTheme()

    return StyleSheet.create({
        container: {
            padding: spacing.xl,
            rowGap: spacing.m,
            paddingBottom: spacing.xl3,
        },
        note: {
            color: color.text._300,
            fontSize: fontSize.s,
            lineHeight: 18,
        },
        actions: {
            flexDirection: 'row',
            columnGap: spacing.s,
            marginTop: spacing.s,
        },
    })
}
