import { fetch as expoFetch } from 'expo/fetch'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { useCallback, useEffect, useRef, useState } from 'react'
import {
    ActivityIndicator,
    Linking,
    ScrollView,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native'

import ThemedButton from '@components/buttons/ThemedButton'
import TText from '@components/text/TText'
import Alert from '@components/views/Alert'
import HeaderTitle from '@components/views/HeaderTitle'
import { AppSettings } from '@lib/constants/GlobalValues'
import { APIManager } from '@lib/engine/API/APIManagerState'
import { generateResponse } from '@lib/engine/Inference'
import { ResearchBundle } from '@lib/research/Research.types'
import { researchWeb } from '@lib/research/WebResearch'
import { useAppModeStore } from '@lib/state/AppMode'
import { Characters } from '@lib/state/Characters'
import { Chats, useInference } from '@lib/state/Chat'
import { Logger } from '@lib/state/Logger'
import { useResearchMemoryStore } from '@lib/state/ResearchMemory'
import { mmkv } from '@lib/storage/MMKV'
import { Theme } from '@lib/theme/ThemeManager'

const ResearchScreen = () => {
    const params = useLocalSearchParams<{ q?: string; auto?: string }>()
    const router = useRouter()
    const styles = useStyles()
    const initialQuery = typeof params.q === 'string' ? params.q : ''
    const [query, setQuery] = useState(initialQuery)
    const [sourceLinks, setSourceLinks] = useState('')
    const [bundle, setBundle] = useState<ResearchBundle>()
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState('')
    const autoStarted = useRef(false)
    const inFlight = useRef(false)
    const controller = useRef<AbortController | undefined>(undefined)
    const comparing = useRef(false)
    const { saveBundle, activate } = useResearchMemoryStore()
    const saved = useResearchMemoryStore((state) =>
        state.notes.some((note) => note.id === bundle?.id)
    )

    useEffect(() => () => controller.current?.abort(), [])

    const runResearch = useCallback(
        async (target = query) => {
            if (inFlight.current) return
            inFlight.current = true
            setLoading(true)
            setError('')
            setBundle(undefined)
            const request = new AbortController()
            controller.current = request
            try {
                const result = await researchWeb(target, {
                    fetchImpl: expoFetch as typeof fetch,
                    signal: request.signal,
                    sourceUrls: sourceLinks.split(/\s+/).filter(Boolean),
                })
                if (!request.signal.aborted) setBundle(result)
            } catch (researchError) {
                if (request.signal.aborted) return
                const message =
                    researchError instanceof Error
                        ? researchError.message
                        : 'A pesquisa falhou sem um detalhe técnico.'
                setError(message)
            } finally {
                inFlight.current = false
                if (!request.signal.aborted) setLoading(false)
            }
        },
        [query, sourceLinks]
    )

    useEffect(() => {
        if (params.auto === '1' && initialQuery.trim() && !autoStarted.current) {
            autoStarted.current = true
            void runResearch(initialQuery)
        }
    }, [initialQuery, params.auto, runResearch])

    const compareInChat = async (consentConfirmed = false) => {
        if (!bundle || comparing.current) return
        if (useInference.getState().nowGenerating) {
            setError('Espere a resposta atual terminar antes de comparar as fontes.')
            return
        }
        const appMode = useAppModeStore.getState().appMode
        const apiState = APIManager.useConnectionsStore.getState()
        const activeAPI = apiState.values[apiState.activeIndex]
        if (
            !consentConfirmed &&
            appMode === 'remote' &&
            activeAPI?.configName === 'Horde' &&
            !mmkv.getBoolean(AppSettings.RemotePrivacyAccepted)
        ) {
            Alert.alert({
                title: 'Antes de comparar online',
                description:
                    'A pergunta, o contexto do chat e os trechos encontrados serão enviados à rede comunitária AI Horde e podem ser processados por operadores voluntários. Não use dados sensíveis.',
                buttons: [
                    { label: 'Cancelar' },
                    {
                        label: 'Entendi e continuar',
                        onPress: () => {
                            mmkv.set(AppSettings.RemotePrivacyAccepted, true)
                            void compareInChat(true)
                        },
                    },
                ],
            })
            return
        }
        const charName = Characters.useCharacterStore.getState().card?.name
        const userName = Characters.useUserStore.getState().card?.name
        const chat = Chats.useChatState.getState().data
        if (!charName || !userName || !chat) {
            setError('Abra uma conversa com a Lunaria antes de enviar a comparação.')
            return
        }

        comparing.current = true
        try {
            activate(bundle)
            await Chats.useChatState
                .getState()
                .addEntry(userName, true, `Compare os fatos e as fontes sobre: ${bundle.query}`)
            const swipeId = await Chats.useChatState.getState().addEntry(charName, false, '')
            if (!swipeId) {
                activate(undefined)
                setError('Não foi possível criar a resposta no chat.')
                return
            }
            router.back()
            void generateResponse(swipeId)
        } catch (comparisonError) {
            activate(undefined)
            setError(`Não foi possível iniciar a comparação: ${comparisonError}`)
        } finally {
            comparing.current = false
        }
    }

    return (
        <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
            <HeaderTitle title="Pesquisa" />
            <TText style={styles.title}>Pesquisar e comparar fontes</TText>
            <TText color="400" style={styles.help}>
                A Lunaria procura páginas públicas, lê trechos relevantes de domínios diferentes e
                permite salvar a pesquisa na memória local. A consulta é enviada ao DuckDuckGo; não
                digite dados sensíveis. Confira os links: fontes também podem errar.
            </TText>
            <TextInput
                value={query}
                onChangeText={setQuery}
                editable={!loading}
                placeholder="Ex.: o que mudou nesta lei?"
                placeholderTextColor={styles.placeholder.color}
                style={styles.input}
                multiline
            />
            <ThemedButton
                iconName="search"
                label={
                    loading
                        ? 'Pesquisando…'
                        : sourceLinks.trim()
                          ? 'Ler e comparar os links'
                          : 'Pesquisar em vários sites'
                }
                variant={loading ? 'disabled' : 'primary'}
                onPress={() => void runResearch()}
            />
            <TText color="400">
                Opcional: cole links HTTPS de dois ou mais sites, um por linha. Com links, a
                pesquisa usa essas páginas.
            </TText>
            <TextInput
                value={sourceLinks}
                onChangeText={setSourceLinks}
                editable={!loading}
                placeholder="https://site.com/fonte"
                placeholderTextColor={styles.placeholder.color}
                style={styles.input}
                multiline
                autoCapitalize="none"
                autoCorrect={false}
                accessibilityLabel="Links das fontes"
            />
            {loading && <ActivityIndicator size="large" style={styles.progress} />}
            {!!error && <TText style={styles.error}>{error}</TText>}
            {bundle && (
                <View style={styles.results}>
                    <TText style={styles.resultTitle}>
                        {bundle.sources.length} fontes diferentes encontradas
                    </TText>
                    {bundle.sources.map((source, index) => (
                        <View key={source.url} style={styles.sourceCard}>
                            <TouchableOpacity
                                onPress={() =>
                                    Linking.openURL(source.url).catch((linkError) =>
                                        Logger.error(`Falha ao abrir fonte: ${linkError}`)
                                    )
                                }>
                                <TText style={styles.sourceTitle}>
                                    [{index + 1}] {source.title}
                                </TText>
                                <TText color="500" style={styles.domain}>
                                    {source.domain}
                                </TText>
                            </TouchableOpacity>
                            <TText color="300" style={styles.excerpt}>
                                {source.excerpt}
                            </TText>
                        </View>
                    ))}
                    <ThemedButton
                        label={saved ? 'Pesquisa salva na memória' : 'Salvar pesquisa na memória'}
                        iconName="save"
                        variant={saved ? 'disabled' : 'secondary'}
                        onPress={() => saveBundle(bundle)}
                    />
                    <ThemedButton
                        label="Comparar no chat com a Lunaria"
                        iconName="message"
                        onPress={() => void compareInChat()}
                    />
                </View>
            )}
        </ScrollView>
    )
}

export default ResearchScreen

const useStyles = () => {
    const { color, spacing, borderRadius, fontSize } = Theme.useTheme()
    return StyleSheet.create({
        container: {
            padding: spacing.xl,
            paddingBottom: spacing.xl3,
            rowGap: spacing.l,
        },
        title: { fontSize: fontSize.xl2, fontWeight: '600' },
        help: { lineHeight: 20 },
        input: {
            minHeight: 88,
            padding: spacing.l,
            color: color.text._100,
            backgroundColor: color.neutral._200,
            borderColor: color.primary._400,
            borderWidth: 1,
            borderRadius: borderRadius.m,
            textAlignVertical: 'top',
        },
        placeholder: { color: color.text._600 },
        progress: { marginVertical: spacing.l },
        error: {
            color: color.error._400,
            padding: spacing.l,
            backgroundColor: color.neutral._200,
            borderRadius: borderRadius.m,
        },
        results: { rowGap: spacing.l },
        resultTitle: { fontSize: fontSize.xl, fontWeight: '600' },
        sourceCard: {
            padding: spacing.l,
            rowGap: spacing.m,
            backgroundColor: color.neutral._200,
            borderRadius: borderRadius.m,
            borderLeftWidth: 3,
            borderLeftColor: color.primary._500,
        },
        sourceTitle: { color: color.primary._700, fontWeight: '600' },
        domain: { marginTop: 2 },
        excerpt: { lineHeight: 20 },
    })
}
