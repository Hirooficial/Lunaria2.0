import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from 'expo-speech-recognition'
import { useEffect, useRef, useState } from 'react'

import ThemedButton from '@components/buttons/ThemedButton'
import { useChatInputTextStore } from '@lib/state/components/ChatInput'
import { Logger } from '@lib/state/Logger'

type VoiceInputButtonProps = {
    disabled?: boolean
}

const VoiceInputButton = ({ disabled = false }: VoiceInputButtonProps) => {
    const [listening, setListening] = useState(false)
    const baseText = useRef('')
    const ownsSession = useRef(false)
    const starting = useRef(false)
    const mounted = useRef(true)
    const disabledRef = useRef(disabled)
    disabledRef.current = disabled

    useEffect(() => {
        mounted.current = true
        return () => {
            mounted.current = false
            if (ownsSession.current) ExpoSpeechRecognitionModule.abort()
            ownsSession.current = false
        }
    }, [])

    useEffect(() => {
        if (disabled && ownsSession.current) {
            ownsSession.current = false
            ExpoSpeechRecognitionModule.abort()
            setListening(false)
        }
    }, [disabled])

    useSpeechRecognitionEvent('start', () => {
        if (ownsSession.current) setListening(true)
    })
    useSpeechRecognitionEvent('end', () => {
        ownsSession.current = false
        setListening(false)
    })
    useSpeechRecognitionEvent('result', (event) => {
        if (!ownsSession.current || disabledRef.current) return
        const transcript = event.results[0]?.transcript?.trim()
        if (!transcript) return
        const separator = baseText.current.trim() ? ' ' : ''
        useChatInputTextStore
            .getState()
            .setText(`${baseText.current.trim()}${separator}${transcript}`)
    })
    useSpeechRecognitionEvent('error', (event) => {
        if (!ownsSession.current) return
        ownsSession.current = false
        setListening(false)
        if (event.error !== 'no-speech' && event.error !== 'aborted') {
            Logger.errorToast(`Não consegui reconhecer a fala: ${event.message || event.error}`)
        }
    })

    const toggle = async () => {
        if (disabled || starting.current) return
        if (listening) {
            ExpoSpeechRecognitionModule.stop()
            return
        }
        if (!ExpoSpeechRecognitionModule.isRecognitionAvailable()) {
            Logger.warnToast('O reconhecimento de voz do Android não está disponível.')
            return
        }
        starting.current = true
        try {
            const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync()
            if (!mounted.current || disabledRef.current) return
            if (!permission.granted) {
                Logger.warnToast('Permissão de microfone não concedida.')
                return
            }
            baseText.current = useChatInputTextStore.getState().text
            ownsSession.current = true
            ExpoSpeechRecognitionModule.start({
                lang: 'pt-BR',
                interimResults: true,
                continuous: false,
                maxAlternatives: 1,
            })
        } catch (error) {
            ownsSession.current = false
            if (mounted.current) {
                setListening(false)
                Logger.errorToast(`Não foi possível iniciar a voz: ${error}`)
            }
        } finally {
            starting.current = false
        }
    }

    return (
        <ThemedButton
            label={listening ? 'Parar' : 'Falar'}
            iconName={listening ? 'pause-circle' : 'audio'}
            variant={disabled ? 'disabled' : listening ? 'critical' : 'secondary'}
            buttonStyle={{ flex: 1, paddingHorizontal: 6, paddingVertical: 8 }}
            onPress={() => void toggle()}
        />
    )
}

export default VoiceInputButton
