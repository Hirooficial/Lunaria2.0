import { Dimensions, TouchableOpacity, View } from 'react-native'

import PrivateImage from '@components/views/PrivateImage'
import ScaledImage from '@components/views/ScaledImage'
import { isPrivateUri } from '@lib/security/PrivateImageCache'
import { Chats } from '@lib/state/Chat'
import { useImageViewer } from '@lib/state/components/ImageViewer'

type ChatAttachmentsProps = {
    index: number
}

const ChatAttachments: React.FC<ChatAttachmentsProps> = ({ index }) => {
    const openViewer = useImageViewer((state) => state.openUri)
    const message = Chats.useEntryData(index)
    if (message.attachments.length < 1) return
    const imageAttachments = message.attachments.filter((item) => item.type === 'image')

    return (
        <View style={{ rowGap: 8 }}>
            {imageAttachments.length > 0 && (
                <View
                    style={{
                        paddingVertical: 4,
                        rowGap: 8,
                        columnGap: 8,
                        flexDirection: 'row',
                        flexWrap: 'wrap',
                    }}>
                    {imageAttachments.map((item) => {
                        // Imagem gerada: fica cifrada no cofre e abre no visualizador.
                        const protectedImage = isPrivateUri(item.uri)
                        return (
                            <TouchableOpacity
                                key={item.id ?? item.uri}
                                activeOpacity={0.85}
                                onPress={() =>
                                    openViewer(item.uri, {
                                        attachmentId: item.id,
                                        entryIndex: index,
                                    })
                                }>
                                {protectedImage ? (
                                    <PrivateImage
                                        uri={item.uri}
                                        style={{
                                            height: Dimensions.get('window').height / 8,
                                            width: Dimensions.get('window').height / 8,
                                            borderRadius: 8,
                                        }}
                                    />
                                ) : (
                                    <ScaledImage
                                        cachePolicy="none"
                                        uri={item.uri}
                                        style={{
                                            height: Dimensions.get('window').height / 8,
                                            borderRadius: 8,
                                        }}
                                    />
                                )}
                            </TouchableOpacity>
                        )
                    })}
                </View>
            )}
        </View>
    )
}

export default ChatAttachments
