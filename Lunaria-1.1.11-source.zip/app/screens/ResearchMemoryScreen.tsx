import { FlatList, StyleSheet, View } from 'react-native'

import ThemedButton from '@components/buttons/ThemedButton'
import TText from '@components/text/TText'
import HeaderTitle from '@components/views/HeaderTitle'
import { useResearchMemoryStore } from '@lib/state/ResearchMemory'
import { Theme } from '@lib/theme/ThemeManager'

const ResearchMemoryScreen = () => {
    const styles = useStyles()
    const { notes, remove, clear } = useResearchMemoryStore()

    return (
        <View style={styles.container}>
            <HeaderTitle title="Memória de pesquisa" />
            <TText color="400" style={styles.help}>
                Pesquisas ficam apenas neste aparelho e podem ser reutilizadas como contexto. Como
                notícias mudam, a Lunaria deve avisar quando uma nota antiga precisar ser
                verificada.
            </TText>
            {notes.length > 0 && (
                <ThemedButton label="Apagar toda a memória" variant="critical" onPress={clear} />
            )}
            <FlatList
                data={notes}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.list}
                ListEmptyComponent={
                    <TText color="500" style={styles.empty}>
                        Nenhuma pesquisa foi guardada ainda.
                    </TText>
                }
                renderItem={({ item }) => (
                    <View style={styles.note}>
                        <TText style={styles.query}>{item.query}</TText>
                        <TText color="500">
                            {new Date(item.createdAt).toLocaleString('pt-BR')} ·{' '}
                            {item.sources.length} fontes
                        </TText>
                        {!!item.summary && (
                            <TText color="300" numberOfLines={5} style={styles.summary}>
                                {item.summary}
                            </TText>
                        )}
                        <ThemedButton
                            label="Excluir"
                            variant="tertiary"
                            onPress={() => remove(item.id)}
                        />
                    </View>
                )}
            />
        </View>
    )
}

export default ResearchMemoryScreen

const useStyles = () => {
    const { color, spacing, borderRadius, fontSize } = Theme.useTheme()
    return StyleSheet.create({
        container: { flex: 1, padding: spacing.xl, rowGap: spacing.l },
        help: { lineHeight: 20 },
        list: { paddingVertical: spacing.l, rowGap: spacing.l },
        empty: { textAlign: 'center', marginTop: spacing.xl3 },
        note: {
            backgroundColor: color.neutral._200,
            borderRadius: borderRadius.m,
            padding: spacing.l,
            rowGap: spacing.m,
        },
        query: { fontSize: fontSize.xl, fontWeight: '600' },
        summary: { lineHeight: 20 },
    })
}
