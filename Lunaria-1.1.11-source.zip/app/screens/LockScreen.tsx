/**
 * Tela de bloqueio.
 *
 * É a única coisa que o aplicativo mostra enquanto está bloqueado — nada de
 * conversa, nada de imagem. Ela também é a barreira de todas as entradas:
 * abertura normal, volta do segundo plano, notificação e link, porque o
 * `_layout.tsx` não monta o aplicativo enquanto `locked` for verdadeiro.
 */

import { Ionicons } from '@expo/vector-icons'
import React, { useEffect, useRef, useState } from 'react'
import { BackHandler, ScrollView, StyleSheet, Text, View } from 'react-native'
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated'

import ThemedButton from '@components/buttons/ThemedButton'
import ThemedTextInput from '@components/input/ThemedTextInput'
import Alert from '@components/views/Alert'
import { FORGOT_SECRET_EXPLANATION, formatLockout, validateSecret } from '@lib/security/LockPolicy'
import { useAppLock } from '@lib/state/AppLock'
import { Theme } from '@lib/theme/ThemeManager'

const LockScreen: React.FC = () => {
    const styles = useStyles()
    const { color } = Theme.useTheme()

    const unlock = useAppLock((state) => state.unlock)
    const unlockWithBiometrics = useAppLock((state) => state.unlockWithBiometrics)
    const resetVaultKeepingChats = useAppLock((state) => state.resetVaultKeepingChats)
    const tickLockout = useAppLock((state) => state.tickLockout)
    const lockoutSeconds = useAppLock((state) => state.lockoutSeconds)
    const failures = useAppLock((state) => state.failures)
    const settings = useAppLock((state) => state.settings)
    const biometricAvailable = useAppLock((state) => state.biometricAvailable)

    const [secret, setSecret] = useState('')
    const [error, setError] = useState<string | undefined>(undefined)
    const [checking, setChecking] = useState(false)
    const [resetMode, setResetMode] = useState(false)
    const [newSecret, setNewSecret] = useState('')

    // A biometria é oferecida **uma vez** por abertura da tela: repetir a cada
    // render vira uma cascata de popups do sistema.
    const biometricPrompted = useRef(false)

    useEffect(() => {
        if (biometricPrompted.current) return
        if (!settings.biometric || !biometricAvailable) return
        biometricPrompted.current = true
        unlockWithBiometrics()
    }, [biometricAvailable, settings.biometric, unlockWithBiometrics])

    useEffect(() => {
        // Contador da espera progressiva após erros seguidos.
        if (lockoutSeconds <= 0) return
        const timer = setInterval(() => tickLockout(), 1000)
        return () => clearInterval(timer)
    }, [lockoutSeconds, tickLockout])

    useEffect(() => {
        // Enquanto bloqueado, o botão "voltar" do Android não faz nada.
        const listener = BackHandler.addEventListener('hardwareBackPress', () => true)
        return () => listener.remove()
    }, [])

    const handleUnlock = async () => {
        if (checking || lockoutSeconds > 0) return
        setChecking(true)
        setError(undefined)
        try {
            const ok = await unlock(secret.trim())
            if (!ok) {
                setError('Senha ou PIN incorreto.')
                setSecret('')
            }
        } catch {
            setError('Não foi possível abrir o cofre neste aparelho.')
        } finally {
            setChecking(false)
        }
    }

    const askForgot = () => {
        Alert.alert({
            title: 'Esqueci a senha',
            description: FORGOT_SECRET_EXPLANATION.join('\n\n'),
            alignButtons: 'left',
            buttons: [
                { label: 'Voltar', type: 'default' },
                { label: 'Vou redefinir', type: 'warning', onPress: () => setResetMode(true) },
            ],
        })
    }

    const confirmReset = async () => {
        const verdict = validateSecret(newSecret.trim())
        if (!verdict.ok) {
            setError(verdict.reason)
            return
        }
        const result = await resetVaultKeepingChats(newSecret.trim())
        if (!result.ok) {
            setError(result.error)
            return
        }
        setResetMode(false)
        setNewSecret('')
    }

    return (
        <View style={styles.container}>
            <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
                <Animated.View entering={FadeIn.duration(400)} style={styles.brand}>
                    <Ionicons name="lock-closed" size={42} color={color.primary._300} />
                    <Text style={styles.title}>Lunaria bloqueada</Text>
                    <Text style={styles.subtitle}>
                        As conversas e as imagens geradas só aparecem depois do desbloqueio.
                    </Text>
                </Animated.View>

                {!resetMode ? (
                    <Animated.View entering={FadeInDown.duration(400)} style={styles.form}>
                        <ThemedTextInput
                            label={settings.biometric ? 'Senha ou PIN' : 'Senha ou PIN'}
                            description="Pelo menos 6 dígitos ou caracteres."
                            value={secret}
                            onChangeText={setSecret}
                            secureTextEntry
                            keyboardType="default"
                            autoFocus
                            onSubmitEditing={handleUnlock}
                            returnKeyType="go"
                        />

                        {error && <Text style={styles.error}>{error}</Text>}
                        {lockoutSeconds > 0 && (
                            <Text style={styles.lockout}>
                                {formatLockout(lockoutSeconds)} ({failures} tentativas erradas)
                            </Text>
                        )}
                        {lockoutSeconds === 0 && failures > 0 && (
                            <Text style={styles.hint}>
                                {failures} tentativa(s) errada(s). Nada foi apagado — a Lunaria
                                nunca apaga seus dados sozinha.
                            </Text>
                        )}

                        <ThemedButton
                            label={checking ? 'Conferindo…' : 'Desbloquear'}
                            iconName="unlock"
                            variant="primary"
                            onPress={handleUnlock}
                        />

                        {settings.biometric && biometricAvailable && (
                            <ThemedButton
                                label="Usar biometria"
                                iconName="scan"
                                variant="secondary"
                                onPress={unlockWithBiometrics}
                            />
                        )}

                        <ThemedButton
                            label="Esqueci a senha"
                            variant="tertiary"
                            onPress={askForgot}
                        />
                    </Animated.View>
                ) : (
                    <Animated.View entering={FadeInDown.duration(400)} style={styles.form}>
                        <Text style={styles.warningTitle}>Redefinir a senha apaga o cofre</Text>
                        {FORGOT_SECRET_EXPLANATION.map((line) => (
                            <Text key={line} style={styles.warningLine}>
                                • {line}
                            </Text>
                        ))}
                        <ThemedTextInput
                            label="Nova senha ou PIN"
                            description="Mínimo de 6 dígitos ou caracteres."
                            value={newSecret}
                            onChangeText={setNewSecret}
                            secureTextEntry
                            containerStyle={{ marginTop: 8 }}
                        />
                        {error && <Text style={styles.error}>{error}</Text>}
                        <ThemedButton
                            label="Apagar cofre e definir nova senha"
                            variant="critical"
                            onPress={confirmReset}
                        />
                        <ThemedButton
                            label="Cancelar"
                            variant="tertiary"
                            onPress={() => {
                                setResetMode(false)
                                setError(undefined)
                            }}
                        />
                    </Animated.View>
                )}
            </ScrollView>
        </View>
    )
}

export default LockScreen

const useStyles = () => {
    const { color, spacing, fontSize } = Theme.useTheme()

    return StyleSheet.create({
        container: {
            flex: 1,
            backgroundColor: color.neutral._100,
        },
        content: {
            flexGrow: 1,
            justifyContent: 'center',
            paddingHorizontal: spacing.xl,
            paddingVertical: spacing.xl2,
            rowGap: spacing.l,
        },
        brand: {
            alignItems: 'center',
            rowGap: spacing.s,
            marginBottom: spacing.l,
        },
        title: {
            color: color.text._100,
            fontSize: fontSize.xl3,
        },
        subtitle: {
            color: color.text._300,
            fontSize: fontSize.m,
            textAlign: 'center',
        },
        form: {
            rowGap: spacing.m,
        },
        error: {
            color: color.text._100,
            fontSize: fontSize.m,
        },
        lockout: {
            color: color.text._200,
            fontSize: fontSize.m,
        },
        hint: {
            color: color.text._300,
            fontSize: fontSize.s,
        },
        warningTitle: {
            color: color.text._100,
            fontSize: fontSize.xl,
        },
        warningLine: {
            color: color.text._300,
            fontSize: fontSize.s,
            lineHeight: 20,
        },
    })
}
