import { useRouter } from 'expo-router'
import React from 'react'
import { View } from 'react-native'
import { useShallow } from 'zustand/react/shallow'

import ThemedButton from '@components/buttons/ThemedButton'
import SectionTitle from '@components/text/SectionTitle'
import Alert from '@components/views/Alert'
import { useBackgroundStore } from '@lib/state/BackgroundImage'

const StyleSettings = () => {
    const router = useRouter()

    const { chatBackground, importBackground, deleteBackground } = useBackgroundStore(
        useShallow((state) => ({
            chatBackground: state.image,
            importBackground: state.importImage,
            deleteBackground: state.removeImage,
        }))
    )

    return (
        <View style={{ rowGap: 8 }}>
            <SectionTitle>Style</SectionTitle>

            <ThemedButton
                label="Trocar tema"
                variant="secondary"
                onPress={() => router.push('/screens/AppSettingsScreen/ColorSelector')}
            />
            <ThemedButton
                label={chatBackground ? 'Replace Chat Background' : 'Import Chat Background'}
                variant="secondary"
                onPress={importBackground}
            />
            {chatBackground && (
                <ThemedButton
                    label="Apagar plano de fundo da conversa"
                    variant="critical"
                    onPress={() =>
                        Alert.alert({
                            title: 'Delete Background',
                            description:
                                'Are you sure you want to delete this background? This cannot be undone!',
                            buttons: [
                                { label: 'Cancel' },
                                {
                                    label: 'Delete Background',
                                    type: 'warning',
                                    onPress: deleteBackground,
                                },
                            ],
                        })
                    }
                />
            )}
        </View>
    )
}

export default StyleSettings
