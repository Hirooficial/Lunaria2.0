import React from 'react'
import { View } from 'react-native'
import { useMMKVBoolean } from 'react-native-mmkv'

import ThemedSwitch from '@components/input/ThemedSwitch'
import SectionTitle from '@components/text/SectionTitle'
import { AppSettings } from '@lib/constants/GlobalValues'

const ChatWindowSettings = () => {
    const [autoScroll, setAutoScroll] = useMMKVBoolean(AppSettings.AutoScroll)
    const [sendOnEnter, setSendOnEnter] = useMMKVBoolean(AppSettings.SendOnEnter)
    const [quickDelete, setQuickDelete] = useMMKVBoolean(AppSettings.QuickDelete)
    const [saveScroll, setSaveScroll] = useMMKVBoolean(AppSettings.SaveScrollPosition)
    const [alternate, setAlternate] = useMMKVBoolean(AppSettings.AlternatingChatMode)
    const [wide, setWide] = useMMKVBoolean(AppSettings.WideChatMode)

    const [showTokensPerSecond, setShowTokensPerSecond] = useMMKVBoolean(
        AppSettings.ShowTokenPerSecond
    )

    return (
        <View style={{ rowGap: 8 }}>
            <SectionTitle>Chat Window</SectionTitle>

            <ThemedSwitch
                label="Rolagem automática"
                value={autoScroll}
                onChangeValue={setAutoScroll}
                description="Rola o texto enquanto a resposta é gerada"
            />

            <ThemedSwitch
                label="Enviar com Enter"
                value={sendOnEnter}
                onChangeValue={setSendOnEnter}
                description="Envia a mensagem ao pressionar Enter"
            />

            <ThemedSwitch
                label="Mostrar tokens por segundo"
                value={showTokensPerSecond}
                onChangeValue={setShowTokensPerSecond}
                description="Mostra tokens por segundo ao usar modelos locais"
            />

            <ThemedSwitch
                label="Exclusão rápida"
                value={quickDelete}
                onChangeValue={setQuickDelete}
                description="Liga o botão de excluir na barra de opções da conversa"
            />

            <ThemedSwitch
                label="Salvar posição de rolagem"
                value={saveScroll}
                onChangeValue={setSaveScroll}
                description="Volta automaticamente para a última posição vista na conversa"
            />

            <ThemedSwitch
                label="Conversa larga"
                value={wide}
                onChangeValue={setWide}
                description="Remove espaços para uma conversa mais larga"
            />

            <ThemedSwitch
                label="Alternar posição de usuário e personagem"
                value={alternate}
                onChangeValue={setAlternate}
                description="Alinha o personagem à esquerda e você à direita"
            />
        </View>
    )
}

export default ChatWindowSettings
