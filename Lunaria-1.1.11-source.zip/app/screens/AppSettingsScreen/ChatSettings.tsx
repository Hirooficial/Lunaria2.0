import { useTextIntentStatus } from '@vali98/react-native-process-text'
import { useRouter } from 'expo-router'
import React from 'react'
import { View } from 'react-native'
import { useMMKVBoolean } from 'react-native-mmkv'

import ThemedButton from '@components/buttons/ThemedButton'
import ThemedSwitch from '@components/input/ThemedSwitch'
import SectionTitle from '@components/text/SectionTitle'
import { AppSettings } from '@lib/constants/GlobalValues'

const ChatSettings = () => {
    const [firstMes, setFirstMes] = useMMKVBoolean(AppSettings.CreateFirstMes)
    const [chatOnStartup, setChatOnStartup] = useMMKVBoolean(AppSettings.ChatOnStartup)
    const [autoLoadUser, setAutoLoadUser] = useMMKVBoolean(AppSettings.AutoLoadUser)
    const [autoTitle, setAutoTitle] = useMMKVBoolean(AppSettings.AutoGenerateTitle)
    const { enabled: textIntent, setEnabled: setTextIntent } = useTextIntentStatus()
    const router = useRouter()
    return (
        <View style={{ rowGap: 8 }}>
            <SectionTitle>Conversa</SectionTitle>

            <ThemedSwitch
                label="Usar mensagem inicial"
                value={firstMes}
                onChangeValue={setFirstMes}
                description="Desative apenas se um modelo específico precisar iniciar em branco"
            />

            <ThemedSwitch
                label="Abrir a última conversa ao iniciar"
                value={chatOnStartup}
                onChangeValue={setChatOnStartup}
                description="Carrega automaticamente a conversa mais recente"
            />

            <ThemedSwitch
                label="Carregar usuário automaticamente"
                value={autoLoadUser}
                onChangeValue={setAutoLoadUser}
                description="Usa o perfil associado à conversa aberta"
            />

            <ThemedSwitch
                label="Gerar títulos automaticamente"
                value={autoTitle}
                onChangeValue={setAutoTitle}
                description="Cria títulos com IA no modo online"
            />

            <ThemedSwitch
                label="Perguntar à Lunaria"
                value={textIntent}
                onChangeValue={setTextIntent}
                description="Adiciona a Lunaria ao menu de texto selecionado do Android"
            />

            <ThemedButton
                label="Aparência da conversa"
                variant="secondary"
                onPress={() => router.push('/screens/AppSettingsScreen/ChatStyleSettings')}
            />
        </View>
    )
}

export default ChatSettings
