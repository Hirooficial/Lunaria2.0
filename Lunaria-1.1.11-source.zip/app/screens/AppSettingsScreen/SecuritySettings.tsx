import React from 'react'
import { View } from 'react-native'
import { useMMKVBoolean } from 'react-native-mmkv'

import ThemedSwitch from '@components/input/ThemedSwitch'
import SectionTitle from '@components/text/SectionTitle'
import { AppSettings } from '@lib/constants/GlobalValues'

const SecuritySettings = () => {
    const [authLocal, setAuthLocal] = useMMKVBoolean(AppSettings.LocallyAuthenticateUser)
    return (
        <View style={{ rowGap: 8 }}>
            <SectionTitle>Security</SectionTitle>
            <ThemedSwitch
                label="Bloquear aplicativo"
                value={authLocal}
                onChangeValue={setAuthLocal}
                description="Exige autenticação para abrir o aplicativo. Não funciona sem bloqueio de tela configurado no aparelho."
            />
        </View>
    )
}

export default SecuritySettings
