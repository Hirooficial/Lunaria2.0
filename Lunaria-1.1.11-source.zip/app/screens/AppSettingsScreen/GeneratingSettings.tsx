import React from 'react'
import { View } from 'react-native'
import { useMMKVBoolean } from 'react-native-mmkv'

import ThemedSwitch from '@components/input/ThemedSwitch'
import SectionTitle from '@components/text/SectionTitle'
import { AppSettings } from '@lib/constants/GlobalValues'

const GeneratingSettings = () => {
    const [printContext, setPrintContext] = useMMKVBoolean(AppSettings.PrintContext)
    const [bypassContextLength, setBypassContextLength] = useMMKVBoolean(
        AppSettings.BypassContextLength
    )
    return (
        <View style={{ rowGap: 8 }}>
            <SectionTitle>Generation</SectionTitle>

            <ThemedSwitch
                label="Registrar contexto"
                value={printContext}
                onChangeValue={setPrintContext}
                description="Grava o contexto da geração nos registros para depuração"
            />

            <ThemedSwitch
                label="Ignorar limite de contexto"
                value={bypassContextLength}
                onChangeValue={setBypassContextLength}
                description="Ignora os limites de contexto ao montar o pedido"
            />
        </View>
    )
}

export default GeneratingSettings
