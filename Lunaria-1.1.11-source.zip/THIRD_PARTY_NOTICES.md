# Créditos e componentes de terceiros

Lunaria deriva do [ChatterUI](https://github.com/Vali-98/ChatterUI), de Vali-98 e
colaboradores, sob AGPL-3.0. O arquivo LICENSE preserva a licença do código-base.
Ao distribuir uma versão modificada, disponibilize seu código-fonte correspondente.

As dependências e versões exatas estão em package.json e package-lock.json.
Entre os componentes principais estão Expo, React Native, React, cui-llama.rn
e llama.cpp. As licenças desses componentes acompanham seus pacotes; a licença
deste projeto não substitui as respectivas licenças.

O modo online utiliza a [AI Horde](https://github.com/Haidra-Org/AI-Horde), serviço
independente mantido pela comunidade. A aplicação não opera os workers nem
garante disponibilidade, privacidade ou qualidade dos modelos fornecidos por eles.
Modelos GGUF importados têm suas próprias licenças e não acompanham este backup.

O tokenizer GGUF distribuído em assets/models foi preservado do código-base.
Não é um modelo de conversação. Os ícones da interface usam as bibliotecas
de ícones declaradas nas dependências. Os arquivos de identidade visual Lunaria
fazem parte desta personalização.
