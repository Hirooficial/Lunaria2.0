/**
 * Entrada do aplicativo — a primeira linha de código que roda.
 *
 * Ordem importa e é o ponto inteiro deste arquivo:
 *
 *   1. o porteiro (`lib/utils/EntradaSegura`) é carregado **primeiro** e não
 *      depende de nada (nem um `import` no topo): ele apenas instala o registro
 *      de erros fatais;
 *   2. só então o `expo-router/entry` é carregado, e **dentro de um try/catch**.
 *      Todo o aplicativo — telas, banco, cofre, geração de imagem — pende desse
 *      `require`. Se qualquer módulo do caminho falhar ao ser avaliado (o defeito
 *      relatado: código nativo executado no instante do carregamento), o erro cai
 *      aqui em vez de fechar o aplicativo em silêncio;
 *   3. com o erro em mãos, o porteiro registra uma **tela de aviso** como tela
 *      inicial: o aplicativo abre, mostra o motivo e oferece "Copiar
 *      diagnóstico" — o dado que faltava para achar a causa.
 *
 * Por que CommonJS (`require`) em vez de `import`: com `import`, o empacotador
 * pode reordenar a avaliação dos módulos; com `require` explícito, a ordem é
 * literalmente a ordem escrita. Neste arquivo, ordem é correção.
 *
 * O `main` do `package.json` aponta para cá (`index.js`), e não mais direto para
 * `expo-router/entry` — é o padrão documentado do Expo Router para entrada
 * personalizada. Há testes que travam os dois pontos (`index.js` carrega o
 * porteiro antes das rotas, e o `main` aponta para este arquivo).
 */

const EntradaSegura = require('./lib/utils/EntradaSegura')

// Antes de tudo: quem registra erro fatal passa a ser este arquivo.
EntradaSegura.instalarTratador()

// Primeira etapa do lado JavaScript na trilha de abertura. Carregado tarde e
// dentro de try/catch: a trilha não pode ser motivo de falha na abertura.
try {
    require('./lib/utils/TrilhaJs').marcarEtapaJs('1/8 porteiro instalado')
} catch {
    // sem trilha, a abertura segue igual
}

try {
    require('expo-router/entry')
    EntradaSegura.marcarRotasCarregadas()
} catch (erro) {
    // O aplicativo não chegou a montar. Em vez de fechar em silêncio, abre na
    // tela de aviso com o motivo.
    EntradaSegura.mostrarFalha(erro)
}
