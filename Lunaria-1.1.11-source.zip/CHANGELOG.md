# Changelog

## 1.1.2 — cancelar agora avisa o provedor (18/09/2026)

**Defeito corrigido, encontrado na revisão depois da 1.1.1:** o botão "Cancelar"
parava a espera no aplicativo, mas **não avisava o provedor**. O trabalho
continuava na fila e era gerado do mesmo jeito — medido com o serviço real: um
trabalho abandonado terminou sozinho, com imagem pronta, cerca de 60 s depois.
Resultado prático: a imagem era produzida por um worker voluntário e ninguém a
recebia, gastando a prioridade (kudos) de quem cancelou.

- ao cancelar, o aplicativo agora envia `DELETE /generate/status/{id}` e o
  trabalho sai da fila;
- geração concluída **não** envia cancelamento (a imagem pronta não é descartada);
- erros que não são cancelamento (401, 404) também não;
- conferido na API real: o `DELETE` funciona sem cabeçalho de chave.

Testes: 3 novos em `tests/imageprovider.test.mjs` (30 no arquivo). Suíte de
lógica: 104/104; renderização: 50/50.

Versão 1.1.2, versionCode 4 — atualiza por cima da 1.1.1 (mesma assinatura).


## 1.1.1 — correção do limite de consultas do provedor (18/09/2026)

**Defeito corrigido, encontrado testando o provedor de verdade:** com fila longa,
a chave anônima da AI Horde responde **429 (muitas consultas)** a uma consulta de
status — mesmo com tudo certo. O aplicativo tratava esse 429 como erro definitivo
e abortava a geração, mostrando "cota esgotada" para quem não tinha cota esgotada
nenhuma. Numa fila de 262 pedidos (situação observada hoje), a geração nunca
chegaria ao fim.

- consultas de status com **429** ou **5xx** agora são tratadas como passageiras:
  o aplicativo espera e tenta de novo, com espera crescente (5 s, 10 s, 20 s… até
  30 s) e respeitando o cabeçalho `Retry-After` quando o provedor manda;
- erros que **não** são passageiros continuam abortando na hora: 401/403
  (autenticação), 404 (trabalho não encontrado), 400 (pedido inválido);
- o intervalo entre consultas subiu de 3 s para **5 s**, reduzindo a chance de
  bater no limite;
- o cancelamento continua funcionando durante a espera.

Testes: 6 novos em `tests/imageprovider.test.mjs` (19 no arquivo) cobrindo 429
repetido, teto da espera, `Retry-After`, 5xx, 401 e 404. Suíte de lógica: 93/93.

Versão 1.1.1, versionCode 3 — atualiza por cima da 1.1.0 (mesma assinatura).

## 1.1.0 — rodada Arena 2 (18/09/2026)

### Geração de imagem
- botão **Gerar imagem** na conversa, com tela própria de descrição, proporção
  (retrato, vertical, quadrado, paisagem, cinema) e 8 estilos: gótico, sombrio,
  fantasia, anime, fotografia, ilustração, moda e romântico;
- perfil visual editável da Lunaria (adulta, cabelo, olhos, roupas, acessórios)
  usado quando o pedido é sobre ela, com aviso do limite de consistência do modelo;
- prévia da descrição final (o texto exato enviado), prompt negativo e semente;
- estados reais de conexão, fila, geração, conclusão, erro e cancelamento, com
  tempo decorrido e nova tentativa;
- imagem exibida na conversa com visualizador (zoom, salvar, compartilhar, apagar);
- política de conteúdo antes do envio: permite adulta, sensualidade não explícita,
  moda alternativa e romance; recusa nudez sexual, atos, menores e coerção.

### Provedores
- **AI Horde (imagem)** como padrão, com a chave anônima que já existia no app e
  suporte a chave pessoal gratuita;
- **Pollinations** como alternativa sem cadastro;
- provedores pagos desativados por padrão;
- mensagens específicas para falta de internet, cota estourada (429), provedor
  indisponível (5xx), recusa e resposta inválida.

### Bloqueio e privacidade
- senha ou PIN de no mínimo 6 dígitos, com biometria opcional;
- bloqueio ao abrir e ao voltar do segundo plano, com intervalo configurável e
  botão “Bloquear agora”;
- nenhuma tela é montada enquanto bloqueado; notificação com conversa fica
  pendente até o desbloqueio;
- conteúdo escondido nas notificações e na prévia de aplicativos recentes;
- opção de impedir capturas de tela (ligada automaticamente enquanto bloqueado);
- espera progressiva nas tentativas erradas, **sem apagar dados**;
- ao bloquear: para a leitura em voz alta, aborta o microfone, descarta a chave
  da memória e apaga as cópias decifradas temporárias;
- ativar, alterar e desativar exigem autenticação; procedimento de senha
  esquecida explicado antes de qualquer redefinição.

### Cifragem e migração
- imagens privadas em AES-256-GCM com chave no Android Keystore (sem senha,
  a chave fica só no Keystore; com senha, embrulhada por PBKDF2-HMAC-SHA256,
  150.000 iterações);
- pasta `private/` com nomes aleatórios e extensão `.lunaenc`;
- migração automática das imagens antigas em claro para o cofre, com verificação
  de leitura antes de apagar o original;
- cópia de segurança do Android desativada para os dados do app.

### Compatibilidade
- versão 1.1.0, versionCode 2, mesma assinatura de release da 1.0.0 (atualiza por
  cima sem desinstalar);
- nenhum recurso anterior removido: conversa, personalidade editável em pt-BR,
  tratamento masculino a Hamura, GGUF local, API remota, ditado, leitura em voz
  alta, Pesquisa/Fatos e memória continuam iguais.

## 1.0.0

- rebranding completo para Lunaria;
- cartão de personagem em português e preservação das respostas sem frases prontas;
- AI Horde anônimo como conexão online inicial;
- Pesquisa/Fatos com comparação de fontes e memória;
- ditado pt-BR, TTS e telas de privacidade traduzidas;
- execução local GGUF preservada;
- testes automatizados de persona e pesquisa.
- decodificação incremental de UTF-8, SSE e NDJSON;
- proteção contra envio duplicado e finalização duplicada de respostas;
- cancelamento de gerações antigas sem misturar novas mensagens;
- limite de tempo cobrindo a leitura completa da resposta online;
- pesquisa por links públicos como alternativa à indisponibilidade do buscador;
- salvamento explícito de pesquisas, com fontes e data;
- interrupção do ditado ao sair da conversa e idioma pt-BR no TTS;
- compilação manual no GitHub Actions, sem o servidor privado do projeto-base.

## 1.0.0 — rodada Arena (15/09/2026)

- **APK arm64 compilado e assinado** com chave própria da Lunaria (o template
  do Expo assinava o release com a chave de depuração);
- plugin `expo-build-plugins/lunaria-signing.plugin.js`, que sobrevive a
  `expo prebuild --clean` e usa `android/keystore.properties` quando existe;
- buffer de geração com dono (`lib/engine/StreamBuffer.ts`): texto de outra
  conversa, de outro swipe ou de uma resposta antiga nunca prefixa nem contamina
  a resposta nova — corrige a sobra de texto e a gravação contaminada;
- mesma separação no buffer da leitura em voz alta e na tela (`ChatTextLast`);
- pesquisa agrupa trechos repetidos por similaridade e informa quantos
  textos-base distintos existem; o contexto separa fatos, divergências,
  opiniões e evidências insuficientes;
- padrão local conservador para 6 GB de RAM (lote 256, contexto 4096, 4 threads,
  `ctx_shift`), tudo editável em Configurações → Modelo;
- 150 rótulos de interface herdados do ChatterUI traduzidos para português;
- 7 testes novos (26 no total), TypeScript e ESLint sem avisos.
