/**
 * Ajustes do ambiente de teste de renderização.
 *
 * - Reanimated 4 e Worklets são substituídos por shims em
 *   tests/render/mocks/ via moduleNameMapper (ver package.json): eles dependem
 *   de código nativo (JSI) que não existe fora do aparelho.
 * - O MMKV também é nativo: o pacote oferece uma implementação em memória para
 *   testes (`createMockMMKV`), usada aqui no lugar do módulo real.
 * - Guardamos o mapa de módulos nativos em memória para os testes de telas.
 */
jest.mock('react-native-mmkv', () => {
    const store = new Map()
    const instance = {
        set: (k, v) => store.set(k, v),
        getString: (k) => store.get(k),
        getNumber: (k) => store.get(k),
        getBoolean: (k) => store.get(k),
        contains: (k) => store.has(k),
        delete: (k) => store.delete(k),
        remove: (k) => store.delete(k),
        getAllKeys: () => [...store.keys()],
        clearAll: () => store.clear(),
    }
    const createMMKV = () => instance
    return {
        createMMKV,
        MMKV: function () {
            return instance
        },
        useMMKVString: (k) => [store.get(k), (v) => store.set(k, v)],
        useMMKVBoolean: (k) => [store.get(k), (v) => store.set(k, v)],
        useMMKVNumber: (k) => [store.get(k), (v) => store.set(k, v)],
        __store: store,
    }
})

jest.mock('expo-secure-store', () => {
    const slots = new Map()
    return {
        getItemAsync: jest.fn(async (k) => (slots.has(k) ? slots.get(k) : null)),
        setItemAsync: jest.fn(async (k, v) => slots.set(k, v)),
        deleteItemAsync: jest.fn(async (k) => slots.delete(k)),
        isAvailableAsync: jest.fn(async () => true),
        __slots: slots,
    }
})

jest.mock('expo-local-authentication', () => ({
    hasHardwareAsync: jest.fn(async () => false),
    isEnrolledAsync: jest.fn(async () => false),
    authenticateAsync: jest.fn(async () => ({ success: false })),
    supportedAuthenticationTypesAsync: jest.fn(async () => []),
}))

jest.mock('react-native-simple-toast', () => ({
    __esModule: true,
    default: { show: jest.fn(), showWithGravity: jest.fn(), LONG: 1, SHORT: 0 },
    show: jest.fn(),
    showWithGravity: jest.fn(),
    LONG: 1,
    SHORT: 0,
}))

/**
 * expo-sqlite: o banco real é nativo. No ambiente de teste ele é substituído por
 * um banco de mentira que aceita as mesmas chamadas e não guarda nada — o
 * objetivo aqui é a tela abrir, não testar SQL (isso é do aparelho).
 */
jest.mock('expo-sqlite', () => {
    const resultado = () => ({ changes: 0, lastInsertRowId: 0 })
    const statement = () => ({
        executeSync: resultado,
        executeAsync: async () => resultado(),
        finalizeSync: () => {},
        finalizeAsync: async () => {},
    })
    const db = {
        execSync: jest.fn(),
        execAsync: jest.fn(async () => {}),
        runSync: jest.fn(resultado),
        runAsync: jest.fn(async () => resultado()),
        getAllSync: jest.fn(() => []),
        getAllAsync: jest.fn(async () => []),
        getFirstSync: jest.fn(() => null),
        getFirstAsync: jest.fn(async () => null),
        withTransactionSync: (fn) => fn(),
        withTransactionAsync: async (fn) => fn(),
        prepareSync: statement,
        prepareAsync: async () => statement(),
        loadExtensionAsync: jest.fn(async () => {}),
        loadExtensionSync: jest.fn(),
        closeSync: jest.fn(),
        closeAsync: jest.fn(async () => {}),
    }
    function SQLiteDatabase() {
        return db
    }
    return {
        __esModule: true,
        openDatabaseSync: () => db,
        openDatabaseAsync: async () => db,
        SQLiteDatabase,
        default: { NativeDatabase: SQLiteDatabase },
        bundledExtensions: {}, // sem extensões no teste; o app verifica a existência
        addDatabaseChangeListener: () => ({ remove: () => {} }),
    }
})

/**
 * Módulos Nitro (turbo modules nativos) não existem no node. O MMKV desta versão
 * e o `@vali98/react-native-png-utils` (usado no estado dos personagens) são
 * construídos sobre eles. Aqui vão stubs com as funções que o app usa.
 */
jest.mock('react-native-nitro-modules', () => ({
    __esModule: true,
    NitroModules: {
        createHybridObject: () => ({}),
        hasHybridObject: () => false,
        box: (v) => v,
        unbox: (v) => v,
    },
    default: {
        createHybridObject: () => ({}),
        hasHybridObject: () => false,
        box: (v) => v,
        unbox: (v) => v,
    },
}))

jest.mock('@vali98/react-native-png-utils', () => ({
    __esModule: true,
    // o app usa estas funções para ler dimensões/gerar miniatura de imagem
    getPngInfo: jest.fn(async () => ({ width: 512, height: 768 })),
    getImageSize: jest.fn(async () => ({ width: 512, height: 768 })),
    createThumbnail: jest.fn(async () => 'file:///cache/miniatura.png'),
    getPngDimensions: jest.fn(async () => ({ width: 512, height: 768 })),
    resizeImage: jest.fn(async (uri) => uri),
    default: {},
}))

jest.mock('react-native-keyboard-controller', () => {
    const React = require('react')
    const RN = require('react-native')
    const passthrough = (nome) => {
        const C = ({ children, ...props }) => React.createElement(RN.View, props, children)
        C.displayName = nome
        return C
    }
    return {
        __esModule: true,
        KeyboardProvider: passthrough('KeyboardProvider'),
        KeyboardAwareScrollView: React.forwardRef((props, ref) =>
            React.createElement(RN.ScrollView, { ...props, ref }, props?.children)
        ),
        KeyboardStickyView: passthrough('KeyboardStickyView'),
        KeyboardToolbar: passthrough('KeyboardToolbar'),
        KeyboardAvoidingView: passthrough('KeyboardAvoidingView'),
        KeyboardGestureArea: passthrough('KeyboardGestureArea'),
        // teclado sempre "fechado" no ambiente de teste: altura 0, sem animação
        useReanimatedKeyboardAnimation: () => ({
            height: { value: 0 },
            progress: { value: 0 },
        }),
        useKeyboardHandler: () => {},
        useKeyboardState: (selector) =>
            selector ? selector({ isVisible: false, height: 0 }) : { isVisible: false, height: 0 },
        useKeyboardAnimation: () => ({ height: { value: 0 }, progress: { value: 0 } }),
        KeyboardController: { dismiss: () => {}, setInputMode: () => {} },
    }
})

jest.mock('react-native-background-actions', () => ({
    __esModule: true,
    default: {
        start: jest.fn(async () => {}),
        stop: jest.fn(async () => {}),
        isRunning: jest.fn(async () => false),
        updateNotification: jest.fn(async () => {}),
        on: jest.fn(),
    },
}))

// `expo/fetch` é a implementação de inverno (JSI); no node usamos o fetch global
jest.mock('expo/fetch', () => ({
    __esModule: true,
    fetch: (...args) => global.fetch(...args),
}))

// Módulos de voz: sem motor nativo no node. Nenhum teste de tela depende de
// falar ou ouvir de verdade — isso é do aparelho.
jest.mock('expo-speech-recognition', () => ({
    __esModule: true,
    ExpoSpeechRecognitionModule: {
        start: jest.fn(),
        stop: jest.fn(),
        abort: jest.fn(),
        requestPermissionsAsync: jest.fn(async () => ({ granted: true })),
        getPermissionsAsync: jest.fn(async () => ({ granted: true })),
        addListener: jest.fn(() => ({ remove: jest.fn() })),
        isRecognitionAvailable: jest.fn(() => true),
    },
    useSpeechRecognitionEvent: jest.fn(),
}))

/**
 * O preset do React Native não implementa `Image.getSize` (devolve undefined e
 * quebra quem usa `.then`). Aqui ele responde na hora, com um tamanho fixo —
 * nenhum teste depende da dimensão real da imagem.
 */
const RN = require('react-native')
if (RN.Image) {
    RN.Image.getSize = (uri, sucesso) => {
        sucesso?.(512, 768)
    }
    RN.Image.getSizeWithHeaders = (uri, headers, sucesso) => {
        sucesso?.(512, 768)
    }
    RN.Image.prefetch = async () => true
}
if (RN.NativeModules?.RNSafeAreaContext === undefined) {
    // nada a fazer: o SafeAreaProvider recebe métricas iniciais nos testes
}

/**
 * Sistema de arquivos do aplicativo, em memória.
 *
 * `expo-file-system` na versão nova (File/Directory) é nativo e não roda no
 * node. Esta implementação guarda tudo num Map, com a mesma API que o cofre
 * usa: escrever, ler bytes, apagar, listar. Isso permite testar de verdade o
 * caminho "cifrar → gravar → ler de volta → apagar" sem tocar no disco, e
 * continua valendo como prova de que o arquivo gravado **não** tem o conteúdo
 * em claro.
 */
jest.mock('expo-file-system', () => {
    const arquivos = new Map() // caminho -> Uint8Array
    const pastas = new Set(['/doc', '/cache'])

    const juntar = (partes) =>
        partes
            .map((p) => {
                if (p === null || p === undefined) return ''
                if (typeof p === 'string') return p
                if (typeof p === 'object' && 'uri' in p) return String(p.uri).replace('file://', '')
                return String(p)
            })
            .filter(Boolean)
            .join('/')
            .replace(/\/+/g, '/')

    const nomeDe = (caminho) => caminho.split('/').filter(Boolean).pop() ?? ''

    const paraBytes = (conteudo) => {
        if (conteudo instanceof Uint8Array) return conteudo
        if (typeof conteudo === 'string') return new TextEncoder().encode(conteudo)
        return new TextEncoder().encode(String(conteudo))
    }

    class File {
        constructor(...partes) {
            this.path = juntar(partes.map((p) => (p instanceof Directory ? p.path : p)))
            this.name = nomeDe(this.path)
        }
        get uri() {
            return 'file://' + this.path
        }
        get exists() {
            return arquivos.has(this.path)
        }
        get size() {
            return arquivos.get(this.path)?.length ?? 0
        }
        create() {
            if (!arquivos.has(this.path)) arquivos.set(this.path, new Uint8Array())
        }
        write(conteudo) {
            arquivos.set(this.path, paraBytes(conteudo))
        }
        append(conteudo) {
            const atual = arquivos.get(this.path) ?? new Uint8Array()
            const novo = paraBytes(conteudo)
            const junto = new Uint8Array(atual.length + novo.length)
            junto.set(atual, 0)
            junto.set(novo, atual.length)
            arquivos.set(this.path, junto)
        }
        bytes() {
            return arquivos.get(this.path) ?? new Uint8Array()
        }
        bytesSync() {
            return this.bytes()
        }
        text() {
            return new TextDecoder().decode(this.bytes())
        }
        textSync() {
            return this.text()
        }
        base64() {
            const b = this.bytes()
            let s = ''
            for (const byte of b) s += String.fromCharCode(byte)
            return Buffer.from(s, 'binary').toString('base64')
        }
        base64Sync() {
            return this.base64()
        }
        md5() {
            return 'md5-falso'
        }
        delete() {
            arquivos.delete(this.path)
        }
        move(destino) {
            const d =
                destino instanceof Directory ? destino.path + '/' + this.name : String(destino)
            arquivos.set(d, this.bytes())
            arquivos.delete(this.path)
        }
        copy(destino) {
            const d =
                destino instanceof Directory ? destino.path + '/' + this.name : String(destino)
            arquivos.set(d, this.bytes())
        }
        info() {
            return {
                exists: this.exists,
                size: this.size,
                uri: this.uri,
                isDirectory: false,
                modificationTime: 0,
            }
        }
        static downloadFileAsync = jest.fn(async (url, destino) => {
            const alvo = destino instanceof File ? destino : new File(String(destino))
            alvo.write(new Uint8Array([1, 2, 3, 4]))
            return alvo
        })
    }

    class Directory {
        constructor(...partes) {
            this.path = juntar(partes.map((p) => (p instanceof Directory ? p.path : p)))
            this.name = nomeDe(this.path)
            pastas.add(this.path)
        }
        get uri() {
            return 'file://' + this.path
        }
        get exists() {
            return pastas.has(this.path)
        }
        create() {
            pastas.add(this.path)
        }
        delete() {
            pastas.delete(this.path)
            for (const caminho of [...arquivos.keys()]) {
                if (caminho.startsWith(this.path + '/')) arquivos.delete(caminho)
            }
        }
        createFile(nome) {
            const f = new File(this.path, nome)
            f.create()
            return f
        }
        createDirectory(nome) {
            return new Directory(this.path, nome)
        }
        list() {
            const prefixo = this.path.endsWith('/') ? this.path : this.path + '/'
            const itens = []
            for (const caminho of arquivos.keys()) {
                if (caminho.startsWith(prefixo)) {
                    const resto = caminho.slice(prefixo.length)
                    if (!resto.includes('/')) itens.push(new File(caminho))
                }
            }
            for (const pasta of pastas) {
                if (pasta !== this.path && pasta.startsWith(prefixo)) {
                    const resto = pasta.slice(prefixo.length)
                    if (resto && !resto.includes('/')) itens.push(new Directory(pasta))
                }
            }
            return itens
        }
        listAsRecords() {
            return this.list().map((item) => ({
                name: item.name,
                uri: item.uri,
                size: item.size ?? 0,
                isDirectory: item instanceof Directory,
                modificationTime: 0,
            }))
        }
        info() {
            return {
                exists: this.exists,
                size: 0,
                uri: this.uri,
                isDirectory: true,
                modificationTime: 0,
            }
        }
    }

    const Paths = {
        document: new Directory('/doc'),
        cache: new Directory('/cache'),
    }

    return { File, Directory, Paths, __arquivos: arquivos, __pastas: pastas }
})
