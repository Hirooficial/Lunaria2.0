# Changelog

## 1.0.0

- rebranding completo para Lunaria;
- cartão de personagem em português e preservação das respostas sem frases prontas;
- AI Horde anônimo como conexão online inicial;
- Pesquisa/Fatos com comparação de fontes e memória;
- ditado pt-BR, TTS e telas de privacidade traduzidas;
- execução local GGUF preservada;
- testes automatizados de persona e pesquisa.
- decodificação incremental de UTF-8, SSE e NDJSON;
- proteção contra envio duplicado e finalização duplicada de respostas;
- cancelamento de gerações antigas sem misturar novas mensagens;
- limite de tempo cobrindo a leitura completa da resposta online;
- pesquisa por links públicos como alternativa à indisponibilidade do buscador;
- salvamento explícito de pesquisas, com fontes e data;
- interrupção do ditado ao sair da conversa e idioma pt-BR no TTS;
- compilação manual no GitHub Actions, sem o servidor privado do projeto-base.

## 1.0.0 — rodada Arena (15/09/2026)

- **APK arm64 compilado e assinado** com chave própria da Lunaria (o template
  do Expo assinava o release com a chave de depuração);
- plugin `expo-build-plugins/lunaria-signing.plugin.js`, que sobrevive a
  `expo prebuild --clean` e usa `android/keystore.properties` quando existe;
- buffer de geração com dono (`lib/engine/StreamBuffer.ts`): texto de outra
  conversa, de outro swipe ou de uma resposta antiga nunca prefixa nem contamina
  a resposta nova — corrige a sobra de texto e a gravação contaminada;
- mesma separação no buffer da leitura em voz alta e na tela (`ChatTextLast`);
- pesquisa agrupa trechos repetidos por similaridade e informa quantos
  textos-base distintos existem; o contexto separa fatos, divergências,
  opiniões e evidências insuficientes;
- padrão local conservador para 6 GB de RAM (lote 256, contexto 4096, 4 threads,
  `ctx_shift`), tudo editável em Configurações → Modelo;
- 150 rótulos de interface herdados do ChatterUI traduzidos para português;
- 7 testes novos (26 no total), TypeScript e ESLint sem avisos.
