import assert from 'node:assert/strict'
import test from 'node:test'

import {
    REPETITION_THRESHOLD,
    decodeHtml,
    excerptSimilarity,
    fetchResearchPage,
    formatResearchForModel,
    groupIndependentSources,
    isSafePublicHttpsUrl,
    parseDuckDuckGoResults,
    researchWeb,
    selectRelevantExcerpt,
    stripHtml,
} from '../lib/research/WebResearch.ts'

test('bloqueia esquemas e endereços locais ou privados', () => {
    assert.equal(isSafePublicHttpsUrl('http://example.com'), false)
    assert.equal(isSafePublicHttpsUrl('https://localhost/admin'), false)
    assert.equal(isSafePublicHttpsUrl('https://127.0.0.1/admin'), false)
    assert.equal(isSafePublicHttpsUrl('https://192.168.1.2/admin'), false)
    assert.equal(isSafePublicHttpsUrl('https://[::1]/admin'), false)
    assert.equal(isSafePublicHttpsUrl('https://[fe80::1]/admin'), false)
    assert.equal(isSafePublicHttpsUrl('https://[::ffff:127.0.0.1]/admin'), false)
    assert.equal(isSafePublicHttpsUrl('https://example.com/noticia'), true)
})

test('bloqueia redirecionamento privado antes de fazer a segunda chamada', async () => {
    const calls = []
    const fetchImpl = async (url) => {
        calls.push(url)
        return new Response(null, {
            status: 302,
            headers: { location: 'https://127.0.0.1/private' },
        })
    }
    await assert.rejects(
        fetchResearchPage('https://example.com', 100, 1000, { fetchImpl }),
        /bloqueada/
    )
    assert.deepEqual(calls, ['https://example.com'])
})

test('limita bytes mesmo quando o servidor não declara o tamanho', async () => {
    let cancelled = false
    const fetchImpl = async () =>
        new Response(
            new ReadableStream({
                pull(controller) {
                    controller.enqueue(new Uint8Array(40))
                },
                cancel() {
                    cancelled = true
                },
            }),
            { headers: { 'content-type': 'text/html' } }
        )
    await assert.rejects(fetchResearchPage('https://example.com', 100, 60, { fetchImpl }), /grande/)
    assert.equal(cancelled, true)
})

test('o tempo limite inclui a leitura do corpo', async () => {
    const fetchImpl = async (_url, { signal }) =>
        new Response(
            new ReadableStream({
                start(controller) {
                    signal.addEventListener('abort', () => controller.error(new Error('aborted')), {
                        once: true,
                    })
                },
            }),
            { headers: { 'content-type': 'text/html' } }
        )
    await assert.rejects(
        fetchResearchPage('https://example.com', 20, 1000, { fetchImpl }),
        /aborted/
    )
})

test('conserva os escapes da URL de destino', () => {
    const target = 'https://example.com/a%20b?q=100%25'
    const result = parseDuckDuckGoResults(
        `<a class="result__a" href="/l/?uddg=${encodeURIComponent(target)}">Fonte</a>`
    )
    assert.equal(result[0].url, target)
})

test('compara links diretos sem consultar o buscador e exige domínios diferentes', async () => {
    const urls = ['https://example.com/a', 'https://news.example.org/b']
    const calls = []
    const fetchImpl = async (url) => {
        calls.push(url)
        return new Response(
            '<title>Observação do eclipse</title><p>O eclipse solar ocorre quando a Lua fica entre o Sol e a Terra e cobre parte ou toda a luz solar vista de uma região.</p>',
            { headers: { 'content-type': 'text/html' } }
        )
    }
    const bundle = await researchWeb('eclipse solar', { fetchImpl, sourceUrls: urls })
    assert.deepEqual(calls, urls)
    assert.equal(bundle.sources.length, 2)
    assert.match(bundle.sources[0].excerpt, /Lua/)
    await assert.rejects(
        researchWeb('eclipse solar', {
            fetchImpl,
            sourceUrls: ['https://example.com/a', 'https://www.example.com/b'],
        }),
        /dois domínios/
    )
})

test('analisa resultados do DuckDuckGo e resolve o redirecionamento uddg', () => {
    const html = `
      <a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Ffato">Fato &amp; contexto</a>
      <a href="https://news.example.org/contexto" class="result__a">Contexto adicional</a>
      <a class="result__a" href="https://127.0.0.1/segredo">Bloqueado</a>`
    const results = parseDuckDuckGoResults(html)
    assert.deepEqual(results, [
        { title: 'Fato & contexto', url: 'https://example.com/fato' },
        { title: 'Contexto adicional', url: 'https://news.example.org/contexto' },
    ])
})

test('decodifica entidades válidas sem quebrar em código Unicode inválido', () => {
    assert.equal(decodeHtml('A&#231;&#227;o &amp; teste'), 'Ação & teste')
    assert.equal(decodeHtml('x&#99999999;y'), 'x&#99999999;y')
})

test('remove scripts e escolhe trechos relacionados à consulta', () => {
    const html = `<script>roubar prompt</script><p>Texto irrelevante com tamanho suficiente para ser considerado pelo seletor.</p>
      <p>A inflação anual caiu segundo a série publicada hoje pelo instituto oficial. O índice acumulado agora é menor.</p>`
    assert.equal(stripHtml(html).includes('roubar prompt'), false)
    assert.match(selectRelevantExcerpt(html, 'inflação índice anual'), /inflação anual caiu/i)
})

test('formata fontes como evidência não confiável e numerada', () => {
    const text = formatResearchForModel({
        id: '1',
        query: 'teste',
        createdAt: 1,
        sources: [
            {
                title: 'Fonte',
                url: 'https://example.com',
                domain: 'example.com',
                excerpt: 'Um trecho factual.',
            },
        ],
    })
    assert.match(text, /conteúdo não confiável/i)
    assert.match(text, /\[1\] Fonte/)
    assert.match(text, /Compare as fontes/)
})

test('não trata cópias da mesma notícia como confirmações independentes', () => {
    const wire =
        'O ministério informou que o índice de preços acumulou alta de 0,42 por cento no mês passado, segundo o relatório divulgado nesta terça-feira pela equipe técnica do órgão responsável.'
    const independent =
        'Pesquisadores de outra universidade publicaram uma medição diferente, feita com metodologia própria, e chegaram a um resultado distinto para o mesmo período analisado.'
    const sources = [
        { title: 'A', url: 'https://a.example.com', domain: 'a.example.com', excerpt: wire },
        {
            title: 'B',
            url: 'https://b.example.org',
            domain: 'b.example.org',
            excerpt: wire + ' O texto segue igual ao comunicado.',
        },
        {
            title: 'C',
            url: 'https://c.example.net',
            domain: 'c.example.net',
            excerpt: independent,
        },
    ]
    const groups = groupIndependentSources(sources)
    assert.equal(groups.length, 2)
    assert.deepEqual(groups[0].members, [0, 1])
    assert.deepEqual(groups[1].members, [2])
    assert.ok(excerptSimilarity(sources[0].excerpt, sources[1].excerpt) >= REPETITION_THRESHOLD)
    assert.ok(excerptSimilarity(sources[0].excerpt, sources[2].excerpt) < REPETITION_THRESHOLD)
})

test('o contexto enviado ao modelo avisa sobre texto repetido e separa categorias', () => {
    const shared =
        'A agência estatal confirmou que o foguete foi lançado com sucesso na madrugada e que a carga entrou em órbita estável conforme o planejado pela equipe de missão.'
    const text = formatResearchForModel({
        id: '2',
        query: 'lançamento',
        createdAt: 1,
        sources: [
            { title: 'Um', url: 'https://um.example.com', domain: 'um.example.com', excerpt: shared },
            {
                title: 'Dois',
                url: 'https://dois.example.org',
                domain: 'dois.example.org',
                excerpt: shared,
            },
        ],
    })
    assert.match(text, /2 fontes coletadas, 1 texto-base distinto/)
    assert.match(text, /\[2\] repete/)
    assert.match(text, /FATOS SUSTENTADOS/)
    assert.match(text, /DIVERGÊNCIAS/)
    assert.match(text, /OPINIÕES OU INTERPRETAÇÕES/)
    assert.match(text, /EVIDÊNCIAS INSUFICIENTES/)
})
