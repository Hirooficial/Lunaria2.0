# Compilar Lunaria

## Requisitos

- Node.js 22 LTS ou superior e npm;
- Java 17 (testado com Temurin 17.0.20.1);
- Android SDK com plataforma/build-tools 36, NDK 27.1.12297006 e CMake 3.22.1;
- **8 GB de RAM e 15 GB livres em disco** para compilar. Com 2 núcleos e 1,9 GB
  de RAM (ambiente usado na última rodada) o build só termina com swap e
  `--max-workers=1`; sem isso o Gradle morre por memória.

Versões usadas na última compilação bem-sucedida:

```
Node 20.20.2 · JDK 17.0.20.1 · Gradle 9.0.0 (wrapper)
SDK 36 / build-tools 36.0.0 · NDK 27.1.12297006 · CMake 3.22.1
Expo 55 · React Native 0.83.6 · cui-llama.rn 1.11.9
```

## Instalação e validação

```bash
npm ci
npm run test:unit
npx tsc --noEmit
npx eslint app db lib --ignore-pattern db/migrations --max-warnings=0
npx expo config --type public --json
```

Esperado: 26 testes aprovados, nenhum erro de TypeScript, nenhum aviso de lint.

## APK de release

```bash
export JAVA_HOME=/caminho/para/jdk-17
export ANDROID_HOME=/caminho/para/android-sdk
CI=1 NODE_ENV=production npx expo prebuild --platform android --no-install
cd android
chmod +x gradlew
NODE_ENV=production ./gradlew :app:assembleRelease \
  -PreactNativeArchitectures=arm64-v8a \
  --max-workers=2
```

Em máquina apertada, use `--no-parallel --max-workers=1 -Pkotlin.incremental=false`;
foi assim que o build passou aqui.

Saída: `android/app/build/outputs/apk/release/app-release.apk`.

### Assinatura

O template do Expo assina o release com `debug.keystore`, que serve para testar
e **não** para distribuir. O plugin `expo-build-plugins/lunaria-signing.plugin.js`
resolve isso: se existir `android/keystore.properties`, o release passa a ser
assinado com a chave própria; se não existir, o build continua funcionando com a
chave de depuração, como antes.

Crie `android/keystore.properties` (arquivo local, **nunca** publicar):

```properties
storeFile=/caminho/absoluto/lunaria-release.jks
storePassword=...
keyAlias=lunaria
keyPassword=...
```

Para gerar uma chave nova:

```bash
keytool -genkeypair -v -keystore lunaria-release.jks -alias lunaria \
  -keyalg RSA -keysize 4096 -validity 10950
```

`android/keystore.properties` e `*.jks` já estão no `.gitignore` do projeto.
Guarde a chave e a senha fora do ZIP e fora do GitHub: sem elas não é possível
atualizar um aplicativo já instalado.

### Conferir o APK antes de instalar

```bash
$ANDROID_HOME/build-tools/36.0.0/apksigner verify --print-certs app-release.apk
$ANDROID_HOME/build-tools/36.0.0/aapt dump badging app-release.apk | head -8
```

Confirme: pacote `br.aurora.luna.lunaria.next`, versão 1.0.0, minSdk 24,
targetSdk 36 e apenas `arm64-v8a` entre as bibliotecas (é a arquitetura do A05s).

## O que não entra no backup

`node_modules`, `android/`, `.gradle`, `*.jks`, `keystore.properties`, `*.apk`,
caches e conversas privadas. O repositório guarda o código, os recursos e o
lockfile — o resto é reconstruído pelos comandos acima.

## Onde o tokenizador entra

`assets/models/llama3tokenizer.gguf` é empacotado como recurso `raw`
(`res/RT.gguf` dentro do APK) por causa da otimização/encurtamento de recursos do
release. O texto `expo-asset: .gguf is not a supported asset type` que aparece no
prebuild é um aviso do plugin de assets e **não** significa que o arquivo ficou de
fora: confira com `unzip -l app-release.apk | grep -i gguf`.
