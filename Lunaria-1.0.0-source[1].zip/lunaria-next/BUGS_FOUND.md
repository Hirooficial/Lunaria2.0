# Correções e pendências

Este arquivo lista o que foi corrigido, o que foi **verificado nesta rodada** e
o que continua pendente por falta de aparelho.

## Corrigido e verificado no código (com teste automatizado)

| Problema | Alteração | Verificação |
| --- | --- | --- |
| Acentos/emoji quebrados entre partes da resposta | Decodificação UTF-8 incremental e eventos SSE completos em `lib/engine/StreamDecoder.ts` e `lib/engine/SSEFetch.ts` | `tests/stream.test.mjs`, 5 testes, incluindo todos os cortes de byte de uma mensagem com emoji |
| Sobra de outra resposta/conversa prefixando uma resposta nova | O buffer de geração agora tem dono: `lib/engine/StreamBuffer.ts` + swipe informado por `Inference.ts`, `LocalInference.ts`, `Chat.ts` e `TTS.ts` | `tests/buffer.test.mjs`, 5 testes |
| Texto de outra conversa aparecendo na tela | `ChatTextLast.tsx` só renderiza o buffer do swipe exibido | inspeção de código + teste de `bufferBelongsToSwipe` |
| Frases prontas, eco e perda da formatação | `lib/persona/ResponseGuard.ts` preserva Markdown, links, números e emoji; remove só controles, prefixo e eco exato | `tests/persona.test.mjs`, 4 testes |
| Cópias da mesma notícia tratadas como confirmações separadas | Agrupamento por similaridade de trechos (`groupIndependentSources`) e prompt que separa fatos, divergências, opiniões e evidências insuficientes | `tests/research.test.mjs`, 2 testes novos |
| Pesquisa com leitura sem limites, URLs locais e fontes repetidas | Limites de corpo/tempo, validação de URL e redirecionamento, diversidade de domínios, links manuais | `tests/research.test.mjs` |
| Contagem de tokens sem tokenizador | Estimativa conservadora por bytes UTF-8 em `lib/engine/Tokenizer.ts` | inspeção de código |
| Voz padrão em idioma inadequado | Padrão pt-BR em `lib/state/TTS.ts` | inspeção de código |
| Chat carregado antes da preparação inicial | Inicialização coordenada em `app/index.tsx` | inspeção de código |
| Pesquisa ativa persistindo indevidamente | Só as notas são gravadas; o salvamento é explícito | `lib/state/ResearchMemory.ts`, `app/screens/ResearchScreen.tsx` |

## Verificado nesta rodada (sem aparelho)

- **Compilação arm64**: `:app:assembleRelease` terminou (`BUILD SUCCESSFUL`,
  14m32s). O erro de `Binary store`/`EOFException` da tentativa anterior **não
  reapareceu**; ele não se reproduziu com `-Pkotlin.incremental=false` e com um
  único worker. A causa real da falha anterior não pôde ser confirmada — o
  ambiente foi reiniciado antes do fim —, então o registro honesto é: não
  reproduzido agora, possível cache inconsistente.
- **Falta de espaço em disco**: durante o build o sistema ficou com 0 bytes
  livres e a tarefa `:cui-llama.rn:copyReleaseJniLibsProjectOnly` falhou com
  `No space left on device`. Era o ambiente, não o projeto; resolvido liberando
  espaço. Registrado para quem compilar com pouco disco.
- **OpenMP**: as 14 bibliotecas `librnllama*.so` arm64 do APK têm **zero**
  símbolos indefinidos `__kmpc*`/`omp_*` e só dependem de `liblog`, `libandroid`,
  `libm`, `libdl` e `libc`. O `UnsatisfiedLinkError` de `__kmpc_fork_call` da
  versão antiga não pode vir destes binários.
- **Tokenizador embutido**: `assets/models/llama3tokenizer.gguf` entra no APK
  como `res/RT.gguf` (o otimizador de recursos encurta o nome). O aviso
  `expo-asset: .gguf is not a supported asset type` é sobre o plugin de assets e
  não impede o arquivo de ser empacotado como recurso `raw`.
- **IA remota**: pedido real à AI Horde anônima, com os mesmos parâmetros do
  aplicativo, respondeu corretamente (7,8 s, fila 0, sem falha de nó).

## Pendências que exigem o aparelho

### 1. Instalação e inicialização

Não houve instalação: este ambiente não tem aparelho por USB, emulador Android
nem `/dev/kvm` (e é x86_64, enquanto o APK é arm64-v8a). Conferir no A05s:
instalação, primeira abertura, migrações do SQLite e reinício sem perder dados.

### 2. Carregamento do GGUF e inferência local

Falta importar um GGUF compatível e medir memória, tempo até o primeiro token e
tokens por segundo. O padrão conservador (contexto 4096, lote 256, 4 threads,
`ctx_shift`) foi escolhido para 6 GB de RAM, mas **não foi medido em aparelho**.
Sugestão para o A05s: modelo de 1 B a 3 B com quantização Q4_K_M; comece pelo
contexto 2048 se notar reinício do aplicativo.

### 3. Caracteres, cancelamento e repetição no uso real

Os testes cobrem o transporte e o estado, não o comportamento do modelo. Falta
observar no aparelho: acentos e emoji durante a geração local, cancelar na fila
remota, cancelar no meio da resposta local, reenviar depois de cancelar e
alternar entre duas conversas durante a geração.

### 4. Busca automática (DuckDuckGo)

No ambiente de desenvolvimento a busca automática foi bloqueada. O aplicativo
explica a indisponibilidade e aceita dois ou mais links HTTPS. Testar a busca
automática na rede do celular; se continuar bloqueada em uso normal, avaliar
outro provedor documentando limites e privacidade.

### 5. Voz, notificações e segundo plano

Faltam: ditar em pt-BR e conferir o encerramento do microfone ao sair da
conversa; ler uma resposta em voz alta; verificar a geração com o aplicativo em
segundo plano e a notificação de conclusão.

### 6. Assinatura e atualização

O APK desta entrega é assinado com a chave de release da Lunaria (fora do ZIP).
Falta confirmar no aparelho que uma segunda instalação por cima da primeira
funciona sem desinstalar.

## Critério para fechar uma pendência

Só marcar como resolvido com: reprodução, mudança aplicada, comando/teste
executado e resultado observado. Sem aparelho, modelo ou rede, a pendência
continua aberta e registrada como tal.
