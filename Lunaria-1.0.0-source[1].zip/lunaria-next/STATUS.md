# Estado da entrega — 15/09/2026 (Arena)

## Resultado desta rodada

| Item | Situação |
| --- | --- |
| APK arm64 de release | **Compilado** (`assembleRelease`, BUILD SUCCESSFUL) e assinado com chave própria da Lunaria |
| Testes automatizados | **26 de 26** passaram (19 originais + 7 novos) |
| TypeScript | `npx tsc --noEmit` sem erros |
| ESLint | `eslint app db lib` sem erros e sem avisos (`--max-warnings=0`) |
| Inspeção das bibliotecas nativas | 14 bibliotecas `librnllama*.so` arm64 sem símbolos OpenMP indefinidos; dependências apenas de sistema |
| Tokenizador dentro do APK | Confirmado: `res/RT.gguf` (7.818.140 bytes = `assets/models/llama3tokenizer.gguf`) |
| IA remota (AI Horde anônima) | Chamada real reproduzindo o pedido do aplicativo: resposta correta em 7,8 s, fila 0 |
| Instalação e uso no aparelho | **Não executados** — este ambiente não tem aparelho, emulador nem `/dev/kvm`; ver limitações |

O caminho crítico que faltava desde o checkpoint anterior foi concluído: o build
Android **termina**. O que continua pendente é a validação no Galaxy A05s, que
exige o aparelho conectado.

## O que mudou nesta rodada

Código:

- `lib/engine/StreamBuffer.ts` (novo): o buffer de geração passa a registrar
  **de qual resposta** o texto é. Um pedaço vindo de outro swipe nunca herda o
  texto anterior — antes, sobra de outra conversa podia prefixar a resposta nova.
- `lib/state/Chat.ts`, `lib/engine/Inference.ts`, `lib/engine/LocalInference.ts`:
  todas as escritas no buffer (stream local, stream remoto, regenerar, continuar)
  informam o swipe de origem; o preenchimento de “regenerar” grava o estado
  explicitamente, inclusive vazio.
- `lib/state/TTS.ts`: a leitura em voz alta também separa o texto por swipe e é
  limpa ao iniciar nova geração.
- `app/screens/ChatScreen/ChatWindow/ChatTextLast.tsx`: o buffer só é renderizado
  se pertencer ao swipe exibido.
- `lib/research/WebResearch.ts`: agrupa trechos por similaridade (shingles de 6
  palavras) e diz ao modelo quantos **textos-base distintos** existem; o prompt
  separa FATOS / DIVERGÊNCIAS / OPINIÕES / EVIDÊNCIAS INSUFICIENTES e avisa que
  cópias da mesma notícia não são confirmações independentes.
- `lib/engine/Local/LlamaLocal.ts`: padrão local conservador para aparelho de
  6 GB (lote 256 em vez de 512). Continua editável em Configurações → Modelo.
- 150 rótulos de interface herdados do ChatterUI traduzidos para português;
  telas de teste do desenvolvedor ficaram como estavam.
- `expo-build-plugins/lunaria-signing.plugin.js` (novo): assinatura de release
  com chave própria via `android/keystore.properties`, sobrevivendo a
  `expo prebuild --clean`.

Testes novos (7): 5 de propriedade do buffer de geração, 2 de independência de
fontes na pesquisa.

## Evidências do build

```
BUILD SUCCESSFUL in 14m 32s
951 actionable tasks: 877 executed, 74 up-to-date
app-release.apk — 59,3 MB
pacote br.aurora.luna.lunaria.next · versão 1.0.0 (versionCode 1)
minSdk 24 · targetSdk 36 (Android 16) · compilado com SDK 36
ABI: apenas arm64-v8a · 53 bibliotecas nativas
```

Os números acima saem do log do Gradle e do `aapt dump badging`/`apksigner` na
pasta `android/app/build/outputs/apk/release/`. O ambiente era apertado
(2 núcleos, 1,9 GB de RAM): o build precisou de swap e de `--max-workers=1`
para não morrer por falta de memória. Isso não afeta o APK gerado.

## Arquitetura e comportamento atual

- Expo 55, React Native 0.83.6, React 19.2, cui-llama.rn 1.11.9.
- Android mínimo API 24; compilação/alvo API 36; APK arm64-v8a.
- IA remota gratuita via AI Horde anônima (`0000000000`). **A API é de fila, não
  de streaming**: o texto volta completo no fim, então “tempo até o primeiro
  token” só existe de fato no modo local. O aplicativo mostra fila, geração,
  cancelamento e erro, e cancela a tarefa no servidor ao desistir.
- Modelos GGUF de conversação devem ser importados pelo usuário; o tokenizador
  vem embutido.
- Pesquisa/Fatos: trechos realmente lidos, links de origem, agrupamento de
  repetição e aviso de conteúdo externo não confiável.
- Voz depende das permissões e dos serviços de reconhecimento/TTS do Android.
- Release exige HTTPS para conexões remotas (`usesCleartextTraffic: false`).

## Próxima entrega necessária

Instalar o APK no Galaxy A05s e executar a lista de `TEST_REPORT.md`:
instalação, conversa, cancelamento e reenvio, acentos/emoji, voz, pesquisa,
memória e um GGUF local com medição de memória e tokens por segundo.
